# Party slots and Player 2's character creator

Source files used (from the user's GOG install; nothing is redistributed):

- `packages/core/data/scripts.erf` → `script.ldf`: every engine command and constant, with BioWare's doc comments.
- `packages/core/data/designerscripts.rim` → `sys_chargen.ncs`, `module_core.ncs`, `player_core.ncs`.
- `modules/single player/data/designerscripts.erf` → `sp_module.ncs`.
- `packages/core/data/chargen.rim` → `default_player.utc`, `player_core.nss` (source).
- `packages/core/data/guiexport.erf` → `portraits.gfx`, `partypicker.gfx`, `chargen.gfx`.
- `packages/core/data/2da.erf` → `partypicker.gda`, `party_picker.gda`, `chargen_preload.gda`.

Tools: Ghidra 11.4.2, xoreos-tools 0.0.6 (`ncsdis --dragonage`, `convert2da`, `gff2xml`) and JPEXS FFDec 22.0.2.

How each finding is known: **[asm]** confirmed in the disassembly, **[dec]**
read in the Ghidra decompile, **[ncs]** read in the script disassembly,
**[ldf]** from BioWare's own documentation, **[inf]** inferred, not yet confirmed.

---

## 1. Where the 4-member party limit lives

| Layer | Limit? | Details |
|---|---|---|
| Engine party list (`CCParty+0x234`, `std::vector<object id>`) | **none** | `CCParty::SetMemberState` 0x63B9A0: states 1 and 7 → `AddMember` 0x63A020, which never checks a count [dec]. |
| Script docs | "limited to 3 additional followers" | Wording in `script.ldf` for the deprecated `AddToParty`/`GetPartySize` [ldf]. Story scripts may assume ≤4 [inf]. |
| **HUD data (engine → Flash)** | **4** | The CCParty constructor sizes the GUI token arrays `Members`, `MemberSelected`, `Summons` and `SummonSelected` to 4 (`push 4` at 0x63ADDC/F0, 0x63AE04/18) [asm]. `UpdatePortraitTokens` 0x635B60 builds four local arrays of 4 (0x635B8F/A6/B8/CB), clears with `cmp esi,4` (0x635C7F) and stops at 4 members with `cmp [esp+14],4` (0x635CB7) [asm]. |
| **HUD movie** `portraits.gfx` | **4** | `Portraits.as`: four placed clips `Portrait1_mc`…`Portrait4_mc` bound to `Party.Members.0..3`, and `MAX_NUM_FOLLOWERS = 4` [AS2 decompile]. |
| Party picker (`partypicker.gfx` + `partypicker.gda` / `party_picker.gda`) | picks 3 | Rows exist only for the 10 story followers (tags `gen00fl_*`) [2da]. A creature that isn't in the table probably isn't listed; untested. |
| Keyboard | 1–4 | `SelectPartyMember1..4` input actions [strings]. Doesn't matter for controllers. |
| Follow / formation AI | none found | The other party-list loops with a 4 in them were checked: 0x631F30 loops over ability ranks and 0x709280 is a GUI fill [dec]. |

### What 0.4.0 prepares

- `partyslots.cpp`: `[Party] HudSlots=6` rewrites the 10 constants above (4 becomes 6), each
  checked against the original bytes first. It must run before a game is loaded,
  so it runs at DLL start.
- `dll/assets/portraits.gfx`: the original movie with two more placements,
  `Portrait5_mc` and `Portrait6_mc`. They reuse the Portrait4 character (id 206),
  spaced 1990 twips apart like the originals, at y 7830 and 9820. The two toggle buttons
  move down to y 11920. `Portraits.as` is patched for tokens `Party.Members.4/5`,
  observers 70000/70001, `MAX_NUM_FOLLOWERS = 6` and a visible count up to 6.
  Built with FFDec: `-swf2xml` → edit → `-xml2swf` → `-importScript`. The
  `CFX` header is kept.
  The installer copies it to `packages\core\override\DAOCoop\portraits.gfx`.
  With `HudSlots=4` the extra clips stay hidden, because the engine never fills
  `Party.Members.4/5`.
- Joining the party: `SetFollowerState(p2, 7)` (locked active) → `SetMemberState`
  case 7 → `AddMember` plus 0x637560 [dec]. The engine has no cap.

Still to test in game: whether the portraits for members 5 and 6 render and
update, how the party picker treats the extra members, and whether area
transitions and saves keep them.

---

## 2. How the character creator works

```
StartCharGen(obj, mode, import)        command 746, handler 0x66B0E0 [dec]
  mode 0 refused if paused (*(0xC32938)+0x5F4+0xC) or flags *(0xC1D0A0)+0x250/0x251
  "CharGenCreature" ← obj; chargen screen (+0xC0) ← obj; SetGameMode(11 = GM_CHARGEN)
      │
      ▼  GUI screens send engine events to the MODULE  (module_core → sys_chargen.ncs)
  44 START (mode)   → sub_1F17 initialise, CHARGEN_MODE module var                [ncs]
  46 RACE, 47 CLASS, 54 GENDER, 48 SOUNDSET (hero only), 49 NAME, 50/51 points
  55 BACKGROUND     → Chargen_SelectBackground + sub_3EE3 "Setting plot flags,
                      race/background" → SetPlot on the HERO's party plot
                      C9736A91…  ← would rewrite the Warden's ORIGIN flags        [ncs]
      │
      ▼  GUI finished: message handler 0x7FCA90 (stdcall, msg+4 creature, +8 mode, +C flag) [asm]
  mode 0 → engine starts a LOADING mode (type 7) and SetGameMode(9)               [dec]
  posts engine event 59 CHARGEN_END(mode, quickstart) to the module
      │
      ▼  sys_chargen CHARGEN_END
  mode 0 → crafting items, tactic preset, chargen plot flags,
           sub_720B → SignalEvent(module, 1027 MODULE_CHARGEN_DONE, wp, area)     [ncs]
  mode 1 → level-up finish only (SetCanLevelUp etc.)
      │
      ▼  sp_module 1027 → Campaign_ChargenDone → UT_DoAreaTransition(origin StartArea/StartWP)
         ← would teleport the party to the origin start                          [ncs strings]
```

Module events all run through `Module::RunEventScript` 0x67BFB0
(thiscall: event, script). The event type is at `Event+0x20`, and the event is deleted
by its virtual destructor with argument 1 [asm].

### What 0.4.0 does for Player 2

1. **Trigger:** Ostagar. Area tag `pre100ar_kings_camp`, checked with `GetTag(GetArea(hero))`
   once a second; the list is set in `[P2Create] TriggerAreas`. Before anything happens,
   Player 2 must press START on their controller.
2. `PreloadCharGen()`, then 1.5 s later `CreateObject(32, "default_player.utc", Location
   beside the Warden)`. The template's tag is `player` [gff], so the mod sets it to
   `SetTag(p2, "daocoop_p2")`, then calls `SetFollowerState(p2, 7)` and `StartCharGen(p2, 0)`.
3. While the session runs:
   - **Hook 0x67BFB0** drops module events **55** and **1027**. That keeps the Warden's
     origin plot flags and stops the origin teleport.
   - **Hook 0x7FCA90** passes the end message on with `mode = 1` for Player 2 only. The engine
     then skips the origin loading screen, and sys_chargen runs its level-up finish. Any other
     creature passes through untouched.
4. A watchdog switches back to `GM_EXPLORE` if the game is still in a non-play mode
   4 s after the creator closes. Player 2's controller then drives `daocoop_p2`
   (found by tag after loads and saves).

Hook stolen bytes: 0x67BFB0 `53 56 57 8B 7C 24 10` (push ebx/esi/edi; mov edi,[esp+10]) and
0x7FCA90 `6A FF 68 E6 D4 AB 00` (SEH frame push). Neither contains a relative jump [asm].

### Open questions for the first test

- Does the appearance and head-morph screen work outside the chargen stage area?
- Which background abilities are lost when event 55 is dropped? Expected: just the background's
  starting bonus.
- Does the module variable `CHARGEN_MODE` (set to 0 at START) matter later?
- The new character is level 1. The plan is to grant XP to match the Warden, then open
  `StartCharGen(p2, 1)` (level-up). Mode 1 works on any creature [dec].

---

## 3. Equipment ownership in the inventory and character screens (0.4.1)

- Every inventory change from the Flash screen ends up in a CCCreature message handler [RTTI + asm]:
  - `EquipItemMessage` → 0x6BE330
  - `UnequipItemMessage` → 0x6BC050
  - `SwitchWeaponSetNowMessage` → 0x6AB3C0
  - `DropItemMessage` 0x6A72E0 and `AcquireItemMessage` 0x6A70E0 work on the shared backpack and are not locked.
  - All are `bool __thiscall(CCCreature*, const Msg&)`, `ret 4`. The object id is at CCCreature+0x10 (0x6BBD06 / 0x53CC40) [asm].
- The screens grey out equipment with the token `SelectedChar.CanChangeEquipment` (CCCreature+0x5F4).
  The engine computes it in `UpdateGUIData` 0x6BBCB0 from a creature flag (bit 9). It is not used by the
  lock, because the token can't tell which player is acting.
- Previous/Next on the screens sends `GUI.SelectNext/PreviousCharacterMessage`. The selected tab is assumed to be
  `GetControlled()`. 0.4.1 logs it on every tab change so this can be checked [inf].
- The controller framework imports `XInputGetState` from `XINPUT9_1_0.dll` [PE imports].
  0.4.1 patches that import inside `dinput8_chain.dll` only, so on Player 2/3's tab the framework reads that
  player's pad. Player 1's LB/RB are merged in so they can still flip tabs.
- The veto: the owner of the changed character must equal the acting player. A physical mouse button
  in the last 0.4 s counts as Player 1; otherwise the actor is whoever holds the UI. Refusals show a HUD
  message and a log line.
- When the screen closes on a co-op character's tab, Player 1 gets their previous character back
  (`SetPrimaryControlled`, command 815).

---

## 4. Players 2/3 using the world; conversations stay with Player 1 (0.5.0)

How a mouse click uses something [dec/asm]:
`GameModeExplore::PerformPrimaryActionOnTargetUnderCursor` 0x7132B0 →
`GetCursorAction(obj)` 0x70CAD0 (cdecl) → `PerformAction` 0x712830.

- **Cursor actions:** 3 attack, 8 use. Type byte at object+0x14: 6 creature, 7 item, 8 trigger, 10 placeable,
  as `GetObjectType = 1 << (byte-1)`.
- **Placeable:** usable when `obj->vt[0x24]()` (placeable) has byte +0x42C set. Its default action is
  `obj->vt[0x100](0)`, which returns a short `PLACEABLE_ACTION_*`: 1 open, 3 unlock, 5 use, 7 disarm,
  10 **dialog**, 11 open inventory, 15 area transition, and so on.
- **Dead body:** `cr = obj->vt[0x10]()`, `cr->vt[0x1D0]() == 1` (dead). The loot bag id is at cr+0x790,
  and `GetPlaceable(bag)` is 0x5D5B40 (thiscall app) (0x712C20).
- **Use:** `UseObject(user, target, action)` 0x7F6550 (stdcall, `ret 0xC`). It queues command 0x1F
  (`CommandUseObject`), sends `EVENT_TYPE_PLACEABLE_ONCLICK` (78) and event 90. Action 4 (destroy) becomes an attack.
  Any party member id works as the user.
- **Containers:** `placeable_core` → `OpenInventory(OBJECT_SELF, user)` (410, 0x65FA40). This opens the
  container GUI on the one screen [ncs + dec].

Players 2/3 (A when exploring, D-pad up always): candidates are
`GetNearestObject(self, PLACEABLE|CREATURE, 16)` (433) within 4 m. Anything that resolves as above
qualifies, except action 10 (dialog) and, optionally, 15. The pick prefers what's ahead of the stick
direction. If a screen opens within 5 s, the user's controller gets it.

Where conversations start [dec]:
- Every script start (`BeginConversation` 440 → 0x65D9A0, used by `UT_Talk`, `creature_core` DIALOGUE,
  `placeable_core`) calls `GameObject::StartConversation(initiator, dlg)` 0x6976B0 (thiscall, ret 8).
  That calls `CreateConversation(owner, initiator, dlg, 0)` 0x68CEE0, then `SetGameMode(GM_DIALOG)`.
- The only other creator, 0x65DC30, has no initiator (owner/initiator -1).
- **Dialog guard:** the hook on 0x6976B0 swaps a Player 2/3 initiator for Player 1's character.

Triggers [ncs]: `pre100tr_kennel`, `lot100tr_talk_bodahn`, `gen00tr_talk` and others start scenes on
`EVENT_TYPE_ENTER` (8) when `IsFollower(GetEventCreator())`, which includes Players 2/3 when they walk ahead.
All object events pass through `GameObject::HandleEvent(Event**)` 0x698960 (thiscall, ret 4;
Event +0x20 type, +0x24 creator; the object id is at this+0x10). The script name is at this+0x26C.
- **Trigger guard:** drops ENTER/EXIT on objects of type 8 (triggers, not AoEs) created by Player 2/3,
  unless the trigger's script name contains "trap". The event is deleted with its own destructor.

---

## 5. Target markers for Players 2/3 (0.5.1)

The game's floaty layer is `floatylayer.gfx`. These are the parts the mod reuses:

- `ShowFloatyIcon(creature, name)` (749, 0x662DB0) works on creatures only (`GetCreatureByID`) [dec].
  `FloatyIcon.SetIcon` first tries a library symbol (only `Icon` and `FloatyIcon` are exported). Otherwise
  it calls `MovieUtils.LoadImage`, which appends ".dds" to names without a dot [AS2]. The texture
  resolves through the normal resource system, so the files in `packages\core\override\DAOCoop` work.
  An empty name hides the icon. Each creature has one icon slot.
- `DisplayFloatyMessage(obj, text, style, colour, seconds)` (744, 0x662180) works on any object
  (`GetObjectByID` 0x5D5BE0) [dec]. Style 0 is a plain message. It fades out, so the mod re-sends it about every 1.3 s.
- Markers: `tools/make_markers.py` writes `daocoop_p{2,3}_{target,self}.dds`, 64×64 uncompressed
  A8R8G8B8 DDS (blue P2, green P3).
  - **Enemy target:** a chevron icon, re-sent every 2 s and removed when the target changes or dies.
  - **Use preview:** "P2 (A): loot Chest" over `InteractPick`'s choice, every 0.4 s out of combat.
  - **Own tag:** "P2" over the player's own character.

---

## 6. Experience and per-player progression (0.6.0)

How the game hands out XP. `sys_reward_h` is compiled into `creature_core.ncs` [ncs]:

- **`RewardXPParty(xp)`** (sub_BF08): the target set is `GetPartyList(-1)`, every party member. For combat kills
  each member gets the full value, scaled only per member: killer 100%, others 95%, dead members 90%. Nothing
  is divided by party size, so extra party members don't lower anyone's XP, and the Warden's XP stays at
  single-player values.
- **`RewardXP(creature, xp, …)`** (sub_C797):
  - It refuses if the local int `CREATURE_REWARD_FLAGS` is set, or if `GetFollowerState(creature) == 0`. Locked-active
    co-op characters (state 7) qualify.
  - It sets `PROPERTY_SIMPLE_EXPERIENCE` (19, base) and runs the level checks against M2DA 164 ("XP" column):
    `SetCanLevelUp`, points, tutorials, and auto level-up when `GetAutoLevelUp`.
- **Stock debug script `addxp.ncs`:** it reads the amount from the module's `RUNSCRIPT_VAR`, then calls `RewardXP(OBJECT_SELF, n)`.
- **Running it on a creature from C++:** set `RUNSCRIPT_VAR` (`SetLocalString` 70). Temporarily set the command
  implementer's OBJECT_SELF (impl+0x08; read by `Event` 0x6580D0 and `HandleEvent` 0x6586D0) to the creature.
  Then call `HandleEvent(Event(0), "addxp.ncs")` (106 + 121). The script runs synchronously through
  `GameObject::RunEventScript`, and the old OBJECT_SELF is restored afterwards.

0.6.0:
- **Sync:** every 2 s in explore or combat, Player 2/3's XP is brought to the Warden's.
  - Behind: they get the difference via `addxp.ncs`, so it goes through the real level-up flow.
  - Ahead (killing-blow bonus): they're trimmed back with `SetCreatureProperty` 740, but never below `M2DA(164, "XP", level)`.
- **Auto level-up:** `SetAutoLevelUp(c, 0)` for co-op characters.
- **Level-up screen ownership:** the command implementer's vtable slot 2 (0xB00314 → 0x64DD60) is redirected to
  a wrapper. For `StartCharGen` (746) it peeks the VM stack top (tag 6 → creature id) before the handler runs.
  In `GM_CHARGEN` the equipment lock treats that creature as the shown character and routes the controller to its owner.
- **START on controller 2:** `StartCharGen(p2, 1)` when `GetCanLevelUp(p2)`. The creator flow also registers the new
  character as Player 2's and gives the creator screen to controller 2.

---

## 7. Area changes and placement (0.6.1)

- **Area changes:** `DoAreaTransition(area, waypoint)` (745) "will jump ALL party members" [ldf]. Doors, world-map travel
  and scripted moves (`UT_DoAreaTransition`) take every member of `CCParty+0x234`, including locked-active co-op
  characters. The trigger guard only drops Player 2/3's ENTER on story triggers. Area doors (placeable action 15)
  move the whole party, and are allowed for Players 2/3 by default.
- **Safe placement tools** [ldf + dec]:
  - `GetFollowerWouldBeLocation(obj)` (728, 0x666650): object → location, the formation spot behind the leader.
  - `GetSafeLocation(loc)` (659, 0x65B0D0): location → nearest walkable, unoccupied location.
  - `CommandJumpToLocation(loc)` (581, 0x670010): command type 10, teleport.
  - `IsLocationSafe` (456) exists, but would count the creature standing there.
- **0.6.1** (`regroup.cpp`):
  - **Hold LB 1.5 s:** jump to formation spot → safe location.
  - **Auto-placement:** 1.5 s after a load, cutscene, conversation or movie ends, a co-op character more than 12 m away,
    or in another area, is jumped the same way.
  - **Stuck detection:** the stick pushed, a move order accepted, not held back by the leash, and less than 1 m of
    progress. After 3 s a hint shows; after 6 s it jumps automatically.

**0.6.2 — agency first:** co-op players are never pulled toward the Warden. LB no longer switches to "follow the Warden";
only holding LB 1.5 s (the player's own choice) teleports. Automatic placement after scenes and the stuck auto-teleport
are off by default (`AutoPlaceMetres=0`, `StuckTeleportSeconds=0`). The only automatic move is rescuing a co-op character
left in another area. AI following only happens when a player switches control off with View.

## 0.7.0: Player 3, drop-in/drop-out, ability pages, ally targeting

- `coopcontrol.cpp` replaces `p2control.cpp`: one `Player` state per co-op player
  (2 and 3), same code path. A player never takes the Warden, Player 1's current
  character, or anything the other co-op player has/owns (`Taken()`).
- `coopcreate.cpp` replaces `p2create.cpp`: one creator session at a time;
  `daocoop_p2` / `daocoop_p3` tags; every joined player without a character is
  prompted while the party is in a trigger area (also a player who joins later there).
- Drop-in/out: join state per player. Disconnect or View -> AI follows, and a
  *borrowed* companion's equipment owner goes back to Player 1 (own characters
  stay owned). Unplugged pads are polled once a second (`pads.cpp`), since
  XInputGetState on an empty slot is slow.
- Ability targets: ABI_BASE (M2DA 1) `TargetType` bit mask, read in rules_core
  (sub_00035A09; tests at 0x2A431): 1 self, 2 friendly, 4 hostile, 8 dead,
  32 ground. *Read in disassembly; not yet checked in game* - the log prints
  "Ability N: TargetType T" for the first 30 casts.
- Health for "most hurt": GetCreatureProperty(c, 7 PROPERTY_DEPLETABLE_HEALTH,
  3 CURRENT / 1 TOTAL) (constants from script.ldf).
- Markers: one manager (`TargetUiFlush`) because a creature shows one floaty
  icon; priority enemy > ally > own tag, Player 2 before 3.
