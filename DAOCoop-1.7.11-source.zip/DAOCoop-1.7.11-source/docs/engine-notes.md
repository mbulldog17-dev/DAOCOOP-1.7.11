# DAOrigins.exe engine notes (GOG 1.05.13263.0)

Everything here comes from static analysis of the GOG exe (image base 0x400000,
no DRM, large-address-aware already set). Tags say how each fact is known:

- **[asm]**: confirmed in the disassembly
- **[dec]**: read in the Ghidra decompile, not checked against the assembly
- **[inf]**: inferred from the layout or naming; not yet confirmed at runtime
- **[run]**: seen working in the game (filled in as tests come back)

`dll/src/game.h` holds the addresses. `game::CheckBuild()` compares the first
bytes of each function with this exe, and the engine bridge stays off on any
other build.

---

## 1. The big shortcut: call any script command from C++

Toolset scripts (`.nss`) can do almost everything: move, attack, use
abilities, manage the party, start character creation and more. Each script
function is a numbered native "command" inside the exe. If we can call those
commands directly, we don't have to reverse every engine system one by one.

| What | Where | Notes |
|---|---|---|
| Script VM global | `*(VM**)0xC1D080` | [asm] |
| Command implementer | `*(void**)(vm+0x1968)` | vtable slot 2 = `RunCommand(id, argc)` → 0x64DD60, thiscall [asm] |
| Command table | impl+0xC, filled by `0x64DD40(id, handler, name)` | 827 commands; full list in `docs/script_commands.csv` [asm] |
| Handler ABI | `int __thiscall h(impl, id, argc)`, `ret 8` | returns 0 = ok, −638 push failed, −639 pop failed [asm] |
| Value stack | vm+0x1738, int count at +0 | `TruncateTo(depth)` = 0xA2F390 (thiscall on the stack) [asm] |

Command IDs are in the same order as the toolset's `script.ldf`.

### Push and pop (all `__thiscall` on the VM)

| Op | Push | Pop | Tag |
|---|---|---|---|
| int | 0xA2D650 `(int)` | 0xA2F3C0 `(int*)` | 3 |
| float | 0xA2D690 `(float)` | 0xA2F410 `(float*)` | 4 |
| vector | 3 × PushFloat x, y, z | 3 × PopFloat z, y, x | – |
| string | 0xA2D730 `(const GameString*)`, copied [asm] | 0xA2F4C0 `(GameString*)` [asm] | 5 |
| resource name | 0xA2D890 `(const GameString*)` [asm] | 0xA2F5F0 | 0x60 |
| object array | (not needed yet) | 0xA2F720 `({tag, holder*, owner}*)`, free with 0xA2F7C0 [asm] | 0x43 |
| engine struct | 0xA2D920 `(type, void*)` | 0xA2F650 `(type, void**)` | 0x10+type |
| object | 0xA2D980 `(uint32 id)` | 0xA2F6D0 `(uint32*)` | 6 |

Engine struct types: 1 = location, 2 = command [asm]. **Both push and pop
copy** [asm]: PopStruct returns a fresh copy via implementer vtable +0x20, and
the handlers free their own struct after pushing. Popped copies are ours to
free with implementer vtable +0x18 `DestroyStruct(type, p)` [asm].

> 0.2.0 bug found statically: it pushed strings with the *resource* push
> (tag 0x60), which `GetObjectByTag` refuses (its pop wants tag 5). Fixed in
> 0.3.0, along with leaking one location and one command per move order. Arrays use
tags 0x40–0x59. PopArray (0xA2F720) fills `{tag, holder, owner}`, and
`holder` is a fresh copy made by 0xA2D4E0 → 0xA2D260: `holder = {tag, box}`,
`box = {std::vector<uint32 object id>*, refcount*}`, the vector laid out
`{proxy, first, last, end}` [dec, 1.2.5]. Up to 1.2.4 the bridge read
`holder[0]` (the tag, 0x43) as the vector pointer, so every
GetNearestObject / GetNearestObjectByHostility call crashed (caught).

**Argument order.** Handlers pop their parameters first-to-last, so the caller
pushes the last parameter first [asm].

**GameString** is the VS2008 `std::wstring` layout, 0x1C bytes [asm, copy
ctor 0x4C2510]:

| Offset | Field |
|---|---|
| +0 | allocator proxy |
| +4 | `wchar_t buf[8]` or a pointer to the text |
| +0x14 | size |
| +0x18 | capacity (7 = inline buffer) |

**Game allocator:** `operator new` 0x413660 and `operator delete` 0x4136C0
(cdecl).

### Verified signatures

These are the argument orders as the handlers pop them [asm]:

- `Location(object oArea, vector v, float fFacing)` → location
- `CommandMoveToLocation(location l, int bRun, int bDeactivateAtEnd=0)` → command
- `AddCommand(object o, command c, int bAddToFront, int bStatic, int nOverride=-1)` → int
- `GetObjectByTag(string tag, int nth)` → object
- `GetArea(object)` → object
- `ClearAllCommands(object, int)` → int
- `SetFollowPartyLeader(object, int)`
- `StartCharGen(object oCreature, int nMode, int)`: works on **any** creature, see §4

`dll/src/script.cpp` implements this bridge with a stack-depth guard and an SEH
guard on every call. It is only called on the game's own thread: the game
runs its frames on a worker (task) thread, not on the window's thread (seen in
a crash dump, 1.2.3), so `tick.cpp` hooks the frame function `0x412EB0`
(`__fastcall(app)`, prologue `83 EC 08 56 8B F1`, called from the task
`0x413310`) and runs our tick after each frame. The old window timer is only a
fallback if that hook can't be installed; it ran on the wrong thread and was
starved during play.

---

## 2. Player controls: the full surface

The keyboard and mouse controls are routed through the message handlers of
`GameModeExplore`. Their RTTI names list every action that Player 1 can
perform [asm, RTTI]:

| P1 action | Engine handler | How P2 gets it (script command) |
|---|---|---|
| Click to move | `MoveCharacterToLocation` | `CommandMoveToLocation` 559 → `AddCommand` 533 ✅ prototype |
| Move to an object | – | `CommandMoveToObject` 560 |
| Attack | `PerformPrimaryAction*` | `CommandAttack` 566 |
| Talents and spells | `PerformAbility*` | `CommandUseAbility` 582 |
| Use, loot, open, talk | `PerformPrimaryAction*` | `CommandUseObject` 586 |
| Tab target | `SelectNextHostileTarget` | `GetNearestObjectByHostility` 127 / `GetPerceivedCreatureList` 169 |
| Hold position | `ToggleHoldParty` | `SetFollowPartyLeader` 769 / `ClearAllCommands` 538 |
| Select member | `SelectPartyMember*` | `SetPrimaryControlled` 815 (P1 only) |
| Tactical cam, zoom | `ToggleTacticalCamera`, `CameraZoom` | P1 only (shared screen) |

Other handlers:

- **Pause** is handled in `GameModeController`. It stays P1-only, or P2 gets it
  through a pause command.
- **Character selection** is handled in `CCParty`.

Rule of thumb: everything P1 does through a mouse click ends up as a
*command* in the creature's queue. Giving P2 the same commands therefore
means P2 gets the same game rules: pathing, animations, cooldowns and
combat rolls.

### Camera

- `app = *(CClientExoApp**)0xC327EC` [asm]
- `cam = *(*(app+0x114)+0x60)` is the `CameraControllerExplore` (vtable 0xB1D954, ctor 0x76F890) [dec]
- Camera position is at cam+0x70 and the focus point at cam+0x80; both are vec4 and z is up [inf]

P2's stick is mapped through `focus − position`. This is checked at runtime by
the `[Debug] Verbose=1` log lines.

### Planned P2 controller layout (next iterations)

| Input | Action |
|---|---|
| Left stick | Move (camera-relative) ✅ |
| A | Attack or use the nearest target in front (`CommandAttack` / `CommandUseObject`) |
| X / Y / B | Quickbar slots 1–3 (`CommandUseAbility` with the ability IDs from the character) |
| RB | Cycle hostile target |
| LB (hold) | Regroup with the Warden ✅ |
| View | P2 on/off ✅ |
| D-pad | Potions, or the radial later |

---

### More verified signatures (0.3.0)

| Command | Pops (in order) | Notes |
|---|---|---|
| `CommandAttack` 566 | object target, int (optional) | command type 1 [dec] |
| `CommandUseAbility` 582 | int ability, object target, vector pos, float, string | **all five always popped** [dec] |
| `CommandUseObject` 586 | object, int action | command type 0x1F [dec] |
| `GetNearestObjectByHostility` 127 | object, int bHostile, int type, int count, int bLiving, int bPerceived | returns object array [dec] |
| `GetQuickSlot` 330 | object, int slot | → ability id [dec] |
| `IsAbilityAvailable` 610 | object, int ability | [dec] |
| `GetCombatState` 526 | object | creature+0xC60 → int [dec] |
| `GetObjectType` 207 | object | `1 << (type byte − 1)` [dec] |
| `GetName` 275 | object | pushes string (tag 5) [dec] |
| `DisplayStatusMessage` 747 | string, int colour | HUD message via app+0x158 vtable +0x5C [dec] |
| `CreateObject` 306 | int type, resource, location, string script, int bActive, [int] | [dec] |
| `AddToParty` 396 | object, object | → CCParty::SetMemberState(obj, 1) [dec] |
| `StartCharGen` 746 | object, int mode, int | see §4 [dec] |

## 2b. Game state, read directly

- **Current game mode:** `ctrl = *(app+0x114)` (GameModeController, which also
  owns the camera). `mode = *(ctrl+0x74)` and the mode id is `mode+0x5C`
  [asm 0x640060]. The id numbers are assigned at registration, so 0.3.0 tells
  modes apart by vtable (Explore 0xB16374, Combat 0xB1D89C, Dialog 0xB0E3DC,
  Cutscene 0xB0E76C, GUI 0xB172A4, Dead 0xB1D734, Pregame 0xB06CE4, Loading
  0xB108D4, Movie 0xB11604, PartyPicker 0xB1D31C, CharGen 0xB173D4, FlyCam
  0xB1D60C, Fixed 0xB1D504) [RTTI] and logs the id with it.
  `StartCharGen` switches to mode **11**, so 11 = character creation [dec].
- **Paused:** `*(byte*)(*(0xC32938) + 0x5F4 + 0xC)` [asm 0x838210, used by
  TogglePause].
- **Party members:** `CCParty+0x234` is `std::vector<object id>`; first at
  +0x238 and last at +0x23C [dec GetPartyList + asm].
- **Camera:** confirmed that +0x80 = position of the followed object and +0x70 =
  the camera node's own position (vtable slot `GetPosition` returns +0x70).
  +0x100 holds the camera-to-target offset with z zeroed [dec 0x7709B0].

## 3. Party and followers

- `app+0xD0 → +0x58` is `CCParty`, and +0x234 is its member list [dec].
- `CCParty::SetMemberState` is at 0x63B9A0. State 1 or 7 adds a member, through 0x63A020 [dec].
- **No hard 4-member cap** was found in the server-side party code [dec]. The
  party *UI* (portraits, party picker) has not been checked yet, and is the
  likely place a limit of 4 lives.

Useful commands:

| Command | ID |
|---|---|
| `GetPartyList` | 504 |
| `GetPartyPoolList` | 395 |
| `AddToParty` | 396 |
| `RemoveFromParty` | 397 |
| `SetFollowerState` | 706 |
| `GetFollowerState` | 399 |
| `GetPartyLeader` | 624 |
| `SetPartyLeader` | 625 |
| `ShowPartyPickerGUI` | 794 |
| `AddNonPartyFollower` | 351 |
| `IsPartyAIEnabled` | 787 |

The toolset way to add a follower:

1. Make a UTC template with Rank = Player, and a partypicker M2DA row.
2. Hire it with `UT_HireFollower` and `ShowPartyPickerGUI`.
3. In the module event, `EVENT_TYPE_PARTYMEMBER_ADDED` → `WR_SetFollowerState(FOLLOWER_STATE_ACTIVE)`.

---

## 4. A custom character for Player 2: the route

1. **Create the creature.** Use `CreateObject` 306 with a small follower
   template that we ship in an override `.erf`: tag `daocoop_p2`, Rank = Player.
2. **Make it a party member.** Use `SetFollowerState(p2, ACTIVE)` /
   `AddToParty`, and then check that the save game keeps it.
   Templates on disk (from the user's GOG install, ERF listing):
   `chargen.rim` has `default_player.utc` plus race/origin variants
   (`default_hm_noble.utc`, `default_elf_dal_r.utc`, …). The follower
   templates are `gen00fl_<name>.utc` in `designercreatures.erf`, and their
   tags match the names.
3. **Customise it in the real character creator.** `StartCharGen(object
   oCreature, int nMode, int)` takes **any** creature [asm]. Pointed at the P2
   follower, it should open the full creator (race, class, face, name) for that
   character instead of the Warden. This is the main thing to test next.
   `PreloadCharGen` 390 comes first.
   Handler details [dec 0x66B0E0]: mode 0 = full creation, mode 1 = level-up
   (opens `GUILevelUp` for that creature, which is useful for P2 levelling too).
   Mode 0 refuses to run while the game is **paused**, or when two flags at
   `*(0xC1D0A0)+0x250/0x251` are set (their meaning is unknown). It sets the
   chargen screen's creature (+0xC0) and switches to game mode 11.
   0.3.0 can try this end-to-end behind `[Experimental] CreateP2Combo=1`.
4. **Party size.** Once P2 and P3 are followers, test going past 4 members
   with `AddToParty`. If the UI breaks, patch the portrait or picker limit.

---

## 5. Test log

| Build | Result |
|---|---|
| 0.1.2 | DLL loads on GOG, LAA active, controller framework chain OK, P2 pad read OK [run] |
| 0.2.0 | Not tested; static review found the string-push bug (GetObjectByTag would fail) |
| 0.3.0 | Move, attack, target cycling, quickbar X/Y/B, game-mode gate, party auto-pick: *pending* |

## Start menu and GUI callbacks (0.8.0)

- `startmenu2.gfx` (guiexport.erf) is the front-end start menu; `mainmenu.gfx` is the
  in-game pause menu. New Game = `fscommand("LoadModule","single player")`
  (handler 0x51B8D0, checks the movie is "startmenu2").
- The GUI callback tables are built in 0x521AF0: fscommand names -> handlers
  (map at this+4, e.g. LoadModule 0x51B8D0, SendMessage 0x51B5E0) and
  ExternalInterface names -> handlers (map at this+0x18, e.g. GetValue 0x51EC60,
  GetString 0x51EE00 = jmp GetValue, GetCurrentModuleName 0x51EE10).
- ExternalInterface handler: `void cdecl(holder, const GfxValue* args, unsigned argc)`.
  GfxValue is 12 bytes: type at +0 (4 = UTF-8 string, 5 = wide string, 1 = null),
  data at +8. Return value: `movie = *(holder+0x1C)` (0x510FA0 AddRefs and returns it),
  `movie->vtbl[0xA8/4](movie, &value)` (SetExternalInterfaceRetVal). Read in assembly.
- DAOCoop hooks GetValue (prologue `6A FF 68 B8 10 A8 00`) and answers "DAOCoop.*".
- Start menu buttons: `bu_m` symbol (exported, class SharedLibrary.PushButton),
  placed in sprite 147 `buttonCascade_m` (StartMenuButtons_mc) 34 px apart
  (Resume 20 .. Quit 292); the cascade stops on frame 43. Elements call
  `<instance name>_init` found on any parent (MovieClip.prototype.GetInitFunction).
  Font: `$TitleFont` imported from gfxfontlib; menu gold 0xCEB874.
- The Native Controller Framework touches the start menu at runtime
  (StartMenu.Back, ms_ShowContents) but does not replace the movie.
- Source of the patched class: tools/startmenu/StartMenu.as (+ coop_menu.as),
  compiled with `ffdec -importScript startmenu2.gfx out.gfx scripts`.

## 0.9.0: off-screen arrows, pause, hand-over, idle behaviour, rumble

- Off-screen arrows: every party member already gets one. CCParty::AddMember (0x637560)
  calls 0x69E490, which creates a type-5 floaty (CreateFloaty 0x63E530 -> 0x63E2B0 ->
  OffscreenIndicatorFloaty, vtable 0xB1D010) and stores its id at client creature +0xC6C.
  The movie gets FloatyLayer.UpdateOffscreenIndicatorFloatyData(id, type 0 party / 1 hostile,
  x, y). Patched floatylayer.gfx asks "DAOCoop.Floaty.<id>" and tints/labels the arrow.
  Client creature by object id: 0x5D58C0 thiscall(*0xC327EC, id).
- Pause: key bindings send message strings; pause = "UserTogglePauseMessage", handled by
  GameModeController. Sent with the GUI SendMessage fscommand handler 0x51B5E0
  (cdecl(movie, const char* "GameModeController.UserTogglePauseMessage"); the text is split at
  '.' by 0x524BE0 into a reflected object and a message).
- Party AI switch (tactics screen): IsPartyAIEnabled 0x66AC60 reads byte
  (*(clientCreature+0xC0C)) + 0x68. rules_core: a follower with AI off only runs sub_00024242
  in combat = CommandAttack(GetAttackTarget) - "keep attacking", no tactics.
- Command queue: GetCommandQueueSize = command 724.

## 1.0.0: save safety, names on markers

- Save folders: engine format "%ls%ls\Saves\%ls%d" (Characters root, character, prefix
  QuickSave_/AutoSave_/..., number). Autosave = script command DoAutoSave (513); quick save =
  "GameModeController.SaveGameMessage -1 2" (the key binding's message). savesafe.cpp waits
  for a save newer than the request on disk before copying.
- Floaty icons: FloatyLayer.SetFloatyIcon(id, name) -> FloatyIcon.SetIcon loads "<name>.dds"
  into Icon_mc. Patched: icons "daocoop_pN_*_n" get a name label (DAOCoop.Name.N, cached
  character name from targetui.cpp).

## 1.1.0: co-op characters from the start of the origin

- Origin area tags (from modules/single player/data area lists): bhn (Human Noble),
  bdn (Dwarf Noble), bdc (Dwarf Commoner), bec (City Elf), bed (Dalish), bhm (Mage;
  bhm600 = Harrowing in the Fade, solo). Ostagar = pre*.
- Lobby launch -> CoopCreateNewGame(); after 4 s of explore mode the creator opens for each
  joined player in turn (no save-before-creator on a brand-new game).
- Origin scripts may drop extra followers: every 2 s in an origin area (not solo areas) the
  co-op characters are put back with SetFollowerState(locked active). Regroup no longer
  brings a character that is out of the party into another area.

## 1.2.0: camera, scaling, own screens, conversations, P1 lock, controller order

- Camera (CameraControllerExplore): follow update 0x771250 thiscall(this, dt). +0x80 focus =
  followed creature pos (object +0x120), +0x70 position = focus + offset(+0xF0 & +0x100) +
  dir * distance (0x76EAB0), +0xC0 copy of +0x70; the view is built after it (0x76EFA0, vtable
  +0x34 with +0x70 and the angles). +0x90 == 1 tactical camera, +0x48 zoom speed.
  Hook after the original: shift both points to the players' middle, scale pos-focus (zoom).
- Screens: key bindings send "ToggleFullScreenGUIMessage <Inventory|CharacterRecord|Journal|
  Map|SpellsTalents|Skills|Tactics>", handled by GUI::DragonAgeGUISystem; sent as
  "GUI.ToggleFullScreenGUIMessage X" (fallback "GameModeController.PushGUIScreen X").
- Dialogue skill checks: gen00pt_skills.ncs (designerscripts.rim) tests GetHero(): HasAbility
  4020 + 100001..100004 (Coercion ranks), attribute 5 (Cunning) / 1 (Strength), value type 1.
  Abilities: HasAbility 252, AddAbility 253 (obj, ability, notify), RemoveAbility 254.
- Enemy scaling marker: PROPERTY_SIMPLE_AGE (18) = 1777.

## 1.2.1: no more Ostagar start

- [P2Create] OfferAtOstagar (=1 in older installs; installs never change values) is no longer
  read. OfferAnywhere=1: a joined player without an own character is offered the creator in any
  area except SoloAreas. OfferAtOstagarToo=0 brings the old trigger back if wanted.
- Awakening plan (after a real co-op save exists): copy Player 2/3's creature from the Origins
  save (.das, GFF4) - face morph included - into the Awakening game. Needs the save format of
  a follower creature studied from an actual save first.

## 1.2.6: P2 movement direction, the hero after the creator

- Camera view direction: camera node `*(cam+4)`, rotation quaternion at node+0x90
  {x,y,z,w}; forward = rotate(+Y) = (2(xy − wz), 1 − 2(x² + z²), 2(zy + xw))
  [dec 0x4CBD30, used by the follow update 0x771250]. `cam+0x70` = pivot +
  normalize(forward × up) · k: a **sideways** shoulder offset (0 when zoomed
  out), so `focus − pos` was never the view direction. P2's stick and the old
  camera "zoom" both used it (fixed / zoom disabled).
- Camera distance is lerp(cam+0x64, cam+0x68, node+0x24) [dec 0x7EE7E0] (not used yet).
- Hero: GetHero 0x660AA0 = `player = *(*(app+0xD0)+0x58)`, value of the property
  object at player+0x1F8 (+0xC), setter vtable +0x54 thiscall(prop, id). Party
  leader is the sibling at +0x1E8. After StartCharGen(creation) on Player 2's
  creature the hero was Player 2's creature (1.2.5 log: GetHero's position and
  name = P2's); 1.2.6 remembers the Warden and sets it back.
- 1.2.6 run confirmed: the hero becomes the creator's creature (restored fine), and the
  quaternion look vector is unit length and turns with the camera.

## 1.2.7
- The creator's preview/race/body follow the hero (1.2.6: preview kept a human male
  body whatever race was picked). Player 2's creature is made the hero while the
  creator is open, the Warden is put back afterwards.
- P2 movement: AddCommand(front) every 200 ms without clearing piled old move orders
  up behind the current one. Now: soft ClearAllCommands + one order 5 m ahead, renewed
  only on a >12 degree turn, walk/run change, < 2.5 m left, or after 0.8 s.

## Character creator (1.2.9)

The creator is the Flash movie chargen.gfx driving GUI::GUICharGen through
"GUICharGen.<Message>" SendMessages. The handlers (member functions found through
the MemberFunctionMessageHandler<GUICharGen, …> objects built at 0x737929…0x73a579):

| Message | Handler | What it does |
|---|---|---|
| CharGenStart | 0x736680 | module event 44 (creature) |
| CharGenSelectGender | 0x736760 | module event 54; preview refresh |
| CharGenSelectRace | 0x736860 | module event 46 (old, new); preview refresh 0x7356F0(1) |
| CharGenSelectClass | 0x7369F0 | module event 47 |
| CharGenSelectBackground | 0x736C80 | module event 55 |
| CharGenSelectAppearanceAndSoundSet | 0x736E10 | |
| CharGenSelectName | 0x736F00 | |
| CharGenResetCreature | 0x738410 | **resets the player**: 0x69E120 deletes the hero's client object, 0x69DDA0 deletes the party's and the player object, 0x69D200 makes a new player, 0x69DBB0 a new hero; then GUI+0xC0 = hero, paperdoll creature = hero (0x7B8470), "CharGenCreature" = hero |
| UpdateHeroAppearance | 0x738550 | import a hero's look (0x6D1850), preview = hero |
| CharGenEnd | 0x7FCA90 (GUICharGenBase) | mode 0: loading transition 0x5D5E90(9, …) to start the game; module event 59; then unregisters "CharGenCreature" |

- GUICharGen = GUI system `*(app+0x158)` vtable +0x60 thiscall(sys, 1). +0xC0 = the
  creature being made, +0x110 = GUIPaperdoll (the preview), paperdoll+0x58 = the client
  creature shown. "CharGenCreature" is a named-object registry entry (singleton
  0x455BF0 → 0xC325B0, set 0x456540) that the Flash side reads as CharGenCreature.*.
- sys_chargen.ncs applies race/gender/class on the event's creature (SetAppearanceType,
  SetCreatureRacialType, SetCreatureGender); IsHero gates some parts (sound set).
- Preview refresh 0x7356F0: skips when 0x7FEF20 (a flag looked up as 0x4236) is set,
  else paperdoll 0x7BC110(creature, 1, 1, n) rebuilds the preview from GUI+0xC0.
- Head morph: GUIPaperdoll CommandCreateMorph (0x7C11D0) composes a morph from the sliders,
  CommandApplyMorph (0x7C1390) stores its name in the client creature +0x96C and applies it
  to the paperdoll creature's appearance (+0x7B0).
- Client creature +0x7B4 = model live in the world: 0x7B8470 clears it in mode 11, and the
  model builder 0x6C1400(creature, appearance, a, b, force) only builds when it is set.

Why Player 2's creator went wrong (1.2.1–1.2.8): ResetCreature (sent by the movie's first
scene) reset the player and pointed the creator and preview at the (new) hero; the
preview refresh was skipped outside the new-game creator; the creature's world model
was left with +0x7B4 = 0 (T-pose). 1.2.9: ResetCreature is replaced during a co-op
session by "creator + preview use Player 2's creature" (no player reset), the preview
refresh runs without the flag check, the creator/preview target is re-checked every
tick, and Player 2's world model is rebuilt after the creator.

## Free movement (1.2.11)

Player 1's WASD / left stick outside the tactical camera (found from the controller
framework's own hook points, "movement_lateral/forward" at 0x763C58 / 0x763C73):

- GameModeExplore::Update 0x712F90 → 0x70BE60(dt) → 0x764150(dt) on the player's movement
  input object (+0 = controlled client creature, +0x10 direction, +0x20 magnitude, +0x25 changed,
  +0x30 camera heading, +0x34 move heading, +0x38 facing).
- 0x763CD0 reads the input: keys (0x763A00, actions for W/A/S/D, 0.5 when walking) or the
  analog actions 0 = AccelerateCharacterLateral, 1 = AccelerateCharacterForward (0x763C10,
  through 0x891C30 / 0x8925B0); turn-rate smoothing 0x763850.
- 0x7636A0: camera heading (0x6C21C0), move heading = input heading + camera heading, run = 1
  when the magnitude > 0.95; when anything changed (or the creature isn't moving yet) it calls
  **0x6ADCF0** thiscall(creature, float moveDeg, float faceDeg, float camDeg, uint run), ret 0x10,
  which builds a type-0x21 action (0x6A21C0) on that creature (or updates the running one).
- Headings are degrees in [0, 360): 0 = +Y, counter-clockwise, = atan2(−x, y)·57.2958 (0x4EE570).
- Stop: if creature+0xB20 (movement state of the sub-object at +0xA30) is not 0 or 3,
  0xA63800 thiscall(creature+0xA30, 3) [0x763810]. creature+0xB24 = moving freely.

P2/P3 now use the same call on their own creature instead of move-to-location orders.

## 1.2.12
- 1.2.11 test: 0x6ADCF0 on Player 2's creature returned normally but the creature never
  moved (the type-0x21 action is handled by sub-action handler 0x7A4100, table filled in
  0x7AB8D0; it only acts for the player-controlled creature, it seems). 1.2.12 tests free
  movement on first use (moved > 0.3 m in 0.7 s?) and otherwise uses move orders.
- Creator look: the sliders/presets change only the preview's own creature
  (paperdoll+0x5C property value; CommandApplyMorph 0x7C1390 reads the morph name from
  copy+0x96C and writes copy+0x7B0 +0x1E4). 1.2.10 dump: preview copy appearance has the
  slider weights and morph "ss_pc_melf_wise", the real creature has template defaults.
  1.2.12 builds the real creature's model from the preview's appearance data at CharGenEnd
  (0x6C1400(real, copy+0x7B0, 1, 0, 1)) before the GUI tears the preview down.

## 1.2.22 follow target
- COMMAND_COMMANDMOVETOOBJECT 560 (0x66F260) pops: object target, int bRun, float fMinRange, int, float fMaxRange (clamped >= min). Builds a command and pushes it.
- COMMAND_SETPOSITION 22 (0x6554B0) pops object, vector, int bJump; a non-creature (or bJump 0) just sets the position (0x695540).
- COMMAND_DESTROYOBJECT 214 (0x6599E0) pops object, int; COMMAND_SETPLOT 218 (0x659B70) pops object, int.
- Marker: designerplaceables.erf `genip_inv_target.utp` (appearance 472, Useable 0, Plot 1), created as OBJECT_TYPE_PLACEABLE 512 and tagged daocoop_follow_p2/p3 so it is reused after loading a save.
- P2/P3 chase the marker with one CommandMoveToObject; the marker is moved 5 m (run) / 3 m (walk) ahead every tick. Renewed only when the character stops for 0.4 s, walk/run changes, or a turn of more than 60 degrees. Untested whether the game re-aims at a moving target; the log lines "Pn follow:" show it.

## 1.2.23 head morph, NPC style
- 1.2.22 dump: the string at creature +0x96C is the **sound set** ("ss_pc_melf_wise" = 2da row in 2da.erf, VO files ss_pc_*), not the head morph. Appearance data +0x1C8 is HeadMorph (reader 0x748AE0 "HeadMorph"; writer 0x748E90 saves field 0x3FC8 only when it isn't "Head_Morph").
- .mor files (face.erf) are GFF V4.0, platform "PC  ", type "MORP". The creator's commit 0x803000 serializes the face with platform 'PC  ' into the player profile *(app+0x14C) field 0x4236 - i.e. a complete .mor file. The model build 0x6C0DE0 reads that blob only for the hero (+0x7D4 == 1, app+0x58 == app+0x5A).
- So Player 2's creator overwrote the Warden's face blob (1.2.22 and older). 1.2.23 snapshots the blob before Player 2's creator, takes Player 2's after it, puts the Warden's back.
- Player 2's blob is written to Documents\BioWare\Dragon Age\packages\core\override\daocoop_p<N>_<stamp>.mor; their appearance HeadMorph is set to that resref (persists in saves, loads like an NPC face; the game picks up new override files at startup).
- The preview's appearance is copied at CharGenEnd (new 0x1F0, ctor 0x74A440, operator= 0x74A610) and handed to the creature in explore with 0x6C1400(creature, app, 0, 0, 0) like COMMAND_SETCREATUREGENDER; for that one build the creature is marked hero and the profile holds Player 2's face.
- Profile field helpers: root 0x643420 thiscall(profile, out[3]); field 0xA5A8E0 thiscall(root, out[3], id); size 0x4DB2A0; byte 0x47C940(fld, i); resize 0x4DD730(fld, n); set 0x4782F0(fld, i, const uint8_t*).

## 1.2.24 HUD ability bars
- portraits.gfx (tools/portraits/Portraits.as, build.sh imports it into dll/assets/portraits.gfx with JPEXS): every 4 frames each visible portrait asks GetValue("<token>.ID") and then GetValue("DAOCoop.Bar.<id>"); the DLL (lobby.cpp Handle) answers "player|page|ab1|ab2|ab3" from a cache coopcontrol refreshes every 0.4 s (GetQuickSlot of the page's three slots), or "".
- Icons: ExternalCommands.Get2DAValue(_2DA.TABLE_ABI_BASE (1), ability, _2DA.HASH_ICON) -> image name, loaded with MovieUtils.LoadImageFixedSize ("img://<name>.dds?Width=36&Height=36"). Shown only in GM_EXPLORE / GM_COMBAT.
- The "P2 RT: X/Y/B = slots" floaty on page change is gone.

## 1.2.27 online play (from the Amalur co-op mod)
- dll/src/online/: OnlineProtocol.h (magic "DAC1"), OnlineClock.h, OnlineAudio.* (WASAPI process loopback) copied from AmalurCoop; Logger.h / Paths.h map its logger and ini onto DAOCoop.
- OnlineVideo9.cpp: Amalur's Media Foundation H.264 encoder/decoder unchanged; D3D9 side new: Present hook -> back buffer StretchRect to a 720p render target -> GetRenderTargetData one frame later -> BGRA -> NV12 (BT.601 limited) on the encoder thread. Friend: NV12 -> BGRA on the decoder thread -> sysmem surface -> UpdateSurface -> StretchRect over the back buffer.
- d3d9hook.cpp: Direct3DCreate9 import of DAOrigins.exe -> IDirect3D9 vtbl[16] CreateDevice -> device vtbl[17] Present, [16] Reset. Installed in DllMain (before the device exists).
- OnlinePlay.cpp: invite codes (IP + port + 24-bit secret, 15 chars), UPnP, STUN, LAN discovery; up to 2 friends; one encoder, packets sent to each friend; per-friend bitrate, the stream uses the lowest. No Steam (GOG build).
- vpad.cpp: friends' controllers are slots 4 and 5 (pads.cpp scans 0-5, lobby assigns them like local pads, xinputroute can hand the UI to them). Friend side: XInputRouteBlank(true) while watching so their own menu ignores their controller.
- Lobby: Mode.host starts hosting (code in the lobby lines + clipboard), Mode.join opens the join window (clipboard watched for a code; LAN game: X), Leave/Close/Mode.local stop.

## 1.2.43-1.2.51: direct movement, screen wall, rings, combat zoom, fallen Player 1

- Direct-move executor (action 0x10) 0x7A8C20 thiscall(this, param, action): steers only the
  controlled creature (creature id [obj+0x10] == 0x606F10()); call sites 0x7A8DAD and 0x7A3ADC
  (inside 0x7A3810) are redirected while it runs for Player 2/3 (directmove.cpp).
- 0x745870 (start of command 0x21) is thiscall(cmd, x, creature), not stdcall.
- World -> screen: *0xC31650 vtbl+0x24 -> +0xC0 camera, vtbl+0x4C thiscall(cam, vec4*, float* x,
  float* y, bool* onScreen), pixels of the back buffer. Player 1's feet sit at y 0.92-1.1.
- Explore camera eye = +0x70 (the view is built from it in 0x76EFA0); node+0x24 "zoom" is -1..1,
  not a distance. Combat zoom moves the eye back along the measured forward axis.
- Line of sight: command 47 (vector, vector) adds 1.8 m to both, area from OBJECT_SELF (impl +8).
- Party control switch 0x6368F0 thiscall(party, id, a, b), ret 0xC; SetPrimaryControlled (815)
  refuses dead creatures (vtbl+0x1D0). Hooked to keep a fallen Player 1 off co-op characters.
- Command type 0x0E = move to location (click-to-move), 0x0D = move to object.

## Cutscene casting (research, 1.3.x)
- .cut = GFF V4 "CUT ". Actor list field 5200: name (2), type 5201 (0 master, 2 camera, 3 PLAYER,
  4-6 HENCHMAN 1-3, ...), binding name 5216, tracks 5206 (curves in the matching .cub); 5017 = stage.
- 2574 cutscenes in the campaign: 1244 have all three generic "HENCHMAN n" actors, 118 have one or
  two, 1212 none; 1064 also cast named companions ("HENCH:gen00fl_alistair" etc.).
- Binding: actor init 0x7E36B0 -> 0x7CD0A0 thiscall(actor, name, index) -> 0x7F2D80. "PLAYER" =
  the player; "HENCH:<tag>" = party member with that tag (party list from index 1); "HENCHMAN n" =
  party list entry [counter] where the counter (cutscene +0x17C) is bumped until the member isn't
  already cast (0x8663A0 = contains). Party list = party +0x234 (game::PartyMembers), index 0 = Warden.
  So generic slots go to the first followers in party order - AI companions before Players 2/3.
- 0x7D7E00 sorts the "HENCHMAN " actors by number. Cutscene +0x1CC/+0x1D0 = actor vector.
- Ambient animation patterns: ambient_anim_patterns.gda (59 rows: listener_passive_1/2,
  arms_crossed, hands_behind_back, guard_attention, idle_chatter, praying, crouch, ...).
  Single animations: COMMAND_COMMANDPLAYANIMATION 569; cutscenes: LOADCUTSCENE 647 / PLAYCUTSCENE 648.
