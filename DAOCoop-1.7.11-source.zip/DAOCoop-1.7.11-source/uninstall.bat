@echo off
rem Takes the mod out of the game and puts back anything it replaced.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install-DAOCoop.ps1" -Uninstall %*
echo.
pause
