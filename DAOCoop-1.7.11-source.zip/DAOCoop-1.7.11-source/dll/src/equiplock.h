#pragma once
// Who may change whose equipment in the inventory / character screens.
//
//   Player 2's character  -> only Player 2 (their controller drives the UI on that tab)
//   Player 3's character  -> only Player 3
//   Warden + AI followers -> only Player 1
//
// Everyone may still cycle the character tabs. Two layers:
//  1. Controller hand-off: while the selected tab belongs to Player 2/3, the
//     controller framework reads that player's pad (Player 1's LB/RB still
//     pass through to cycle tabs), see xinputroute.h.
//  2. Engine veto: hooks on CCCreature's EquipItem (0x6BE330), UnequipItem
//     (0x6BC050) and SwitchWeaponSetNow (0x6AB3C0) message handlers refuse a
//     change when the player who caused it does not own that character. A
//     mouse click in the last 0.4 s counts as Player 1.
//  3. Hand-over: in any full-screen menu (a store, the inventory, a loot window)
//     the hand-over button passes the screen to the next player who is
//     playing: RS click on the controller that holds it, or Player 1's own
//     controller / keyboard key at any time.
#include <cstdint>
#include <windows.h>

struct EquipLockSettings {
    bool enabled;
    int  padP2, padP3;          // XInput slots of Player 2 / 3 (from [Controllers])
    WORD passThrough;           // Player 1 buttons still sent while P2/P3 hold the UI
    WORD handOverButton;        // passes an open screen to the next player (0 = off)
    int  handOverKey;           // Player 1's keyboard key for the same (virtual key, 0 = none)
    bool blockPlayer1;          // Player 1 can't select Player 2's/3's character
    bool passConversations;     // RS passes conversation choices on (with the holder's skill checks)
};

void EquipLockInit(const EquipLockSettings& s);
void EquipLockSetOwner(int player, uint32_t creature);   // player 2 or 3
void EquipLockTick(unsigned nowMs);                      // main thread

// Shared co-op ownership helpers (used by interact.cpp too).
int      CoopOwnerOf(uint32_t creature);     // 1, 2 or 3
uint32_t CoopCharacterOf(int player);         // Player 2/3's character, or 0xFFFFFFFF
uint32_t CoopPlayer1Character();             // Player 1's own character (for conversations)
// Player `player` just used something that may open a screen (loot window):
// if a full-screen GUI opens within a few seconds, their controller gets it.
void     CoopNoteScreenOpener(int player);
// Controller slots changed (lobby assignment).
void EquipLockSetPads(int padP2, int padP3);
// The mod selects a co-op character itself for `ms` (to open that player's screen).
void EquipLockAllowControl(unsigned ms);
// 1.7.0: who a full-screen GUI that's open now belongs to (2/3 = a co-op player opened it), 0 = none / Player 1.
int  EquipLockGuiOwner();
