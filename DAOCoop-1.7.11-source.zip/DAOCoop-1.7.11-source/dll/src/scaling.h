#pragma once
// Tougher enemies for a bigger party: every extra player adds `perPlayer`
// (default 25%) to hostile creatures - health, and the part of Strength,
// Dexterity and Magic above 10 (what drives their damage and accuracy).
// Each creature is scaled once; it is marked through its unused Age property
// (PROPERTY_SIMPLE_AGE 18 = 1777), which is saved with the game, so loading a
// save never scales it twice.
#include <cstdint>

struct ScalingSettings {
    bool  enabled;
    float perPlayer;     // 0.25 = +25% per player after the first
    bool  attributes;    // also raise STR/DEX/MAG (damage), not only health
};

void ScalingInit(const ScalingSettings& s);
void ScalingTick(unsigned now, uint32_t hero, int creatureType, int players);   // playable modes only
// 1.7.8: the co-op menu's Game tab: percent per extra player (0 = off), kept in DAOCoop.ini
void ScalingSetPercent(int pct);
int  ScalingPercent();
