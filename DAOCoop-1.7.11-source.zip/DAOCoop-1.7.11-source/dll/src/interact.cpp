#include "interact.h"
#include "equiplock.h"
#include "hooks.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <windows.h>
#include <cmath>
#include <cwchar>

static InteractSettings g_s;

// PLACEABLE_ACTION_* (script.ldf)
enum { PA_OPEN = 1, PA_CLOSE, PA_UNLOCK, PA_DESTROY, PA_USE, PA_EXAMINE, PA_DISARM, PA_FLIP_COVER,
       PA_USE_COVER, PA_DIALOG, PA_OPEN_INVENTORY, PA_TRIGGER_TRAP, PA_TOPPLE, PA_LEAVE_COVER,
       PA_AREA_TRANSITION, PA_TURN_LEFT, PA_TURN_RIGHT };

static const wchar_t* ActionName(int a)
{
    switch (a) {
    case PA_OPEN: return L"open"; case PA_CLOSE: return L"close"; case PA_UNLOCK: return L"unlock";
    case PA_DESTROY: return L"bash"; case PA_USE: return L"use"; case PA_EXAMINE: return L"examine";
    case PA_DISARM: return L"disarm"; case PA_OPEN_INVENTORY: return L"loot";
    case PA_TRIGGER_TRAP: return L"trigger"; case PA_TOPPLE: return L"topple";
    case PA_AREA_TRANSITION: return L"go through"; case PA_TURN_LEFT: case PA_TURN_RIGHT: return L"turn";
    default: return L"use";
    }
}

// ---------------------------------------------------------------------------
// Engine access (all thiscall/cdecl as found; guarded)
// ---------------------------------------------------------------------------
typedef char* (__thiscall* GetObj_t)(void* app, uint32_t id);
typedef char* (__thiscall* VCall0_t)(void* self);
typedef short (__thiscall* VAction_t)(void* self, int which);
typedef void  (__stdcall* UseObject_t)(uint32_t user, uint32_t target, uint32_t action);

static void* App() { return *reinterpret_cast<void**>(game::kAppPtr); }
static void* VFunc(void* obj, uint32_t off) { return (*reinterpret_cast<void***>(obj))[off / 4]; }

// The object a player would use when "using" `id`, and how.
// type byte at object+0x14: 6 creature, 7 item, 8 trigger, 10 placeable.
static bool ResolveRaw(uint32_t id, uint32_t* useId, int* action)
{
    void* app = App();
    if (!app) return false;
    char* obj = reinterpret_cast<GetObj_t>(0x5D5BE0)(app, id);
    if (!obj) return false;
    uint8_t type = static_cast<uint8_t>(obj[0x14]);
    if (type == 6) {
        // Dead body with loot -> its loot bag (as 0x712C20 does).
        char* cr = reinterpret_cast<VCall0_t>(VFunc(obj, 0x10))(obj);
        if (!cr) return false;
        if (!reinterpret_cast<VCall0_t>(VFunc(cr, 0x1D0))(cr)) return false;   // alive: talking/attacking, not ours
        uint32_t bag = *reinterpret_cast<uint32_t*>(cr + 0x790);
        if (bag == 0xFFFFFFFF) return false;
        char* b = reinterpret_cast<GetObj_t>(0x5D5B40)(app, bag);
        if (!b) return false;
        short a = reinterpret_cast<VAction_t>(VFunc(b, 0x100))(b, 0);
        if (a == 0) return false;
        *useId = bag; *action = a;
        return true;
    }
    if (type == 10) {
        char* pl = reinterpret_cast<VCall0_t>(VFunc(obj, 0x24))(obj);
        if (!pl || !pl[0x42C]) return false;                               // not interactive
        short a = reinterpret_cast<VAction_t>(VFunc(obj, 0x100))(obj, 0);
        if (a == 0) return false;
        *useId = id; *action = a;
        return true;
    }
    return false;
}

static bool Resolve(uint32_t id, uint32_t* useId, int* action)
{
#ifdef _MSC_VER
    __try { return ResolveRaw(id, useId, action); }
    __except (EXCEPTION_EXECUTE_HANDLER) { Log("Interact: crash resolving 0x%08X - caught", id); return false; }
#else
    return ResolveRaw(id, useId, action);
#endif
}

static bool UseRaw(uint32_t user, uint32_t target, int action)
{
    reinterpret_cast<UseObject_t>(0x7F6550)(user, target, (uint32_t)(action & 0xFFFF));
    return true;
}

static bool Use(uint32_t user, uint32_t target, int action)
{
#ifdef _MSC_VER
    __try { return UseRaw(user, target, action); }
    __except (EXCEPTION_EXECUTE_HANDLER) { Log("Interact: crash using 0x%08X - caught", target); return false; }
#else
    return UseRaw(user, target, action);
#endif
}

// ---------------------------------------------------------------------------
// Guard 1: conversations stay with Player 1
// ---------------------------------------------------------------------------
// bool __thiscall GameObject::StartConversation(object initiator, const GameString* dlg)   ret 8
typedef char (__thiscall* StartConv_t)(void* self, uint32_t initiator, void* dlg);
static StartConv_t g_origStartConv = nullptr;

static char __fastcall HookStartConv(void* self, void*, uint32_t initiator, void* dlg)
{
    int owner = CoopOwnerOf(initiator);
    if (owner >= 2) {
        uint32_t p1 = CoopPlayer1Character();
        Log("Dialog guard: a conversation tried to start with Player %d (0x%08X); Player 1 (0x%08X) takes it",
            owner, initiator, p1);
        script::DisplayStatusMessage(L"Conversations go to Player 1", 0x66CCFF);
        initiator = p1;
    }
    return g_origStartConv(self, initiator, dlg);
}

// ---------------------------------------------------------------------------
// Guard 2: Player 2/3 don't set off talk/cutscene triggers
// ---------------------------------------------------------------------------
// void __thiscall GameObject::HandleEvent(Event** ev)   ret 4. Event: +0x20 type, +0x24 creator.
typedef void (__thiscall* HandleEvent_t)(void* self, int** ev);
static HandleEvent_t g_origHandleEvent = nullptr;

static bool ScriptIsTrap(char* self)
{
    // GameString event script at +0x26C (VS2008 wstring: buf/ptr +4, size +0x14, cap +0x18)
    char* gs = self + 0x26C;
    uint32_t size = *reinterpret_cast<uint32_t*>(gs + 0x14);
    uint32_t cap = *reinterpret_cast<uint32_t*>(gs + 0x18);
    const wchar_t* text = cap >= 8 ? *reinterpret_cast<wchar_t**>(gs + 4) : reinterpret_cast<wchar_t*>(gs + 4);
    if (!text || size > 64) return false;
    wchar_t buf[65];
    for (uint32_t i = 0; i < size; ++i) buf[i] = towlower(text[i]);
    buf[size] = 0;
    return wcsstr(buf, L"trap") != nullptr;
}

static bool DropTriggerEventRaw(char* self, int* ev)
{
    int type = ev[8];
    if (type != 8 && type != 9) return false;                          // ENTER / EXIT
    uint32_t creator = static_cast<uint32_t>(ev[9]);
    int owner = CoopOwnerOf(creator);
    if (owner < 2) return false;
    uint32_t selfId = *reinterpret_cast<uint32_t*>(self + 0x10);
    void* app = App();
    char* obj = app ? reinterpret_cast<GetObj_t>(0x5D5840)(app, selfId) : nullptr;
    if (!obj || static_cast<uint8_t>(obj[0x14]) != 8) return false;    // triggers only (not AoEs)
    if (ScriptIsTrap(self)) return false;                               // traps still go off
    return true;
}

static void __fastcall HookHandleEvent(void* self, void*, int** pev)
{
    if (g_s.triggerGuard && pev && *pev) {
        bool drop = false;
#ifdef _MSC_VER
        __try { drop = DropTriggerEventRaw(static_cast<char*>(self), *pev); }
        __except (EXCEPTION_EXECUTE_HANDLER) { drop = false; }
#else
        drop = DropTriggerEventRaw(static_cast<char*>(self), *pev);
#endif
        if (drop) {
            static int logged = 0;
            if (++logged <= 40) Log("Trigger guard: Player %d %s trigger 0x%08X - ignored (Player 1 sets off story triggers)",
                CoopOwnerOf((uint32_t)(*pev)[9]), (*pev)[8] == 8 ? "entered" : "left",
                *reinterpret_cast<uint32_t*>(static_cast<char*>(self) + 0x10));
            typedef void (__thiscall* Dtor_t)(void*, int);
            (*reinterpret_cast<Dtor_t*>(*reinterpret_cast<void**>(*pev)))(*pev, 1);
            *pev = nullptr;
            return;
        }
    }
    g_origHandleEvent(self, pev);
}

void InteractInit(const InteractSettings& s)
{
    g_s = s;
    if (s.dialogGuard) {
        static const uint8_t k[] = { 0x6A, 0xFF, 0x68, 0x48, 0x01, 0xAA, 0x00 };
        g_origStartConv = reinterpret_cast<StartConv_t>(HookInstall(0x6976B0, reinterpret_cast<void*>(&HookStartConv), 7, k, "dialog guard"));
    }
    if (s.triggerGuard) {
        static const uint8_t k[] = { 0x6A, 0xFF, 0x68, 0xC8, 0xA2, 0xA7, 0x00 };
        g_origHandleEvent = reinterpret_cast<HandleEvent_t>(HookInstall(0x698960, reinterpret_cast<void*>(&HookHandleEvent), 7, k, "trigger guard"));
        if (!g_origHandleEvent) g_s.triggerGuard = false;
    }
    Log("Interact: %s, range %.1f m, area doors %s, dialog guard %s, trigger guard %s",
        s.enabled ? "on" : "off", s.range, s.allowTransitions ? "allowed" : "Player 1 only",
        g_origStartConv ? "on" : "off", g_s.triggerGuard ? "on" : "off");
}

// ---------------------------------------------------------------------------

// 1.7.1: the loot window of a container within reach, for the party (Player 1's character, as when Player 1
// opens it; the loot goes to the shared party inventory). False: too far (then walked to and used as before).
static bool OpenLootNow(int player, uint32_t me, uint32_t container)
{
    const float d = script::GetDistance(me, container);
    if (d < 0.f || d > 3.5f) return false;
    uint32_t p1 = CoopPlayer1Character();
    if (p1 == game::kInvalidObject) p1 = me;
    const bool ok = script::OpenInventory(container, p1);
    Log("Interact: Player %d opens the loot window of 0x%08X (%.1f m) for 0x%08X: %s", player, container, d, p1, ok ? "ok" : "FAILED");
    return ok;
}

struct Pick { uint32_t obj, use; int action; };

static bool PickBest(uint32_t me, float dirX, float dirY, Pick* out)
{
    if (!g_s.enabled || me == game::kInvalidObject) return false;
    // Nearest placeables and creatures (bodies) around the player.
    uint32_t list[16];
    int n = script::GetNearestObjects(me, 512 | 32, list, 16, false, false);   // OBJECT_TYPE_PLACEABLE | CREATURE
    if (n <= 0) return false;

    script::Vec3 mp;
    if (!script::GetPosition(me, &mp)) return false;
    float dlen = std::sqrt(dirX * dirX + dirY * dirY);
    if (dlen > 0.01f) { dirX /= dlen; dirY /= dlen; }

    bool found = false;
    float bestScore = 1e9f;
    for (int i = 0; i < n; ++i) {
        uint32_t id = list[i];
        float d = script::GetDistance(me, id);
        if (d < 0 || d > g_s.range) continue;
        uint32_t useId; int action;
        if (!Resolve(id, &useId, &action)) continue;
        if (action == PA_DIALOG) continue;                                   // conversations: Player 1
        if (action == PA_AREA_TRANSITION && !g_s.allowTransitions) continue;
        float score = d;
        if (dlen > 0.01f) {
            script::Vec3 op;
            if (script::GetPosition(id, &op)) {
                float ox = op.x - mp.x, oy = op.y - mp.y, ol = std::sqrt(ox * ox + oy * oy);
                if (ol > 0.01f) score -= 1.5f * (ox * dirX + oy * dirY) / ol;  // prefer what's ahead
            }
        }
        if (score < bestScore) { bestScore = score; out->obj = id; out->use = useId; out->action = action; found = true; }
    }
    return found;
}

bool InteractPick(uint32_t me, float dirX, float dirY, uint32_t* object, const wchar_t** verb, wchar_t* name, int nameCap)
{
    Pick p;
    if (!PickBest(me, dirX, dirY, &p)) return false;
    *object = p.obj;
    *verb = ActionName(p.action);
    if (!script::GetName(p.obj, name, nameCap) || !name[0]) wcscpy(name, L"that");
    return true;
}

bool InteractUse(int player, uint32_t me, float dirX, float dirY)
{
    Pick p;
    if (!PickBest(me, dirX, dirY, &p)) return false;
    wchar_t name[64];
    if (!script::GetName(p.obj, name, 64) || !name[0]) wcscpy(name, L"that");
    wchar_t text[128];
    swprintf(text, 128, L"Player %d: %ls %ls", player, ActionName(p.action), name);
    script::DisplayStatusMessage(text, 0x66CCFF);
    Log("Interact: Player %d (0x%08X) -> %ls 0x%08X (via 0x%08X, action %d)", player, me, name, p.obj, p.use, p.action);

    script::ClearAllCommands(me, true);
    script::SetFollowPartyLeader(me, false);
    CoopNoteScreenOpener(player);
    // 1.7.1: a chest or body to loot, close by: its loot window opened straight away. Player 2/3's queued "use"
    // never got to opening it (it opened only when Player 1 used the chest too).
    if (p.action == PA_OPEN_INVENTORY && OpenLootNow(player, me, p.use)) return true;
    return Use(me, p.use, p.action);
}

void InteractScan(uint32_t me)
{
    uint32_t list[64];
    int n = script::GetNearestObjects(me, 512 | 32, list, 64, false, false);
    int shown = 0;
    Log("Interact scan around 0x%08X: %d objects, the usable ones:", me, n);
    for (int i = 0; i < n && shown < 24; ++i) {
        uint32_t useId = 0; int action = -1;
        if (!Resolve(list[i], &useId, &action)) continue;
        wchar_t name[64] = L"";
        script::GetName(list[i], name, 64);
        script::Vec3 p = {};
        script::GetPosition(list[i], &p);
        Log("  0x%08X \"%ls\" %.1f m at %.1f %.1f, action %d (%ls)", list[i], name, script::GetDistance(me, list[i]),
            p.x, p.y, action, ActionName(action));
        ++shown;
    }
}

bool InteractUseId(int player, uint32_t me, uint32_t object)
{
    uint32_t useId = 0; int action = -1;
    if (!Resolve(object, &useId, &action)) { Log("Interact: 0x%08X can't be used now", object); return false; }
    wchar_t name[64];
    if (!script::GetName(object, name, 64) || !name[0]) wcscpy(name, L"that");
    Log("Interact: Player %d (0x%08X) -> %ls 0x%08X (via 0x%08X, action %d) [test pad]", player, me, name, object, useId, action);
    script::ClearAllCommands(me, true);
    script::SetFollowPartyLeader(me, false);
    CoopNoteScreenOpener(player);
    if (action == PA_OPEN_INVENTORY && OpenLootNow(player, me, useId)) return true;
    return Use(me, useId, action);
}
