#pragma once
// Online play (Players 2 and 3 over the internet; from the Amalur co-op mod): the wire format, and the parts of the stream that need no
// Windows API (so they are tested on their own, see DevNotes tests/online_protocol_test.cpp):
//   - UDP packets (little-endian, packed, one header for all);
//   - join codes (the host's address, port and a secret, as 15 letters/digits);
//   - video: an encoded frame -> numbered packets plus XOR parity packets (one lost packet in a group
//     is rebuilt with no wait), back into whole frames in order, with resend requests for what is
//     still missing and "wait for a keyframe" once a frame is lost for good;
//   - audio: IMA ADPCM (4 bits a sample) in 10 ms packets, and a small jitter buffer.
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <utility>
#include <vector>
#include "RsCode.h"

namespace OnlineProtocol
{
    constexpr uint32_t kMagic = 0x31434144u;   // "DAC1" (DAOCoop; Amalur used "AMC1")
    constexpr uint8_t kVersion = 3;   // 1.7.1: 3 - Reed-Solomon recovery packets (older versions can't connect)
    constexpr uint16_t kDefaultPort = 27615;
    constexpr size_t kMaxDatagram = 1200;      // under the usual internet MTU, VPN overhead included

    enum Type : uint8_t
    {
        kHello = 1,     // friend -> host: join (with the code's secret)
        kWelcome,       // host -> friend: accepted (stream size, whether the Player 2 slot is free)
        kRefuse,        // host -> friend: not accepted (reason)
        kClaim,         // friend -> host: take the Player 2 slot
        kClaimed,       // host -> friend: the slot is yours
        kPing,          // either way, twice a second
        kPong,
        kInput,         // friend -> host: the friend's controller, as controller 2
        kVideo,         // host -> friend
        kNack,          // friend -> host: resend these packets of a frame
        kKeyRequest,    // friend -> host: send a keyframe (a frame was lost)
        kAudio,         // host -> friend
        kBye,           // either way: leaving
        kDiscover,      // friend -> LAN broadcast: any games here?
        kOffer,         // host -> friend: this game (LAN)
        kStats,         // friend -> host: how the stream arrives (once a second)
        kRelease,       // friend -> host: give the Player 2 slot back (still watching)
        kPunch,         // host -> accepted player (public list): opens the way through both routers; ignored
        kLobbyText,     // host -> friend (1.4.6): the co-op lobby as text while the host is in it (slot + lines)
        kVoice,         // 1.7.2 voice chat: friend -> host (the host plays it and passes it on), host -> friend
        kChat           // 1.7.8 text chat: the same way as kVoice (sent 3 times; kept apart by sender + id)
    };

#pragma pack(push, 1)
    struct Header { uint32_t magic; uint8_t type; uint8_t version; uint16_t size; uint32_t session; };
    struct HelloMsg { Header h; uint32_t token; uint32_t clientId; char name[32]; };   // clientId: the same friend from a new address
    struct WelcomeMsg { Header h; uint16_t width, height; uint8_t fps; uint8_t slotTaken; char name[32]; uint32_t hostMs; };
    struct RefuseMsg { Header h; char reason[96]; };
    struct EmptyMsg { Header h; };
    struct PingMsg { Header h; uint32_t sentMs; uint32_t echoMs; uint32_t rttMs; };
    struct InputMsg { Header h; uint32_t seq; uint16_t buttons; uint8_t lt, rt; int16_t lx, ly, rx, ry; };
    struct VideoHeader
    {
        Header h;
        uint32_t frame;        // counts up by one per frame
        uint32_t frameSize;    // encoded bytes of the whole frame
        uint32_t captureMs;    // host clock, when the picture was taken
        uint16_t index;        // data packet 0..count-1, or kParity | group number
        uint16_t count;        // data packets in the frame
        uint16_t width, height;
        uint8_t flags;         // kVideoKey
        uint8_t group;         // data packets per parity packet (0: none)
    };
    struct NackHeader { Header h; uint32_t frame; uint16_t n; /* uint16_t index[n] */ };
    struct KeyRequestMsg { Header h; uint32_t expected; };
    struct AudioHeader
    {
        Header h;
        uint32_t seq;
        uint16_t frames;       // samples per channel in this packet
        uint8_t channels;      // 2
        uint8_t codec;         // kAudioAdpcm / kAudioPcm16
        int16_t predictor[2];  // ADPCM state at the start of the packet (each packet decodes on its own)
        uint8_t stepIndex[2];
    };
    struct ByeMsg { Header h; char reason[64]; };
    // 1.7.2 voice chat: 20 ms of 16 kHz mono speech, IMA ADPCM (decodes on its own, like AudioHeader).
    // speaker: who talks - 1 the host, 2/3 the friend playing Player 2/3, 4+ a friend without a player yet;
    // a friend sends 0 (the host fills it in before passing it on). seq counts the speaker's packets.
    struct VoiceHeader
    {
        Header h;
        uint32_t seq;
        uint8_t speaker;
        uint8_t level;         // how loud (0-255), for the "talking" mark
        uint16_t samples;
        int16_t predictor;
        uint8_t stepIndex;
        uint8_t reserved;
    };
    // slot: the Player number (2/3) this friend's controller has in the host's lobby, 0 none; text: UTF-8
    // lines separated by '|', each starting with the colour letter ('H' 'W' 'R' 'X').
    struct LobbyTextMsg { Header h; uint8_t slot; uint8_t ready; uint8_t reserved[2]; char text[760]; };
    struct DiscoverMsg { Header h; uint32_t nonce; };
    struct OfferMsg { Header h; uint32_t nonce; uint32_t token; uint16_t port; uint8_t slotTaken; uint8_t busy; char name[32]; };
    struct StatsMsg
    {
        Header h;
        uint32_t packets, recovered, resendAsked, duplicates;
        uint32_t framesShown, framesLost, keyAsks;
        uint16_t decodeUs100;  // average decode time, 0.1 ms
        uint16_t latencyMs;    // picture taken on the host -> on the friend's screen (estimate)
        uint16_t audioMs;      // audio buffered on the friend's side
        uint16_t reserved;
    };
    // 1.7.8 text chat. from: 1 the host, 2/3 Player 2/3, 4+ a friend without a player; a friend sends 0 and the
    // host fills it (and the name) in before passing it on. text: UTF-8.
    struct ChatMsg { Header h; uint32_t id; uint8_t from; uint8_t reserved[3]; char name[32]; char text[200]; };
#pragma pack(pop)

    constexpr uint16_t kParity = 0x8000;
    constexpr uint8_t kVideoKey = 1;
    // 1.7.1: recovery packets are Reed-Solomon (RsCode.h): a frame's data packets are dealt into `group` blocks
    // (packet i in block i % group, so a run of losses in a row is spread over the blocks), and each block of k packets
    // gets about ParityPercent % recovery packets; any k of a block's packets rebuild all of it.
    // A recovery packet's index: kParity | block << 8 | j.
    constexpr uint8_t kVideoRs = 4;
    constexpr int kRsBlockMax = 64;          // data packets per block at most
    constexpr uint8_t kAudioPcm16 = 0, kAudioAdpcm = 1;
    constexpr size_t kVideoPayload = kMaxDatagram - sizeof(VideoHeader);

    template <typename T> inline void Fill(T& msg, uint8_t type, uint32_t session, size_t size = sizeof(T))
    {
        msg.h.magic = kMagic;
        msg.h.type = type;
        msg.h.version = kVersion;
        msg.h.size = static_cast<uint16_t>(size);
        msg.h.session = session;
    }
    inline void FillHeader(Header& h, uint8_t type, uint32_t session, size_t size)
    {
        h.magic = kMagic; h.type = type; h.version = kVersion; h.size = static_cast<uint16_t>(size); h.session = session;
    }
    // The header of a datagram, or nullptr when it is not ours (wrong magic / version / length).
    inline const Header* Check(const void* data, size_t n)
    {
        if (n < sizeof(Header) || n > 65535) return nullptr;
        const Header* h = static_cast<const Header*>(data);
        if (h->magic != kMagic || h->version != kVersion || h->size != n) return nullptr;
        return h;
    }
    // Packets of a fixed layout must be at least that long.
    template <typename T> inline const T* As(const void* data, size_t n)
    {
        return n >= sizeof(T) ? static_cast<const T*>(data) : nullptr;
    }
    inline void CopyName(char* dst, size_t cap, const std::string& s)
    {
        std::memset(dst, 0, cap);
        std::memcpy(dst, s.data(), std::min(cap - 1, s.size()));
    }
    inline std::string ReadName(const char* src, size_t cap)
    {
        size_t n = 0;
        while (n < cap && src[n]) ++n;
        std::string s(src, n);
        for (char& c : s) if (static_cast<unsigned char>(c) < 32) c = ' ';
        return s;
    }

    // ---- Join code: IPv4 + port + 24-bit secret (9 bytes) and a 3-bit check, as 15 base-32 digits ----
    // "0123456789ABCDEFGHJKMNPQRSTVWXYZ" (no I, L, O, U: typed I/L read as 1, O as 0), shown as XXXXX-XXXXX-XXXXX.
    inline unsigned JoinCodeCheck(const uint8_t* b)
    {
        uint32_t h = 2166136261u;   // FNV-1a: a typed digit changed is caught 7 times in 8
        for (int i = 0; i < 9; ++i) { h ^= b[i]; h *= 16777619u; }
        return h >> 29;
    }
    inline std::string MakeJoinCode(uint32_t ip, uint16_t port, uint32_t token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        const uint8_t b[9] = { static_cast<uint8_t>(ip >> 24), static_cast<uint8_t>(ip >> 16), static_cast<uint8_t>(ip >> 8),
            static_cast<uint8_t>(ip), static_cast<uint8_t>(port >> 8), static_cast<uint8_t>(port),
            static_cast<uint8_t>(token >> 16), static_cast<uint8_t>(token >> 8), static_cast<uint8_t>(token) };
        const unsigned check = JoinCodeCheck(b);
        std::string out;
        int bit = -3;   // 75 bits: the 3 check bits, then the 72 data bits
        for (int d = 0; d < 15; ++d)
        {
            unsigned v = 0;
            for (int k = 0; k < 5; ++k, ++bit)
            {
                const unsigned x = bit < 0 ? (check >> (-bit - 1)) & 1u : (b[bit / 8] >> (7 - bit % 8)) & 1u;
                v = (v << 1) | x;
            }
            if (d == 5 || d == 10) out += '-';
            out += kDigits[v];
        }
        return out;
    }
    inline bool ParseJoinCode(const std::string& text, uint32_t& ip, uint16_t& port, uint32_t& token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        unsigned vals[15];
        int n = 0;
        for (char c : text)
        {
            if (c == '-' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '"' || c == '\'') continue;
            if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
            if (c == 'I' || c == 'L') c = '1';
            if (c == 'O') c = '0';
            const char* at = std::strchr(kDigits, c);
            if (!at || !c) return false;
            if (n >= 15) return false;
            vals[n++] = static_cast<unsigned>(at - kDigits);
        }
        if (n != 15) return false;
        uint8_t b[9]{};
        unsigned check = 0;
        int bit = -3;
        for (int d = 0; d < 15; ++d)
            for (int k = 4; k >= 0; --k, ++bit)
            {
                const unsigned x = (vals[d] >> k) & 1u;
                if (bit < 0) check = (check << 1) | x;
                else if (x) b[bit / 8] = static_cast<uint8_t>(b[bit / 8] | (1u << (7 - bit % 8)));
            }
        if (JoinCodeCheck(b) != check) return false;
        ip = (uint32_t(b[0]) << 24) | (uint32_t(b[1]) << 16) | (uint32_t(b[2]) << 8) | b[3];
        port = static_cast<uint16_t>((b[4] << 8) | b[5]);
        token = (uint32_t(b[6]) << 16) | (uint32_t(b[7]) << 8) | b[8];
        return ip != 0 && port != 0;
    }

    // ---- Steam code: the host's Steam account number + the 24-bit secret, 12 base-32 digits ----
    // XXXX-XXXX-XXXX. The friend's game reaches the host through Steam with it (no open port needed).
    constexpr uint64_t kSteamIdIndividual = 0x0110000100000000ull;   // public universe, individual, desktop
    inline unsigned SteamCodeCheck(const uint8_t* b)
    {
        uint32_t h = 2166136261u ^ 0x5Au;
        for (int i = 0; i < 7; ++i) { h ^= b[i]; h *= 16777619u; }
        return h >> 29;
    }
    inline std::string MakeSteamCode(uint64_t steamId, uint32_t token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        const uint32_t account = static_cast<uint32_t>(steamId);
        const uint8_t b[7] = { static_cast<uint8_t>(account >> 24), static_cast<uint8_t>(account >> 16), static_cast<uint8_t>(account >> 8),
            static_cast<uint8_t>(account), static_cast<uint8_t>(token >> 16), static_cast<uint8_t>(token >> 8), static_cast<uint8_t>(token) };
        const unsigned check = SteamCodeCheck(b);
        std::string out;
        int bit = -4;   // 60 bits: a zero bit, the 3 check bits, then the 56 data bits
        for (int d = 0; d < 12; ++d)
        {
            unsigned v = 0;
            for (int k = 0; k < 5; ++k, ++bit)
            {
                unsigned x = 0;
                if (bit >= 0) x = (b[bit / 8] >> (7 - bit % 8)) & 1u;
                else if (bit >= -3) x = (check >> (-bit - 1)) & 1u;
                v = (v << 1) | x;
            }
            if (d == 4 || d == 8) out += '-';
            out += kDigits[v];
        }
        return out;
    }
    inline bool ParseSteamCode(const std::string& text, uint64_t& steamId, uint32_t& token)
    {
        static const char* kDigits = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        unsigned vals[12];
        int n = 0;
        for (char c : text)
        {
            if (c == '-' || c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '"' || c == '\'') continue;
            if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
            if (c == 'I' || c == 'L') c = '1';
            if (c == 'O') c = '0';
            const char* at = std::strchr(kDigits, c);
            if (!at || !c || n >= 12) return false;
            vals[n++] = static_cast<unsigned>(at - kDigits);
        }
        if (n != 12) return false;
        uint8_t b[7]{};
        unsigned check = 0, pad = 0;
        int bit = -4;
        for (int d = 0; d < 12; ++d)
            for (int k = 4; k >= 0; --k, ++bit)
            {
                const unsigned x = (vals[d] >> k) & 1u;
                if (bit < -3) pad |= x;
                else if (bit < 0) check = (check << 1) | x;
                else if (x) b[bit / 8] = static_cast<uint8_t>(b[bit / 8] | (1u << (7 - bit % 8)));
            }
        if (pad || SteamCodeCheck(b) != check) return false;
        const uint32_t account = (uint32_t(b[0]) << 24) | (uint32_t(b[1]) << 16) | (uint32_t(b[2]) << 8) | b[3];
        steamId = kSteamIdIndividual | account;
        token = (uint32_t(b[4]) << 16) | (uint32_t(b[5]) << 8) | b[6];
        return account != 0;
    }

    // ---- Video: frame -> packets ----
    // A frame's data packets, then its recovery packets (pct: about pct % of the data, at least 1 per block; 0: none).
    inline void BuildVideoPackets(uint32_t session, uint32_t frame, const uint8_t* data, size_t size, bool key,
        uint16_t width, uint16_t height, uint32_t captureMs, int pct, std::vector<std::vector<uint8_t>>& out)
    {
        out.clear();
        const size_t P = kVideoPayload;
        const size_t count = size == 0 ? 1 : (size + P - 1) / P;
        if (count >= kParity) return;
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        const size_t blocks = pct ? std::min<size_t>(127, (count + kRsBlockMax - 1) / kRsBlockMax) : 0;
        VideoHeader vh{};
        vh.frame = frame;
        vh.frameSize = static_cast<uint32_t>(size);
        vh.captureMs = captureMs;
        vh.count = static_cast<uint16_t>(count);
        vh.width = width;
        vh.height = height;
        vh.flags = static_cast<uint8_t>((key ? kVideoKey : 0) | (blocks ? kVideoRs : 0));
        vh.group = static_cast<uint8_t>(blocks);
        for (size_t i = 0; i < count; ++i)
        {
            const size_t off = i * P, len = std::min(P, size - std::min(size, off));
            std::vector<uint8_t> pkt(sizeof(VideoHeader) + len);
            vh.index = static_cast<uint16_t>(i);
            FillHeader(vh.h, kVideo, session, pkt.size());
            std::memcpy(pkt.data(), &vh, sizeof(vh));
            if (len) std::memcpy(pkt.data() + sizeof(vh), data + off, len);
            out.push_back(std::move(pkt));
        }
        static const uint8_t kZero[1] = { 0 };
        for (size_t b = 0; b < blocks; ++b)
        {
            std::vector<const uint8_t*> ptr;
            std::vector<size_t> lens;
            for (size_t i = b; i < count; i += blocks)
            {
                const size_t off = i * P, len = std::min(P, size - std::min(size, off));
                ptr.push_back(len ? data + off : kZero);
                lens.push_back(len);
            }
            const int k = static_cast<int>(ptr.size());
            int m = (k * pct + 99) / 100;
            if (m < 1) m = 1;
            if (k + m > 255) m = 255 - k;
            std::vector<std::vector<uint8_t>> rec;
            RsCode::Encode(k, m, ptr.data(), lens.data(), P, rec);
            for (int j = 0; j < m; ++j)
            {
                std::vector<uint8_t> pp(sizeof(VideoHeader) + P);
                vh.index = static_cast<uint16_t>(kParity | (b << 8) | static_cast<size_t>(j));
                FillHeader(vh.h, kVideo, session, pp.size());
                std::memcpy(pp.data(), &vh, sizeof(vh));
                std::memcpy(pp.data() + sizeof(vh), rec[static_cast<size_t>(j)].data(), P);
                out.push_back(std::move(pp));
            }
        }
    }

    struct VideoFrame
    {
        uint32_t frame = 0, captureMs = 0;
        bool key = false;
        uint16_t width = 0, height = 0;
        std::vector<uint8_t> data;
    };

    // ---- Video: packets -> frames, in order ----
    class VideoReceiver
    {
    public:
        struct Stats { uint32_t packets = 0, recovered = 0, resendAsked = 0, duplicates = 0, framesDone = 0, framesLost = 0, keyAsks = 0; };
        Stats stats;

        void Reset()
        {
            m_slots.clear();
            m_haveExpected = false;
            m_waitKey = true;
            m_keyAsked = false;
            m_haveNewest = false;
        }

        void Add(const uint8_t* p, size_t n, uint32_t nowMs)
        {
            if (n < sizeof(VideoHeader)) return;
            VideoHeader vh;
            std::memcpy(&vh, p, sizeof(vh));
            const uint8_t* payload = p + sizeof(vh);
            const size_t len = n - sizeof(vh);
            const size_t P = kVideoPayload;
            if (vh.count == 0 || vh.count >= kParity || vh.frameSize > size_t(vh.count) * P ||
                (vh.count > 1 && vh.frameSize <= size_t(vh.count - 1) * P)) return;
            if (m_haveExpected && static_cast<int32_t>(vh.frame - m_expected) < 0) return;   // already shown or given up
            if (!m_haveNewest || static_cast<int32_t>(vh.frame - m_newest) > 0) { m_newest = vh.frame; m_haveNewest = true; }
            Slot& s = m_slots[vh.frame];
            if (!s.any)
            {
                s.any = true;
                s.size = vh.frameSize; s.count = vh.count; s.width = vh.width; s.height = vh.height;
                s.flags = vh.flags; s.group = vh.group; s.captureMs = vh.captureMs;
                s.data.assign(s.size, 0);
                s.have.assign(s.count, 0);
                s.firstMs = nowMs;
            }
            else if (s.size != vh.frameSize || s.count != vh.count || s.group != vh.group) return;
            s.lastMs = nowMs;
            ++stats.packets;
            if (vh.index & kParity)
            {
                const uint16_t key = static_cast<uint16_t>(vh.index & ~kParity);
                const uint16_t g = static_cast<uint16_t>(key >> 8);
                if (!(s.flags & kVideoRs) || !s.group || g >= s.group || len < P) return;
                if (s.parity.count(key)) { ++stats.duplicates; return; }
                s.parity[key].assign(payload, payload + P);
                s.sawEnd = true;                       // (recovery packets come after all the data)
                if (!s.Complete()) Recover(s, g);
            }
            else
            {
                const uint16_t i = vh.index;
                if (i >= s.count) return;
                const size_t off = size_t(i) * P, want = std::min(P, s.size - off);
                if (len != want) return;
                if (s.have[i]) { ++stats.duplicates; return; }
                if (want) std::memcpy(s.data.data() + off, payload, want);
                s.have[i] = 1;
                ++s.haveCount;
                if (i + 1u == s.count) s.sawEnd = true;
                if (s.group && (s.flags & kVideoRs)) Recover(s, GroupOf(s, i));
            }
            while (m_slots.size() > 240) m_slots.erase(m_slots.begin());
        }

        // The next frame to decode, in order. After a loss only from a keyframe on.
        bool Next(VideoFrame& out)
        {
            for (;;)
            {
                if (m_waitKey)
                {
                    // the newest complete keyframe (least delay)
                    auto key = m_slots.end();
                    for (auto it = m_slots.begin(); it != m_slots.end(); ++it)
                        if (it->second.Complete() && (it->second.flags & kVideoKey) &&
                            (!m_haveExpected || static_cast<int32_t>(it->first - m_expected) >= 0))
                            if (key == m_slots.end() || static_cast<int32_t>(it->first - key->first) > 0) key = it;
                    if (key == m_slots.end()) return false;
                    DropBefore(key->first);
                    m_expected = key->first;
                    m_haveExpected = true;
                    m_waitKey = false;
                    m_keyAsked = false;
                }
                auto it = m_slots.find(m_expected);
                if (it != m_slots.end() && it->second.Complete())
                {
                    Slot& s = it->second;
                    out.frame = it->first; out.captureMs = s.captureMs; out.key = (s.flags & kVideoKey) != 0;
                    out.width = s.width; out.height = s.height; out.data.swap(s.data);
                    if (out.key) { m_keyAsked = false; m_concealAsk = false; }
                    m_slots.erase(it);
                    ++m_expected;
                    ++stats.framesDone;
                    return true;
                }
                // a newer complete keyframe: what is before it is not needed any more
                bool jumped = false;
                for (auto& kv : m_slots)
                    if (static_cast<int32_t>(kv.first - m_expected) > 0 && kv.second.Complete() && (kv.second.flags & kVideoKey))
                    {
                        stats.framesLost += kv.first - m_expected;
                        DropBefore(kv.first);
                        m_expected = kv.first;
                        jumped = true;
                        break;
                    }
                if (!jumped) return false;
            }
        }

        // Resend requests for what is missing, and whether to ask for a keyframe.
        void Poll(uint32_t nowMs, uint32_t rttMs, std::vector<std::pair<uint32_t, std::vector<uint16_t>>>& nacks, bool& wantKey)
        {
            nacks.clear();
            wantKey = false;
            if (rttMs < 1) rttMs = 1;
            if (rttMs > 1000) rttMs = 1000;
            const uint32_t giveUp = std::clamp<uint32_t>(rttMs * 3 + 40, 70, 300);
            if (!m_waitKey && m_haveExpected)
            {
                // the frame we wait for: given up once it (or the next frame, if none of it came) is too old
                uint32_t since = 0;
                bool have = false;
                auto it = m_slots.find(m_expected);
                if (it != m_slots.end()) { since = it->second.firstMs; have = true; }
                else
                    for (auto& kv : m_slots)
                        if (static_cast<int32_t>(kv.first - m_expected) > 0) { since = kv.second.firstMs; have = true; break; }
                if (have && static_cast<uint32_t>(nowMs - since) > giveUp)
                {
                    ++stats.framesLost;
                    if (m_conceal)
                    {
                        // 1.7.1: past it, and on with the next frames (a smudge where the lost one changed the picture,
                        // gone with the keyframe asked for now) - instead of a still picture until that keyframe
                        m_slots.erase(m_expected);
                        ++m_expected;
                        m_concealAsk = true;
                    }
                    else m_waitKey = true;
                }
            }
            if (m_concealAsk && !m_waitKey && (!m_keyAsked || static_cast<uint32_t>(nowMs - m_keyAskMs) > std::max<uint32_t>(rttMs * 2 + 20, 120)))
            {
                wantKey = true;
                m_keyAsked = true;
                m_keyAskMs = nowMs;
                m_concealAsk = false;
                ++stats.keyAsks;
            }
            if (m_waitKey && (!m_keyAsked || static_cast<uint32_t>(nowMs - m_keyAskMs) > std::max<uint32_t>(rttMs * 2 + 20, 120)))
            {
                wantKey = true;
                m_keyAsked = true;
                m_keyAskMs = nowMs;
                ++stats.keyAsks;
            }
            // not one packet of the awaited frame came (and a later one did): ask for all of it
            if (!m_waitKey && m_haveExpected && !m_slots.count(m_expected))
            {
                for (auto& kv : m_slots)
                    if (static_cast<int32_t>(kv.first - m_expected) > 0)
                    {
                        if (m_wholeFrame != m_expected) { m_wholeFrame = m_expected; m_wholeAsks = 0; }
                        const uint32_t wait = m_wholeAsks ? std::max<uint32_t>(rttMs + rttMs / 2 + 5, 20) : 3;
                        if (m_wholeAsks < 3 && static_cast<uint32_t>(nowMs - (m_wholeAsks ? m_wholeAskMs : kv.second.firstMs)) >= wait)
                        {
                            ++m_wholeAsks;
                            m_wholeAskMs = nowMs;
                            nacks.emplace_back(m_expected, std::vector<uint16_t>());   // empty: the whole frame
                        }
                        break;
                    }
            }
            size_t asked = 0;
            for (auto& kv : m_slots)
            {
                Slot& s = kv.second;
                if (s.Complete()) continue;
                if (m_waitKey && !(s.flags & kVideoKey)) continue;   // only the keyframe matters now
                if (!m_waitKey && m_haveExpected && static_cast<int32_t>(kv.first - m_expected) < 0) continue;
                const bool newer = m_haveNewest && static_cast<int32_t>(m_newest - kv.first) > 0;
                const uint32_t quiet = static_cast<uint32_t>(nowMs - s.lastMs);
                // the end of the frame is known (or a later frame started), and nothing came for a moment
                if (!(s.sawEnd || newer || quiet > 6)) continue;
                if (!newer && quiet < 2) continue;
                // 1.7.1: Reed-Solomon frames: the recovery packets come last, paced 1 ms apart in groups - give them a
                // moment (5 ms of nothing new) before asking for anything again: asked at once, the resend beat them
                // every time and nothing was ever rebuilt (PC2's log: 749 asked again, 2 rebuilt)
                if ((s.flags & kVideoRs) && !newer && quiet < 5) continue;
                if (s.nacks >= 4) continue;
                if (s.nacks && static_cast<uint32_t>(nowMs - s.nackMs) < std::max<uint32_t>(rttMs + rttMs / 2 + 5, 20)) continue;
                std::vector<uint16_t> missing;
                for (uint16_t i = 0; i < s.count && missing.size() < 256; ++i)
                {
                    if (s.have[i]) continue;
                    // one missing in a group whose parity has not come yet: the parity may still fix it
                    if (s.group && !s.nacks && !newer && quiet < 12)
                    {
                        // (recovery packets not here yet, or enough of them: rebuilt, no resend needed)
                        if (RecoveryCount(s, GroupOf(s, i)) == 0) continue;
                    }
                    missing.push_back(i);
                }
                if (missing.empty()) continue;
                s.nacks++;
                s.nackMs = nowMs;
                stats.resendAsked += static_cast<uint32_t>(missing.size());
                asked += missing.size();
                nacks.emplace_back(kv.first, std::move(missing));
                if (asked > 512) break;
            }
        }

        bool WaitingForKey() const { return m_waitKey; }
        void SetConceal(bool on) { m_conceal = on; }   // 1.7.1: [Online] ConcealLoss

    private:
        struct Slot
        {
            uint32_t size = 0, captureMs = 0;
            uint16_t count = 0, width = 0, height = 0, haveCount = 0;
            uint8_t flags = 0, group = 0;
            std::vector<uint8_t> data, have;
            std::map<uint16_t, std::vector<uint8_t>> parity;
            uint32_t firstMs = 0, lastMs = 0, nackMs = 0;
            int nacks = 0;
            bool any = false, sawEnd = false;
            bool Complete() const { return count && haveCount == count; }
        };

        static uint16_t GroupOf(const Slot& s, size_t i) { return static_cast<uint16_t>(s.group ? i % s.group : 0); }
        static int Missing(const Slot& s, uint16_t g)
        {
            int missing = 0;
            if (!s.group) return 0;
            for (size_t i = g; i < s.count; i += s.group) if (!s.have[i]) ++missing;
            return missing;
        }
        static int RecoveryCount(const Slot& s, uint16_t g)
        {
            int n = 0;
            for (auto it = s.parity.lower_bound(static_cast<uint16_t>(g << 8)); it != s.parity.end() && (it->first >> 8) == g; ++it) ++n;
            return n;
        }

        // Block g rebuilt from its recovery packets, once there are as many as packets missing.
        void Recover(Slot& s, uint16_t g)
        {
            if (!s.group) return;
            const int missing = Missing(s, g);
            if (missing == 0 || RecoveryCount(s, g) < missing) return;
            const size_t P = kVideoPayload;
            std::vector<size_t> idx;
            for (size_t i = g; i < s.count; i += s.group) idx.push_back(i);
            const int k = static_cast<int>(idx.size());
            std::vector<std::vector<uint8_t>> buf(idx.size());
            std::vector<std::vector<uint8_t>*> sh(idx.size());
            std::vector<uint8_t> present(idx.size());
            for (size_t c = 0; c < idx.size(); ++c)
            {
                buf[c].assign(P, 0);
                present[c] = s.have[idx[c]];
                if (present[c]) { const size_t off = idx[c] * P, len = std::min(P, s.size - off); if (len) std::memcpy(buf[c].data(), s.data.data() + off, len); }
                sh[c] = &buf[c];
            }
            std::vector<std::pair<int, const uint8_t*>> rec;
            for (auto it = s.parity.lower_bound(static_cast<uint16_t>(g << 8)); it != s.parity.end() && (it->first >> 8) == g && static_cast<int>(rec.size()) < missing; ++it)
                rec.emplace_back(it->first & 0xFF, it->second.data());
            std::vector<int> rebuilt;
            if (!RsCode::Decode(k, sh, present, rec, P, &rebuilt)) return;
            for (int c : rebuilt)
            {
                const size_t i = idx[static_cast<size_t>(c)];
                const size_t off = i * P, len = std::min(P, s.size - off);
                if (len) std::memcpy(s.data.data() + off, buf[static_cast<size_t>(c)].data(), len);
                s.have[i] = 1;
                ++s.haveCount;
                ++stats.recovered;
            }
        }

        void DropBefore(uint32_t frame)
        {
            for (auto it = m_slots.begin(); it != m_slots.end();)
                if (static_cast<int32_t>(it->first - frame) < 0) it = m_slots.erase(it);
                else ++it;
        }

        std::map<uint32_t, Slot> m_slots;
        uint32_t m_expected = 0, m_newest = 0, m_keyAskMs = 0, m_wholeFrame = 0, m_wholeAskMs = 0;
        int m_wholeAsks = 0;
        bool m_haveExpected = false, m_waitKey = true, m_keyAsked = false, m_haveNewest = false;
        bool m_conceal = true, m_concealAsk = false;
    };

    // A resend request: these data packets of a frame (none listed: the whole frame).
    constexpr size_t kNackMax = (kMaxDatagram - sizeof(NackHeader)) / 2;
    inline std::vector<uint8_t> BuildNack(uint32_t session, uint32_t frame, const std::vector<uint16_t>& index, size_t from = 0)
    {
        const size_t n = std::min(kNackMax, index.size() - std::min(index.size(), from));
        std::vector<uint8_t> pkt(sizeof(NackHeader) + n * 2);
        NackHeader nh{};
        FillHeader(nh.h, kNack, session, pkt.size());
        nh.frame = frame;
        nh.n = static_cast<uint16_t>(n);
        std::memcpy(pkt.data(), &nh, sizeof(nh));
        if (n) std::memcpy(pkt.data() + sizeof(nh), index.data() + from, n * 2);
        return pkt;
    }
    inline bool ReadNack(const uint8_t* p, size_t n, uint32_t& frame, std::vector<uint16_t>& index)
    {
        if (n < sizeof(NackHeader)) return false;
        NackHeader nh;
        std::memcpy(&nh, p, sizeof(nh));
        if (n != sizeof(nh) + size_t(nh.n) * 2) return false;
        frame = nh.frame;
        index.resize(nh.n);
        if (nh.n) std::memcpy(index.data(), p + sizeof(nh), size_t(nh.n) * 2);
        return true;
    }

    // The host keeps the packets of the last frames it sent, for resend requests.
    class VideoHistory
    {
    public:
        explicit VideoHistory(size_t frames = 120) : m_keep(frames) {}
        void Store(uint32_t frame, const std::vector<std::vector<uint8_t>>& packets)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_frames[frame] = packets;
            while (m_frames.size() > m_keep) m_frames.erase(m_frames.begin());
        }
        void Clear() { std::lock_guard<std::mutex> lock(m_mutex); m_frames.clear(); }
        // The data packets asked for (an empty list: all of the frame's packets). False when the frame is gone.
        bool Get(uint32_t frame, const std::vector<uint16_t>& index, std::vector<std::vector<uint8_t>>& out)
        {
            out.clear();
            std::lock_guard<std::mutex> lock(m_mutex);
            auto it = m_frames.find(frame);
            if (it == m_frames.end()) return false;
            const auto& pk = it->second;
            if (index.empty()) { out = pk; return true; }
            for (uint16_t want : index)
                for (const auto& p : pk)
                {
                    if (p.size() < sizeof(VideoHeader)) continue;
                    VideoHeader vh;
                    std::memcpy(&vh, p.data(), sizeof(vh));
                    if (vh.index == want) { out.push_back(p); break; }
                }
            return true;
        }
    private:
        std::mutex m_mutex;
        std::map<uint32_t, std::vector<std::vector<uint8_t>>> m_frames;
        size_t m_keep;
    };

    // ---- Audio: IMA ADPCM, 4 bits a sample ----
    struct AdpcmState { int predictor = 0; int index = 0; };
    inline const int* AdpcmSteps()
    {
        static const int steps[89] = {
            7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
            107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
            876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
            5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623,
            27086, 29794, 32767 };
        return steps;
    }
    inline int AdpcmIndexDelta(int nibble)
    {
        static const int table[16] = { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
        return table[nibble & 15];
    }
    inline int16_t AdpcmDecode(AdpcmState& st, int nibble)
    {
        const int step = AdpcmSteps()[st.index];
        int diff = step >> 3;
        if (nibble & 4) diff += step;
        if (nibble & 2) diff += step >> 1;
        if (nibble & 1) diff += step >> 2;
        st.predictor += (nibble & 8) ? -diff : diff;
        st.predictor = std::clamp(st.predictor, -32768, 32767);
        st.index = std::clamp(st.index + AdpcmIndexDelta(nibble), 0, 88);
        return static_cast<int16_t>(st.predictor);
    }
    inline int AdpcmEncode(AdpcmState& st, int16_t sample)
    {
        const int step = AdpcmSteps()[st.index];
        int diff = sample - st.predictor;
        int nibble = 0;
        if (diff < 0) { nibble = 8; diff = -diff; }
        int s = step;
        if (diff >= s) { nibble |= 4; diff -= s; }
        s >>= 1;
        if (diff >= s) { nibble |= 2; diff -= s; }
        s >>= 1;
        if (diff >= s) nibble |= 1;
        AdpcmDecode(st, nibble);   // keep the encoder's state equal to the decoder's
        return nibble;
    }

    // One audio packet: stereo s16 frames -> ADPCM (one byte per frame: left low nibble, right high nibble).
    inline std::vector<uint8_t> BuildAudioPacket(uint32_t session, uint32_t seq, const int16_t* stereo, int frames, AdpcmState st[2])
    {
        std::vector<uint8_t> pkt(sizeof(AudioHeader) + static_cast<size_t>(frames));
        AudioHeader ah{};
        FillHeader(ah.h, kAudio, session, pkt.size());
        ah.seq = seq;
        ah.frames = static_cast<uint16_t>(frames);
        ah.channels = 2;
        ah.codec = kAudioAdpcm;
        for (int c = 0; c < 2; ++c) { ah.predictor[c] = static_cast<int16_t>(st[c].predictor); ah.stepIndex[c] = static_cast<uint8_t>(st[c].index); }
        std::memcpy(pkt.data(), &ah, sizeof(ah));
        uint8_t* out = pkt.data() + sizeof(ah);
        for (int i = 0; i < frames; ++i)
        {
            const int l = AdpcmEncode(st[0], stereo[i * 2]);
            const int r = AdpcmEncode(st[1], stereo[i * 2 + 1]);
            out[i] = static_cast<uint8_t>(l | (r << 4));
        }
        return pkt;
    }
    inline bool ReadAudioPacket(const uint8_t* p, size_t n, uint32_t& seq, std::vector<int16_t>& stereo)
    {
        if (n < sizeof(AudioHeader)) return false;
        AudioHeader ah;
        std::memcpy(&ah, p, sizeof(ah));
        if (ah.channels != 2 || ah.codec != kAudioAdpcm || n != sizeof(ah) + ah.frames) return false;
        AdpcmState st[2];
        for (int c = 0; c < 2; ++c) { st[c].predictor = ah.predictor[c]; st[c].index = std::clamp<int>(ah.stepIndex[c], 0, 88); }
        seq = ah.seq;
        stereo.resize(size_t(ah.frames) * 2);
        const uint8_t* in = p + sizeof(ah);
        for (int i = 0; i < ah.frames; ++i)
        {
            stereo[size_t(i) * 2] = AdpcmDecode(st[0], in[i] & 15);
            stereo[size_t(i) * 2 + 1] = AdpcmDecode(st[1], in[i] >> 4);
        }
        return true;
    }

    // ---- Voice chat (1.7.2) ----
    constexpr int kVoiceRate = 16000;
    constexpr int kVoiceFrame = 320;   // 20 ms
    inline std::vector<uint8_t> BuildVoicePacket(uint32_t session, uint32_t seq, uint8_t speaker, uint8_t level, const int16_t* mono, int samples)
    {
        samples &= ~1;
        std::vector<uint8_t> pkt(sizeof(VoiceHeader) + static_cast<size_t>(samples / 2));
        VoiceHeader vh{};
        FillHeader(vh.h, kVoice, session, pkt.size());
        vh.seq = seq; vh.speaker = speaker; vh.level = level; vh.samples = static_cast<uint16_t>(samples);
        AdpcmState st;                      // every packet starts fresh: a lost one does not spoil the next
        st.predictor = mono[0];
        st.index = 20;
        vh.predictor = static_cast<int16_t>(st.predictor);
        vh.stepIndex = static_cast<uint8_t>(st.index);
        std::memcpy(pkt.data(), &vh, sizeof(vh));
        uint8_t* out = pkt.data() + sizeof(vh);
        for (int i = 0; i < samples; i += 2)
        {
            const int a = AdpcmEncode(st, mono[i]);
            const int b = AdpcmEncode(st, mono[i + 1]);
            out[i / 2] = static_cast<uint8_t>(a | (b << 4));
        }
        return pkt;
    }
    inline bool ReadVoicePacket(const uint8_t* p, size_t n, VoiceHeader& vh, std::vector<int16_t>& mono)
    {
        if (n < sizeof(VoiceHeader)) return false;
        std::memcpy(&vh, p, sizeof(vh));
        if (vh.samples == 0 || vh.samples > 4000 || (vh.samples & 1) || n != sizeof(vh) + vh.samples / 2u) return false;
        AdpcmState st;
        st.predictor = vh.predictor;
        st.index = std::clamp<int>(vh.stepIndex, 0, 88);
        mono.resize(vh.samples);
        const uint8_t* in = p + sizeof(vh);
        for (int i = 0; i < vh.samples; i += 2)
        {
            mono[size_t(i)] = AdpcmDecode(st, in[i / 2] & 15);
            mono[size_t(i) + 1] = AdpcmDecode(st, in[i / 2] >> 4);
        }
        return true;
    }

    // Audio waiting to be played on the friend's side (stereo s16). Packets go in as they arrive;
    // the player takes what it needs. Holds about `target` frames: more is dropped, and after running
    // dry it waits until half of that is there again.
    class AudioBuffer
    {
    public:
        void Configure(int targetFrames, int maxFrames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_target = targetFrames;
            m_max = std::max(maxFrames, targetFrames * 2);
        }
        void Clear()
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_data.clear();
            m_haveSeq = false;
            m_refill = true;
        }
        void Push(uint32_t seq, const int16_t* stereo, int frames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_haveSeq)
            {
                const int32_t d = static_cast<int32_t>(seq - m_lastSeq);
                if (d <= 0) return;   // late or twice
                if (d > 1 && d <= 4) m_data.insert(m_data.end(), size_t(frames) * 2 * size_t(d - 1), 0);   // lost: keep the timing
            }
            m_lastSeq = seq;
            m_haveSeq = true;
            m_data.insert(m_data.end(), stereo, stereo + size_t(frames) * 2);
            const size_t have = m_data.size() / 2;
            if (have > size_t(m_max))
            {
                const size_t drop = have - size_t(m_target);
                m_data.erase(m_data.begin(), m_data.begin() + static_cast<std::ptrdiff_t>(drop * 2));
                ++m_dropped;
            }
        }
        // Always fills `frames` (silence where nothing is there); returns how many were real audio.
        int Pull(int16_t* out, int frames)
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            const size_t have = m_data.size() / 2;
            if (m_refill && have < size_t(std::max(1, m_target / 2)))
            {
                std::memset(out, 0, size_t(frames) * 4);
                return 0;
            }
            m_refill = false;
            const size_t n = std::min(have, size_t(frames));
            if (n) std::memcpy(out, m_data.data(), n * 4);
            if (n < size_t(frames)) { std::memset(out + n * 2, 0, (size_t(frames) - n) * 4); m_refill = true; ++m_underruns; }
            m_data.erase(m_data.begin(), m_data.begin() + static_cast<std::ptrdiff_t>(n * 2));
            return static_cast<int>(n);
        }
        int Level() const
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            return static_cast<int>(m_data.size() / 2);
        }
        unsigned Underruns() const { std::lock_guard<std::mutex> lock(m_mutex); return m_underruns; }
        unsigned Dropped() const { std::lock_guard<std::mutex> lock(m_mutex); return m_dropped; }

    private:
        mutable std::mutex m_mutex;
        std::vector<int16_t> m_data;
        uint32_t m_lastSeq = 0;
        bool m_haveSeq = false, m_refill = true;
        int m_target = 1920, m_max = 7200;
        unsigned m_underruns = 0, m_dropped = 0;
    };
}
