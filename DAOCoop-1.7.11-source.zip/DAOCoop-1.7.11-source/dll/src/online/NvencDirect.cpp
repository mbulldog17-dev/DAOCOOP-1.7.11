// 1.7.8: see NvencDirect.h. Built into DAOCoopStream.exe (64-bit) only.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdio>
#include <cstring>
#include <chrono>
#include "NvencDirect.h"
#include "nvEncodeAPI.h"   // NVIDIA Video Codec SDK 12.0 header (MIT licence, see its top): drivers 522 and newer

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace
{
    typedef NVENCSTATUS (NVENCAPI* CreateInstance_t)(NV_ENCODE_API_FUNCTION_LIST*);
    typedef NVENCSTATUS (NVENCAPI* MaxVersion_t)(uint32_t*);
    NV_ENCODE_API_FUNCTION_LIST& F(void* p) { return *static_cast<NV_ENCODE_API_FUNCTION_LIST*>(p); }
    std::string Hex(long v) { char b[16]; std::snprintf(b, sizeof(b), "0x%08lX", v); return b; }
}

bool NvencDirect::Open(int w, int h, int fps, int kbps, std::string& why)
{
    Close();
    w_ = w; h_ = h; fps_ = fps > 0 ? fps : 30; kbps_ = kbps > 0 ? kbps : 20000;
    // the driver's encoder library
    HMODULE lib = LoadLibraryW(L"nvEncodeAPI64.dll");
    if (!lib) { why = "no NVIDIA encoder library (not an NVIDIA graphics card)"; return false; }
    lib_ = lib;
    auto maxVer = reinterpret_cast<MaxVersion_t>(GetProcAddress(lib, "NvEncodeAPIGetMaxSupportedVersion"));
    auto create = reinterpret_cast<CreateInstance_t>(GetProcAddress(lib, "NvEncodeAPICreateInstance"));
    if (!maxVer || !create) { why = "the NVIDIA encoder library has no entry points"; Close(); return false; }
    uint32_t mv = 0;
    if (maxVer(&mv) != NV_ENC_SUCCESS || mv < ((NVENCAPI_MAJOR_VERSION << 4) | NVENCAPI_MINOR_VERSION)) {
        why = "the NVIDIA driver is too old for direct encoding (needs 522 or newer)"; Close(); return false;
    }
    auto* fl = new NV_ENCODE_API_FUNCTION_LIST();
    std::memset(fl, 0, sizeof(*fl));
    fl->version = NV_ENCODE_API_FUNCTION_LIST_VER;
    fn_ = fl;
    if (create(fl) != NV_ENC_SUCCESS || !fl->nvEncOpenEncodeSessionEx) { why = "NvEncodeAPICreateInstance failed"; Close(); return false; }

    // a Direct3D 11 device on the NVIDIA card
    IDXGIFactory1* fac = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), reinterpret_cast<void**>(&fac))) || !fac) { why = "no DXGI"; Close(); return false; }
    IDXGIAdapter1* nv = nullptr;
    for (UINT i = 0;; ++i) {
        IDXGIAdapter1* a = nullptr;
        if (fac->EnumAdapters1(i, &a) == DXGI_ERROR_NOT_FOUND) break;
        DXGI_ADAPTER_DESC1 d{};
        a->GetDesc1(&d);
        if (d.VendorId == 0x10DE && !nv) { nv = a; continue; }
        a->Release();
    }
    fac->Release();
    if (!nv) { why = "no NVIDIA graphics card found"; Close(); return false; }
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    const D3D_FEATURE_LEVEL lv[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1, D3D_FEATURE_LEVEL_10_0 };
    const HRESULT hr = D3D11CreateDevice(nv, D3D_DRIVER_TYPE_UNKNOWN, nullptr, 0, lv, 3, D3D11_SDK_VERSION, &dev, nullptr, &ctx);
    nv->Release();
    if (FAILED(hr) || !dev) { why = "D3D11CreateDevice " + Hex(hr); Close(); return false; }
    dev_ = dev; ctx_ = ctx;

    NV_ENC_OPEN_ENCODE_SESSION_EX_PARAMS op{};
    op.version = NV_ENC_OPEN_ENCODE_SESSION_EX_PARAMS_VER;
    op.deviceType = NV_ENC_DEVICE_TYPE_DIRECTX;
    op.device = dev;
    op.apiVersion = NVENCAPI_VERSION;
    const NVENCSTATUS st = fl->nvEncOpenEncodeSessionEx(&op, &enc_);
    if (st != NV_ENC_SUCCESS || !enc_) { why = "nvEncOpenEncodeSessionEx " + std::to_string(st) + " (too many encode sessions?)"; enc_ = nullptr; Close(); return false; }

    if (!Configure(false)) { why = "the encoder settings were not taken"; Close(); return false; }

    // the picture's texture (BGRA - NVENC turns it to YUV on the card) and the output buffer
    D3D11_TEXTURE2D_DESC td{};
    td.Width = static_cast<UINT>(w); td.Height = static_cast<UINT>(h);
    td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_RENDER_TARGET;
    ID3D11Texture2D* tex = nullptr;
    if (FAILED(dev->CreateTexture2D(&td, nullptr, &tex)) || !tex) { why = "the picture texture was not made"; Close(); return false; }
    tex_ = tex;
    NV_ENC_REGISTER_RESOURCE rr{};
    rr.version = NV_ENC_REGISTER_RESOURCE_VER;
    rr.resourceType = NV_ENC_INPUT_RESOURCE_TYPE_DIRECTX;
    rr.width = static_cast<uint32_t>(w); rr.height = static_cast<uint32_t>(h); rr.pitch = 0;
    rr.resourceToRegister = tex;
    rr.bufferFormat = NV_ENC_BUFFER_FORMAT_ARGB;
    rr.bufferUsage = NV_ENC_INPUT_IMAGE;
    if (fl->nvEncRegisterResource(enc_, &rr) != NV_ENC_SUCCESS) { why = "nvEncRegisterResource failed"; Close(); return false; }
    reg_ = rr.registeredResource;
    NV_ENC_CREATE_BITSTREAM_BUFFER bb{};
    bb.version = NV_ENC_CREATE_BITSTREAM_BUFFER_VER;
    if (fl->nvEncCreateBitstreamBuffer(enc_, &bb) != NV_ENC_SUCCESS) { why = "nvEncCreateBitstreamBuffer failed"; Close(); return false; }
    bits_ = bb.bitstreamBuffer;
    return true;
}

bool NvencDirect::Configure(bool reconfigure)
{
    auto& fl = F(fn_);
    if (!cfg_) cfg_ = new NV_ENC_CONFIG();
    if (!init_) init_ = new NV_ENC_INITIALIZE_PARAMS();
    NV_ENC_CONFIG& cfg = *static_cast<NV_ENC_CONFIG*>(cfg_);
    NV_ENC_INITIALIZE_PARAMS& ip = *static_cast<NV_ENC_INITIALIZE_PARAMS*>(init_);
    if (!reconfigure) {
        // the fastest preset with NVIDIA's ultra low latency tuning (game streaming), then our changes
        NV_ENC_PRESET_CONFIG pc{};
        pc.version = NV_ENC_PRESET_CONFIG_VER;
        pc.presetCfg.version = NV_ENC_CONFIG_VER;
        if (fl.nvEncGetEncodePresetConfigEx(enc_, NV_ENC_CODEC_H264_GUID, NV_ENC_PRESET_P2_GUID, NV_ENC_TUNING_INFO_ULTRA_LOW_LATENCY, &pc) != NV_ENC_SUCCESS)
            return false;
        cfg = pc.presetCfg;
        cfg.version = NV_ENC_CONFIG_VER;
        cfg.profileGUID = NV_ENC_H264_PROFILE_HIGH_GUID;
        cfg.gopLength = NVENC_INFINITE_GOPLENGTH;   // no regular keyframes: the picture renews itself strip by strip
        cfg.frameIntervalP = 1;                     // no B-frames (they wait for later pictures)
        auto& h = cfg.encodeCodecConfig.h264Config;
        h.idrPeriod = NVENC_INFINITE_GOPLENGTH;
        h.repeatSPSPPS = 1;                         // the stream's header with every keyframe (a friend joining late)
        h.enableIntraRefresh = 1;                   // a lost picture heals within half a second, no keyframe burst
        h.intraRefreshPeriod = static_cast<uint32_t>(fps_);
        h.intraRefreshCnt = static_cast<uint32_t>(fps_ / 2 > 1 ? fps_ / 2 : 2);
        h.sliceMode = 0; h.sliceModeData = 0;
    }
    auto& rc = cfg.rcParams;
    rc.rateControlMode = NV_ENC_PARAMS_RC_CBR;
    rc.averageBitRate = static_cast<uint32_t>(kbps_) * 1000u;
    rc.maxBitRate = rc.averageBitRate;
    // the buffer of one picture: every picture about the same size, so none waits behind a big one on the way
    rc.vbvBufferSize = rc.averageBitRate / static_cast<uint32_t>(fps_);
    rc.vbvInitialDelay = rc.vbvBufferSize;
    rc.zeroReorderDelay = 1;
    std::memset(&ip, 0, sizeof(ip));
    ip.version = NV_ENC_INITIALIZE_PARAMS_VER;
    ip.encodeGUID = NV_ENC_CODEC_H264_GUID;
    ip.presetGUID = NV_ENC_PRESET_P2_GUID;
    ip.tuningInfo = NV_ENC_TUNING_INFO_ULTRA_LOW_LATENCY;
    ip.encodeWidth = static_cast<uint32_t>(w_); ip.encodeHeight = static_cast<uint32_t>(h_);
    ip.darWidth = ip.encodeWidth; ip.darHeight = ip.encodeHeight;
    ip.maxEncodeWidth = ip.encodeWidth; ip.maxEncodeHeight = ip.encodeHeight;
    ip.frameRateNum = static_cast<uint32_t>(fps_); ip.frameRateDen = 1;
    ip.enablePTD = 1;
    ip.enableEncodeAsync = 0;                       // each picture waited for right away (it is a few ms)
    ip.encodeConfig = &cfg;
    if (reconfigure) {
        NV_ENC_RECONFIGURE_PARAMS rp{};
        rp.version = NV_ENC_RECONFIGURE_PARAMS_VER;
        rp.reInitEncodeParams = ip;
        return fl.nvEncReconfigureEncoder(enc_, &rp) == NV_ENC_SUCCESS;
    }
    return fl.nvEncInitializeEncoder(enc_, &ip) == NV_ENC_SUCCESS;
}

void NvencDirect::SetBitrate(int kbps)
{
    if (!enc_ || kbps <= 0 || kbps == kbps_) return;
    kbps_ = kbps;
    Configure(true);
}

bool NvencDirect::Encode(const uint8_t* bgra, int w, int h, int64_t us, bool forceKey, const Out& out, double* encodeMs)
{
    if (!enc_ || w != w_ || h != h_) return false;
    auto& fl = F(fn_);
    const auto t0 = std::chrono::steady_clock::now();
    auto* ctx = static_cast<ID3D11DeviceContext*>(ctx_);
    ctx->UpdateSubresource(static_cast<ID3D11Texture2D*>(tex_), 0, nullptr, bgra, static_cast<UINT>(w) * 4, 0);
    NV_ENC_MAP_INPUT_RESOURCE mp{};
    mp.version = NV_ENC_MAP_INPUT_RESOURCE_VER;
    mp.registeredResource = reg_;
    if (fl.nvEncMapInputResource(enc_, &mp) != NV_ENC_SUCCESS) return false;
    NV_ENC_PIC_PARAMS pp{};
    pp.version = NV_ENC_PIC_PARAMS_VER;
    pp.inputWidth = static_cast<uint32_t>(w); pp.inputHeight = static_cast<uint32_t>(h);
    pp.inputBuffer = mp.mappedResource;
    pp.bufferFmt = mp.mappedBufferFmt;
    pp.outputBitstream = bits_;
    pp.pictureStruct = NV_ENC_PIC_STRUCT_FRAME;
    pp.inputTimeStamp = static_cast<uint64_t>(us);
    if (forceKey) pp.encodePicFlags = NV_ENC_PIC_FLAG_FORCEIDR | NV_ENC_PIC_FLAG_OUTPUT_SPSPPS;
    bool ok = false;
    if (fl.nvEncEncodePicture(enc_, &pp) == NV_ENC_SUCCESS) {
        NV_ENC_LOCK_BITSTREAM lk{};
        lk.version = NV_ENC_LOCK_BITSTREAM_VER;
        lk.outputBitstream = bits_;
        if (fl.nvEncLockBitstream(enc_, &lk) == NV_ENC_SUCCESS) {
            if (encodeMs) *encodeMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            const bool key = lk.pictureType == NV_ENC_PIC_TYPE_IDR || lk.pictureType == NV_ENC_PIC_TYPE_I;
            if (lk.bitstreamSizeInBytes) out(static_cast<const uint8_t*>(lk.bitstreamBufferPtr), lk.bitstreamSizeInBytes, key);
            fl.nvEncUnlockBitstream(enc_, bits_);
            ok = true;
        }
    }
    fl.nvEncUnmapInputResource(enc_, mp.mappedResource);
    return ok;
}

void NvencDirect::Close()
{
    if (fn_ && enc_) {
        auto& fl = F(fn_);
        if (bits_) fl.nvEncDestroyBitstreamBuffer(enc_, bits_);
        if (reg_) fl.nvEncUnregisterResource(enc_, reg_);
        fl.nvEncDestroyEncoder(enc_);
    }
    bits_ = reg_ = enc_ = nullptr;
    if (tex_) { static_cast<ID3D11Texture2D*>(tex_)->Release(); tex_ = nullptr; }
    if (ctx_) { static_cast<ID3D11DeviceContext*>(ctx_)->Release(); ctx_ = nullptr; }
    if (dev_) { static_cast<ID3D11Device*>(dev_)->Release(); dev_ = nullptr; }
    delete static_cast<NV_ENCODE_API_FUNCTION_LIST*>(fn_); fn_ = nullptr;
    delete static_cast<NV_ENC_CONFIG*>(cfg_); cfg_ = nullptr;
    delete static_cast<NV_ENC_INITIALIZE_PARAMS*>(init_); init_ = nullptr;
    if (lib_) { FreeLibrary(static_cast<HMODULE>(lib_)); lib_ = nullptr; }
}
