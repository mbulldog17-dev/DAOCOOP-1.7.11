#include "OnlineChat.h"
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <Xinput.h>
#include <d3d9.h>

#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "Logger.h"
#include "Paths.h"
#include "../d3d9hook.h"
#include "../game.h"
#include "../proxy.h"
#include "../pads.h"
#include "../xinputroute.h"
#include "../modmenu.h"
#include "../equiplock.h"
#include "../targetui.h"

#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "xinput.lib")

namespace
{
    struct Line { uint8_t from; std::wstring name, text; DWORD at; COLORREF colour = 0; };   // 1.7.8: from 0xFE = a notice
    std::mutex g_m;
    std::deque<Line> g_lines;                 // newest last
    std::wstring g_input;                     // what is being typed
    std::atomic<bool> g_typing{ false };
    std::atomic<bool> g_online{ false }, g_host{ false };
    OnlineChat::Sender g_sender = nullptr;
    unsigned g_rev = 1;
    std::wstring g_status;                    // (g_m) 1.7.8: who is in a menu (the game waits), shown till it closes                       // (g_m) the panel's content changed
    DWORD g_lastAdd = 0;
    bool g_enabled = true;
    int g_fadeMs = 12000;
    bool g_loaded = false;
    int g_openKey = VK_OEM_2;                 // [Chat] Key: "/" by default (the US "/ ?" key)
    bool g_skipChar = false;                  // the key that opened the line also makes a character: not typed

    void Load()
    {
        if (g_loaded) return;
        g_loaded = true;
        const std::string ini = Paths::GetConfigPath();
        g_enabled = GetPrivateProfileIntA("Chat", "Enabled", 1, ini.c_str()) != 0;
        g_fadeMs = std::clamp((int)GetPrivateProfileIntA("Chat", "FadeSeconds", 12, ini.c_str()), 2, 600) * 1000;
        char k[32] = {};
        GetPrivateProfileStringA("Chat", "Key", "/", k, sizeof(k), ini.c_str());
        if (!k[0] || _stricmp(k, "none") == 0) g_openKey = 0;
        else if (_stricmp(k, "Enter") == 0) g_openKey = VK_RETURN;
        else if ((k[0] == 'F' || k[0] == 'f') && k[1] >= '1' && k[1] <= '9') { const int n = atoi(k + 1); g_openKey = n >= 1 && n <= 12 ? VK_F1 + n - 1 : VK_OEM_2; }
        else if (!k[1]) {
            const SHORT v = VkKeyScanA(k[0]);   // the key that types this character on this keyboard
            g_openKey = v != -1 ? (v & 0xFF) : VK_OEM_2;
        }
    }

    std::wstring Wide(const std::string& s)
    {
        std::wstring w;
        const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
        if (n > 1) { w.resize(static_cast<size_t>(n - 1)); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n); }
        return w;
    }
    std::string Utf8(const std::wstring& w)
    {
        std::string s;
        const int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr);
        if (n > 1) { s.resize(static_cast<size_t>(n - 1)); WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, nullptr, nullptr); }
        return s;
    }

    void SetTyping(bool on)
    {
        if (g_typing.exchange(on) == on) return;
        Logger::WriteFormat(Logger::Level::Info, "Chat: line %s", on ? "open (typing)" : "closed");
        ProxyBlockKeyboard(on);                // the game's DirectInput keyboard reads nothing while typing
        if (g_host.load() || !on) XInputRouteHoldChat(on);   // and the host's Player 1 controller is idle; back once sent
        std::lock_guard<std::mutex> lock(g_m);
        if (!on) g_input.clear();
        ++g_rev;
    }

    // ---- the keyboard: the game window's messages (typing gives WM_CHAR) ----
    WNDPROC g_origProc = nullptr;
    HWND g_wnd = nullptr;
    bool CanOpen()
    {
        if (!g_enabled || !g_online.load()) return false;
        if (ModMenuOpen()) return false;                          // (Enter / A there belongs to the co-op menu)
        if (!g_host.load()) return true;                          // a friend's own game only shows the picture
        const game::Mode m = game::CurrentMode();
        return m == game::MODE_EXPLORE || m == game::MODE_COMBAT; // (the host: not in menus, conversations, scenes)
    }
    void Send()
    {
        std::wstring text;
        { std::lock_guard<std::mutex> lock(g_m); text = g_input; }
        while (!text.empty() && text.back() == L' ') text.pop_back();
        if (!text.empty() && g_sender) g_sender(0, "", Utf8(text));
    }
    LRESULT CALLBACK ChatProc(HWND w, UINT msg, WPARAM wp, LPARAM lp)
    {
        if (g_typing.load()) {
            switch (msg) {
            case WM_CHAR:
                if (g_skipChar) { g_skipChar = false; return 0; }
                if (wp >= 32 && wp != 127) {
                    std::lock_guard<std::mutex> lock(g_m);
                    if (g_input.size() < 150) { g_input.push_back(static_cast<wchar_t>(wp)); ++g_rev; }
                }
                return 0;
            case WM_KEYDOWN:
                g_skipChar = false;
                if (wp == VK_RETURN) { Send(); SetTyping(false); }
                else if (wp == VK_ESCAPE) SetTyping(false);
                else if (wp == VK_BACK) { std::lock_guard<std::mutex> lock(g_m); if (!g_input.empty()) { g_input.pop_back(); ++g_rev; } }
                return 0;
            case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP: case WM_SYSCHAR: case WM_DEADCHAR:
                return 0;
            default: break;
            }
        } else if (msg == WM_KEYDOWN && g_openKey && (int)wp == g_openKey && !(lp & (1 << 30)) && CanOpen()) {
            g_skipChar = g_openKey != VK_RETURN && (g_openKey < VK_F1 || g_openKey > VK_F12);   // its "/" isn't typed
            SetTyping(true);
            return 0;
        }
        return CallWindowProcW(g_origProc, w, msg, wp, lp);
    }
    void Hook()
    {
        HWND w = reinterpret_cast<HWND>(D3D9GameWindow());
        if (!w || w == g_wnd) return;
        WNDPROC old = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(w, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(&ChatProc)));
        if (old) { g_origProc = old; g_wnd = w; Logger::Write(Logger::Level::Info, "Chat: ready (Enter to type in online games)"); }
    }

    // ---- the panel (GDI into a texture, made again only when its content changes) ----
    IDirect3DDevice9* g_dev = nullptr;
    IDirect3DTexture9* g_tex = nullptr;
    int g_texW = 0, g_texH = 0, g_pw = 0, g_ph = 0;
    unsigned g_texRev = 0;
    bool g_texCaret = false;
    int g_texForH = 0;

    COLORREF NameColour(uint8_t from)
    {
        switch (from) {
        case 1: return RGB(232, 190, 96);        // the host: Player 1's gold
        case 2: return RGB(110, 180, 255);       // Player 2: blue
        case 3: return RGB(120, 225, 120);       // Player 3: green
        case 0: return RGB(240, 230, 204);       // this PC's own
        default: return RGB(190, 176, 150);
        }
    }
    HFONT MakeFont(int px, bool bold, bool italic)
    {
        static const wchar_t* kBody[] = { L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static int pick = -1;
        if (pick < 0) {
            pick = 2;
            HDC dc = CreateCompatibleDC(nullptr);
            for (int i = 0; i < 3; ++i) {
                HFONT f = CreateFontW(-20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, kBody[i]);
                HGDIOBJ o = SelectObject(dc, f); wchar_t face[64] = {}; GetTextFaceW(dc, 64, face); SelectObject(dc, o); DeleteObject(f);
                if (_wcsicmp(face, kBody[i]) == 0) { pick = i; break; }
            }
            DeleteDC(dc);
        }
        return CreateFontW(-px, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, italic, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                           ANTIALIASED_QUALITY, DEFAULT_PITCH, kBody[pick]);
    }
    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }
    void Fill(HDC dc, int x0, int y0, int x1, int y1, COLORREF c) { RECT r = { x0, y0, x1, y1 }; HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b); }
    void Grad(HDC dc, int x0, int y0, int x1, int y1, COLORREF a, COLORREF b, bool vertical)
    {
        if (x1 <= x0 || y1 <= y0) return;
        TRIVERTEX v[2] = { { x0, y0, (COLOR16)(GetRValue(a) << 8), (COLOR16)(GetGValue(a) << 8), (COLOR16)(GetBValue(a) << 8), 0 },
                           { x1, y1, (COLOR16)(GetRValue(b) << 8), (COLOR16)(GetGValue(b) << 8), (COLOR16)(GetBValue(b) << 8), 0 } };
        GRADIENT_RECT g = { 0, 1 };
        GdiGradientFill(dc, v, 2, &g, 1, vertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
    }
    void Gem(HDC dc, int cx, int cy, int r, COLORREF c)
    {
        POINT p[4] = { { cx, cy - r }, { cx + r, cy }, { cx, cy + r }, { cx - r, cy } };
        HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
        HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
        Polygon(dc, p, 4);
        SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
    }

    // The panel: the messages (oldest at the top) and, while typing, the line being typed.
    bool Render(IDirect3DDevice9* dev, const std::vector<Line>& lines, const std::wstring& input, bool typing, bool caret, float s)
    {
        auto S = [&](float v) { int x = (int)(v * s + 0.5f); return x < 1 ? 1 : x; };
        const int pw = S(560), pad = S(14);
        HDC dc = CreateCompatibleDC(nullptr);
        HFONT fName = MakeFont(S(19), true, false), fText = MakeFont(S(19), false, false), fHint = MakeFont(S(15), false, true);
        // measure: each message wraps inside the panel
        struct Lay { int h; std::wstring name; };
        std::vector<Lay> lay;
        int total = pad;
        const int textW = pw - pad * 2 - S(14);
        for (const Line& l : lines) {
            const std::wstring name = l.from >= 0xFD ? std::wstring() : (l.name.empty() ? L"?" : l.name) + L":  ";
            HGDIOBJ o = SelectObject(dc, fText);
            RECT r = { 0, 0, textW, 0 };
            DrawTextW(dc, (name + l.text).c_str(), -1, &r, DT_CALCRECT | DT_WORDBREAK | DT_NOPREFIX);
            SelectObject(dc, o);
            lay.push_back({ (int)(r.bottom - r.top) + S(4), name });
            total += lay.back().h;
        }
        const int inputH = typing ? S(40) : 0;
        int ph = total + pad + inputH;
        if (lines.empty() && !typing) { DeleteObject(fName); DeleteObject(fText); DeleteObject(fHint); DeleteDC(dc); return false; }
        if (lines.empty()) ph = pad + inputH;
        const int tw = Pow2(pw), th = Pow2(ph);
        if (!g_tex || g_texW != tw || g_texH != th) {
            if (g_tex) { g_tex->Release(); g_tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex) {
                g_tex = nullptr; DeleteObject(fName); DeleteObject(fText); DeleteObject(fHint); DeleteDC(dc); return false;
            }
            g_texW = tw; g_texH = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = pw; bi.bmiHeader.biHeight = -ph;
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        bool ok = false;
        if (bmp && bits) {
            HGDIOBJ ob = SelectObject(dc, bmp);
            SetBkMode(dc, TRANSPARENT);
            // a plate like the co-op menu's: dark, lighter at the top, gold lines above and below, a gold edge on the left
            Grad(dc, 0, 0, pw, ph, RGB(26, 21, 16), RGB(10, 8, 6), true);
            Grad(dc, 0, 0, pw / 2, 1, RGB(98, 74, 40), RGB(201, 165, 90), false);
            Grad(dc, pw / 2, 0, pw, 1, RGB(201, 165, 90), RGB(30, 24, 18), false);
            Grad(dc, 0, ph - 1, pw / 2, ph, RGB(98, 74, 40), RGB(201, 165, 90), false);
            Grad(dc, pw / 2, ph - 1, pw, ph, RGB(201, 165, 90), RGB(30, 24, 18), false);
            Fill(dc, 0, 0, S(3), ph, RGB(201, 165, 90));
            Gem(dc, S(2), S(2), S(5), RGB(201, 165, 90));
            Gem(dc, S(2), ph - S(3), S(5), RGB(201, 165, 90));
            int y = pad;
            for (size_t i = 0; i < lines.size(); ++i) {
                const Line& l = lines[i];
                RECT r = { pad + S(14), y, pad + S(14) + textW, y + lay[i].h };
                const COLORREF lineC = l.from >= 0xFD ? (l.colour ? l.colour : RGB(150, 200, 240)) : NameColour(l.from);
                Gem(dc, pad + S(4), y + S(11), S(4), lineC);
                // the name in its colour, then the text in cream on the same wrapped lines
                HGDIOBJ o = SelectObject(dc, fName);
                SetTextColor(dc, NameColour(l.from));
                SIZE ns = {}; GetTextExtentPoint32W(dc, lay[i].name.c_str(), (int)lay[i].name.size(), &ns);
                TextOutW(dc, r.left, r.top, lay[i].name.c_str(), (int)lay[i].name.size());
                SelectObject(dc, fText);
                SetTextColor(dc, l.from >= 0xFD ? lineC : RGB(236, 226, 202));
                // the first line after the name, the rest wrapped under it
                std::wstring text = l.text;
                const int firstW = textW - ns.cx;
                size_t cut = text.size();
                {
                    SIZE ts = {};
                    GetTextExtentPoint32W(dc, text.c_str(), (int)text.size(), &ts);
                    if (ts.cx > firstW) {
                        cut = 0;
                        size_t lastSpace = 0;
                        for (size_t k = 1; k <= text.size(); ++k) {
                            GetTextExtentPoint32W(dc, text.c_str(), (int)k, &ts);
                            if (ts.cx > firstW) break;
                            cut = k;
                            if (text[k - 1] == L' ') lastSpace = k;
                        }
                        if (lastSpace > 0 && cut < text.size()) cut = lastSpace;
                    }
                }
                TextOutW(dc, r.left + ns.cx, r.top, text.c_str(), (int)cut);
                if (cut < text.size()) {
                    RECT rest = { r.left, r.top + S(22), r.right, r.bottom + S(30) };
                    const std::wstring tail = text.substr(cut);
                    DrawTextW(dc, tail.c_str(), -1, &rest, DT_WORDBREAK | DT_NOPREFIX);
                }
                SelectObject(dc, o);
                y += lay[i].h;
            }
            if (typing) {
                const int iy = ph - inputH;
                Fill(dc, pad, iy + S(4), pw - pad, iy + inputH - S(6), RGB(40, 14, 10));          // the line: the menu's red band
                Fill(dc, pad, iy + S(4), pw - pad, iy + S(5), RGB(120, 52, 30));
                Fill(dc, pad, iy + inputH - S(7), pw - pad, iy + inputH - S(6), RGB(120, 52, 30));
                Gem(dc, pad + S(10), iy + inputH / 2 - S(1), S(5), RGB(240, 214, 140));
                HGDIOBJ o = SelectObject(dc, fText);
                SetTextColor(dc, RGB(244, 236, 214));
                std::wstring shown = input + (caret ? L"|" : L" ");
                RECT r = { pad + S(24), iy + S(4), pw - pad - S(150), iy + inputH - S(6) };
                // the end of a long line stays in view
                SIZE ts = {}; GetTextExtentPoint32W(dc, shown.c_str(), (int)shown.size(), &ts);
                while (ts.cx > r.right - r.left && shown.size() > 1) { shown.erase(0, 1); GetTextExtentPoint32W(dc, shown.c_str(), (int)shown.size(), &ts); }
                DrawTextW(dc, shown.c_str(), -1, &r, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
                SelectObject(dc, fHint);
                SetTextColor(dc, RGB(146, 130, 106));
                RECT hr = { pw - pad - S(150), iy + S(4), pw - pad - S(8), iy + inputH - S(6) };
                DrawTextW(dc, L"Enter send \x00B7 Esc close", -1, &hr, DT_RIGHT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
                SelectObject(dc, o);
            }
            GdiFlush();
            D3DLOCKED_RECT lr;
            if (SUCCEEDED(g_tex->LockRect(0, &lr, nullptr, 0))) {
                for (int yy = 0; yy < th; ++yy) {
                    uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + yy * lr.Pitch);
                    if (yy >= ph) { std::memset(dst, 0, size_t(tw) * 4); continue; }
                    const uint32_t* src = static_cast<const uint32_t*>(bits) + size_t(yy) * pw;
                    for (int x = 0; x < pw; ++x) dst[x] = (src[x] & 0x00FFFFFF) | 0xDC000000u;
                    if (tw > pw) std::memset(dst + pw, 0, size_t(tw - pw) * 4);
                }
                g_tex->UnlockRect(0);
                ok = true;
            }
            SelectObject(dc, ob);
            DeleteObject(bmp);
        }
        DeleteObject(fName); DeleteObject(fText); DeleteObject(fHint);
        DeleteDC(dc);
        if (ok) { g_pw = pw; g_ph = ph; }
        return ok;
    }
    struct Vtx { float x, y, z, rhw; DWORD c; float u, v; };
}

namespace OnlineChat
{
    void SetSender(Sender s) { g_sender = s; }

    void SetOnline(bool on, bool host)
    {
        Load();
        g_host.store(host);
        if (g_online.exchange(on) != on && !on) { SetTyping(false); Clear(); }
    }

    bool Active() { return g_enabled && g_online.load(); }
    bool Typing() { return g_typing.load(); }

    void Open() { if (CanOpen() && !g_typing.load()) SetTyping(true); }
    void Close() { SetTyping(false); }

    void Add(uint8_t from, const std::string& nameUtf8, const std::string& textUtf8)
    {
        Load();
        if (!g_enabled) return;
        Line l{ from, Wide(nameUtf8), Wide(textUtf8), GetTickCount() };
        for (wchar_t& c : l.text) if (c < 32) c = L' ';
        Logger::WriteFormat(Logger::Level::Info, "Chat: %s: %s", nameUtf8.c_str(), textUtf8.c_str());
        std::lock_guard<std::mutex> lock(g_m);
        g_lines.push_back(std::move(l));
        while (g_lines.size() > 6) g_lines.pop_front();
        g_lastAdd = GetTickCount();
        ++g_rev;
    }

    void SetStatus(const std::wstring& text)
    {
        std::wstring t = text;
        while (!t.empty() && t.back() == L' ') t.pop_back();
        std::lock_guard<std::mutex> lock(g_m);
        if (t == g_status) return;
        g_status = t;
        ++g_rev;
    }

    void Notice(const wchar_t* text, uint32_t rgb)
    {
        if (!text || !*text) return;
        Load();
        std::wstring t = text;
        for (wchar_t& c : t) if (c < 32) c = L' ';
        const DWORD now = GetTickCount();
        {
            std::lock_guard<std::mutex> lock(g_m);
            // the same notice again within 4 s: not repeated
            for (const Line& l : g_lines) if (l.from == 0xFE && l.text == t && now - l.at < 4000) return;
            Line l{ 0xFE, L"", t, now, rgb ? RGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF) : 0 };
            g_lines.push_back(std::move(l));
            while (g_lines.size() > 6) g_lines.pop_front();
            g_lastAdd = now;
            ++g_rev;
        }
        Logger::WriteFormat(Logger::Level::Info, "Notice: %s", Utf8(t).c_str());
        // the host's notices reach its friends' screens too
        if (g_sender && g_online.load() && g_host.load()) g_sender(0xFE, "", Utf8(t));
    }

    void Say(uint8_t localPlayer, const std::wstring& name, const std::wstring& text)
    {
        if (g_sender && Active()) g_sender(localPlayer, Utf8(name), Utf8(text));
    }

    void Clear()
    {
        std::lock_guard<std::mutex> lock(g_m);
        g_lines.clear();
        g_status.clear();
        ++g_rev;
    }

    void Draw(IDirect3DDevice9* dev)
    {
        if (!dev) return;
        if (dev != g_dev) { g_tex = nullptr; g_dev = dev; g_texRev = 0; }   // (the old texture belongs to the old device)
        Load();
        if (g_online.load() && g_enabled) Hook();
        else {
            if (g_typing.load()) SetTyping(false);
            // offline (or chat off): only notices and the menu status are shown (nothing to draw: it returns below)
        }
        const DWORD now = GetTickCount();
        // the host: Player 1 opens the line from the keyboard only; B on controller 1 still closes it
        if (g_host.load()) {
            XINPUT_STATE st{};
            const bool got = PadsIndex(PLAYER_2) != 0 && PadsIndex(PLAYER_3) != 0 && XInputGetState(0, &st) == ERROR_SUCCESS;
            // B closes the line without sending (like Esc)
            static bool bWas = true;
            const bool b = got && (st.Gamepad.wButtons & XINPUT_GAMEPAD_B) != 0;
            if (b && !bWas && g_typing.load()) SetTyping(false);
            bWas = b;
        }
        const bool typing = g_typing.load();
        std::vector<Line> lines; std::wstring input, status; unsigned rev; DWORD last;
        {
            std::lock_guard<std::mutex> lock(g_m);
            lines.assign(g_lines.begin(), g_lines.end());
            input = g_input; rev = g_rev; last = g_lastAdd; status = g_status;
        }
        // shown while typing, and for a while after the newest message (fading out over its last 2 seconds);
        // a menu notice stays while it's true
        float alpha = 1.f;
        const bool fresh = !lines.empty() && now - last <= (DWORD)g_fadeMs;
        if (!typing) {
            if (!fresh) lines.clear();
            if (lines.empty() && status.empty()) return;
            if (status.empty()) {
                const DWORD left = (DWORD)g_fadeMs - (now - last);
                if (left < 2000) alpha = left / 2000.f;
            }
        }
        if (!status.empty()) {
            Line st{ 0xFD, L"", status, now, RGB(240, 214, 140) };
            lines.insert(lines.begin(), st);
        }
        if (!fresh && !typing) rev ^= 0x80000000u;   // (the panel without the old lines is another picture)
        int W = 0, H = 0;
        if (!D3D9BackBufferSize(&W, &H) || W <= 0 || H <= 0) return;
        const float s = std::max(0.5f, H / 1080.f);
        const bool caret = typing && ((now / 500) & 1) == 0;
        if (!g_tex || rev != g_texRev || caret != g_texCaret || g_texForH != H) {
            if (!Render(dev, lines, input, typing, caret, s)) return;
            g_texRev = rev; g_texCaret = caret; g_texForH = H;
        }
        // bottom left, just above the player's health bar: Player 1's (the game's bar over the quickbar) on the host,
        // the friend's own (their HUD at the bottom left of their picture) on a friend's PC
        const float x0 = (float)(int)(24 * s) - 0.5f;
        const float bottom = (float)H - (g_host.load() || !g_online.load() ? 132.f : 168.f) * s;
        const float y0 = bottom - g_ph - 0.5f;
        IDirect3DStateBlock9* sb = D3D9SaveState(dev, 4);
        if (!sb) return;
        IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
        dev->GetRenderTarget(0, &oldRt);
        dev->GetDepthStencilSurface(&oldDs);
        if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
            dev->SetRenderTarget(0, bb);
            dev->SetDepthStencilSurface(nullptr);
            const bool began = SUCCEEDED(dev->BeginScene());
            D3DVIEWPORT9 vp = { 0, 0, (DWORD)W, (DWORD)H, 0.f, 1.f };
            dev->SetViewport(&vp);
            dev->SetVertexShader(nullptr);
            dev->SetPixelShader(nullptr);
            dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
            dev->SetRenderState(D3DRS_ZENABLE, FALSE);
            dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
            dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
            dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
            dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
            dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
            dev->SetRenderState(D3DRS_LIGHTING, FALSE);
            dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
            dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
            dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
            dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
            dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
            dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
            dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
            dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
            dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
            dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
            dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
            dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
            dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
            dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
            dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
            dev->SetTexture(0, g_tex);
            const DWORD c = ((DWORD)(alpha * 255.f + 0.5f) << 24) | 0xFFFFFF;
            const float u1 = (float)g_pw / g_texW, v1 = (float)g_ph / g_texH;
            const Vtx q[4] = { { x0, y0, 0, 1, c, 0, 0 }, { x0 + g_pw, y0, 0, 1, c, u1, 0 },
                               { x0, y0 + g_ph, 0, 1, c, 0, v1 }, { x0 + g_pw, y0 + g_ph, 0, 1, c, u1, v1 } };
            dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, q, sizeof(Vtx));
            dev->SetTexture(0, nullptr);
            if (began) dev->EndScene();
            bb->Release();
        }
        if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
        dev->SetDepthStencilSurface(oldDs);
        if (oldDs) oldDs->Release();
        sb->Apply();
    }
}
