#pragma once
// 1.7.8 text chat for online games, like other multiplayer games: a panel at the bottom left, just above the player's
// health bar, in the co-op menu's look. Keyboard: Enter (or START on the controller) opens the line, Enter sends, Esc closes (the game doesn't get
// the keys meanwhile). Controller: quick phrases in the co-op menu's Chat tab. Messages fade after a while and come
// back while typing. Drawn on each PC after its picture was taken (never in the stream).
#include <cstdint>
#include <string>

struct IDirect3DDevice9;

namespace OnlineChat
{
    // The online code sends a message this PC wrote: who (0 this PC's own player; 2/3 a co-op player on the host's PC
    // using quick chat), their name ("" = the online code's own), the text (UTF-8). It shows it here too (Add).
    using Sender = void (*)(uint8_t localPlayer, const std::string& name, const std::string& text);
    void SetSender(Sender s);
    // online now (a host with friends, a friend watching); host: whose panel position (above Player 1's health bar)
    void SetOnline(bool on, bool host);
    bool Active();
    // a message to show. from: 1 host, 2 / 3 Player 2 / 3, 4+ a friend without a player, 0 this PC's own (a friend)
    void Add(uint8_t from, const std::string& nameUtf8, const std::string& textUtf8);
    // 1.7.8: the mod's own messages (were the game's big blue banner), in the panel; a host's go to its friends too
    void Notice(const wchar_t* text, uint32_t rgb);
    void SetStatus(const std::wstring& text);   // 1.7.8: "Player 2 is in a menu..." while true ("" = none)
    void Say(uint8_t localPlayer, const std::wstring& name, const std::wstring& text);   // quick chat (co-op menu)
    bool Typing();
    void Close();                       // (B on the controller: closed without sending)
    void Open();                        // 1.7.8: START on the controller opens the line (then the keyboard types)
    void Draw(IDirect3DDevice9* dev);   // render thread, once a frame
    void Clear();
}
