#pragma once
// The public game list (1.4.0): talks to the DAOCoop lobby server (lobby-server/worker.js) over
// HTTPS / WebSocket with Windows' own WinHTTP. Same for every store version of the game: no
// Steam or GOG services involved. Everything here runs on its own threads; all calls are safe
// from any thread.
//
//   Host:   HostStart -> listed; HostUpdate (area, open spots, lock); requests arrive with
//           HostTakeRequest, answered with HostAnswer; HostStop.
//   Player: BrowseStart -> BrowseList every frame (asked once, then again on BrowseRefreshNow); JoinAsk ->
//           JoinState until accepted / declined; JoinCancel.
#include <string>
#include <vector>

namespace OnlineLobby
{
    // --- host ---
    struct Request { std::string req, name, cid, addr, lan, country; };
    enum HostStatus { kHostOff, kHostConnecting, kHostListed, kHostFailed };
    void HostStart(const std::string& server, const std::string& version, const std::string& name, int maxPlayers, int open);
    // "key=value&..." (URL-encoded values): name, area, players, max, open, diff, locked. Kept and re-sent after a reconnect.
    void HostUpdate(const std::string& fields);
    void HostAnswer(const std::string& req, bool ok, const std::string& token, const std::string& addr, const std::string& lan, const std::string& why);
    bool HostTakeRequest(Request& out);
    bool HostTakeCancel(std::string& req);
    HostStatus HostState(std::string* why = nullptr);
    void HostStop();

    // --- player: the list ---
    struct Game { std::string id, name, area, diff, country; int players = 1, max = 3, open = 0, minutes = 0; };
    void BrowseStart(const std::string& server, const std::string& version);
    void BrowseStop();
    // The latest list; status: "" when fine, else what went wrong. Returns false before the first answer.
    bool BrowseList(std::vector<Game>& out, std::string& status);
    void BrowseRefreshNow();

    // --- player: one join request ---
    enum JoinStatus { kJoinNone, kJoinWaiting, kJoinAccepted, kJoinDeclined };
    void JoinAsk(const std::string& server, const std::string& version, const std::string& hostId, const std::string& name,
                 const std::string& cid, const std::string& addr, const std::string& lan);
    JoinStatus JoinState(std::string& token, std::string& addr, std::string& lan, std::string& why);
    void JoinCancel();

    std::string UrlEncode(const std::string& s);
}
