#include "OnlineVoice.h"
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <objbase.h>
#include <mmreg.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <audiopolicy.h>
#include <ks.h>
#include <ksmedia.h>
#include <propsys.h>
#include <dmo.h>
#include <wmcodecdsp.h>
#include <uuids.h>
#include <Xinput.h>
#include <d3d9.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "Logger.h"
#include "OnlineAudio.h"
#include "OnlineChat.h"
#include "OnlineProtocol.h"
#include "Paths.h"
#include "../d3d9hook.h"

#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "msdmo.lib")
#pragma comment(lib, "dmoguids.lib")
#pragma comment(lib, "wmcodecdspuuid.lib")
#pragma comment(lib, "strmiids.lib")
#pragma comment(lib, "xinput9_1_0.lib")

using Microsoft::WRL::ComPtr;
namespace P = OnlineProtocol;

namespace
{
    constexpr int kRate = P::kVoiceRate;
    constexpr int kFrame = P::kVoiceFrame;
    constexpr int kMaxSpeakers = 8;

    // ---------------- settings ([Voice] in DAOCoop.ini) ----------------
    struct Settings
    {
        bool enabled = true;
        bool echoCancel = true;
        int sensitivity = 50;      // 0-100
        int gateDb = -48;          // speech louder than this is sent
        int volume = 100;          // %
        int bufferMs = 60;
        int micKey = VK_PAUSE;
        bool showMicOff = true;
    };
    int IniInt(const char* key, int fallback)
    {
        return static_cast<int>(GetPrivateProfileIntA("Voice", key, fallback, Paths::GetConfigPath().c_str()));
    }
    int KeyByName(const char* t)
    {
        if (!t[0] || _stricmp(t, "none") == 0) return 0;
        if ((t[0] == 'F' || t[0] == 'f') && t[1] >= '1' && t[1] <= '9') { const int n = std::atoi(t + 1); if (n >= 1 && n <= 12) return VK_F1 + n - 1; }
        if (_stricmp(t, "Pause") == 0) return VK_PAUSE;
        if (_stricmp(t, "ScrollLock") == 0) return VK_SCROLL;
        if (_stricmp(t, "Insert") == 0) return VK_INSERT;
        if (_stricmp(t, "Home") == 0) return VK_HOME;
        if (_stricmp(t, "End") == 0) return VK_END;
        if (_stricmp(t, "PageUp") == 0) return VK_PRIOR;
        if (_stricmp(t, "PageDown") == 0) return VK_NEXT;
        if (t[1] == 0 && ((t[0] >= 'A' && t[0] <= 'Z') || (t[0] >= '0' && t[0] <= '9'))) return t[0];
        if (t[1] == 0 && t[0] >= 'a' && t[0] <= 'z') return t[0] - 'a' + 'A';
        return VK_PAUSE;
    }
    Settings LoadSettings()
    {
        Settings s;
        s.enabled = IniInt("Enabled", 1) != 0;
        s.echoCancel = IniInt("EchoCancel", 1) != 0;
        // MicSensitivity 0-100: higher sends quieter speech too (50 = -48 dB)
        s.sensitivity = std::clamp(IniInt("MicSensitivity", 50), 0, 100);
        s.gateDb = -30 - s.sensitivity * 36 / 100;   // 0 -> -30 dB, 50 -> -48 dB, 100 -> -66 dB
        s.volume = std::clamp(IniInt("Volume", 100), 0, 400);
        s.bufferMs = std::clamp(IniInt("BufferMs", 60), 20, 400);
        s.showMicOff = IniInt("ShowMicOff", 1) != 0;
        char key[32]{};
        GetPrivateProfileStringA("Voice", "MicKey", "Pause", key, sizeof(key), Paths::GetConfigPath().c_str());
        s.micKey = KeyByName(key);
        return s;
    }

    // ---------------- state ----------------
    std::mutex g_mutex;                     // everything below unless noted
    Settings g_s;
    OnlineVoice::Sink g_sink;
    std::atomic<bool> g_on{ false };
    std::atomic<bool> g_micOn{ true };
    std::atomic<unsigned> g_settingsRev{ 1 };   // 1.7.2 menu: settings changed while running
    bool g_loaded = false;                      // (g_mutex) g_s read from the ini
    std::atomic<uint32_t> g_sentAt{ 0 }, g_toggledAt{ 0 };
    std::string g_capStatus = "off", g_playStatus = "off";
    // (never destroyed: the game can close while online, and a joinable std::thread at exit ends the process)
    std::thread& g_capThread = *new std::thread();
    std::thread& g_playThread = *new std::thread();

    struct Speaker
    {
        std::map<uint32_t, std::vector<int16_t>> q;
        uint32_t next = 0, firstAt = 0, heardAt = 0;
        bool playing = false;
        std::vector<int16_t> cur;
        size_t pos = 0;
        uint8_t level = 0;
        std::string name;
    };
    Speaker g_spk[kMaxSpeakers];

    uint32_t Now() { return GetTickCount(); }

    bool GameInFront()
    {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        return pid == GetCurrentProcessId();
    }

    void SetMic(bool on, const char* how)
    {
        g_micOn.store(on);
        uint32_t t = Now(); if (!t) t = 1;
        g_toggledAt.store(t);
        WritePrivateProfileStringA("Voice", "MicOn", on ? "1" : "0", Paths::GetConfigPath().c_str());
        Logger::WriteFormat(Logger::Level::Info, "Voice: microphone %s (%s)", on ? "on" : "off", how);
    }

    // ---------------- the mic on / off switch (capture thread) ----------------
    struct Toggle
    {
        bool keyWas = false;

        void Poll(const Settings& s)
        {
            if (s.micKey)
            {
                const bool down = GameInFront() && !OnlineChat::Typing() && (GetAsyncKeyState(s.micKey) & 0x8001) != 0;   // (a quick tap too)
                if (down && !keyWas) SetMic(!g_micOn.load(), "key");
                keyWas = down;
            }
        }
    };

    // ---------------- recording ----------------
    // IMediaBuffer for the voice capture DSP's output
    class MediaBuf final : public IMediaBuffer
    {
    public:
        explicit MediaBuf(DWORD max) : m_max(max), m_data(new BYTE[max]) {}
        ~MediaBuf() { delete[] m_data; }
        STDMETHODIMP QueryInterface(REFIID riid, void** ppv) override
        {
            if (!ppv) return E_POINTER;
            if (riid == __uuidof(IUnknown) || riid == __uuidof(IMediaBuffer)) { *ppv = static_cast<IMediaBuffer*>(this); AddRef(); return S_OK; }
            *ppv = nullptr;
            return E_NOINTERFACE;
        }
        STDMETHODIMP_(ULONG) AddRef() override { return static_cast<ULONG>(InterlockedIncrement(&m_ref)); }
        STDMETHODIMP_(ULONG) Release() override { const LONG r = InterlockedDecrement(&m_ref); if (!r) delete this; return static_cast<ULONG>(r); }
        STDMETHODIMP SetLength(DWORD len) override { if (len > m_max) return E_INVALIDARG; m_len = len; return S_OK; }
        STDMETHODIMP GetMaxLength(DWORD* max) override { if (!max) return E_POINTER; *max = m_max; return S_OK; }
        STDMETHODIMP GetBufferAndLength(BYTE** buf, DWORD* len) override { if (buf) *buf = m_data; if (len) *len = m_len; return S_OK; }
    private:
        LONG m_ref = 1;
        DWORD m_max, m_len = 0;
        BYTE* m_data;
    };

    WAVEFORMATEX VoiceFormat()
    {
        WAVEFORMATEX f{};
        f.wFormatTag = WAVE_FORMAT_PCM;
        f.nChannels = 1;
        f.nSamplesPerSec = kRate;
        f.wBitsPerSample = 16;
        f.nBlockAlign = 2;
        f.nAvgBytesPerSec = kRate * 2;
        return f;
    }

    // Whatever the mic gives -> 16 kHz mono s16 (only when Windows can't convert it itself).
    struct Down
    {
        int channels = 1, rate = kRate, bits = 16;
        bool isFloat = false;
        double step = 1.0, pos = 0.0;
        std::vector<float> hist;
        void Setup(const WAVEFORMATEX* f)
        {
            channels = std::max<int>(1, f->nChannels);
            rate = static_cast<int>(f->nSamplesPerSec);
            bits = f->wBitsPerSample;
            isFloat = f->wFormatTag == WAVE_FORMAT_IEEE_FLOAT;
            if (f->wFormatTag == WAVE_FORMAT_EXTENSIBLE && f->cbSize >= 22)
                isFloat = IsEqualGUID(reinterpret_cast<const WAVEFORMATEXTENSIBLE*>(f)->SubFormat, KSDATAFORMAT_SUBTYPE_IEEE_FLOAT) != 0;
            step = static_cast<double>(rate) / kRate;
            pos = 0; hist.clear();
        }
        float Sample(const BYTE* p) const
        {
            if (isFloat) { float v; std::memcpy(&v, p, 4); return v; }
            switch (bits)
            {
            case 16: { int16_t v; std::memcpy(&v, p, 2); return v / 32768.0f; }
            case 24: { const int32_t v = (static_cast<int32_t>(p[2]) << 24 | p[1] << 16 | p[0] << 8) >> 8; return v / 8388608.0f; }
            case 32: { int32_t v; std::memcpy(&v, p, 4); return static_cast<float>(v / 2147483648.0); }
            default: return 0.0f;
            }
        }
        void Feed(const BYTE* data, UINT32 frames, bool silent, std::vector<int16_t>& out)
        {
            const int bytes = (isFloat ? 32 : bits) / 8, block = bytes * channels;
            for (UINT32 i = 0; i < frames; ++i)
            {
                float v = 0;
                if (!silent && data)
                {
                    const BYTE* f = data + size_t(i) * block;
                    for (int c = 0; c < channels; ++c) v += Sample(f + c * bytes);
                    v /= static_cast<float>(channels);
                }
                hist.push_back(v);
            }
            while (pos + 1.0 < static_cast<double>(hist.size()))
            {
                const size_t i = static_cast<size_t>(pos);
                const float t = static_cast<float>(pos - static_cast<double>(i));
                const float v = hist[i] * (1.0f - t) + hist[i + 1] * t;
                out.push_back(static_cast<int16_t>(std::clamp(v, -1.0f, 1.0f) * 32767.0f));
                pos += step;
            }
            const size_t used = std::min(static_cast<size_t>(pos), hist.empty() ? 0 : hist.size() - 1);
            hist.erase(hist.begin(), hist.begin() + static_cast<std::ptrdiff_t>(used));
            pos -= static_cast<double>(used);
        }
    };

    // The mic, opened while it is on. Echo cancelling (Windows' voice capture DSP: the speakers' sound is taken
    // out of the mic's) when [Voice] EchoCancel=1 and it works; else the plain default mic.
    struct Mic
    {
        ComPtr<IMediaObject> dmo;
        MediaBuf* dmoBuf = nullptr;
        int dmoFails = 0;
        ComPtr<IAudioClient> client;
        ComPtr<IAudioCaptureClient> cap;
        Down down;
        bool convert = false;
        std::string mode;
        bool echoFailed = false;            // (don't try the DSP again this session)

        bool OpenEcho(std::string& why)
        {
            HRESULT hr = CoCreateInstance(CLSID_CWMAudioAEC, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dmo));
            if (FAILED(hr)) { char t[64]; std::snprintf(t, sizeof(t), "echo cancelling not available (0x%08lX)", static_cast<unsigned long>(hr)); why = t; return false; }
            ComPtr<IPropertyStore> ps;
            if (SUCCEEDED(dmo.As(&ps)))
            {
                PROPVARIANT pv; PropVariantInit(&pv);
                pv.vt = VT_I4; pv.lVal = SINGLE_CHANNEL_AEC;
                ps->SetValue(MFPKEY_WMAAECMA_SYSTEM_MODE, pv);
            }
            DMO_MEDIA_TYPE mt{};
            hr = MoInitMediaType(&mt, sizeof(WAVEFORMATEX));
            if (SUCCEEDED(hr))
            {
                mt.majortype = MEDIATYPE_Audio;
                mt.subtype = MEDIASUBTYPE_PCM;
                mt.lSampleSize = 0;
                mt.bFixedSizeSamples = TRUE;
                mt.bTemporalCompression = FALSE;
                mt.formattype = FORMAT_WaveFormatEx;
                const WAVEFORMATEX f = VoiceFormat();
                std::memcpy(mt.pbFormat, &f, sizeof(f));
                hr = dmo->SetOutputType(0, &mt, 0);
                MoFreeMediaType(&mt);
            }
            if (SUCCEEDED(hr)) hr = dmo->AllocateStreamingResources();
            if (FAILED(hr)) { char t[64]; std::snprintf(t, sizeof(t), "echo cancelling did not start (0x%08lX)", static_cast<unsigned long>(hr)); why = t; dmo.Reset(); return false; }
            dmoBuf = new MediaBuf(kRate * 2);
            dmoFails = 0;
            mode = "echo cancelling";
            return true;
        }

        bool OpenPlain(std::string& why)
        {
            ComPtr<IMMDeviceEnumerator> en;
            ComPtr<IMMDevice> dev;
            HRESULT hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, IID_PPV_ARGS(&en));
            if (SUCCEEDED(hr)) hr = en->GetDefaultAudioEndpoint(eCapture, eConsole, &dev);
            if (FAILED(hr)) { why = "no microphone found"; return false; }
            hr = dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf()));
            WAVEFORMATEX want = VoiceFormat();
            if (SUCCEEDED(hr))
                hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
                    200000, 0, &want, nullptr);
            convert = false;
            if (FAILED(hr) && client)
            {
                client.Reset();
                WAVEFORMATEX* mix = nullptr;
                if (SUCCEEDED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf()))) &&
                    SUCCEEDED(client->GetMixFormat(&mix)) && mix)
                {
                    hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 200000, 0, mix, nullptr);
                    if (SUCCEEDED(hr)) { down.Setup(mix); convert = true; }
                    CoTaskMemFree(mix);
                }
            }
            if (SUCCEEDED(hr)) hr = client->GetService(IID_PPV_ARGS(&cap));
            if (SUCCEEDED(hr)) hr = client->Start();
            if (FAILED(hr))
            {
                char t[160];
                std::snprintf(t, sizeof(t), "the microphone did not start (0x%08lX - is \"Let desktop apps access your microphone\" on in Windows' privacy settings?)",
                    static_cast<unsigned long>(hr));
                why = t;
                cap.Reset(); client.Reset();
                return false;
            }
            mode = "microphone (no echo cancelling)";
            return true;
        }

        bool Open(const Settings& s, std::string& why)
        {
            why.clear();
            if (s.echoCancel && !echoFailed)
            {
                if (OpenEcho(why)) return true;
                echoFailed = true;
                Logger::WriteFormat(Logger::Level::Warning, "Voice: %s - using the plain microphone", why.c_str());
            }
            return OpenPlain(why);
        }

        void Close()
        {
            if (dmo) { dmo->FreeStreamingResources(); dmo.Reset(); }
            if (dmoBuf) { dmoBuf->Release(); dmoBuf = nullptr; }
            if (client) client->Stop();
            cap.Reset(); client.Reset();
            mode.clear();
        }

        bool IsOpen() const { return dmo || client; }

        // What came in since last time, appended. False: the mic stopped working.
        bool Read(std::vector<int16_t>& out)
        {
            if (dmo)
            {
                for (int guard = 0; guard < 50; ++guard)
                {
                    DMO_OUTPUT_DATA_BUFFER ob{};
                    ob.pBuffer = dmoBuf;
                    dmoBuf->SetLength(0);
                    DWORD status = 0;
                    const HRESULT hr = dmo->ProcessOutput(0, 1, &ob, &status);
                    if (FAILED(hr))
                    {
                        // (it fails while nothing plays on the speakers: then it simply has nothing yet)
                        if (++dmoFails > 300) { Logger::WriteFormat(Logger::Level::Warning, "Voice: echo cancelling keeps failing (0x%08lX)", static_cast<unsigned long>(hr)); return false; }
                        return true;
                    }
                    BYTE* p = nullptr; DWORD len = 0;
                    dmoBuf->GetBufferAndLength(&p, &len);
                    if (len >= 2) { dmoFails = 0; const size_t at = out.size(); out.resize(at + len / 2); std::memcpy(out.data() + at, p, (len / 2) * 2); }
                    if (!(ob.dwStatus & DMO_OUTPUT_DATA_BUFFERF_INCOMPLETE)) break;
                }
                return true;
            }
            if (!cap) return false;
            UINT32 next = 0;
            while (true)
            {
                HRESULT hr = cap->GetNextPacketSize(&next);
                if (FAILED(hr)) return false;
                if (!next) break;
                BYTE* data = nullptr; UINT32 frames = 0; DWORD flags = 0;
                if (FAILED(cap->GetBuffer(&data, &frames, &flags, nullptr, nullptr))) return false;
                const bool silent = (flags & AUDCLNT_BUFFERFLAGS_SILENT) != 0;
                if (convert) down.Feed(data, frames, silent, out);
                else
                {
                    const size_t at = out.size();
                    out.resize(at + frames);
                    if (silent || !data) std::memset(out.data() + at, 0, size_t(frames) * 2);
                    else std::memcpy(out.data() + at, data, size_t(frames) * 2);
                }
                cap->ReleaseBuffer(frames);
            }
            return true;
        }
    };

    void SetCapStatus(const std::string& s) { std::lock_guard<std::mutex> lock(g_mutex); g_capStatus = s; }

    void CaptureMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
        Settings s;
        OnlineVoice::Sink sink;
        { std::lock_guard<std::mutex> lock(g_mutex); s = g_s; sink = g_sink; }
        Toggle toggle;
        Mic mic;
        std::vector<int16_t> pcm, prev;
        bool open = false, failed = false, prevValid = false;
        uint32_t retryAt = 0, openUntil = 0, seq = 0, pollAt = 0;
        float gate = 32768.0f * std::pow(10.0f, s.gateDb / 20.0f);
        unsigned rev = g_settingsRev.load();
        while (g_on.load())
        {
            const uint32_t now = Now();
            if (g_settingsRev.load() != rev)            // changed in the co-op menu
            {
                rev = g_settingsRev.load();
                const bool echoWas = s.echoCancel;
                { std::lock_guard<std::mutex> lock(g_mutex); s = g_s; }
                gate = 32768.0f * std::pow(10.0f, s.gateDb / 20.0f);
                if (s.echoCancel != echoWas) { mic.echoFailed = false; if (mic.IsOpen()) { mic.Close(); failed = false; } }
            }
            if (static_cast<int32_t>(now - pollAt) >= 0) { pollAt = now + 20; toggle.Poll(s); }
            const bool want = g_micOn.load() && s.enabled;
            if (want && !mic.IsOpen() && (!failed || static_cast<int32_t>(now - retryAt) >= 0))
            {
                std::string why;
                if (mic.Open(s, why))
                {
                    failed = false;
                    SetCapStatus("mic: " + mic.mode);
                    Logger::WriteFormat(Logger::Level::Info, "Voice: recording - %s", mic.mode.c_str());
                }
                else
                {
                    if (!failed) Logger::WriteFormat(Logger::Level::Warning, "Voice: cannot record: %s", why.c_str());
                    failed = true;
                    retryAt = now + 10000;
                    SetCapStatus("no mic (" + why + ")");
                }
                pcm.clear(); prevValid = false; open = false;
            }
            else if (!want && mic.IsOpen())
            {
                mic.Close();                    // off really is off: the mic is let go
                SetCapStatus("mic off");
                pcm.clear(); prevValid = false; open = false;
            }
            if (mic.IsOpen())
            {
                if (!mic.Read(pcm))
                {
                    mic.Close();
                    if (s.echoCancel) mic.echoFailed = true;   // the plain mic next
                    retryAt = now + 500; failed = true;
                    SetCapStatus("mic lost - trying again");
                }
                size_t at = 0;
                while (pcm.size() - at >= static_cast<size_t>(kFrame))
                {
                    const int16_t* f = pcm.data() + at;
                    double sum = 0;
                    for (int i = 0; i < kFrame; ++i) sum += static_cast<double>(f[i]) * f[i];
                    const float rms = static_cast<float>(std::sqrt(sum / kFrame));
                    const uint8_t level = static_cast<uint8_t>(std::min(255.0f, rms / 32.0f));
                    if (rms > gate) { if (!open && prevValid && sink) sink(seq++, level, prev.data(), kFrame); open = true; openUntil = now + 400; }
                    else if (open && static_cast<int32_t>(now - openUntil) >= 0) open = false;
                    if (open && sink)
                    {
                        sink(seq++, level, f, kFrame);
                        uint32_t t = now; if (!t) t = 1;
                        g_sentAt.store(t);
                    }
                    prev.assign(f, f + kFrame);     // (sent first when speech starts: the first syllable is not cut)
                    prevValid = true;
                    at += kFrame;
                }
                if (at) pcm.erase(pcm.begin(), pcm.begin() + static_cast<std::ptrdiff_t>(at));
                if (pcm.size() > static_cast<size_t>(kRate)) pcm.clear();
            }
            Sleep(10);
        }
        mic.Close();
        SetCapStatus("off");
        if (SUCCEEDED(co)) CoUninitialize();
    }

    // ---------------- playing ----------------
    // One speaker's next 20 ms: false when there is nothing to play (waiting for enough to start).
    bool Advance(Speaker& k, uint32_t now, int startPackets)
    {
        if (!k.playing)
        {
            if (k.q.empty()) return false;
            if (static_cast<int>(k.q.size()) < startPackets && now - k.firstAt < static_cast<uint32_t>(startPackets * 20 + 40)) return false;
            k.playing = true;
            k.next = k.q.begin()->first;
        }
        while (!k.q.empty() && static_cast<int32_t>(k.q.begin()->first - k.next) < 0) k.q.erase(k.q.begin());   // late
        if (k.q.empty()) { k.playing = false; return false; }          // ran dry: wait for enough again
        auto it = k.q.find(k.next);
        ++k.next;
        k.pos = 0;
        if (it == k.q.end()) { k.cur.assign(kFrame, 0); return true; }   // lost: 20 ms of quiet
        k.cur.swap(it->second);
        k.q.erase(it);
        return true;
    }

    void Mix(int16_t* out, int n, int volume, int startPackets)
    {
        std::vector<int32_t> acc(static_cast<size_t>(n), 0);
        const uint32_t now = Now();
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            for (Speaker& k : g_spk)
            {
                if (k.q.empty() && !k.playing) continue;
                for (int i = 0; i < n; ++i)
                {
                    if (k.pos >= k.cur.size() && !Advance(k, now, startPackets)) break;
                    acc[size_t(i)] += k.cur[k.pos++];
                }
            }
        }
        for (int i = 0; i < n; ++i) out[i] = static_cast<int16_t>(std::clamp(acc[size_t(i)] * volume / 100, -32768, 32767));
    }

    void SetPlayStatus(const std::string& s) { std::lock_guard<std::mutex> lock(g_mutex); g_playStatus = s; }

    void PlaybackMain()
    {
        const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
        Settings s;
        { std::lock_guard<std::mutex> lock(g_mutex); s = g_s; }
        ComPtr<IMMDeviceEnumerator> en;
        ComPtr<IMMDevice> dev;
        ComPtr<IAudioClient> client;
        ComPtr<IAudioRenderClient> render;
        std::wstring instance;
        HRESULT hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, IID_PPV_ARGS(&en));
        if (SUCCEEDED(hr)) hr = en->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
        if (SUCCEEDED(hr)) hr = dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, reinterpret_cast<void**>(client.GetAddressOf()));
        GUID session{};
        CoCreateGuid(&session);                 // its own session: a friend's PC mutes the game's own sound, not this
        WAVEFORMATEX want = VoiceFormat();
        if (SUCCEEDED(hr)) hr = client->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
            200000, 0, &want, &session);
        if (SUCCEEDED(hr)) hr = client->GetService(IID_PPV_ARGS(&render));
        if (SUCCEEDED(hr))
        {
            ComPtr<IAudioSessionControl> c;
            ComPtr<IAudioSessionControl2> c2;
            LPWSTR id = nullptr;
            if (SUCCEEDED(client->GetService(IID_PPV_ARGS(&c))) && SUCCEEDED(c.As(&c2)))
            {
                if (SUCCEEDED(c2->GetSessionInstanceIdentifier(&id)) && id) { instance = id; CoTaskMemFree(id); OnlineAudio::KeepUnmuted(instance, true); }
                c2->SetDuckingPreference(TRUE);
                c->SetDisplayName(L"DAOCoop voice chat", nullptr);
            }
        }
        UINT32 bufferFrames = 0;
        if (SUCCEEDED(hr)) hr = client->GetBufferSize(&bufferFrames);
        if (SUCCEEDED(hr)) hr = client->Start();
        if (FAILED(hr))
        {
            char t[96]; std::snprintf(t, sizeof(t), "cannot play voices (0x%08lX)", static_cast<unsigned long>(hr));
            SetPlayStatus(t);
            Logger::WriteFormat(Logger::Level::Warning, "Voice: %s", t);
        }
        else
        {
            SetPlayStatus("playing voices");
            const UINT32 queue = std::min<UINT32>(bufferFrames, kRate * 30 / 1000);   // ~30 ms in the speakers' queue
            while (g_on.load())
            {
                Sleep(5);
                UINT32 padding = 0;
                if (FAILED(client->GetCurrentPadding(&padding))) { Logger::Write(Logger::Level::Warning, "Voice: the speakers went away - voices stop"); break; }
                if (padding >= queue) continue;
                const UINT32 n = queue - padding;
                BYTE* data = nullptr;
                if (SUCCEEDED(render->GetBuffer(n, &data)) && data)
                {
                    int volume, startNow;
                    { std::lock_guard<std::mutex> lock(g_mutex); volume = g_s.enabled ? g_s.volume : 0; startNow = std::max(1, g_s.bufferMs / 20); }
                    Mix(reinterpret_cast<int16_t*>(data), static_cast<int>(n), volume, startNow);
                    render->ReleaseBuffer(n, 0);
                }
            }
            client->Stop();
        }
        if (!instance.empty()) OnlineAudio::KeepUnmuted(instance, false);
        render.Reset(); client.Reset(); dev.Reset(); en.Reset();
        SetPlayStatus("off");
        if (SUCCEEDED(co)) CoUninitialize();
    }

    // ---------------- the notice (render thread) ----------------
    IDirect3DDevice9* g_dev = nullptr;
    IDirect3DTexture9* g_tex = nullptr;
    std::wstring g_texText;
    int g_texW = 0, g_texH = 0, g_pw = 0, g_ph = 0;

    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }

    // lines: L"\x01text" = highlighted (gold), else white; L"\x02text" = grey
    bool Render(IDirect3DDevice9* dev, const std::vector<std::wstring>& lines, float s)
    {
        const int lineH = std::max(14, static_cast<int>(26 * s));
        HFONT font = CreateFontW(-std::max(12, static_cast<int>(20 * s)), 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, L"Georgia");
        HDC dc = CreateCompatibleDC(nullptr);
        HGDIOBJ oldFont = SelectObject(dc, font);
        int textW = 0;
        for (const auto& l : lines)
        {
            SIZE sz{};
            const wchar_t* t = l.c_str() + ((l[0] == 1 || l[0] == 2) ? 1 : 0);
            GetTextExtentPoint32W(dc, t, static_cast<int>(wcslen(t)), &sz);
            textW = std::max<int>(textW, sz.cx);
        }
        const int pad = std::max(6, static_cast<int>(10 * s));
        const int pw = textW + pad * 2, ph = lineH * static_cast<int>(lines.size()) + pad;
        const int tw = Pow2(pw), th = Pow2(ph);
        if (!g_tex || g_texW != tw || g_texH != th)
        {
            if (g_tex) { g_tex->Release(); g_tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex)
            {
                g_tex = nullptr;
                SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc);
                return false;
            }
            g_texW = tw; g_texH = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
        bi.bmiHeader.biWidth = pw;
        bi.bmiHeader.biHeight = -ph;
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        bool ok = false;
        if (bmp && bits)
        {
            HGDIOBJ oldBmp = SelectObject(dc, bmp);
            RECT all = { 0, 0, pw, ph };
            HBRUSH bg = CreateSolidBrush(RGB(20, 16, 12));
            FillRect(dc, &all, bg);
            DeleteObject(bg);
            SetBkMode(dc, TRANSPARENT);
            for (size_t i = 0; i < lines.size(); ++i)
            {
                const std::wstring& l = lines[i];
                const bool gold = l[0] == 1, grey = l[0] == 2;
                SetTextColor(dc, gold ? RGB(232, 190, 96) : grey ? RGB(170, 160, 144) : RGB(240, 232, 214));
                RECT r = { pad, pad / 2 + static_cast<int>(i) * lineH, pw - pad, pad / 2 + static_cast<int>(i + 1) * lineH };
                DrawTextW(dc, l.c_str() + ((gold || grey) ? 1 : 0), -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
            }
            GdiFlush();
            D3DLOCKED_RECT lr;
            if (SUCCEEDED(g_tex->LockRect(0, &lr, nullptr, 0)))
            {
                for (int y = 0; y < th; ++y)
                {
                    uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch);
                    if (y >= ph) { std::memset(dst, 0, size_t(tw) * 4); continue; }
                    const uint32_t* src = static_cast<const uint32_t*>(bits) + size_t(y) * pw;
                    for (int x = 0; x < pw; ++x) dst[x] = (src[x] & 0x00FFFFFF) | 0xC8000000u;
                    if (tw > pw) std::memset(dst + pw, 0, size_t(tw - pw) * 4);
                }
                g_tex->UnlockRect(0);
                ok = true;
            }
            SelectObject(dc, oldBmp);
            DeleteObject(bmp);
        }
        SelectObject(dc, oldFont);
        DeleteObject(font);
        DeleteDC(dc);
        g_pw = pw; g_ph = ph;
        return ok;
    }

    struct Vtx { float x, y, z, rhw, u, v; };
}

namespace OnlineVoice
{
    void Start(Sink sink)
    {
        if (g_on.load()) return;
        Settings s;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (!g_loaded) { g_s = LoadSettings(); g_loaded = true; g_micOn.store(IniInt("MicOn", 1) != 0); }
            s = g_s;
            g_sink = std::move(sink);
            for (Speaker& k : g_spk) { const std::string n = k.name; k = Speaker{}; k.name = n; }
        }
        g_sentAt.store(0);
        g_toggledAt.store(0);
        g_on.store(true);
        g_capThread = std::thread(CaptureMain);
        g_playThread = std::thread(PlaybackMain);
        Logger::WriteFormat(Logger::Level::Info, "Voice: %s - open mic, %s (switched in the co-op menu: hold START 2 s%s)", s.enabled ? "on" : "off ([Voice] Enabled=0)",
            g_micOn.load() ? "mic on" : "mic off", s.micKey ? ", or the [Voice] MicKey key" : "");
    }

    void Stop()
    {
        if (!g_on.exchange(false)) return;
        if (g_capThread.joinable()) g_capThread.join();
        if (g_playThread.joinable()) g_playThread.join();
        std::lock_guard<std::mutex> lock(g_mutex);
        g_sink = nullptr;
        for (Speaker& k : g_spk) { const std::string n = k.name; k = Speaker{}; k.name = n; }
        Logger::Write(Logger::Level::Info, "Voice: off");
    }

    bool Running() { return g_on.load(); }

    void Received(uint8_t speaker, uint32_t seq, uint8_t level, const int16_t* mono, int samples)
    {
        if (!g_on.load() || speaker == 0 || speaker >= kMaxSpeakers || samples <= 0) return;
        const uint32_t now = Now();
        std::lock_guard<std::mutex> lock(g_mutex);
        if (!g_s.enabled) return;
        Speaker& k = g_spk[speaker];
        if (k.playing && static_cast<int32_t>(seq - k.next) < 0)
        {
            if (static_cast<int32_t>(k.next - seq) < 200) return;   // late: already played past it
            k.q.clear(); k.playing = false;                           // a new run of numbers (they rejoined)
        }
        if (k.q.empty() && !k.playing) k.firstAt = now;
        k.q[seq].assign(mono, mono + samples);
        while (k.q.size() > 12) { k.q.erase(k.q.begin()); if (k.playing) k.next = k.q.begin()->first; }   // never more than ~240 ms behind
        k.heardAt = now ? now : 1;
        k.level = level;
    }

    void SetName(uint8_t speaker, const std::string& utf8)
    {
        if (speaker >= kMaxSpeakers) return;
        std::lock_guard<std::mutex> lock(g_mutex);
        g_spk[speaker].name = utf8;
    }

    void ForgetSpeaker(uint8_t speaker)
    {
        if (speaker >= kMaxSpeakers) return;
        std::lock_guard<std::mutex> lock(g_mutex);
        g_spk[speaker].q.clear();
        g_spk[speaker].playing = false;
        g_spk[speaker].heardAt = 0;
    }

    Prefs GetPrefs()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (!g_loaded) { g_s = LoadSettings(); g_loaded = true; g_micOn.store(IniInt("MicOn", 1) != 0); }
        Prefs p;
        p.enabled = g_s.enabled; p.micOn = g_micOn.load(); p.echoCancel = g_s.echoCancel; p.showMicOff = g_s.showMicOff;
        p.sensitivity = g_s.sensitivity; p.volume = g_s.volume;
        return p;
    }

    void SetPrefs(const Prefs& p)
    {
        const Prefs was = GetPrefs();
        const std::string ini = Paths::GetConfigPath();
        auto put = [&](const char* key, int v) { WritePrivateProfileStringA("Voice", key, std::to_string(v).c_str(), ini.c_str()); };
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_s.enabled = p.enabled; g_s.echoCancel = p.echoCancel; g_s.showMicOff = p.showMicOff;
            g_s.sensitivity = std::clamp(p.sensitivity, 0, 100);
            g_s.gateDb = -30 - g_s.sensitivity * 36 / 100;
            g_s.volume = std::clamp(p.volume, 0, 400);
            if (!p.enabled) for (Speaker& k : g_spk) { k.q.clear(); k.playing = false; k.heardAt = 0; }
        }
        if (p.micOn != was.micOn) SetMic(p.micOn, "co-op menu");
        if (p.enabled != was.enabled) { put("Enabled", p.enabled ? 1 : 0); Logger::WriteFormat(Logger::Level::Info, "Voice: voice chat %s (co-op menu)", p.enabled ? "on" : "off"); }
        if (p.echoCancel != was.echoCancel) put("EchoCancel", p.echoCancel ? 1 : 0);
        if (p.showMicOff != was.showMicOff) put("ShowMicOff", p.showMicOff ? 1 : 0);
        if (p.sensitivity != was.sensitivity) put("MicSensitivity", std::clamp(p.sensitivity, 0, 100));
        if (p.volume != was.volume) put("Volume", std::clamp(p.volume, 0, 400));
        g_settingsRev.fetch_add(1);
    }

    std::string MicStatus()
    {
        if (!g_on.load()) return "";
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_capStatus;
    }

    void Draw(IDirect3DDevice9* dev)
    {
        if (!dev) return;
        if (dev != g_dev) { g_tex = nullptr; g_dev = dev; g_texText.clear(); }   // (the old texture belongs to the old device)
        if (!g_on.load()) return;
        { std::lock_guard<std::mutex> lock(g_mutex); if (!g_s.enabled) return; }
        const uint32_t now = Now();
        std::vector<std::wstring> lines;
        const bool mic = g_micOn.load();
        const uint32_t toggled = g_toggledAt.load();
        bool showOff = true;
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            showOff = g_s.showMicOff;
            if (toggled && now - toggled < 2500)
                lines.push_back(mic ? L"\x01Mic on" : L"\x01Mic off");
            else if (!mic && showOff)
                lines.push_back(L"\x02Mic off");
            const uint32_t sent = g_sentAt.load();
            if (mic && sent && now - sent < 300) lines.push_back(L"You are talking");
            for (int i = 1; i < kMaxSpeakers; ++i)
            {
                const Speaker& k = g_spk[i];
                if (!k.heardAt || now - k.heardAt > 300) continue;
                std::string n = k.name;
                if (n.empty()) n = i == 1 ? "The host" : i <= 3 ? "Player " + std::to_string(i) : "A friend";
                std::wstring w;
                const int len = MultiByteToWideChar(CP_UTF8, 0, n.c_str(), -1, nullptr, 0);
                if (len > 1) { w.resize(static_cast<size_t>(len - 1)); MultiByteToWideChar(CP_UTF8, 0, n.c_str(), -1, &w[0], len); }
                lines.push_back(w + L" is talking");
            }
        }
        if (lines.empty()) return;

        int W = 0, H = 0;
        if (!D3D9BackBufferSize(&W, &H) || W <= 0 || H <= 0) return;
        const float s = std::max(0.5f, H / 1080.f);
        std::wstring key;
        for (const auto& l : lines) { key += l; key += L'\n'; }
        key += std::to_wstring(static_cast<int>(s * 100));
        if (!g_tex || key != g_texText)
        {
            if (!Render(dev, lines, s)) return;
            g_texText = key;
        }
        IDirect3DStateBlock9* sb = D3D9SaveState(dev, 5);
        if (!sb) return;
        IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
        dev->GetRenderTarget(0, &oldRt);
        dev->GetDepthStencilSurface(&oldDs);
        if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb)
        {
            dev->SetRenderTarget(0, bb);
            dev->SetDepthStencilSurface(nullptr);
            if (SUCCEEDED(dev->BeginScene()))
            {
                D3DVIEWPORT9 vp = { 0, 0, static_cast<DWORD>(W), static_cast<DWORD>(H), 0.f, 1.f };
                dev->SetViewport(&vp);
                dev->SetVertexShader(nullptr);
                dev->SetPixelShader(nullptr);
                dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);
                dev->SetTexture(0, g_tex);
                dev->SetRenderState(D3DRS_ZENABLE, FALSE);
                dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
                dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
                dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
                dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
                dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
                dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
                dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
                dev->SetRenderState(D3DRS_LIGHTING, FALSE);
                dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
                dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
                dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
                dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
                dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
                dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
                dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
                dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
                dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
                dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
                dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
                dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
                dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
                dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
                dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
                dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
                dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
                // top middle, under the edge (the party portraits are on the left, the map on the right)
                const float x0 = static_cast<float>((W - g_pw) / 2) - 0.5f, y0 = static_cast<float>(static_cast<int>(H * 0.02f)) - 0.5f;
                const float u1 = static_cast<float>(g_pw) / g_texW, v1 = static_cast<float>(g_ph) / g_texH;
                const Vtx v[4] = {
                    { x0, y0, 0.f, 1.f, 0.f, 0.f },
                    { x0 + g_pw, y0, 0.f, 1.f, u1, 0.f },
                    { x0, y0 + g_ph, 0.f, 1.f, 0.f, v1 },
                    { x0 + g_pw, y0 + g_ph, 0.f, 1.f, u1, v1 },
                };
                dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vtx));
                dev->SetTexture(0, nullptr);
                dev->EndScene();
            }
            bb->Release();
        }
        if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
        dev->SetDepthStencilSurface(oldDs);
        if (oldDs) oldDs->Release();
        sb->Apply();
    }

    std::string Status()
    {
        if (!g_on.load()) return "voice off";
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_capStatus + ", " + g_playStatus;
    }
}
