#pragma once
// Online play (DAOCoop 1.2.27): friends play Player 2 / Player 3 from their own PCs, inside the game.
// The host's game is the only world. It streams its picture and sound to each friend's game, and each
// friend's controller arrives as an extra controller (vpad.h slots 4 and 5), which the co-op lobby
// gives to Player 2 or 3 like a local one. A friend's own game is just a window onto the host's.
//   Host:   Co-op > Online Multiplayer > Host Game        (an invite code shows, copied to the clipboard)
//   Friend: Co-op > Online Multiplayer > Join Game        (copy the code: it connects by itself; or a game
//                                                           on the same network: press A)
// Ported from the Amalur co-op mod (OnlinePlay / OnlineVideo / OnlineAudio / OnlineProtocol); no Steam
// here (the GOG game has no Steam), only invite codes (UPnP opens the host's router port by itself).
// Settings: [Online] in DAOCoop.ini.
// 1.4.0 public list: [Online] LobbyServer = the lobby server (lobby-server/), PublicList = 1 lists hosted
// games there. Players browse it in Join Game and ask to join; the host gets a Yes / No pop-up (1.4.1, popup.h)
// and answers with A / Enter or a click. The lobby's lock button takes the game off the list (invite codes
// still work). Accepted players get a one-time pass and both games send to each other at once, which opens the way through most routers.
#include <string>
#include <vector>

struct IDirect3DDevice9;

namespace OnlinePlay
{
    void Init(const wchar_t* iniPath);   // DllMain: only remembers the ini
    void AfterStartup();                 // startup thread: puts the game's sound back if an old session muted it

    // The game's Present / Reset (render thread, d3d9hook.h).
    void OnPresent(IDirect3DDevice9* dev);
    void OnReset(IDirect3DDevice9* dev);

    // Lobby (main thread / menu).
    std::string StartHosting();          // returns a status line
    std::string OpenJoin();
    void Stop();                         // leave / stop hosting
    bool Hosting();
    int  FriendsPlaying();
    void HostLeftGame();                 // 1.7.0: the host is back in the main menu - the friends are told and let go
    void NotifyExit();                   // 1.7.0: the game is closing - a last goodbye (best effort)               // 1.7.0: hosting, online friends connected now (0-2)
    bool Joining();                      // join window open or watching a host
    bool Watching();                     // a friend: connected to a host
    void StepAway();                     // 1.7.7: a friend: hand their character to the AI (the co-op menu)
    // Lobby lines: code letter ('H' heading, 'W' gold, 'R' green, 'X' grey) + text.
    void LobbyLines(std::vector<std::pair<wchar_t, std::wstring>>& out);
    // Join menus (1.4.3). GamesList: "<status line>|<id>~<label>|..." (up to 6 games, this network's first), "off" when not joining.
    std::wstring GamesList();
    void BrowseRefresh();
    bool AskToJoin(const std::string& id);          // a game from GamesList: ask its host (or join, on this network)
    bool JoinWithCode(const std::string& code);     // false = not a code (the reason shows in GamesList's status)
    std::wstring ClipboardCode();                   // an invite code on the clipboard, or ""
    int  JoinStage();                               // -1 not joining, 0 menus, 1 asking, 2 connecting, 3 playing
    void JoinBack();                                // stop asking / leave the host's game, back to the menus
    // Host (1.4.6): the co-op lobby as friends see it ("<letter><text>|..."), "" when not in the lobby.
    void SetLobbyText(const std::wstring& lines);
    // Host: the lobby's "who can join" button (1.4.1). -1 = no public list (no button), 0 open, 1 locked.
    int  LockState();
    void SetLocked(bool on);
    // Host: what the public list shows (players in the game, 2 or 3, free spots, where the party is).
    void SetHostInfo(int players, int maxPlayers, int open, const std::wstring& area);
    // The friend's name for a controller slot (4/5), "" when none.
    std::wstring FriendName(int slot);

    // Messages for the host's screen (main thread shows them).
    bool TakeMessage(std::wstring& out);

    void Shutdown();
}
