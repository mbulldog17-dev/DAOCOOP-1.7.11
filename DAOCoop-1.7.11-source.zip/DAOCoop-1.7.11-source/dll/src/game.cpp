#include <cwchar>
#include "game.h"
#include "log.h"
#include <cstdio>
#include <cmath>

namespace game {

struct Signature { uintptr_t address; uint8_t bytes[8]; };

// First 8 bytes of each function in the GOG 1.05.13263.0 exe.
static const Signature kSignatures[] = {
    { 0xA2D650, { 0x56, 0x8B, 0xF1, 0x57, 0x8D, 0xBE, 0x38, 0x17 } }, // VM PushInt
    { 0xA2D690, { 0x56, 0x8B, 0xF1, 0x57, 0x8D, 0xBE, 0x38, 0x17 } }, // VM PushFloat
    { 0xA2D730, { 0x6A, 0xFF, 0x68, 0x7B, 0xDC, 0xAA, 0x00, 0x64 } }, // VM PushString
    { 0xA2D890, { 0x6A, 0xFF, 0x68, 0x1B, 0xD5, 0xAB, 0x00, 0x64 } }, // VM PushResource
    { 0xA2D920, { 0x56, 0x8B, 0xF1, 0x83, 0xBE, 0x68, 0x19, 0x00 } }, // VM PushStruct
    { 0xA2D980, { 0x56, 0x8B, 0xF1, 0x57, 0x8D, 0xBE, 0x38, 0x17 } }, // VM PushObject
    { 0xA2F3C0, { 0x8B, 0xD1, 0x8D, 0x8A, 0x38, 0x17, 0x00, 0x00 } }, // VM PopInt
    { 0xA2F410, { 0x8B, 0xD1, 0x8D, 0x8A, 0x38, 0x17, 0x00, 0x00 } }, // VM PopFloat
    { 0xA2F4C0, { 0x56, 0x8B, 0xD1, 0x57, 0x8D, 0xBA, 0x38, 0x17 } }, // VM PopString
    { 0xA2F650, { 0x56, 0x8B, 0xD1, 0x57, 0x8D, 0xBA, 0x38, 0x17 } }, // VM PopStruct
    { 0xA2F390, { 0x53, 0x8B, 0xD9, 0x8B, 0x03, 0x57, 0x8B, 0x7C } }, // VM stack truncate
    { 0xA2F6D0, { 0x8B, 0xD1, 0x8D, 0x8A, 0x38, 0x17, 0x00, 0x00 } }, // VM PopObject
    { 0xA2F720, { 0x56, 0x8B, 0xD1, 0x57, 0x8D, 0xBA, 0x38, 0x17 } }, // VM PopArray
    { 0xA2F7C0, { 0x8B, 0xC1, 0x8B, 0x48, 0x08, 0x85, 0xC9, 0x74 } }, // VM array free
    { 0x413660, { 0x8B, 0x44, 0x24, 0x04, 0x6A, 0xFF, 0x50, 0xE8 } }, // operator new
    { 0x4136C0, { 0xE9, 0xBB, 0x59, 0x0A, 0x00, 0xCC, 0xCC, 0xCC } }, // operator delete
    { 0x4C0DB0, { 0x56, 0x8B, 0xF1, 0x83, 0x7E, 0x18, 0x08, 0x72 } }, // string destructor
    { 0x64DD60, { 0x8B, 0x54, 0x24, 0x04, 0x81, 0xFA, 0x5F, 0x03 } }, // RunCommand
    { 0x640060, { 0x8B, 0x41, 0x74, 0x85, 0xC0, 0x74, 0x04, 0x8B } }, // GameModeController::GetMode
    { 0x838210, { 0x8A, 0x41, 0x0C, 0xC3, 0xCC, 0xCC, 0xCC, 0xCC } }, // IsPaused
    { 0x5D58C0, { 0x51, 0x8B, 0x54, 0x24, 0x08, 0x8B, 0x89, 0xCC } }, // client object by id
    { 0x51B5E0, { 0x6A, 0xFF, 0x68, 0x70, 0x07, 0xA8, 0x00, 0x64 } }, // GUI SendMessage handler
    { 0x66AC60, { 0x51, 0x8B, 0x0D, 0x80, 0xD0, 0xC1, 0x00, 0x56 } }, // IsPartyAIEnabled (layout of the AI flag)
};

// Quiet version of the check below: true when every signature matches.
static bool BuildMatches()
{
    for (const Signature& s : kSignatures) {
        const uint8_t* p = reinterpret_cast<const uint8_t*>(s.address);
        if (IsBadReadPtr(p, sizeof(s.bytes)) || memcmp(p, s.bytes, sizeof(s.bytes)) != 0) return false;
    }
    return true;
}

// The Steam exe is wrapped in Steam's copy protection (SteamStub, a ".bind" section): its code is
// scrambled in the file and only unscrambled by the wrapper when the game starts, which is after
// this DLL has loaded. Read too early, the code looks like a different build.
static bool HasSteamWrapper()
{
    const uint8_t* base = reinterpret_cast<const uint8_t*>(GetModuleHandleW(nullptr));
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (unsigned i = 0; i < nt->FileHeader.NumberOfSections; ++i)
        if (memcmp(sec[i].Name, ".bind", 5) == 0) return true;
    return false;
}

// 1.4.5: waits (on the startup thread) until the game's code is in place. GOG / unwrapped exes:
// at once. Steam: until SteamStub has unscrambled it (normally well under a second).
void WaitForGameCode()
{
    if (BuildMatches()) return;
    const bool steam = HasSteamWrapper();
    Log("Game code not readable yet (%s) - waiting for it before the build check",
        steam ? "Steam copy protection still unpacking the game" : "no Steam wrapper found");
    const DWORD start = GetTickCount();
    const DWORD limit = steam ? 60000 : 5000;
    while (GetTickCount() - start < limit) {
        Sleep(20);
        if (BuildMatches()) {
            Log("Game code ready after %lu ms", (unsigned long)(GetTickCount() - start));
            return;
        }
    }
    Log("Waited %lu s - checking the build anyway", (unsigned long)(limit / 1000));
}

bool CheckBuild()
{
    int bad = 0;
    for (const Signature& s : kSignatures) {
        const uint8_t* p = reinterpret_cast<const uint8_t*>(s.address);
        bool ok = !IsBadReadPtr(p, sizeof(s.bytes)) && memcmp(p, s.bytes, sizeof(s.bytes)) == 0;
        if (!ok) {
            Log("Build check: bytes at 0x%06X differ from the GOG 1.05 exe", (unsigned)s.address);
            ++bad;
        }
    }
    if (bad) {
        Log("Build check FAILED (%d of %d): engine features stay off on this build", bad,
            (int)(sizeof(kSignatures) / sizeof(kSignatures[0])));
        return false;
    }
    Log("Build check passed: engine bridge enabled");
    return true;
}

// ---------------------------------------------------------------------------
// Direct reads
// ---------------------------------------------------------------------------

// Primary vtables of the GameMode classes (RTTI, offset 0).
struct ModeVtable { uintptr_t vtable; Mode mode; const char* name; };
static const ModeVtable kModes[] = {
    { 0xB16374, MODE_EXPLORE,     "Explore" },
    { 0xB1D89C, MODE_COMBAT,      "Combat" },
    { 0xB0E3DC, MODE_DIALOG,      "Dialog" },
    { 0xB0E76C, MODE_CUTSCENE,    "Cutscene" },
    { 0xB172A4, MODE_GUI,         "GUI" },
    { 0xB1D734, MODE_DEAD,        "Dead" },
    { 0xB06CE4, MODE_PREGAME,     "Pregame" },
    { 0xB108D4, MODE_LOADING,     "Loading" },
    { 0xB11604, MODE_MOVIE,       "Movie" },
    { 0xB1D31C, MODE_PARTYPICKER, "PartyPicker" },
    { 0xB173D4, MODE_CHARGEN,     "CharGen" },
    { 0xB1D60C, MODE_FLYCAM,      "FlyCam" },
    { 0xB1D504, MODE_FIXED,       "Fixed" },
};

static char* Ptr(char* base, uint32_t off) { return *reinterpret_cast<char**>(base + off); }

static Mode CurrentModeRaw(int* rawId)
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return MODE_NONE;
    char* ctrl = Ptr(app, kAppModeCtrl);
    if (!ctrl) return MODE_NONE;
    char* mode = Ptr(ctrl, kCtrlCurrentMode);
    if (!mode) return MODE_NONE;
    if (rawId) *rawId = *reinterpret_cast<int*>(mode + kModeId);
    uintptr_t vt = *reinterpret_cast<uintptr_t*>(mode);
    for (const ModeVtable& m : kModes)
        if (m.vtable == vt) return m.mode;
    return MODE_UNKNOWN;
}

static bool IsPausedRaw()
{
    char* owner = *reinterpret_cast<char**>(kPauseOwnerPtr);
    if (!owner) return false;
    return *(owner + 0x5F4 + 0xC) != 0;
}

static int PartyRaw(uint32_t* out, int max)
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return -1;
    char* owner = Ptr(app, kAppPartyOwner);
    if (!owner) return -1;
    char* party = Ptr(owner, kPartyOwnerParty);
    if (!party) return -1;
    uint32_t* first = *reinterpret_cast<uint32_t**>(party + kPartyMembers + 4);
    uint32_t* last  = *reinterpret_cast<uint32_t**>(party + kPartyMembers + 8);
    if (!first || last < first || last - first > 64) return first == last ? 0 : -1;
    int n = 0;
    for (uint32_t* p = first; p < last && n < max; ++p) out[n++] = *p;
    return n;
}

#ifdef _MSC_VER
#define GUARDED(expr, fallback) __try { return expr; } __except (EXCEPTION_EXECUTE_HANDLER) { return fallback; }
#else
#define GUARDED(expr, fallback) return expr;
#endif

Mode CurrentMode(int* rawId) { GUARDED(CurrentModeRaw(rawId), MODE_NONE) }
bool IsPaused()              { GUARDED(IsPausedRaw(), false) }
int  PartyMembers(uint32_t* out, int max) { GUARDED(PartyRaw(out, max), -1) }

// ---------------------------------------------------------------------------
// Client creatures (CCCreature) by object id: 0x5D58C0 thiscall on the client
// app (*0xC327EC). Used by the off-screen arrows and the party-AI switch.
// ---------------------------------------------------------------------------
typedef char* (__thiscall* ClientById_t)(void* app, uint32_t id);

static char* ClientCreatureRaw(uint32_t id)
{
    void* app = *reinterpret_cast<void**>(kAppPtr);
    if (!app || id == kInvalidObject) return nullptr;
    return reinterpret_cast<ClientById_t>(0x5D58C0)(app, id);
}

static int OffscreenFloatyRaw(uint32_t id)
{
    char* c = ClientCreatureRaw(id);
    return c ? *reinterpret_cast<int*>(c + 0xC6C) : 0;     // set by 0x69E490 (CCParty::AddMember)
}

// IsPartyAIEnabled (0x66AC60): client creature +0xC00 -> +0xC = tactics data, byte +0x5C+0xC.
static uint8_t* PartyAiFlagRaw(uint32_t id)
{
    char* c = ClientCreatureRaw(id);
    if (!c) return nullptr;
    char* t = *reinterpret_cast<char**>(c + 0xC00 + 0xC);
    return t ? reinterpret_cast<uint8_t*>(t + 0x5C + 0xC) : nullptr;
}

static int GetPartyAiRaw(uint32_t id)
{
    uint8_t* f = PartyAiFlagRaw(id);
    return f ? *f : -1;
}

static bool SetPartyAiRaw(uint32_t id, bool on)
{
    uint8_t* f = PartyAiFlagRaw(id);
    if (!f || *f > 1) return false;          // not a 0/1 flag: wrong object, leave it
    *f = on ? 1 : 0;
    return true;
}

// GUI "SendMessage" fscommand handler 0x51B5E0: cdecl(movie, const char* text),
// text = "<Object>.<Message> [args]" (parsed by 0x524BE0).
typedef void (__cdecl* SendMessage_t)(void* unused, const char* text);
static bool SendGameMessageRaw(const char* text)
{
    reinterpret_cast<SendMessage_t>(0x51B5E0)(nullptr, text);
    return true;
}

// The "hero" (what GetHero returns): player = *(*(app+0xD0)+0x58), and the hero
// id is the property object at player+0x1F8 (value at +0xC, setter vtable
// +0x54) [asm GetHero 0x660AA0 -> 0x5D57C0 -> 0x62F390 -> 0x53CC40]. The party
// leader is the sibling property at +0x1E8 (SetPartyLeader 0x636180).
static char* HeroOwnerRaw()
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return nullptr;
    char* p = *reinterpret_cast<char**>(app + 0xD0);
    if (!p) return nullptr;
    return *reinterpret_cast<char**>(p + 0x58);
}
static uint32_t HeroRaw()
{
    char* pl = HeroOwnerRaw();
    if (!pl) return kInvalidObject;
    return *reinterpret_cast<uint32_t*>(pl + 0x1F8 + 0xC);
}
typedef void (__thiscall* SetProp_t)(void* prop, uint32_t value);
static bool SetHeroRaw2(uint32_t id)
{
    char* pl = HeroOwnerRaw();
    if (!pl) return false;
    void* prop = pl + 0x1F8;
    void** vt = *reinterpret_cast<void***>(prop);
    if (!vt) return false;
    reinterpret_cast<SetProp_t>(vt[0x54 / 4])(prop, id);
    return HeroRaw() == id;
}

// Camera look direction: the camera node (*(cam+4)) keeps its rotation as a
// quaternion at +0x90; 0x4CBD30 turns it into the forward vector (rotated +Y),
// which the follow update 0x771250 uses. (cam+0x70 - cam+0x80 is NOT the view
// direction: it is the sideways shoulder offset, and 0 when zoomed out.)
static bool CameraLookRaw(float* fx, float* fy)
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return false;
    char* owner = *reinterpret_cast<char**>(app + kAppCameraOwner);
    if (!owner) return false;
    char* cam = *reinterpret_cast<char**>(owner + kCamOwnerCamera);
    if (!cam) return false;
    char* node = *reinterpret_cast<char**>(cam + 4);
    if (!node) return false;
    const float* q = reinterpret_cast<const float*>(node + 0x90);
    float x = q[0], y = q[1], z = q[2], w = q[3];
    *fx = (x * y - w * z) * 2.f;
    *fy = 1.f - (x * x + z * z) * 2.f;
    return true;
}

// ---------------------------------------------------------------------------
// Character creator internals (1.2.9, see engine notes "Character creator")
// ---------------------------------------------------------------------------
// The creator GUI (GUICharGen): GUI system *(app+0x158), vtable +0x60
// thiscall(sys, 1) = screen 1 [asm StartCharGen 0x66B303]. +0xC0 = creature id
// being made, +0x110 = the paperdoll (the preview), paperdoll+0x58 = the client
// creature it shows.
typedef char* (__thiscall* GetScreen_t)(void* sys, int id);
typedef void  (__thiscall* PaperSet_t)(void* paper, void* creature, int a, int b);              // 0x7B8470, ret 0xC
typedef void  (__thiscall* PaperRefresh_t)(void* paper, void* creature, int a, int b, int n);   // 0x7BC110, ret 0x10
typedef unsigned (__thiscall* BuildModel_t)(void* creature, void* appearance, int a, int b, int force); // 0x6C1400, ret 0x10

static char* ChargenGuiRaw()
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return nullptr;
    char* sys = *reinterpret_cast<char**>(app + 0x158);
    if (!sys) return nullptr;
    void** vt = *reinterpret_cast<void***>(sys);
    return reinterpret_cast<GetScreen_t>(vt[0x60 / 4])(sys, 1);
}

static bool ChargenInfoRaw(ChargenInfo* out)
{
    *out = ChargenInfo{};
    char* gui = ChargenGuiRaw();
    if (!gui) return false;
    out->gui = gui;
    out->target = *reinterpret_cast<uint32_t*>(gui + 0xC0);
    char* paper = *reinterpret_cast<char**>(gui + 0x110);
    out->paperdoll = paper;
    out->shown = paper ? *reinterpret_cast<void**>(paper + 0x58) : nullptr;
    return true;
}

// Point the creator (and its preview) at `id`, the way the GUI's own
// "ResetCreature" does for the hero, minus its player reset [dec 0x738410].
static bool ChargenUseRaw(uint32_t id)
{
    char* gui = ChargenGuiRaw();
    char* obj = ClientCreatureRaw(id);
    if (!gui || !obj) return false;
    *reinterpret_cast<uint32_t*>(gui + 0xC0) = id;
    char* paper = *reinterpret_cast<char**>(gui + 0x110);
    if (paper) reinterpret_cast<PaperSet_t>(0x7B8470)(paper, obj, 1, 1);
    return true;
}

// The preview refresh after a race/gender/class pick [dec 0x7356F0], without
// its check of flag 0x4236 (set outside the new-game creator: the preview never
// changed for Player 2).
static bool ChargenRefreshRaw(int n)
{
    char* gui = ChargenGuiRaw();
    if (!gui) return false;
    char* obj = ClientCreatureRaw(*reinterpret_cast<uint32_t*>(gui + 0xC0));
    char* paper = *reinterpret_cast<char**>(gui + 0x110);
    if (!obj || !paper) return false;
    *(obj + 0x7B4) = 0;
    reinterpret_cast<PaperRefresh_t>(0x7BC110)(paper, obj, 1, 1, n);
    return true;
}

// 1.3.3 voice (sound set): client creature +0x96C is the sound set name, a game wstring
// {proxy, buf[8]/ptr, size, cap}; 0x6BD0E0 thiscall(creature, const wstring*, 1) sets it
// (what COMMAND_SETSOUNDSET 182 does). The creator's "test voice" plays it on the preview's
// own creature, *(paperdoll+0x68) [dec 0x60BA20 -> 0x6B5740, which skips an empty name].
static bool ReadGameWString(const char* gs, wchar_t* out, int cap)
{
    uint32_t size = *reinterpret_cast<const uint32_t*>(gs + 0x14);
    uint32_t scap = *reinterpret_cast<const uint32_t*>(gs + 0x18);
    const wchar_t* text = scap >= 8 ? *reinterpret_cast<wchar_t* const*>(gs + 4) : reinterpret_cast<const wchar_t*>(gs + 4);
    if (cap <= 0) return false;
    out[0] = 0;
    if (size >= 260 || !text) return false;
    int n = (int)size < cap - 1 ? (int)size : cap - 1;
    for (int i = 0; i < n; ++i) out[i] = text[i];
    out[n] = 0;
    return true;
}
typedef void (__thiscall* SetSoundSet_t)(void* creature, const void* name, int flag);
static bool SoundSetRaw(uint32_t id, wchar_t* out, int cap)
{
    char* obj = ClientCreatureRaw(id);
    return obj && ReadGameWString(obj + 0x96C, out, cap);
}
static bool SetSoundSetFromRaw(uint32_t id, const void* gameString)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj || !gameString) return false;
    reinterpret_cast<SetSoundSet_t>(0x6BD0E0)(obj, gameString, 1);
    return true;
}
static int ChargenVoiceSyncRaw(uint32_t id)
{
    char* gui = ChargenGuiRaw();
    char* obj = ClientCreatureRaw(id);
    if (!gui || !obj) return -1;
    char* paper = *reinterpret_cast<char**>(gui + 0x110);
    if (!paper) return -1;
    char* prev = *reinterpret_cast<char**>(paper + 0x68);
    if (!prev || prev == obj) return 0;
    wchar_t a[64], b[64];
    if (!ReadGameWString(obj + 0x96C, a, 64) || !a[0]) return 0;
    ReadGameWString(prev + 0x96C, b, 64);
    if (wcscmp(a, b) == 0) return 0;
    reinterpret_cast<SetSoundSet_t>(0x6BD0E0)(prev, obj + 0x96C, 1);
    return 1;
}

// Rebuild a creature's model in the world from its own appearance data
// [dec 0x6C1400; it only builds when +0x7B4 ("model live in the world") is set].
static int ModelLiveRaw(uint32_t id)
{
    char* obj = ClientCreatureRaw(id);
    return obj ? (unsigned char)*(obj + 0x7B4) : -1;
}
// What the creature looks like (client side): appearance type (+0x7B0 -> +0x58),
// and the head morph name the creator stores at +0x96C (a game wstring).
static bool LookInfoRaw(uint32_t id, int* appearance, wchar_t* morph, int cap)
{
    *appearance = -1; if (cap > 0) morph[0] = 0;
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    char* app = *reinterpret_cast<char**>(obj + 0x7B0);
    if (app) *appearance = *reinterpret_cast<unsigned short*>(app + 0x58);
    const char* gs = obj + 0x96C;                      // {proxy, buf[8]/ptr, size, cap}
    uint32_t size = *reinterpret_cast<const uint32_t*>(gs + 0x14);
    uint32_t scap = *reinterpret_cast<const uint32_t*>(gs + 0x18);
    const wchar_t* text = scap >= 8 ? *reinterpret_cast<wchar_t* const*>(gs + 4) : reinterpret_cast<const wchar_t*>(gs + 4);
    if (size < 260 && text && cap > 0) {
        int n = (int)size < cap - 1 ? (int)size : cap - 1;
        for (int i = 0; i < n; ++i) morph[i] = text[i];
        morph[n] = 0;
    }
    return true;
}

// Diagnostics: the preview's creature(s) next to Player 2's real one, so the
// fields that hold the new look can be compared in the log.
static void HexLine(const char* tag, const unsigned char* p, int n)
{
    char buf[3 * 64 + 1]; int k = 0;
    for (int i = 0; i < n && i < 64; ++i) k += sprintf(buf + k, "%02X ", p[i]);
    buf[k] = 0;
    Log("  %s %s", tag, buf);
}
static void DumpCreatureRaw(const char* name, char* obj)
{
    if (!obj) { Log("  %s: none", name); return; }
    char* app = *reinterpret_cast<char**>(obj + 0x7B0);
    const char* gs = obj + 0x96C;
    uint32_t size = *reinterpret_cast<const uint32_t*>(gs + 0x14), scap = *reinterpret_cast<const uint32_t*>(gs + 0x18);
    const wchar_t* text = scap >= 8 ? *reinterpret_cast<wchar_t* const*>(gs + 4) : reinterpret_cast<const wchar_t*>(gs + 4);
    wchar_t m[96] = L"";
    if (size < 90 && text) { for (uint32_t i = 0; i < size; ++i) m[i] = text[i]; m[size] = 0; }
    Log("  %s: obj %p id 0x%08X live %d appearance-data %p morph \"%ls\"", name, obj,
        *reinterpret_cast<uint32_t*>(obj + 0x18), (unsigned char)*(obj + 0x7B4), app, m);
    if (app) for (int off = 0; off < 0x100; off += 32) {
        char tag[32]; sprintf(tag, "%s app+%02X", name, off);
        HexLine(tag, reinterpret_cast<unsigned char*>(app + off), 32);
    }
}
static bool DumpChargenRaw(uint32_t real)
{
    char* gui = ChargenGuiRaw();
    char* paper = gui ? *reinterpret_cast<char**>(gui + 0x110) : nullptr;
    Log("Chargen dump: gui %p target 0x%08X paperdoll %p", gui, gui ? *reinterpret_cast<uint32_t*>(gui + 0xC0) : 0, paper);
    DumpCreatureRaw("real", ClientCreatureRaw(real));
    if (paper) {
        DumpCreatureRaw("paper+58", *reinterpret_cast<char**>(paper + 0x58));
        char* prop = paper + 0x5C;                        // property: value at +0xC
        DumpCreatureRaw("paper+5C", *reinterpret_cast<char**>(prop + 0xC));
        HexLine("paper+50", reinterpret_cast<unsigned char*>(paper + 0x50), 32);
    }
    return true;
}

// Give the real creature the look the creator built. The creator's sliders and
// presets only change the PREVIEW's own copy of the creature (paperdoll+0x5C,
// CommandApplyMorph 0x7C1390); the real creature's appearance data stays the
// template's (1.2.10 log). Build the real one's model from the preview's
// appearance data; param 3 = 1 makes the builder keep its own copy of it
// (0x6C1400 -> new 0x1F0 appearance, copied with 0x74A610).
static bool AdoptPreviewLookRaw(uint32_t id)
{
    char* gui = ChargenGuiRaw();
    char* paper = gui ? *reinterpret_cast<char**>(gui + 0x110) : nullptr;
    char* obj = ClientCreatureRaw(id);
    if (!paper || !obj) return false;
    char* copy = *reinterpret_cast<char**>(paper + 0x5C + 0xC);
    if (!copy || copy == obj) return false;
    void* look = *reinterpret_cast<void**>(copy + 0x7B0);
    if (!look) return false;
    *(obj + 0x7B4) = 1;
    reinterpret_cast<BuildModel_t>(0x6C1400)(obj, look, 1, 0, 1);
    return true;
}

static bool RebuildModelRaw(uint32_t id)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    void* app = *reinterpret_cast<void**>(obj + 0x7B0);
    if (!app) return false;
    *(obj + 0x7B4) = 1;
    reinterpret_cast<BuildModel_t>(0x6C1400)(obj, app, 0, 1, 1);
    return true;
}

// ---------------------------------------------------------------------------
// Head morph, NPC style (1.2.23). The creator's face lives in two places:
//  - the preview's own copy of the creature (paperdoll+0x5C value) holds the
//    finished appearance data (0x1F0 object: tints, hair, parts, HeadMorph
//    string at +0x1C8);
//  - the face itself is a serialized morph (a complete .mor file: GFF V4.0
//    "PC  " "MORP") that the creator's commit (0x803000) stores in the player
//    profile *(app+0x14C), field 0x4236. Only the hero reads it from there
//    (model build 0x6C0DE0 checks creature +0x7D4). NPCs load HeadMorph as a
//    .mor resource instead.
// Profile field access [dec 0x803000 / 0x6C0DE0]: root 0x643420 thiscall(profile,
// int out[3]); field 0xA5A8E0 thiscall(root, int out[3], id); size 0x4DB2A0
// thiscall(fld); byte 0x47C940 thiscall(fld, i); resize 0x4DD730 thiscall(fld, n);
// set byte 0x4782F0 thiscall(fld, i, const uint8_t*). Handles are 3 plain dwords.
// Appearance copy as COMMAND_SETCREATUREGENDER does it [0x65A50D]: new(0x1F0),
// ctor 0x74A440, operator= 0x74A610 thiscall(dst, src), then
// 0x6C1400(creature, newApp, 0, 0, 0) - the creature takes the new data over.
// ---------------------------------------------------------------------------
typedef void     (__thiscall* ProfRoot_t)(void* profile, int* out);
typedef void     (__thiscall* ProfField_t)(int* root, int* out, int id);
typedef unsigned (__thiscall* FldSize_t)(int* fld);
typedef unsigned (__thiscall* FldGet_t)(int* fld, int i);
typedef void     (__thiscall* FldResize_t)(int* fld, int n);
typedef void     (__thiscall* FldSet_t)(int* fld, int i, const unsigned char* v);
typedef void*    (__cdecl*    Alloc_t)(size_t);
typedef void*    (__thiscall* AppCtor_t)(void*);
typedef void     (__thiscall* AppAssign_t)(void*, const void*);
typedef void*    (__thiscall* StrCtor_t)(void*, const wchar_t*);
typedef void     (__thiscall* StrAssign_t)(void*, const void*);
typedef void     (__thiscall* StrDtor_t)(void*);

static bool MorphFieldRaw(int* fld)
{
    fld[0] = fld[1] = fld[2] = 0;
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return false;
    void* prof = *reinterpret_cast<void**>(app + 0x14C);
    if (!prof) return false;
    int root[3] = { 0, 0, 0 };
    reinterpret_cast<ProfRoot_t>(0x643420)(prof, root);
    if (!root[0]) return false;
    reinterpret_cast<ProfField_t>(0xA5A8E0)(root, fld, 0x4236);
    return fld[0] != 0;
}

static int ProfileMorphGetRaw(unsigned char* out, int cap)
{
    int f[3];
    if (!MorphFieldRaw(f)) return -1;
    unsigned n = reinterpret_cast<FldSize_t>(0x4DB2A0)(f);
    if ((int)n > cap) return -2;
    for (unsigned i = 0; i < n; ++i) out[i] = (unsigned char)reinterpret_cast<FldGet_t>(0x47C940)(f, (int)i);
    return (int)n;
}

static bool ProfileMorphSetRaw(const unsigned char* data, int n)
{
    int f[3];
    if (!MorphFieldRaw(f)) return false;
    reinterpret_cast<FldResize_t>(0x4DD730)(f, n);
    if (n == 0) return true;
    if (!MorphFieldRaw(f)) return false;                 // fetch the handle again after the resize
    if ((int)reinterpret_cast<FldSize_t>(0x4DB2A0)(f) != n) return false;
    for (int i = 0; i < n; ++i) reinterpret_cast<FldSet_t>(0x4782F0)(f, i, data + i);
    return true;
}

static void* StashPreviewLookRaw()
{
    char* gui = ChargenGuiRaw();
    char* paper = gui ? *reinterpret_cast<char**>(gui + 0x110) : nullptr;
    if (!paper) return nullptr;
    char* copy = *reinterpret_cast<char**>(paper + 0x5C + 0xC);
    if (!copy) return nullptr;
    void* src = *reinterpret_cast<void**>(copy + 0x7B0);
    if (!src) return nullptr;
    void* mem = reinterpret_cast<Alloc_t>(0x413660)(0x1F0);
    if (!mem) return nullptr;
    mem = reinterpret_cast<AppCtor_t>(0x74A440)(mem);
    reinterpret_cast<AppAssign_t>(0x74A610)(mem, src);
    return mem;
}

static bool ApplyLookRaw(uint32_t id, void* look, bool asHero)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj || !look) return false;
    *(obj + 0x7B4) = 1;
    char wasHero = *(obj + 0x7D4);
    if (asHero) *(obj + 0x7D4) = 1;
    reinterpret_cast<BuildModel_t>(0x6C1400)(obj, look, 0, 0, 0);
    *(obj + 0x7D4) = wasHero;
    return true;   // (0x6BDC70 copies 'look' into the creature's own appearance, +0x7B0 stays the same object)
}

static bool SetHeadMorphRaw(uint32_t id, const wchar_t* name)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    char* app = *reinterpret_cast<char**>(obj + 0x7B0);
    if (!app) return false;
    alignas(8) char tmp[0x40] = {};
    reinterpret_cast<StrCtor_t>(0x4C2480)(tmp, name);
    reinterpret_cast<StrAssign_t>(0x4C2AB0)(app + 0x1C8, tmp);
    reinterpret_cast<StrDtor_t>(0x4C0DB0)(tmp);
    return true;
}

static void SetAppHeadMorph(char* app, const wchar_t* name)
{
    alignas(8) char tmp[0x40] = {};
    reinterpret_cast<StrCtor_t>(0x4C2480)(tmp, name);
    reinterpret_cast<StrAssign_t>(0x4C2AB0)(app + 0x1C8, tmp);
    reinterpret_cast<StrDtor_t>(0x4C0DB0)(tmp);
}
static bool AppHeadMorphRaw(const char* app, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    if (!app) return false;
    const char* gs = app + 0x1C8;
    uint32_t size = *reinterpret_cast<const uint32_t*>(gs + 0x14), scap = *reinterpret_cast<const uint32_t*>(gs + 0x18);
    const wchar_t* text = scap >= 8 ? *reinterpret_cast<wchar_t* const*>(gs + 4) : reinterpret_cast<const wchar_t*>(gs + 4);
    if (size >= 260 || !text) return false;
    int n = (int)size < cap - 1 ? (int)size : cap - 1;
    for (int i = 0; i < n; ++i) out[i] = text[i];
    if (cap > 0) out[n < 0 ? 0 : n] = 0;
    return true;
}

// 1.2.29: a co-op character's model build with its own face. Its HeadMorph names a .mor that the
// game only finds after a restart (override folder), so for the build: the face in the player
// profile, the creature marked as the hero, HeadMorph empty (the hero's face comes from the
// profile [0x6C0DE0]); then everything back, HeadMorph included (it is what the save keeps).
static unsigned BuildWithFaceRaw(void* build, char* obj, char* app, int a, int b, int force,
                                 const unsigned char* face, int faceLen, const wchar_t* morphName,
                                 unsigned char* keep, int keepCap, bool* done)
{
    *done = false;
    int keepLen = ProfileMorphGetRaw(keep, keepCap);
    if (keepLen < 0 || !ProfileMorphSetRaw(face, faceLen)) return 0;
    char wasHero = *(obj + 0x7D4);
    *(obj + 0x7D4) = 1;
    SetAppHeadMorph(app, L"");
    unsigned r = reinterpret_cast<BuildModel_t>(build)(obj, app, a, b, force);
    *done = true;
    *(obj + 0x7D4) = wasHero;
    SetAppHeadMorph(app, morphName);
    char* own = *reinterpret_cast<char**>(obj + 0x7B0);
    if (own && own != app) SetAppHeadMorph(own, morphName);
    ProfileMorphSetRaw(keep, keepLen);
    return r;
}

static bool HeadMorphRaw(uint32_t id, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    char* app = *reinterpret_cast<char**>(obj + 0x7B0);
    if (!app) return false;
    const char* gs = app + 0x1C8;
    uint32_t size = *reinterpret_cast<const uint32_t*>(gs + 0x14), scap = *reinterpret_cast<const uint32_t*>(gs + 0x18);
    const wchar_t* text = scap >= 8 ? *reinterpret_cast<wchar_t* const*>(gs + 4) : reinterpret_cast<const wchar_t*>(gs + 4);
    if (size >= 260 || !text) return false;
    int n = (int)size < cap - 1 ? (int)size : cap - 1;
    for (int i = 0; i < n; ++i) out[i] = text[i];
    if (cap > 0) out[n < 0 ? 0 : n] = 0;
    return true;
}

// ---------------------------------------------------------------------------
// Direct (free) movement - what Player 1's WASD / left stick does outside the
// tactical camera (1.2.11, see engine notes "Free movement").
// GameModeExplore::Update -> 0x70BE60 -> 0x764150 -> 0x763CD0 reads the input
// (keys 0x763A00, analog actions 0/1 = AccelerateCharacterLateral/Forward in
// 0x763C10), 0x7636A0 turns it into headings and calls, on the client creature,
// 0x6ADCF0 thiscall(creature, float moveDeg, float faceDeg, float cameraDeg,
// uint run) ret 0x10 -> 0x6A21C0: a type-0x21 action on that creature. Headings
// are degrees, 0 = +Y, counter-clockwise (atan2(-x, y), 0x4EE570). Stopping is
// the creature's movement state (creature+0xA30, state at +0xB20) set to 3 by
// 0xA63800 thiscall(state, 3) [0x763810]; +0xB24 = moving directly.
// ---------------------------------------------------------------------------
typedef void (__thiscall* DirectMove_t)(void* creature, float moveDeg, float faceDeg, float camDeg, unsigned run);
typedef void (__thiscall* MoveState_t)(void* state, int s);

static float Heading(float x, float y)
{
    float a = std::atan2(-x, y) * 57.29578f;
    while (a < 0.f) a += 360.f;
    while (a >= 360.f) a -= 360.f;
    return a;
}

// 1.2.17 probes: for the Warden the first free-move action starts at once and
// later calls update it in place; for Player 2 every call queued a NEW action
// that never started - the queue add (0x73CD10(action, 0, -1)) appends behind
// whatever the creature is already doing. Start Player 2's the way an
// interrupting action does: same action as 0x6A21C0 builds, added with
// "clear the others first" (4th argument 1 -> 0x73C930).
typedef void* (__cdecl*    New_t)(size_t);
typedef void* (__thiscall* Ctor_t)(void*);
typedef void  (__thiscall* SetVec_t)(void*, int, const void*);
typedef void  (__thiscall* SetFloat_t)(void*, int, float);
typedef void  (__thiscall* SetInt_t)(void*, int, int);
typedef void* (__thiscall* PoolGet_t)(void*);
typedef void  (__thiscall* SetType_t)(void*, int);
typedef int   (__thiscall* Queue_t)(void*, void*, int, int);

static bool FreeMoveRunning(char* obj)
{
    void** cur = *reinterpret_cast<void***>(obj + 0x2DC);
    char* a = cur ? reinterpret_cast<char*>(*cur) : nullptr;
    return a && a[2] == '!';
}

static bool StartFreeMoveRaw(char* obj, float h, float cam, bool run)
{
    char* app = *reinterpret_cast<char**>(kAppPtr);
    if (!app) return false;
    char* pools = *reinterpret_cast<char**>(app + 0x1AC);
    if (!pools) return false;
    void* params = reinterpret_cast<New_t>(0x413660)(0x20);
    if (!params) return false;
    params = reinterpret_cast<Ctor_t>(0xA59E10)(params);
    reinterpret_cast<SetVec_t>(0xA5A9B0)(params, 0, obj + 0x120);
    reinterpret_cast<SetFloat_t>(0xA5B7D0)(params, 0, h);
    reinterpret_cast<SetFloat_t>(0xA5B7D0)(params, 1, h);
    reinterpret_cast<SetFloat_t>(0xA5B7D0)(params, 2, cam);
    reinterpret_cast<SetInt_t>(0xA5B890)(params, 0, 0);
    reinterpret_cast<SetInt_t>(0xA5B890)(params, 1, run ? 1 : 0);
    char* action = reinterpret_cast<char*>(reinterpret_cast<PoolGet_t>(0x7468C0)(*reinterpret_cast<void**>(pools + 0x6C)));
    if (!action) return false;
    reinterpret_cast<SetType_t>(0x742090)(action, 0x21);
    *reinterpret_cast<void**>(action + 4) = params;
    *reinterpret_cast<int*>(action + 0xC) = 0;
    *reinterpret_cast<int*>(action + 0x10) = 1;
    reinterpret_cast<Queue_t>(0x73CD10)(obj, action, 0, 1);
    return true;
}

// 1.2.19 control experiment: selecting a character flips these in its client
// object (and back when deselected): +0x2B0 3 -> 4, movement sub-object
// (+0xA30) byte +0x6E 0 -> 1, +0xB7C 0 -> 1. The guess: "driven locally", which
// free-move actions need to run. Set them on Player 2 while it moves freely.
struct LocalDrive { char* obj = nullptr; int f2b0 = 0; unsigned char fa9e = 0; int fb7c = 0; };
static LocalDrive g_local[4];
static void DriveLocally(char* obj, bool on)
{
    for (LocalDrive& d : g_local) {
        if (on && d.obj == obj) return;                       // already on
        if (!on && d.obj == obj) {
            *reinterpret_cast<int*>(obj + 0x2B0) = d.f2b0;
            *(reinterpret_cast<unsigned char*>(obj) + 0xA9E) = d.fa9e;
            *reinterpret_cast<int*>(obj + 0xB7C) = d.fb7c;
            Log("Free movement: %p back to normal (+0x2B0 %d)", obj, d.f2b0);
            d.obj = nullptr;
            return;
        }
    }
    if (!on) return;
    for (LocalDrive& d : g_local) {
        if (d.obj) continue;
        d.obj = obj;
        d.f2b0 = *reinterpret_cast<int*>(obj + 0x2B0);
        d.fa9e = *(reinterpret_cast<unsigned char*>(obj) + 0xA9E);
        d.fb7c = *reinterpret_cast<int*>(obj + 0xB7C);
        *reinterpret_cast<int*>(obj + 0x2B0) = 4;
        *(reinterpret_cast<unsigned char*>(obj) + 0xA9E) = 1;
        *reinterpret_cast<int*>(obj + 0xB7C) = 1;
        Log("Free movement: %p driven locally (+0x2B0 %d -> 4, +0xA9E %d -> 1, +0xB7C %d -> 1)", obj, d.f2b0, d.fa9e, d.fb7c);
        return;
    }
}

static int g_freeMoveStarts = 0;
static bool DirectMoveRaw(uint32_t id, float dx, float dy, float camX, float camY, bool run)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    if (id != HeroId()) DriveLocally(obj, true);
    float h = Heading(dx, dy), cam = Heading(camX, camY);
    if (!FreeMoveRunning(obj)) {
        bool ok = StartFreeMoveRaw(obj, h, cam, run);
        if (g_freeMoveStarts++ < 10) Log("Free movement: started a new move action on %p (clearing the queue): %s, running now %d",
                                         obj, ok ? "ok" : "failed", FreeMoveRunning(obj) ? 1 : 0);
        return ok;
    }
    reinterpret_cast<DirectMove_t>(0x6ADCF0)(obj, h, h, cam, run ? 1u : 0u);   // updates the running action
    return true;
}
static bool DirectStopRaw(uint32_t id)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj) return false;
    int state = *reinterpret_cast<int*>(obj + 0xB20);
    if (state != 0 && state != 3) reinterpret_cast<MoveState_t>(0xA63800)(obj + 0xA30, 3);
    DriveLocally(obj, false);
    return true;
}
static int DirectMovingRaw(uint32_t id)
{
    char* obj = ClientCreatureRaw(id);
    return obj ? (unsigned char)*(obj + 0xB24) : -1;
}

#ifdef _MSC_VER
#define GUARDED_CALL(expr, fallback) __try { return expr; } __except (EXCEPTION_EXECUTE_HANDLER) { return fallback; }
#else
#define GUARDED_CALL(expr, fallback) return expr;
#endif

int  OffscreenFloatyId(uint32_t creature)         { GUARDED_CALL(OffscreenFloatyRaw(creature), 0) }
int  GetPartyAI(uint32_t creature)                { GUARDED_CALL(GetPartyAiRaw(creature), -1) }
bool SetPartyAI(uint32_t creature, bool on)       { GUARDED_CALL(SetPartyAiRaw(creature, on), false) }
uint32_t HeroId()                                 { GUARDED_CALL(HeroRaw(), kInvalidObject) }
bool SetHero(uint32_t creature)                   { GUARDED_CALL(SetHeroRaw2(creature), false) }
bool CameraLook(float* fx, float* fy)             { GUARDED_CALL(CameraLookRaw(fx, fy), false) }
bool ChargenInfoGet(ChargenInfo* out)             { GUARDED_CALL(ChargenInfoRaw(out), false) }
bool ChargenUse(uint32_t creature)                { GUARDED_CALL(ChargenUseRaw(creature), false) }
bool ChargenRefresh(int n)                        { GUARDED_CALL(ChargenRefreshRaw(n), false) }
int  ModelLive(uint32_t creature)                 { GUARDED_CALL(ModelLiveRaw(creature), -1) }
bool RebuildModel(uint32_t creature)              { GUARDED_CALL(RebuildModelRaw(creature), false) }
bool AdoptPreviewLook(uint32_t creature)          { GUARDED_CALL(AdoptPreviewLookRaw(creature), false) }
int  ProfileMorphGet(unsigned char* out, int cap)  { GUARDED_CALL(ProfileMorphGetRaw(out, cap), -3) }
bool ProfileMorphSet(const unsigned char* d, int n) { GUARDED_CALL(ProfileMorphSetRaw(d, n), false) }
void* StashPreviewLook()                          { GUARDED_CALL(StashPreviewLookRaw(), nullptr) }
bool ApplyLook(uint32_t c, void* look, bool asHero) { GUARDED_CALL(ApplyLookRaw(c, look, asHero), false) }
bool SoundSet(uint32_t c, wchar_t* out, int cap)   { GUARDED_CALL(SoundSetRaw(c, out, cap), false) }
bool SetSoundSetFrom(uint32_t c, const void* gs)   { GUARDED_CALL(SetSoundSetFromRaw(c, gs), false) }
int  ChargenVoiceSync(uint32_t c)                  { GUARDED_CALL(ChargenVoiceSyncRaw(c), -1) }
static int CutsceneFlagsRaw(uint32_t id)
{
    char* obj = ClientCreatureRaw(id);
    if (!obj) return -1;
    return (unsigned char)obj[0x23C] | ((unsigned char)obj[0x23D] << 8);
}
int  CutsceneFlags(uint32_t c)                     { GUARDED_CALL(CutsceneFlagsRaw(c), -1) }
bool ReadGameString(const void* gs, wchar_t* out, int cap) { GUARDED_CALL(ReadGameWString(static_cast<const char*>(gs), out, cap), false) }
bool SetHeadMorph(uint32_t c, const wchar_t* name) { GUARDED_CALL(SetHeadMorphRaw(c, name), false) }
bool HeadMorph(uint32_t c, wchar_t* out, int cap)  { GUARDED_CALL(HeadMorphRaw(c, out, cap), false) }
bool AppHeadMorph(const void* app, wchar_t* out, int cap) { GUARDED_CALL(AppHeadMorphRaw(static_cast<const char*>(app), out, cap), false) }
static unsigned BuildWithFaceGuarded(void* build, char* obj, char* app, int a, int b, int force, const unsigned char* face, int faceLen,
                                     const wchar_t* name, unsigned char* keep, int keepCap, bool* done)
{ GUARDED_CALL(BuildWithFaceRaw(build, obj, app, a, b, force, face, faceLen, name, keep, keepCap, done), 0u) }
unsigned BuildWithFace(void* build, void* obj, void* app, int a, int b, int force, const unsigned char* face, int faceLen, const wchar_t* name)
{
    static unsigned char* keep = new unsigned char[512 * 1024];
    bool done = false;
    unsigned r = BuildWithFaceGuarded(build, static_cast<char*>(obj), static_cast<char*>(app), a, b, force, face, faceLen, name, keep, 512 * 1024, &done);
    if (!done) r = reinterpret_cast<BuildModel_t>(build)(obj, app, a, b, force);   // the trick could not be set up: a plain build
    return r;
}
bool LookInfo(uint32_t c, int* a, wchar_t* m, int n) { GUARDED_CALL(LookInfoRaw(c, a, m, n), false) }
bool DumpChargen(uint32_t real)                   { GUARDED_CALL(DumpChargenRaw(real), false) }
void* ClientCreature(uint32_t creature)           { GUARDED_CALL(ClientCreatureRaw(creature), nullptr) }
bool DirectMove(uint32_t c, float dx, float dy, float cx, float cy, bool run) { GUARDED_CALL(DirectMoveRaw(c, dx, dy, cx, cy, run), false) }
bool DirectStop(uint32_t c)                       { GUARDED_CALL(DirectStopRaw(c), false) }
int  DirectMoving(uint32_t c)                     { GUARDED_CALL(DirectMovingRaw(c), -1) }
bool SendGameMessage(const char* text)
{
    bool ok = false;
#ifdef _MSC_VER
    __try { ok = SendGameMessageRaw(text); } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
#else
    ok = SendGameMessageRaw(text);
#endif
    Log("Game message \"%s\": %s", text, ok ? "sent" : "failed");
    return ok;
}

const char* ModeName(Mode m)
{
    if (m == MODE_NONE) return "none";
    for (const ModeVtable& v : kModes) if (v.mode == m) return v.name;
    return "unknown";
}

} // namespace game
