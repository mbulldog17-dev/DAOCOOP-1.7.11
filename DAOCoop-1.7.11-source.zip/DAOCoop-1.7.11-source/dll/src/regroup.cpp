#include "regroup.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <cmath>
#include <cwchar>
#include <cstdio>
#include <windows.h>

static RegroupSettings g_s;

struct PlayerState {
    int      lastMode = game::MODE_NONE;
    unsigned settleAt = 0;            // check placement at this time (after a scene)
    bool     pushing = false;
    unsigned pushStart = 0;
    script::Vec3 pushFrom = {};
    bool     hinted = false;
    unsigned lastTeleport = 0;
};
static PlayerState g_p[4];

void RegroupInit(const RegroupSettings& s)
{
    g_s = s;
    Log("Regroup: %s - LB teleport, rescue from other areas; auto-place after scenes %s, stuck auto-teleport %s",
        s.enabled ? "on" : "off", s.autoDistance > 0 ? "on" : "off", s.stuckSeconds > 0 ? "on" : "off");
}

bool RegroupTeleport(int player, uint32_t me, uint32_t hero, const char* why)
{
    if (me == game::kInvalidObject || hero == game::kInvalidObject || me == hero) return false;
    PlayerState& st = g_p[player];
    unsigned now = GetTickCount();
    if (now - st.lastTeleport < 1500) return false;              // no double jumps
    bool ok = script::JumpToSafeSpotNear(me, hero);
    st.lastTeleport = now;
    st.pushing = false; st.hinted = false;
    Log("Regroup: Player %d teleported to the Warden (%s): %s", player, why, ok ? "ok" : "failed");
    if (ok) {
        wchar_t text[64];
        swprintf(text, 64, L"Player %d regrouped", player);
        script::DisplayFloatyMessage(me, text, player == 3 ? 0x66DD66 : 0x4DA6FF, 1.5f);
    }
    return ok;
}

void RegroupNoteStick(int player, bool pushing, unsigned now)
{
    PlayerState& st = g_p[player];
    if (pushing && !st.pushing) { st.pushStart = now; st.hinted = false; st.pushFrom = {}; }
    if (!pushing) st.hinted = false;
    st.pushing = pushing;
}

static bool IsScene(int m)
{
    return m == game::MODE_LOADING || m == game::MODE_CUTSCENE || m == game::MODE_DIALOG ||
           m == game::MODE_MOVIE || m == game::MODE_PREGAME || m == game::MODE_NONE;
}

void RegroupTick(unsigned now, int player, uint32_t me, uint32_t hero, int mode)
{
    if (!g_s.enabled || player < 2 || player > 3) return;
    PlayerState& st = g_p[player];

    // Coming back from a load, cutscene or conversation: check placement shortly after.
    if (mode != st.lastMode) {
        if ((mode == game::MODE_EXPLORE || mode == game::MODE_COMBAT) && IsScene(st.lastMode))
            st.settleAt = now + 1500;
        st.lastMode = mode;
    }
    if (mode != game::MODE_EXPLORE && mode != game::MODE_COMBAT) return;
    if (me == game::kInvalidObject || hero == game::kInvalidObject || me == hero) return;
    if (script::IsDead(me)) return;

    if (st.settleAt && (int)(now - st.settleAt) >= 0) {
        st.settleAt = 0;
        bool otherArea = script::GetArea(me) != script::GetArea(hero);
        if (otherArea) {
            // Out of the party = the story sent the Warden on alone (the Harrowing,
            // the Fade...): don't drag the character along.
            uint32_t m[16];
            int n = game::PartyMembers(m, 16);
            bool inParty = n < 0;
            for (int i = 0; i < n; ++i) if (m[i] == me) inParty = true;
            if (!inParty) { Log("Regroup: Player %d's character is out of the party (story) - not brought along", player); otherArea = false; }
        }
        float d = script::GetDistance(me, hero);
        if (otherArea || (g_s.autoDistance > 0 && d > g_s.autoDistance)) {
            char why[64];
            if (otherArea) snprintf(why, sizeof(why), "left behind in another area");
            else snprintf(why, sizeof(why), "%.0f m away after a scene", d);
            RegroupTeleport(player, me, hero, why);
        }
    }

    // Stuck: the stick is pushed but the character doesn't get anywhere.
    if (st.pushing) {
        script::Vec3 p;
        if (!script::GetPosition(me, &p)) return;
        if (st.pushFrom.x == 0 && st.pushFrom.y == 0 && st.pushFrom.z == 0) { st.pushFrom = p; st.pushStart = now; }
        float dx = p.x - st.pushFrom.x, dy = p.y - st.pushFrom.y;
        if (dx * dx + dy * dy > 1.0f) { st.pushFrom = p; st.pushStart = now; st.hinted = false; return; }   // moving
        float held = (now - st.pushStart) / 1000.f;
        if (held > 3.f && !st.hinted) {
            st.hinted = true;
            wchar_t text[96];
            swprintf(text, 96, L"Player %d stuck? Hold LB to teleport to the Warden", player);
            script::DisplayStatusMessage(text, player == 3 ? 0x66DD66 : 0x4DA6FF);
        }
        if (g_s.stuckSeconds > 0 && held > g_s.stuckSeconds) {
            st.pushFrom = {};
            RegroupTeleport(player, me, hero, "stuck");
        }
    }
}
