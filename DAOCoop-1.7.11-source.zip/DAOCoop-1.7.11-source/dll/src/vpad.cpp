#include "vpad.h"

static SRWLOCK g_lock = SRWLOCK_INIT;
static bool g_on[2] = {};
static XINPUT_GAMEPAD g_pad[2] = {};
static DWORD g_packet[2] = {};

DWORD VPadGetState(DWORD index, XINPUT_STATE* state)
{
    if (index < 4) return XInputGetState(index, state);
    if (index >= (DWORD)kVPadSlots || !state) return ERROR_DEVICE_NOT_CONNECTED;
    int i = (int)index - kVPadFirst;
    AcquireSRWLockShared(&g_lock);
    bool on = g_on[i];
    if (on) { state->Gamepad = g_pad[i]; state->dwPacketNumber = g_packet[i]; }
    ReleaseSRWLockShared(&g_lock);
    return on ? ERROR_SUCCESS : ERROR_DEVICE_NOT_CONNECTED;
}

void VPadSetRemote(int slot, const XINPUT_GAMEPAD* pad)
{
    int i = slot - kVPadFirst;
    if (i < 0 || i > 1) return;
    AcquireSRWLockExclusive(&g_lock);
    if (pad) {
        if (!g_on[i] || memcmp(&g_pad[i], pad, sizeof(*pad)) != 0) ++g_packet[i];
        g_pad[i] = *pad;
        g_on[i] = true;
    } else {
        g_on[i] = false;
        ZeroMemory(&g_pad[i], sizeof(g_pad[i]));
    }
    ReleaseSRWLockExclusive(&g_lock);
}

bool VPadRemoteConnected(int slot)
{
    int i = slot - kVPadFirst;
    if (i < 0 || i > 1) return false;
    AcquireSRWLockShared(&g_lock);
    bool on = g_on[i];
    ReleaseSRWLockShared(&g_lock);
    return on;
}
