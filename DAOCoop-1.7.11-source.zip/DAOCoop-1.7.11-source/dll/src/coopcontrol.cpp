#include "online/Paths.h"
#include "coopcontrol.h"
#include "script.h"
#include "game.h"
#include "pads.h"
#include "log.h"
#include "coopcreate.h"
#include "equiplock.h"
#include "interact.h"
#include "targetui.h"
#include "xpshare.h"
#include "regroup.h"
#include "savesafe.h"
#include "camera.h"
#include "views.h"
#include "testpad.h"
#include "screenwall.h"
#include "rings.h"
#include "dialogstage.h"
#include "scaling.h"
#include "vpad.h"
#include "online/OnlinePlay.h"
#include "modmenu.h"
#include "xinputroute.h"
#include <windows.h>
#include <cmath>
#include <cwchar>
#include <cstdio>
#include <cstdarg>
#include <string>

using script::Vec3;

static const uint32_t kNone = game::kInvalidObject;

static const wchar_t* kCompanionTags =
    L"gen00fl_alistair,gen00fl_morrigan,gen00fl_leliana,gen00fl_sten,gen00fl_dog,"
    L"gen00fl_wynne,gen00fl_zevran,gen00fl_oghren,gen00fl_loghain,gen00fl_shale";

// ABI_BASE (M2DA table 1 - every ability "table" maps to it, see rules_core
// sub_00035A90) column TargetType, bit mask (rules_core sub_00035A09 and its
// caller at 0x2A431): 1 self, 2 friendly creature, 4 hostile creature,
// 8 dead creature, 32 ground location.
static const int kTableAbilities = 1;
enum { TT_SELF = 1, TT_FRIEND = 2, TT_HOSTILE = 4, TT_DEAD = 8, TT_GROUND = 32 };

static const int kPropHealth = 7;          // PROPERTY_DEPLETABLE_HEALTH
static const int kValueTotal = 1, kValueCurrent = 3;

static CoopSettings g_s;
static int  g_players = 3;          // players in this game (session): 1 = single player, 2, 3
static bool g_on[2] = { true, true };   // [P2], [P3] active this session (settings + player count)
static bool g_fromLobbyThisRun = false;  // this game was started from the co-op lobby (a new game)

// ---------------------------------------------------------------------------
// Shared state
// ---------------------------------------------------------------------------
static uint32_t   g_hero = kNone;
static int        g_creatureType = 32;     // GetObjectType of a creature; read from the hero
static bool       g_firstInGame = true;
static unsigned   g_nextHeroFind = 0;
static uint32_t   g_rgHero = 0xFFFFFFFF;
static unsigned   g_rgNextHero = 0;
static wchar_t    g_heroName[64] = L"";
static bool       g_sessionBackupDone = false;   // once per game launch
static game::Mode g_lastMode = game::MODE_NONE;
static int        g_lastModeId = -2;

enum Join { JOIN_UNKNOWN, JOIN_IN, JOIN_OUT };

struct Player {
    int        n = 2;                // 2 or 3
    CoopPlayer pad = PLAYER_2;
    uint32_t   colour = 0x4DA6FF;
    const CoopPlayerSettings* cfg = nullptr;

    Join     join = JOIN_UNKNOWN;
    bool     wasConnected = false;
    uint32_t me = kNone, target = kNone, ally = kNone;
    uint32_t borrowed = kNone;       // a companion (not their own character) registered as theirs
    bool     moving = false, followOff = false;
    bool     lbHeld = false, teleported = false;
    unsigned lbStart = 0;
    unsigned nextFind = 0, nextCheck = 0, nextMove = 0, nextDebug = 0, comboStart = 0;
    float    dirX = 0, dirY = 0;
    Vec3     moveTarget = {};          // where the current move order goes
    bool     moveRun = false;
    bool     moveFree = false;         // the current movement is free movement (not a move order)
    // HUD ability bar (portraits.gfx asks DAOCoop.Bar.<id>)
    unsigned nextBar = 0;
    int      barAb[3] = { 0, 0, 0 }, barPage = 0;
    uint32_t barChar = 0xFFFFFFFF;
    bool     moveFollow = false;       // the current movement chases the follow target (1.2.22)
    uint32_t marker = kNone;           // invisible placeable the character chases
    unsigned followIssued = 0, followCheck = 0, followLogUntil = 0, followNextLog = 0;
    Vec3     followCheckPos = {};
    float    followDirX = 0, followDirY = 0;
    float    followHX = 0, followHY = 0;   // smoothed heading the target is placed along
    unsigned followLast = 0;
    unsigned releaseAt = 0, fullSince = 0, markerAt = 0;   // 1.2.35: stick-release grace, time at full tilt
    int      followStuck = 0, followReissues = 0;
    unsigned freeTestStart = 0;        // free movement: when the stick started pushing
    Vec3     freeTestPos = {};
    WORD     prevButtons = 0;
    int      page = 0;
    bool     reportedNone = false;
    int      loggedMoves = 0;
    // idle behaviour / party AI
    uint32_t aiChar = kNone;         // character whose party AI we switched off
    unsigned lastInput = 0, nextIdle = 0, orderUntil = 0;
    uint32_t orderTarget = kNone;    // stand mode: the attack the player ordered
    // View: tap = own inventory, hold 2 s = step away, View + Start = pause
    bool     viewHeld = false, viewCombo = false, viewWarned = false;
    unsigned viewStart = 0;
    // controller feedback
    float    lastHealth = -1.f;
    unsigned nextHealth = 0, nextLowPulse = 0;
    bool     down = false;
    // save safety: this save lacks the player's own character
    // own screens (View + X/Y/B) and the controls sheet (View + A)
    const char* screenReq = nullptr;
    unsigned screenReqAt = 0;
    bool     screenRetried = false;
    unsigned startAt = 0;              // 1.7.2: START held (2 s = the co-op menu, shorter = a press when let go)
    bool     startFired = false;
    bool     restoreOffer = false;
    unsigned lsStart = 0;
    wchar_t  missingName[64] = L"";
};
static Player g_pl[2];

static Player& Other(Player& p) { return g_pl[p.n == 2 ? 1 : 0]; }

static void UpdateOn()
{
    g_on[0] = g_s.player[0].enabled && g_players >= 2;
    g_on[1] = g_s.player[1].enabled && g_players >= 3;
}

void CoopInit(const CoopSettings& s)
{
    CoopFaceSetIni(s.ini);
    g_s = s;
    UpdateOn();
    for (int i = 0; i < 2; ++i) {
        Player& p = g_pl[i];
        p.n = i + 2;
        p.pad = i == 0 ? PLAYER_2 : PLAYER_3;
        p.colour = i == 0 ? 0x4DA6FF : 0x66DD66;
        p.cfg = &g_s.player[i];
        const CoopPlayerSettings& c = g_s.player[i];
        Log("Player %d control: %s, tags \"%ls\", leash %.0f m (combat %.0f m), deadzone %.2f, "
            "slots X/Y/B %d %d %d, RT %d %d %d, LT %d %d %d",
            p.n, c.enabled ? "on" : "off", c.tags[0] ? c.tags : L"(from party)", c.leash, c.leashCombat,
            c.deadzone, c.slots[0][0], c.slots[0][1], c.slots[0][2], c.slots[1][0], c.slots[1][1], c.slots[1][2],
            c.slots[2][0], c.slots[2][1], c.slots[2][2]);
    }
    Log("Drop-in: controllers connected at the start %s; later ones join with START",
        s.autoJoin ? "join by themselves" : "also join with START");
    if (s.expCreate) Log("Experimental: hold View+Start for 2 s to open the creator for that player");
}

int CoopPlayers() { return g_players; }

// ---------------------------------------------------------------------------
// Camera: GameModeController (app+0x114) +0x60 = CameraControllerExplore,
// position at +0x70, focus at +0x80. Returns the flattened forward direction.
// ---------------------------------------------------------------------------
static bool ReadCameraRaw(float* pos, float* focus)
{
    char* app = *reinterpret_cast<char**>(game::kAppPtr);
    if (!app) return false;
    char* owner = *reinterpret_cast<char**>(app + game::kAppCameraOwner);
    if (!owner) return false;
    char* cam = *reinterpret_cast<char**>(owner + game::kCamOwnerCamera);
    if (!cam) return false;
    memcpy(pos, cam + game::kCamPos, 12);
    memcpy(focus, cam + game::kCamFocus, 12);
    return true;
}

static bool ReadCamera(float* pos, float* focus)
{
#ifdef _MSC_VER
    __try { return ReadCameraRaw(pos, focus); }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
#else
    return ReadCameraRaw(pos, focus);
#endif
}

static bool CameraForward(float* fx, float* fy)
{
    // The camera's real view direction (its rotation quaternion). Up to 1.2.5
    // this used focus - position, which is the sideways shoulder offset (and
    // zero when zoomed out): P2's stick was turned 90/180 degrees or fell back
    // to world north, depending on zoom.
    float dx = 0, dy = 0;
    if (!game::CameraLook(&dx, &dy)) return false;
    float len = std::sqrt(dx * dx + dy * dy);
    if (!std::isfinite(len) || len < 0.01f || len > 1000.f) return false;
    *fx = dx / len; *fy = dy / len;
    return true;
}

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------
static void Say(const Player& p, const wchar_t* fmt, ...)
{
    wchar_t text[192];
    va_list ap;
    va_start(ap, fmt);
    _vsnwprintf(text, 191, fmt, ap);
    va_end(ap);
    text[191] = 0;
    script::DisplayStatusMessage(text, p.colour);
    Log("P%d: %ls", p.n, text);
}

static void Floaty(const Player& p, uint32_t obj, const wchar_t* text)
{
    if (obj != kNone) script::DisplayFloatyMessage(obj, text, p.colour, 1.5f);
}

// ---------------------------------------------------------------------------
// Finding a player's character
// ---------------------------------------------------------------------------
static bool NextTag(const wchar_t*& p, wchar_t* out, size_t cap)
{
    while (*p == L',' || *p == L' ') ++p;
    if (!*p) return false;
    size_t n = 0;
    while (*p && *p != L',' && n + 1 < cap) out[n++] = *p++;
    while (n && out[n - 1] == L' ') --n;
    out[n] = 0;
    return n > 0;
}

// Characters this player must not take: the Warden, Player 1's current
// character, and whatever the other co-op player has or owns.
static bool Taken(Player& p, uint32_t obj, uint32_t controlled)
{
    Player& o = Other(p);
    return obj == g_hero || obj == controlled || obj == o.me || obj == CoopCharacterOf(o.n) ||
           obj == CoopCreateCharacter(o.n);
}

static uint32_t FindByTags(Player& p, const wchar_t* list, uint32_t controlled, uint32_t heroArea)
{
    const wchar_t* s = list;
    wchar_t tag[64];
    while (NextTag(s, tag, 64)) {
        uint32_t obj = script::GetObjectByTag(tag, 0);
        if (!script::IsObjectValid(obj) || Taken(p, obj, controlled)) continue;
        if (script::GetArea(obj) != heroArea) continue;
        Log("Player %d is \"%ls\" (object 0x%08X)", p.n, tag, obj);
        return obj;
    }
    return kNone;
}

static int PartyList(uint32_t* out, int max)
{
    int n = game::PartyMembers(out, max);
    static int lastLogged = -2;
    if (n != lastLogged) {
        lastLogged = n;
        char line[256]; int len = 0;
        for (int i = 0; i < n && len < 200; ++i) len += sprintf(line + len, " 0x%08X", out[i]);
        line[len] = 0;
        Log("Party list (%d):%s", n, n > 0 ? line : "");
    }
    return n;
}

static uint32_t FindCharacter(Player& p)
{
    uint32_t heroArea = script::GetArea(g_hero);
    uint32_t controlled = script::GetControlled();

    // The player's own character (made with the creator) always comes first.
    uint32_t mine = CoopCreateCharacter(p.n);
    if (mine != kNone && script::GetArea(mine) == heroArea) {
        Log("Player %d is their own character (object 0x%08X)", p.n, mine);
        CoopFaceRefresh(p.n, mine);
        return mine;
    }

    if (p.cfg->tags[0]) return FindByTags(p, p.cfg->tags, controlled, heroArea);

    // Default: the first party member nobody else is using.
    uint32_t members[16];
    int n = PartyList(members, 16);
    for (int i = 0; i < n; ++i) {
        uint32_t m = members[i];
        if (Taken(p, m, controlled) || !script::IsObjectValid(m)) continue;
        if (script::GetArea(m) != heroArea) continue;
        wchar_t name[64];
        script::GetName(m, name, 64);
        Log("Player %d is party member %d \"%ls\" (object 0x%08X)", p.n, i, name, m);
        {   // a co-op character found this way (1.2.39: Player 3's face was not put back on load)
            wchar_t tag[64] = L"";
            script::GetTag(m, tag, 64);
            if (wcsncmp(tag, L"daocoop_p", 9) == 0 && (tag[9] == L'2' || tag[9] == L'3')) CoopFaceRefresh(tag[9] - L'0', m);
        }
        return m;
    }
    if (n < 0) return FindByTags(p, kCompanionTags, controlled, heroArea);   // party unreadable
    return kNone;
}

// ---------------------------------------------------------------------------
// Character control helpers
// ---------------------------------------------------------------------------
// Free movement works only if the game moves this character from it (1.2.11:
// the call was accepted but Player 2 didn't move). Tested on first use: -1 not
// known yet, 1 works, 0 doesn't -> move orders.
static int g_freeMoveWorks = 1;     // 1.2.43: on - works since directmove.cpp (off 1.2.13-1.2.42)
void CoopFreeMovementTest(bool on) { g_freeMoveWorks = on ? 1 : g_freeMoveWorks; if (on) Log("Free movement: test mode on ([Debug] FreeMovementTest=1) - Player 2/3 always use it"); }

// Follow target (1.2.22): an invisible placeable is kept a few metres ahead of
// the character in the stick direction, and the character gets one
// CommandMoveToObject order to chase it - the way the game moves followers -
// instead of a new move order on every turn. 1 on, 0 off (move orders).
static int g_followMode = 1;
void CoopFollowTarget(bool on) { g_followMode = on ? 1 : 0; Log("Follow target movement: %s", on ? "on" : "off ([Debug] FollowTarget=0)"); }

static void StopMoving(Player& p)
{
    if (p.moving && p.me != kNone) {
        if (p.moveFree) game::DirectStop(p.me);              // free movement: stop like a released stick
        else script::ClearAllCommands(p.me, true);
    }
    p.moving = false;
    p.moveFollow = false;
    p.freeTestStart = 0;
}

// The follow target for this player: reused by tag (so saves don't collect
// copies), re-made when it is gone or in another area.
static uint32_t EnsureMarker(Player& p, const Vec3& pos)
{
    uint32_t area = script::GetArea(p.me);
    if (area == kNone) return kNone;
    if (p.marker != kNone && (!script::IsObjectValid(p.marker) || script::GetArea(p.marker) != area)) p.marker = kNone;
    wchar_t tag[32];
    swprintf(tag, 32, L"daocoop_follow_p%d", p.n);
    if (p.marker == kNone) {
        for (int i = 0; i < 8; ++i) {
            uint32_t o = script::GetObjectByTag(tag, i);
            if (o == kNone) break;
            if (script::GetArea(o) == area) { p.marker = o; break; }
        }
    }
    if (p.marker == kNone) {
        uint32_t o = script::CreateObject(512 /* OBJECT_TYPE_PLACEABLE */, L"genip_inv_target.utp", p.me);
        Log("P%d follow target: CreateObject(genip_inv_target) -> 0x%08X", p.n, o);
        if (o == kNone) return kNone;
        script::SetTag(o, tag);
        p.marker = o;
    }
    return p.marker;
}

void CoopDropMarkers()
{
    for (Player& p : g_pl) {
        if (p.marker != kNone && script::IsObjectValid(p.marker)) script::DestroyObject(p.marker);
        p.marker = kNone;
    }
}

// Returns false when follow-target movement can't be used (then move orders).
static bool FollowMove(Player& p, const Vec3& pos, float dx, float dy, bool run, unsigned now)
{
    uint32_t m = EnsureMarker(p, pos);
    if (m == kNone) return false;

    // Turn the target's heading toward the stick smoothly (max ~360 degrees/s),
    // so a quick flick doesn't swing the target and the path all at once.
    unsigned dtMs = p.moveFollow ? now - p.followLast : 0;
    p.followLast = now;
    if (!p.moveFollow || (p.followHX == 0 && p.followHY == 0)) { p.followHX = dx; p.followHY = dy; }
    else {
        float maxTurn = 6.2832f * (dtMs > 200 ? 200 : dtMs) / 1000.f;
        float cur = std::atan2(p.followHY, p.followHX), want = std::atan2(dy, dx);
        float d = want - cur;
        while (d > 3.14159f) d -= 6.28318f;
        while (d < -3.14159f) d += 6.28318f;
        if (d > maxTurn) d = maxTurn;
        if (d < -maxTurn) d = -maxTurn;
        cur += d;
        p.followHX = std::cos(cur); p.followHY = std::sin(cur);
    }
    // (1.2.41: back to the 1.2.25-1.2.34 settings - 6 m ahead (1.2.35) and the walkable-spot target
    // (1.2.40) both made characters stick more)
    const float ahead = run ? 5.0f : 3.0f;
    Vec3 t = { pos.x + p.followHX * ahead, pos.y + p.followHY * ahead, pos.z };
    script::SetPosition(m, t);

    // One order; renewed only when the character stopped, walk/run changed, or
    // it is heading away from the target (in case the game doesn't re-aim at a
    // moving target). 1.2.24: renewing on every 60-degree turn was jarring.
    float turn = dx * p.followDirX + dy * p.followDirY;
    bool issue = !p.moving || !p.moveFollow || run != p.moveRun;
    const char* why = !p.moveFollow ? "start" : "walk/run";
    if (!issue && (int)(now - p.followCheck) >= 0) {
        float mx = pos.x - p.followCheckPos.x, my = pos.y - p.followCheckPos.y;
        float moved = std::sqrt(mx * mx + my * my);
        float tx = t.x - pos.x, ty = t.y - pos.y, tl = std::sqrt(tx * tx + ty * ty);
        p.followCheckPos = pos;
        p.followCheck = now + 400;
        if (moved < 0.25f && now - p.followIssued > 700) { issue = true; ++p.followStuck; why = "stopped"; }
        else if (moved > 0.3f && tl > 0.5f && (mx * tx + my * ty) / (moved * tl) < 0.0f && now - p.followIssued > 500) {
            issue = true; why = "heading away";
        }
    }
    if (issue) {
        if (p.moving) script::ClearAllCommands(p.me, false);
        bool ok = script::MoveToObject(p.me, m, run, 0.5f, true);
        (void)turn;
        if (p.followReissues < 40) {
            ++p.followReissues;
            Log("P%d follow target order (%s, %s, stuck renewals %d): %s", p.n, run ? "run" : "walk",
                why, p.followStuck, ok ? "ok" : "failed");
        }
        if (!ok) return false;
        if (!p.moveFollow) { p.followLogUntil = now + 6000; p.followNextLog = now; }
        p.moving = true; p.moveFollow = true; p.moveFree = false; p.moveRun = run;
        p.followDirX = dx; p.followDirY = dy;
        p.followIssued = now;
        p.followCheckPos = pos; p.followCheck = now + 400;
    }
    // For the first seconds of each push, log whether the character keeps up.
    if ((int)(p.followLogUntil - now) > 0 && (int)(now - p.followNextLog) >= 0 && p.loggedMoves < 40) {
        ++p.loggedMoves;
        p.followNextLog = now + 1000;
        Log("P%d follow: pos (%.1f %.1f) target (%.1f %.1f) queue %d", p.n, pos.x, pos.y, t.x, t.y,
            script::GetCommandQueueSize(p.me));
    }
    p.dirX = dx; p.dirY = dy;
    return true;
}

static void TakeCharge(Player& p)
{
    if (!p.followOff && p.me != kNone) { script::SetFollowPartyLeader(p.me, false); p.followOff = true; }
}

static void Release(Player& p, bool follow)
{
    if (p.me == kNone) return;
    StopMoving(p);
    if (follow && p.followOff) { script::SetFollowPartyLeader(p.me, true); p.followOff = false; }
}

static void ForgetCharacter(Player& p)
{
    TargetUiClear(p.n);
    p.me = p.target = p.ally = kNone;
    p.moving = p.followOff = false;
    p.aiChar = kNone;                 // object ids change with the area; set again when found
    p.lastHealth = -1.f;
    p.down = false;
    p.orderTarget = kNone;
}

// ---------------------------------------------------------------------------
// Party AI switch (idle behaviour). While a player drives the character the
// game's tactics are switched off (the tactics screen's "AI" box): idle, the
// game then just keeps attacking the current target (rules_core sub_00024242).
// When the player leaves, the AI is switched back on - the AI plays them.
// ---------------------------------------------------------------------------
static void AiTakeOver(Player& p)
{
    if (g_s.idleMode == COOP_IDLE_TACTICS || p.me == kNone || p.aiChar == p.me) return;
    int was = game::GetPartyAI(p.me);
    if (was < 0) { Log("P%d: party AI switch unreadable, idle behaviour from the mod only", p.n); return; }
    if (game::SetPartyAI(p.me, false)) {
        p.aiChar = p.me;
        Log("P%d: tactics AI off while Player %d plays (was %s)", p.n, p.n, was ? "on" : "off");
    }
}

static void AiGiveBack(Player& p)
{
    if (p.aiChar == kNone) return;
    if (script::IsObjectValid(p.aiChar) && game::SetPartyAI(p.aiChar, true))
        Log("P%d: tactics AI back on (the AI plays this character)", p.n);
    p.aiChar = kNone;
}

static void ForgetAll()
{
    for (Player& p : g_pl) ForgetCharacter(p);
    g_hero = kNone;
    TargetUiReset();
}

// Drop-out: the AI takes the character. A borrowed companion goes back to
// Player 1 (equipment); the player's own character stays theirs.
static void Leave(Player& p, const wchar_t* why)
{
    p.join = JOIN_OUT;
    Release(p, true);
    AiGiveBack(p);
    if (p.borrowed != kNone && CoopCharacterOf(p.n) == p.borrowed) EquipLockSetOwner(p.n, kNone);
    p.borrowed = kNone;
    ForgetCharacter(p);
    p.lbHeld = false;
    Say(p, L"Player %d %ls - the AI plays your character. Press START to join again", p.n, why);
}

static void JoinIn(Player& p, const wchar_t* how)
{
    p.join = JOIN_IN;
    p.nextFind = 0;
    p.reportedNone = false;
    Say(p, L"Player %d joined%ls", p.n, how);
}

static void DebugDump(Player& p, unsigned now)
{
    if (!g_s.debug || (int)(now - p.nextDebug) < 0) return;
    p.nextDebug = now + 3000;
    Vec3 hp = {}, pp = {};
    script::GetPosition(g_hero, &hp);
    script::GetPosition(p.me, &pp);
    float cp[3] = {}, cf[3] = {};
    bool cam = ReadCamera(cp, cf);
    float lx = 0, ly = 0;
    bool look = CameraForward(&lx, &ly);
    Log("dbg P%d: hero 0x%08X (%.1f %.1f %.1f) me 0x%08X (%.1f %.1f %.1f) cam %s pos (%.1f %.1f %.1f) focus (%.1f %.1f %.1f) look %s (%.2f %.2f) combat %d paused %d",
        p.n, g_hero, hp.x, hp.y, hp.z, p.me, pp.x, pp.y, pp.z, cam ? "ok" : "unreadable",
        cp[0], cp[1], cp[2], cf[0], cf[1], cf[2], look ? "ok" : "unreadable", lx, ly,
        script::GetCombatState(p.me), game::IsPaused() ? 1 : 0);
}

// ---------------------------------------------------------------------------
// Enemy target
// ---------------------------------------------------------------------------
static bool Usable(uint32_t t)
{
    return t != kNone && script::IsObjectValid(t) && !script::IsDead(t);
}

static int Hostiles(Player& p, uint32_t* out, int max)
{
    int n = script::GetNearestByHostility(p.me, true, g_creatureType, out, max, true, true);
    return n < 0 ? 0 : n;
}

static void SetTarget(Player& p, uint32_t t, bool announce)
{
    p.target = t;
    if (!announce) return;
    if (t == kNone) { Say(p, L"P%d: no enemy target", p.n); return; }
    wchar_t name[64];
    if (!script::GetName(t, name, 64) || !name[0]) wcscpy(name, L"enemy");
    Say(p, L"P%d target: %ls", p.n, name);
}

static void CycleTarget(Player& p)
{
    uint32_t list[8];
    int n = Hostiles(p, list, 8);
    if (n == 0) { SetTarget(p, kNone, true); return; }
    int idx = 0;
    for (int i = 0; i < n; ++i) if (list[i] == p.target) { idx = (i + 1) % n; break; }
    SetTarget(p, list[idx], true);
}

static bool EnsureTarget(Player& p, bool announceNone)
{
    if (Usable(p.target)) return true;
    uint32_t list[1];
    if (Hostiles(p, list, 1) > 0 && script::GetDistance(p.me, list[0]) < 30.f) { SetTarget(p, list[0], true); return true; }
    SetTarget(p, kNone, announceNone);
    return false;
}

// ---------------------------------------------------------------------------
// Ally target (helpful spells)
// ---------------------------------------------------------------------------
// Party members in the player's area (the player included). Falls back to the
// Warden + co-op characters if the party list can't be read.
static int Friends(Player& p, uint32_t* out, int max)
{
    uint32_t all[16];
    int n = game::PartyMembers(all, 16), k = 0;
    if (n < 0) {
        n = 0;
        all[n++] = g_hero;
        all[n++] = p.me;
        if (Other(p).me != kNone) all[n++] = Other(p).me;
    }
    uint32_t area = script::GetArea(p.me);
    for (int i = 0; i < n && k < max; ++i) {
        uint32_t m = all[i];
        if (m == kNone || !script::IsObjectValid(m) || script::GetArea(m) != area) continue;
        bool dup = false;
        for (int j = 0; j < k; ++j) if (out[j] == m) dup = true;
        if (!dup) out[k++] = m;
    }
    return k;
}

static void CycleAlly(Player& p, int dir)
{
    uint32_t list[16];
    int n = Friends(p, list, 16);
    // Positions 0..n-1 = party members, n = "none" (helpful spells pick the most hurt).
    int cur = n;
    for (int i = 0; i < n; ++i) if (list[i] == p.ally) cur = i;
    int idx = (cur + dir + n + 1) % (n + 1);
    p.ally = idx == n ? kNone : list[idx];
    if (p.ally == kNone) {
        Say(p, L"P%d helpful spells: whoever is hurt worst", p.n);
        return;
    }
    wchar_t name[64];
    if (!script::GetName(p.ally, name, 64) || !name[0]) wcscpy(name, L"ally");
    Say(p, L"P%d helpful spells go to: %ls%ls", p.n, name, p.ally == p.me ? L" (you)" : L"");
}

static float HealthFraction(uint32_t c)
{
    float cur = script::GetCreatureProperty(c, kPropHealth, kValueCurrent);
    float max = script::GetCreatureProperty(c, kPropHealth, kValueTotal);
    if (!(max > 0.f) || cur < 0.f) return 1.f;
    return cur / max;
}

// The friend a helpful ability should go to when no ally is picked.
static uint32_t MostHurt(Player& p, bool includeSelf, bool wantDead)
{
    uint32_t list[16];
    int n = Friends(p, list, 16);
    uint32_t best = kNone;
    float bestFrac = 2.f;
    for (int i = 0; i < n; ++i) {
        uint32_t m = list[i];
        if (m == p.me && !includeSelf) continue;
        bool dead = script::IsDead(m);
        if (dead != wantDead) continue;
        float f = dead ? 0.f : HealthFraction(m);
        if (f < bestFrac) { bestFrac = f; best = m; }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------
static void DoAttack(Player& p)
{
    if (!EnsureTarget(p, true)) return;
    StopMoving(p);
    TakeCharge(p);
    bool ok = script::Attack(p.me, p.target, true);
    p.orderTarget = p.target;                       // stand mode: this attack was ordered
    Log("P%d attack 0x%08X: %s", p.n, p.target, ok ? "ok" : "failed");
}

static int AbilityTargetType(int ability)
{
    int tt = script::GetM2DAInt(kTableAbilities, L"TargetType", ability);
    static int logged = 0;
    if (logged < 30) { ++logged; Log("Ability %d: TargetType %d", ability, tt); }
    return tt;
}

// Picks who an ability goes to, from the ability's own TargetType:
// hostile -> the enemy target; friendly -> the picked ally, else the most hurt
// friend; self-only -> yourself; ground -> at the enemy (or at your feet).
static uint32_t PickAbilityTarget(Player& p, int ability, const wchar_t** why)
{
    int tt = AbilityTargetType(ability);
    if (tt <= 0) {                                   // unknown: old behaviour
        *why = L"enemy or self";
        if (!Usable(p.target)) EnsureTarget(p, false);
        return Usable(p.target) ? p.target : p.me;
    }
    if (tt & TT_HOSTILE) {
        *why = L"enemy";
        if (EnsureTarget(p, false)) return p.target;
        if (tt & TT_GROUND) { *why = L"ground"; return p.me; }
        if (tt & TT_SELF)   { *why = L"self"; return p.me; }
        return kNone;
    }
    if (tt & (TT_FRIEND | TT_DEAD)) {
        bool deadOk = (tt & TT_DEAD) != 0, aliveOk = (tt & TT_FRIEND) != 0;
        *why = L"ally";
        if (p.ally != kNone && script::IsObjectValid(p.ally) && (p.ally != p.me || (tt & TT_SELF))) {
            bool dead = script::IsDead(p.ally);
            if ((dead && deadOk) || (!dead && aliveOk)) return p.ally;
        }
        uint32_t m = kNone;
        if (deadOk) m = MostHurt(p, false, true);            // revive: a fallen friend first
        if (m == kNone && aliveOk) m = MostHurt(p, (tt & TT_SELF) != 0, false);
        if (m != kNone) return m;
        if (tt & TT_SELF) { *why = L"self"; return p.me; }
        return kNone;
    }
    if (tt & TT_SELF) { *why = L"self"; return p.me; }
    if (tt & TT_GROUND) {
        *why = L"ground";
        if (EnsureTarget(p, false)) return p.target;
        return p.me;
    }
    *why = L"enemy or self";
    return Usable(p.target) ? p.target : p.me;
}

static void DoSlot(Player& p, int slot, const wchar_t* button)
{
    int ability = script::GetQuickSlot(p.me, slot);
    if (ability <= 0) { Say(p, L"P%d: quickbar slot %d (%ls) is empty", p.n, slot + 1, button); return; }
    if (!script::IsAbilityAvailable(p.me, ability)) { Say(p, L"P%d: %ls not ready", p.n, button); return; }
    const wchar_t* why = L"";
    uint32_t target = PickAbilityTarget(p, ability, &why);
    if (target == kNone) {
        Say(p, L"P%d: no %ls for that ability", p.n, wcscmp(why, L"ally") == 0 ? L"friend" : L"enemy");
        return;
    }
    Vec3 pos = {};
    script::GetPosition(target, &pos);
    StopMoving(p);
    TakeCharge(p);
    bool ok = script::UseAbility(p.me, ability, target, pos, true);
    p.orderUntil = GetTickCount() + 5000;           // stand mode: let the cast finish
    Log("P%d %ls (slot %d): ability %d on 0x%08X (%ls): %s", p.n, button, slot, ability, target, why, ok ? "ok" : "failed");
}

// ---------------------------------------------------------------------------
// Per-player tick (playable modes only)
// ---------------------------------------------------------------------------
static void HandleJoin(Player& p, const PadSnapshot& pad, WORD pressed, bool* consumedStart)
{
    bool conn = pad.connected;
    if (p.join == JOIN_UNKNOWN) {
        if (conn && g_s.autoJoin) JoinIn(p, L"");
        else {
            p.join = JOIN_OUT;
            // A save made while this player was in control has the tactics AI
            // off for their own character: the AI plays it now, so switch it on.
            uint32_t own = CoopCreateCharacter(p.n);
            if (own != kNone && game::GetPartyAI(own) == 0 && game::SetPartyAI(own, true))
                Log("P%d: not playing - tactics AI on for their character", p.n);
            if (conn) Say(p, L"Player %d: press START to join", p.n);
            else Log("Player %d: no controller yet (pad slot from [Controllers])", p.n);
        }
    } else if (p.join == JOIN_IN && !conn) {
        Leave(p, L"controller disconnected");
    } else if (p.join == JOIN_OUT && conn) {
        if (!p.wasConnected) Say(p, L"Player %d controller connected - press START to join", p.n);
        if (pressed & (XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_BACK)) {
            JoinIn(p, L"");
            *consumedStart = true;
        }
    }
    p.wasConnected = conn;
}

// ---------------------------------------------------------------------------
// The player's own screens: inventory, character record, journal. Their
// character is selected for the screen (the equipment lock gives Player 1
// theirs back when it closes) and their controller drives it.
// ---------------------------------------------------------------------------
static void OpenOwnScreen(Player& p, const char* screen, unsigned now)
{
    StopMoving(p);
    EquipLockAllowControl(4000);
    CoopNoteScreenOpener(p.n);
    script::SetPrimaryControlled(p.me);
    char msg[96];
    sprintf(msg, "GUI.ToggleFullScreenGUIMessage %s", screen);
    game::SendGameMessage(msg);
    p.screenReq = screen;
    p.screenReqAt = now;
    p.screenRetried = false;
    Log("P%d: opening their %s", p.n, screen);
}

// If the screen didn't open (wrong message target), try the other route once.
static void ScreenRequestTick(Player& p, unsigned now, game::Mode mode)
{
    if (!p.screenReq) return;
    if (mode == game::MODE_GUI) { p.screenReq = nullptr; return; }
    if (now - p.screenReqAt < 800) return;
    if (!p.screenRetried) {
        p.screenRetried = true;
        p.screenReqAt = now;
        char msg[96];
        sprintf(msg, "GameModeController.PushGUIScreen %s", p.screenReq);
        EquipLockAllowControl(4000);
        CoopNoteScreenOpener(p.n);
        game::SendGameMessage(msg);
        return;
    }
    Log("P%d: the %s screen did not open", p.n, p.screenReq);
    p.screenReq = nullptr;
}

// Controls sheet: shown line by line in the status area.
// 1.7.2: the controls are in the co-op menu (1.7.7: hold View 2 s, Controls tab); View + A is gone.
static void HelpHint(Player& p) { Say(p, L"Player %d: hold View for 2 seconds for the co-op menu - all controls, voice chat, step away", p.n); }

// 1.7.7: "Step away" in the co-op menu (it was View held 2 s): done on the next tick
static volatile bool g_stepAwayReq[2] = {};
static void StepAwayFromMenu(int player) { if (player == 2 || player == 3) g_stepAwayReq[player - 2] = true; }

// ---------------------------------------------------------------------------
// Controller feedback: rumble when hit (stronger for bigger hits), a heartbeat
// below 25% health, and a message + long rumble when knocked out.
// ---------------------------------------------------------------------------
static void HealthFeedback(Player& p, unsigned now)
{
    if ((int)(now - p.nextHealth) < 0) return;
    p.nextHealth = now + 150;
    int deadRc = script::IsDeadChecked(p.me);
    if (deadRc < 0) return;                                // couldn't tell: keep the last state
    bool dead = deadRc != 0;
    if (dead != p.down) {
        p.down = dead;
        if (dead) {
            StopMoving(p);
            Say(p, L"Player %d is down - back up after the fight", p.n);
            if (g_s.rumble) PadsRumble(p.pad, 700, (int)(60000 * g_s.rumbleScale));
        } else {
            Say(p, L"Player %d is back up", p.n);
        }
    }
    if (dead) { p.lastHealth = -1.f; return; }
    float f = HealthFraction(p.me);
    if (g_s.rumble && p.lastHealth >= 0.f && f < p.lastHealth - 0.005f) {
        float drop = p.lastHealth - f;                     // share of max health lost
        int strength = 22000 + (int)(drop * 250000.f);
        int ms = 110 + (int)(drop * 900.f);
        PadsRumble(p.pad, ms > 450 ? 450 : ms, (int)((strength > 65535 ? 65535 : strength) * g_s.rumbleScale));
    }
    p.lastHealth = f;
    if (g_s.rumble && f < 0.25f && (int)(now - p.nextLowPulse) >= 0) {
        p.nextLowPulse = now + 1400;                       // low health heartbeat
        PadsRumble(p.pad, 90, (int)(16000 * g_s.rumbleScale));
    }
}

// ---------------------------------------------------------------------------
// Idle in combat (no input for a moment):
//   Attack  - keep fighting: attack the current target (or the nearest enemy)
//   Stand   - stand still: AI-started attacks are cancelled; attacks and spells
//             the player ordered still finish
//   Tactics - the game's own party AI (the character's tactics) takes over
// ---------------------------------------------------------------------------
static void IdleInCombat(Player& p, unsigned now, game::Mode mode)
{
    if (mode != game::MODE_COMBAT || g_s.idleMode == COOP_IDLE_TACTICS) return;
    if (now - p.lastInput < 1200 || (int)(now - p.nextIdle) < 0) return;
    if (g_s.idleMode == COOP_IDLE_ATTACK) {
        p.nextIdle = now + 1000;
        if (script::GetCommandQueueSize(p.me) != 0) return;     // still busy
        if (!EnsureTarget(p, false)) return;
        TakeCharge(p);
        bool ok = script::Attack(p.me, p.target, false);
        static int logged = 0;
        if (logged < 10) { ++logged; Log("P%d idle in combat: keep attacking 0x%08X: %s", p.n, p.target, ok ? "ok" : "failed"); }
        return;
    }
    // Stand still
    p.nextIdle = now + 400;
    if ((int)(now - p.orderUntil) < 0) return;                  // a spell the player cast
    if (p.orderTarget != kNone && Usable(p.orderTarget)) return; // the attack the player ordered
    p.orderTarget = kNone;
    // (also clears the current command: the queue size may not count it)
    p.moving = false;
    script::ClearAllCommands(p.me, true);
}

static void PlayerTick(Player& p, unsigned now, game::Mode mode, const PadSnapshot& pad, WORD buttons, WORD pressed)
{
    if (p.join != JOIN_IN || g_hero == kNone) return;

    // This save doesn't have the player's own character: holding LS (left stick
    // click) for 2 s copies the newest backup that has it into the Load list.
    if (p.restoreOffer) {
        if (buttons & XINPUT_GAMEPAD_LEFT_THUMB) {
            if (!p.lsStart) p.lsStart = now ? now : 1;
            else if (now - p.lsStart > 2000) {
                p.restoreOffer = false;
                p.lsStart = 0;
                wchar_t msg[160];
                SaveSafeRestore(g_heroName, p.n, msg, 160);
                Say(p, L"%ls", msg);
            }
        } else {
            p.lsStart = 0;
        }
    }

    // --- find this player's character (once a second until found) ----------
    if (p.me == kNone) {
        if ((int)(now - p.nextFind) < 0) return;
        p.nextFind = now + 1000;
        p.me = FindCharacter(p);
        if (p.me == kNone) {
            if (!p.reportedNone) {
                p.reportedNone = true;
                Log("Player %d: no free party member in the Warden's area yet", p.n);
            }
        } else {
            p.reportedNone = false;
            EquipLockSetOwner(p.n, p.me);
            p.borrowed = p.me != CoopCreateCharacter(p.n) ? p.me : kNone;
            // The player is in charge of this character: no automatic following,
            // not even before they first touch the stick or after an area change.
            p.followOff = false;
            TakeCharge(p);
            AiTakeOver(p);
            if (g_s.helpOnce && g_s.ini[0]) {
                wchar_t key[16];
                swprintf(key, 16, L"ShownP%d", p.n);
                if (!GetPrivateProfileIntW(L"Help", key, 0, g_s.ini)) {
                    WritePrivateProfileStringW(L"Help", key, L"1", g_s.ini);
                    HelpHint(p);
                }
            }
            if (p.me == CoopCreateCharacter(p.n)) {
                wchar_t nm[64];
                if (script::GetName(p.me, nm, 64) && nm[0]) SaveSafeRecord(g_heroName, p.n, nm);
                p.restoreOffer = false;
            }
            p.nextCheck = now + 3000;
            p.lastInput = now;
        }
    }

    // Every few seconds make sure the character still exists (area change,
    // party change). Objects get new IDs after loading an area.
    if (p.me != kNone && (int)(now - p.nextCheck) >= 0) {
        p.nextCheck = now + 3000;
        if (!script::IsObjectValid(p.me) || script::GetArea(p.me) != script::GetArea(g_hero)) {
            Log("Player %d: lost their character (area change?), searching again", p.n);
            ForgetCharacter(p);
            return;
        }
    }

    // Experimental creation combo: View + Start held for 2 seconds.
    const WORD combo = XINPUT_GAMEPAD_BACK | XINPUT_GAMEPAD_START;
    if (g_s.expCreate) {
        if ((buttons & combo) == combo) {
            if (!p.comboStart) p.comboStart = now ? now : 1;
            else if (p.comboStart != 0xFFFFFFFF && now - p.comboStart > 2000) {
                p.comboStart = 0xFFFFFFFF;          // fire once per hold
                Log("Debug combo: opening the creator for Player %d", p.n);
                Release(p, true);
                CoopCreateBegin(p.n, g_hero, g_creatureType);
            }
            return;
        }
        p.comboStart = 0;
    }

    if (p.me == kNone) return;
    DebugDump(p, now);

    ScreenRequestTick(p, now, mode);
    if (p.ally != kNone && !script::IsObjectValid(p.ally)) p.ally = kNone;
    TargetUiTick(now, p.n, p.me, true, mode == game::MODE_COMBAT, p.target, p.ally, p.dirX, p.dirY);

    // View (1.2.33): tap = their own inventory (their controller runs it); held 2 s = step away;
    // View + Start = pause / unpause for everyone; View + X / Y / B = inventory / character record / journal.
    if (pressed & XINPUT_GAMEPAD_BACK) { p.viewHeld = true; p.viewCombo = false; p.viewWarned = false; p.viewStart = now; }
    if (p.viewHeld) {
        if ((pressed & XINPUT_GAMEPAD_START) && g_s.pauseCombo && !g_s.expCreate) {
            p.viewCombo = true;
            bool paused = game::IsPaused();
            if (game::SendGameMessage("GameModeController.UserTogglePauseMessage"))
                Say(p, paused ? L"Player %d unpaused the game" : L"Player %d paused the game (View + Start again to go on)", p.n);
        }
        if (pressed & (XINPUT_GAMEPAD_X | XINPUT_GAMEPAD_Y | XINPUT_GAMEPAD_B)) {
            p.viewCombo = true;
            if (pressed & XINPUT_GAMEPAD_X) OpenOwnScreen(p, "Inventory", now);
            else if (pressed & XINPUT_GAMEPAD_Y) OpenOwnScreen(p, "CharacterRecord", now);
            else OpenOwnScreen(p, "Journal", now);
        }
        bool down = (buttons & XINPUT_GAMEPAD_BACK) != 0;
        if (down && !p.viewCombo) {
            // 1.7.7: held 2 s = the co-op menu (it has "Step away"). An online friend's controller: their own PC opens
            // their menu, and only ever sends a long View when they picked "Step away" in it.
            const int slot = PadsIndex(p.pad);
            const bool local = slot >= 0 && slot < kVPadFirst;
            if (now - p.viewStart > 2000) {
                p.viewHeld = false;
                if (local) { StopMoving(p); ModMenuShow(p.n, slot); return; }
                Leave(p, L"stepped away");
                return;
            }
        }
        if (!down) {
            p.viewHeld = false;
            if (!p.viewCombo && now - p.viewStart < 700) OpenOwnScreen(p, "Inventory", now);   // a tap
        }
        StopMoving(p);
        return;                                     // nothing else while View is down
    }

    HealthFeedback(p, now);
    if (p.down) { StopMoving(p); return; }          // knocked out: back up after the fight

    // Player 1 switched to this character: hands off.
    if (script::GetControlled() == p.me) { Release(p, false); return; }

    // LB held 1.5 s: teleport next to the Warden (the player's own choice).
    bool lb = (buttons & XINPUT_GAMEPAD_LEFT_SHOULDER) != 0;
    if (lb != p.lbHeld) { p.lbHeld = lb; p.lbStart = now; p.teleported = false; }
    if (lb) {
        if (!p.teleported && now - p.lbStart > 1500) {
            p.teleported = true;
            StopMoving(p);
            RegroupTeleport(p.n, p.me, g_hero, "LB held");
        }
        RegroupNoteStick(p.n, false, now);
        return;
    }

    // --- buttons ------------------------------------------------------------
    if (pressed & XINPUT_GAMEPAD_RIGHT_SHOULDER) CycleTarget(p);
    if (pressed & XINPUT_GAMEPAD_DPAD_RIGHT) CycleAlly(p, +1);
    if (pressed & XINPUT_GAMEPAD_DPAD_LEFT)  CycleAlly(p, -1);
    // A: attack in combat (or when a target is picked), otherwise use the
    // nearest chest/door/body/lever; D-pad up: always use.
    if (pressed & XINPUT_GAMEPAD_A) {
        if (mode == game::MODE_COMBAT || Usable(p.target)) DoAttack(p);
        else if (!InteractUse(p.n, p.me, p.dirX, p.dirY)) DoAttack(p);
    }
    if (pressed & XINPUT_GAMEPAD_DPAD_UP) {
        StopMoving(p);
        if (!InteractUse(p.n, p.me, p.dirX, p.dirY)) Say(p, L"Player %d: nothing to use here", p.n);
    }

    // Ability pages: hold RT for page 2, LT for page 3.
    int page = pad.gamepad.bLeftTrigger > 100 ? 2 : pad.gamepad.bRightTrigger > 100 ? 1 : 0;
    if (page != p.page) { p.page = page; p.nextBar = 0; }   // the HUD bar next to the portrait shows the page (1.2.24)
    const int* slots = p.cfg->slots[p.page];
    if ((int)(now - p.nextBar) >= 0) {
        p.nextBar = now + 400;
        for (int k = 0; k < 3; ++k) p.barAb[k] = script::GetQuickSlot(p.me, slots[k]);
        p.barPage = p.page;
        p.barChar = p.me;
    }
    if (pressed & XINPUT_GAMEPAD_X) DoSlot(p, slots[0], L"X");
    if (pressed & XINPUT_GAMEPAD_Y) DoSlot(p, slots[1], L"Y");
    if (pressed & XINPUT_GAMEPAD_B) DoSlot(p, slots[2], L"B");

    // --- left stick movement ------------------------------------------------
    float sx = pad.gamepad.sThumbLX / 32767.f, sy = pad.gamepad.sThumbLY / 32767.f;
    float mag = std::sqrt(sx * sx + sy * sy);
    if (pressed || pad.gamepad.bLeftTrigger > 100 || pad.gamepad.bRightTrigger > 100 || mag >= p.cfg->deadzone)
        p.lastInput = now;
    if (mag < p.cfg->deadzone) {
        RegroupNoteStick(p.n, false, now);
        StopMoving(p);
        IdleInCombat(p, now, mode);
        return;
    }
    p.orderTarget = kNone;                          // walking away ends an ordered attack
    sx /= mag; sy /= mag;                         // unit direction
    if (mag > 1.f) mag = 1.f;

    // Stick up = away from the camera. Fall back to world axes if the camera
    // can't be read.
    float fx = 0, fy = 1;
    CameraForward(&fx, &fy);
    {   // 1.7.0: with their own view, "up" is away from their camera (Player 1's turned by their own turn)
        float hx, hy;
        if (ViewsJoinerHeading(p.n, &hx, &hy)) { fx = hx; fy = hy; }   // their own camera's heading
    }
    float rx = fy, ry = -fx;                      // right = forward rotated -90 degrees (z up)
    float dx = fx * sy + rx * sx, dy = fy * sy + ry * sx;

    // Free movement, exactly like Player 1's stick outside the tactical camera
    // (the engine's own direct-move action, see game::DirectMove), re-sent only
    // when the heading turns or walk/run changes, like the game does. If the
    // game turns out not to move this character from it, move orders instead.
    TakeCharge(p);
    // the game: full tilt runs, partial tilt walks (0x7636A0); with some
    // hysteresis so a stick hovering near full tilt doesn't flip it (1.2.25)
    bool run = (p.moving && p.moveRun) ? mag > 0.75f : mag > 0.92f;
    Vec3 pos, hp;
    if (!script::GetPosition(p.me, &pos)) return;

    // Leash: at the leash distance, stop moving further away from the Warden
    // (sliding along the edge is still allowed).
    bool leashed = false;
    float leash = mode == game::MODE_COMBAT ? p.cfg->leashCombat : p.cfg->leash;
    {   // 1.7.4: with their own views, the tether is as long as Player 1's camera draws (farther, and the world
        // would no longer be drawn around them for Player 1's view); the [P2] leash settings are the least
        // 1.7.8: not the whole distance - measured from the Warden, while Player 1's camera sits back and above them, so at
        // the far edge a player vanished from their own view. [Views] TetherPercent of the draw distance (default 60).
        static int pctSet = -1;
        if (pctSet < 0) {
            pctSet = (int)GetPrivateProfileIntA("Views", "TetherPercent", 60, Paths::GetConfigPath().c_str());
            pctSet = pctSet < 20 ? 20 : pctSet > 100 ? 100 : pctSet;
        }
        const float drawM = ViewsP1DrawDistance() * pctSet / 100.f;
        if (leash > 0 && drawM - 2.f > leash) leash = drawM - 2.f;
    }
    if (leash > 0 && script::GetPosition(g_hero, &hp)) {
        float ox = pos.x - hp.x, oy = pos.y - hp.y;
        float d = std::sqrt(ox * ox + oy * oy);
        if (d > leash - 0.5f && d > 0.01f) {
            ox /= d; oy /= d;
            float out = dx * ox + dy * oy;                 // part of the move pointing away
            if (out > 0.f) {
                dx -= out * ox; dy -= out * oy;
                leashed = true;
                float l = std::sqrt(dx * dx + dy * dy);
                if (l < 0.2f) { StopMoving(p); RegroupNoteStick(p.n, false, now); return; }
                dx /= l; dy /= l;
            }
        }
    }
    // Shared screen (1.2.44): not off the screen, not away from someone at its edge.
    if (!ScreenWallFilter(p.me, dx, dy)) { StopMoving(p); RegroupNoteStick(p.n, false, now); return; }

    float dot = dx * p.dirX + dy * p.dirY;             // cos of the turn since the last order

    if (g_freeMoveWorks != 0) {
        bool resend = !p.moving || !p.moveFree || dot < 0.9994f /* ~2 degrees */ || run != p.moveRun ||
                      game::DirectMoving(p.me) == 0 || (int)(now - p.nextMove) >= 0;
        if (resend) {
            bool ok = game::DirectMove(p.me, dx, dy, fx, fy, run);
            if (p.loggedMoves < 5) {
                ++p.loggedMoves;
                Log("P%d free move heading (%.2f %.2f) %s: %s", p.n, dx, dy, run ? "run" : "walk", ok ? "ok" : "failed");
            }
            p.moving = ok; p.moveFree = true; p.moveRun = run;
            p.dirX = dx; p.dirY = dy;
            p.nextMove = now + 1000;
        }
        // First use: did the character actually move?
        if (g_freeMoveWorks < 0) {
            if (!p.freeTestStart) { p.freeTestStart = now ? now : 1; p.freeTestPos = pos; }
            else if (now - p.freeTestStart > 3000) {
                float mx = pos.x - p.freeTestPos.x, my = pos.y - p.freeTestPos.y;
                float moved = std::sqrt(mx * mx + my * my);
                g_freeMoveWorks = moved > 0.3f ? 1 : 0;
                Log("Free movement: Player %d moved %.2f m in %u ms - %s", p.n, moved, now - p.freeTestStart,
                    g_freeMoveWorks ? "works, keeping it" : "the game doesn't move this character from it, using move orders");
                game::DirectStop(p.me); p.moving = false;      // either way: restart cleanly (and undo the local-drive flags)
            }
        }
        if (g_freeMoveWorks != 0) { RegroupNoteStick(p.n, p.moving && !leashed, now); return; }
    }

    if (g_followMode) {
        if (FollowMove(p, pos, dx, dy, run, now)) { RegroupNoteStick(p.n, !leashed, now); return; }
        Log("P%d: follow target unavailable - using move orders", p.n);
        g_followMode = 0;
    }

    // Move orders (CommandMoveToLocation): one order 6 m ahead, renewed only on
    // a turn of more than ~12 degrees, a walk/run change, < 3 m left, or 0.8 s.
    // Each new order makes the game plan a new path and can restart the run
    // animation, so renew as rarely as possible: a turn of more than ~18 degrees,
    // a walk/run change, or less than 4 m left of the 10 m order (1.2.20: jagged
    // when renewed every 0.8 s / 12 degrees).
    if (p.moving && !p.moveFree && !p.moveFollow && dot > 0.95f && run == p.moveRun) {
        float rx2 = p.moveTarget.x - pos.x, ry2 = p.moveTarget.y - pos.y;
        if (rx2 * rx2 + ry2 * ry2 > 4.f * 4.f) { RegroupNoteStick(p.n, !leashed, now); return; }
    }
    const float step = 10.0f;
    Vec3 target = { pos.x + dx * step, pos.y + dy * step, pos.z };
    float facing = std::atan2(dy, dx) * 57.29578f;
    if (p.moving) script::ClearAllCommands(p.me, false);      // drop the old order (soft: no stop animation)
    bool ok = script::MoveTo(p.me, target, facing, run, true);
    if (p.loggedMoves < 10) {
        ++p.loggedMoves;
        Log("P%d move to (%.1f %.1f %.1f) %s: %s", p.n, target.x, target.y, target.z, run ? "run" : "walk", ok ? "ok" : "failed");
    }
    p.moveTarget = target;
    p.moving = ok; p.moveFree = false; p.moveFollow = false; p.moveRun = run;
    p.dirX = dx; p.dirY = dy;
    p.nextMove = now + 800;
    RegroupNoteStick(p.n, ok && !leashed, now);
}

// ---------------------------------------------------------------------------

// 1.2.31: a player with no working controller (theirs unplugged, or an online friend who connected
// after the lobby) takes a free one when START is pressed on it: local controllers 1-3 or online
// friends (slots 4/5). So Players 2 and 3 can be any mix of local and online.
static void ClaimFreeControllers(bool playable)
{
    static bool scanning = false;
    if (!playable) return;                       // (the lobby manages the scan in the menus)
    bool need = false;
    for (int i = 0; i < 2; ++i) if (g_on[i] && !PadsGet(g_pl[i].pad).connected) need = true;
    if (need != scanning) { PadsScanSlots(need); scanning = need; }
    if (!need) return;
    for (int slot = 0; slot < kVPadSlots; ++slot) {
        if (slot == PadsP1Index() || slot == PadsIndex(PLAYER_2) || slot == PadsIndex(PLAYER_3)) continue;
        WORD pr = PadsTakePressed(slot);
        if (!(pr & (XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_A))) continue;
        for (int i = 0; i < 2; ++i) {
            Player& p = g_pl[i];
            if (!g_on[i] || PadsGet(p.pad).connected) continue;
            PadsAssign(p.pad, slot);
            EquipLockSetPads(PadsIndex(PLAYER_2), PadsIndex(PLAYER_3));
            std::wstring who = slot >= kVPadFirst ? OnlinePlay::FriendName(slot) : std::wstring();
            if (!who.empty()) Say(p, L"Player %d: %ls (online) takes over - press START to join", p.n, who.c_str());
            else Say(p, L"Player %d: controller %d takes over - press START to join", p.n, slot + 1);
            Log("Player %d now uses controller slot %d%s", p.n, slot, slot >= kVPadFirst ? " (online friend)" : "");
            break;
        }
    }
}

void CoopTick(unsigned now)
{
    if (!script::Ready()) return;

    // --- what is the game doing? ---------------------------------------------
    int modeId = -1;
    game::Mode mode = game::CurrentMode(&modeId);
    if (mode != g_lastMode || modeId != g_lastModeId) {
        Log("Game mode: %s (id %d)%s", game::ModeName(mode), modeId, game::IsPaused() ? ", paused" : "");
        if (mode == game::MODE_LOADING || mode == game::MODE_PREGAME || mode == game::MODE_NONE) ForgetAll();
        g_lastMode = mode; g_lastModeId = modeId;
    }
    bool playable = mode == game::MODE_EXPLORE || mode == game::MODE_COMBAT;
    DialogStageTick(now, (int)mode, CoopPlayerActive(2) ? CoopCharacterOf(2) : kNone, CoopPlayerActive(3) ? CoopCharacterOf(3) : kNone);
    // A screen a player asked for has opened: forget the request. (1.2.34: this was only checked in
    // the per-player tick, which doesn't run while a screen is open, so after the player closed it
    // the "did not open" retry opened it again - with Player 1's character.)
    if (!playable) for (Player& q : g_pl) if (q.screenReq && (mode == game::MODE_GUI || mode == game::MODE_CHARGEN)) q.screenReq = nullptr;

    // --- controllers -------------------------------------------------------------
    ClaimFreeControllers(playable);
    PadSnapshot pads[2];
    WORD buttons[2], pressed[2];
    for (int i = 0; i < 2; ++i) {
        Player& p = g_pl[i];
        pads[i] = g_on[i] ? PadsGet(p.pad) : PadSnapshot{};
        buttons[i] = pads[i].connected ? pads[i].gamepad.wButtons : 0;
        // Track buttons in every mode, so a press in a menu doesn't fire later.
        pressed[i] = buttons[i] & ~p.prevButtons;
        p.prevButtons = buttons[i];
    }

    // --- drop-in / drop-out (in the game world only) ---------------------------
    bool startUsed[2] = { false, false };
    if (playable)
        for (int i = 0; i < 2; ++i)
            if (g_on[i]) {
                HandleJoin(g_pl[i], pads[i], pressed[i], &startUsed[i]);
                if (startUsed[i]) pressed[i] = 0;          // the join press does nothing else
            }

    // --- own characters (creator) and level-ups --------------------------------
    // 1.7.7: the co-op menu is View held 2 s (PlayerTick; Player 1's controller through the game's controller
    // hook) - START is a plain press again (level up)
    XInputRouteStartFilter(playable);
    { static bool reg = false; if (!reg) { reg = true; ModMenuSetStepAway(&StepAwayFromMenu); } }
    bool start[4] = {}, canPrompt[4] = {};
    for (int i = 0; i < 2; ++i) {
        Player& p = g_pl[i];
        bool joined = p.join == JOIN_IN && pads[i].connected;
        if (ModMenuOpenFor(p.n)) pressed[i] = 0;
        start[p.n] = joined && !startUsed[i] && (pressed[i] & XINPUT_GAMEPAD_START) && !(buttons[i] & XINPUT_GAMEPAD_BACK);
        canPrompt[p.n] = joined;
        if (g_stepAwayReq[i]) {                                // "Step away" picked in their co-op menu
            g_stepAwayReq[i] = false;
            if (p.join == JOIN_IN) Leave(p, L"stepped away");
        }
    }
    bool prompting[4] = { false, false, CoopCreatePrompting(2), CoopCreatePrompting(3) };
    CoopCreateTick(now, g_hero, g_creatureType, start, canPrompt);
    for (int i = 0; i < 2; ++i) {
        Player& p = g_pl[i];
        // START (when the creator isn't asking): open this player's own level-up screen.
        if (!start[p.n] || prompting[p.n] || CoopCreateBusy() || p.me == kNone || !playable) continue;
        if (script::GetCanLevelUp(p.me)) {
            Log("P%d: opening Player %d's level-up screen", p.n, p.n);
            StopMoving(p);
            CoopNoteScreenOpener(p.n);
            script::StartCharGen(p.me, 1);
        } else {
            Say(p, L"Player %d: no level-up yet", p.n);
        }
    }
    if (CoopCreateBusy()) {
        // Hand the current characters back to the AI (a borrowed companion must
        // not be left standing with "follow" off once its player gets their own).
        for (Player& p : g_pl) { Release(p, true); p.me = p.target = kNone; p.followOff = false; }
        g_hero = kNone;                                      // re-find everything afterwards
        return;
    }

    XpShareTick(now, g_hero, playable);

    // Placement safety net: works even when a co-op character was left in
    // another area (then the normal search can't find it).
    if (playable && (int)(now - g_rgNextHero) >= 0) {
        g_rgNextHero = now + 1000;
        uint32_t h = script::GetHero();
        g_rgHero = script::IsObjectValid(h) ? h : 0xFFFFFFFF;
    }
    for (Player& p : g_pl) RegroupTick(now, p.n, CoopCharacterOf(p.n), g_rgHero, (int)mode);

    if (!playable) {
        for (Player& p : g_pl) StopMoving(p);
        CameraSetPlayers(nullptr, 0, false);
        ScreenWallSetPlayers(nullptr, nullptr, nullptr, 0, false, g_hero, now);
        RingsSetMarkers(nullptr, 0, nullptr, 0, false, false);
        return;
    }

    // --- the Warden (once a second until found) -----------------------------
    // Re-find when the game's hero changes (the creator moved it; it's put back).
    if (g_hero != kNone && (int)(now - g_nextHeroFind) >= 0) {
        uint32_t h = game::HeroId();
        if (h != kNone && h != g_hero && CoopCreateCharacter(2) != h && CoopCreateCharacter(3) != h) {
            Log("Hero changed 0x%08X -> 0x%08X", g_hero, h);
            g_hero = kNone;
        }
    }
    if (g_hero == kNone || ((int)(now - g_nextHeroFind) >= 0 && !script::IsObjectValid(g_hero))) {
        if ((int)(now - g_nextHeroFind) < 0) return;
        g_nextHeroFind = now + 1000;
        g_hero = script::GetHero();
        if (!script::IsObjectValid(g_hero)) { g_hero = kNone; return; }
        if (!script::GetName(g_hero, g_heroName, 64)) g_heroName[0] = 0;
        // A save with co-op characters in it is a co-op game, whatever the
        // last session said (e.g. "New Game" was used in between).
        int need = CoopCreateCharacter(3) != kNone ? 3 : CoopCreateCharacter(2) != kNone ? 2 : 1;
        if (need > g_players) {
            Log("Session: this save has Player %d's own character", need);
            CoopSetPlayers(need, false);
        }
        if (g_players >= 2) {
            wchar_t n2[64] = L"", n3[64] = L"";
            if (CoopCreateCharacter(2) != kNone) script::GetName(CoopCreateCharacter(2), n2, 64);
            if (CoopCreateCharacter(3) != kNone) script::GetName(CoopCreateCharacter(3), n3, 64);
            if (!g_sessionBackupDone) {                 // save safety: before the first co-op session
                g_sessionBackupDone = true;
                SaveSafeBackup(L"session-start", false, g_heroName, n2, n3);
            }
            // A Player 2/3 character this Warden had is not in this save.
            // (Not in a new game from the lobby: the Warden may share a name with an
            // older one, and the co-op characters are made after this.)
            for (int i = 0; i < 2 && i < g_players - 1 && !g_fromLobbyThisRun; ++i) {
                Player& q = g_pl[i];
                wchar_t rec[64];
                bool missing = SaveSafeRecorded(g_heroName, q.n, rec, 64) && CoopCreateCharacter(q.n) == kNone;
                q.restoreOffer = missing;
                q.lsStart = 0;
                if (missing) {
                    wcsncpy(q.missingName, rec, 63);
                    Log("Save safety: %ls (Player %d) is not in this save of %ls", rec, q.n, g_heroName);
                    Say(q, L"%ls (Player %d's character) is not in this save - expected if this save is from before they made their character", rec, q.n);
                    Say(q, L"Player %d: hold LS (left stick click) 2 s to restore your newest backup with %ls", q.n, rec);
                }
            }
        }
        if (g_firstInGame) {
            g_firstInGame = false;
            int t = script::GetObjectType(g_hero);
            if (t > 0) g_creatureType = t;
            Log("In game: hero 0x%08X, controlled 0x%08X, party size %d, creature type %d",
                g_hero, script::GetControlled(), script::GetPartySize(), t);
        }
    }

    for (int i = 0; i < 2; ++i) {
        if (!g_on[i]) continue;
        if (ModMenuOpenFor(g_pl[i].n)) { StopMoving(g_pl[i]); continue; }   // 1.7.2: the co-op menu has their controller
        PlayerTick(g_pl[i], now, mode, pads[i], buttons[i], pressed[i]);
    }
    TargetUiFlush(now);

    // Camera: Player 1's character first, then the co-op characters in play.
    {
        float pos[3][3];
        uint32_t ids[3], cols[3] = {}; int nums[3];
        int n = 0;
        uint32_t lead = script::GetControlled();
        Vec3 v;
        if (lead != kNone && script::GetPosition(lead, &v)) { pos[n][0] = v.x; pos[n][1] = v.y; pos[n][2] = v.z; ids[n] = lead; nums[n] = 1; ++n; }
        uint32_t area = n ? script::GetArea(lead) : kNone;
        for (Player& p : g_pl) {
            if (n == 0 || p.join != JOIN_IN || p.me == kNone || p.me == lead || p.down) continue;
            if (script::GetArea(p.me) != area || !script::GetPosition(p.me, &v)) continue;
            pos[n][0] = v.x; pos[n][1] = v.y; pos[n][2] = v.z; ids[n] = p.me; nums[n] = p.n; cols[n] = p.colour; ++n;
        }
        CameraSetLead(n ? lead : kNone);
        TestPadMainThread();                                  // 1.7.0 testing
        {   // 1.7.0: Player 2's and Player 3's own views (views.h)
            if (n > 0) ViewsSetLead(pos[0]);
            uint32_t standIn = kNone;                          // solo test: a companion stands in for a missing joiner
            for (int pl = 2; pl <= 3; ++pl) {
                int ip = -1;
                for (int i = 1; i < n; ++i) if (nums[i] == pl) ip = i;
                if (ip > 0) { ViewsSetPlayer(pl, pos[ip], true, ids[ip]); continue; }
                bool set = false;
                if (n > 0 && ViewsFollowCompanion()) {
                    uint32_t m[16]; int pm = game::PartyMembers(m, 16);
                    for (int k = 0; k < pm && !set; ++k) {
                        Vec3 cv;
                        if (m[k] == lead || m[k] == kNone || m[k] == standIn) continue;
                        bool taken = false;
                        for (int i = 1; i < n; ++i) if (ids[i] == m[k]) taken = true;
                        if (taken || script::GetArea(m[k]) != area || !script::GetPosition(m[k], &cv)) continue;
                        float cp[3] = { cv.x, cv.y, cv.z };
                        ViewsSetPlayer(pl, cp, true, m[k]);
                        standIn = m[k]; set = true;
                    }
                    if (!set && g_creatureType > 0) {             // no companion: a nearby friendly character
                        uint32_t nb[4];
                        int cnt = script::GetNearestByHostility(lead, false, g_creatureType, nb, 4, true, false);
                        for (int j = 0; j < cnt && !set; ++j) {
                            Vec3 cv;
                            if (nb[j] == lead || nb[j] == kNone || nb[j] == standIn || !script::GetPosition(nb[j], &cv)) continue;
                            bool taken = false;
                            for (int i = 1; i < n; ++i) if (ids[i] == nb[j]) taken = true;
                            if (taken) continue;
                            float cp[3] = { cv.x, cv.y, cv.z };
                            ViewsSetPlayer(pl, cp, true, nb[j]);
                            standIn = nb[j]; set = true;
                        }
                    }
                }
                if (!set) ViewsSetPlayer(pl, pos[0], false);
            }
        }
        const int framed = ViewsActive() ? (n ? 1 : 0) : n;   // with own views, Player 1's camera follows only Player 1
        CameraSetPlayers(pos, framed, framed >= 2, mode == game::MODE_COMBAT);
        ScreenWallSetPlayers(ids, nums, pos, framed, framed >= 2 && !CameraIsTactical() && mode != game::MODE_COMBAT, g_hero, now);   // 1.2.47: off in combat (Player 1 must reach enemies)
        // Player markers (1.2.46 rings; 1.7.4 also name plates and target marks, drawn in every player's own view):
        // everyone's character with their name, and what Players 2/3 aim at.
        MarkerChar mc[3]; int mn = 0;
        MarkerPoint mp[4]; int mpn = 0;
        static wchar_t leadName[48] = L""; static uint32_t leadNameOf = kNone; static unsigned leadNameAt = 0;
        for (int i = 0; i < n && mn < 3; ++i) {
            MarkerChar& c = mc[mn++];
            c.player = nums[i];
            c.feet[0] = pos[i][0]; c.feet[1] = pos[i][1]; c.feet[2] = pos[i][2];
            if (nums[i] == 1) {
                c.rgb = 0xD8B66A;                                    // Player 1: gold
                if (ids[i] != leadNameOf || (int)(now - leadNameAt) >= 0) {   // (the name asked for every few seconds)
                    leadNameOf = ids[i]; leadNameAt = now + 3000;
                    if (!script::GetName(ids[i], leadName, 48)) leadName[0] = 0;
                }
                wcsncpy(c.name, leadName, 47); c.name[47] = 0;
            } else {
                c.rgb = cols[i];
                TargetUiName(nums[i], c.name, 48);
            }
        }
        for (Player& p : g_pl) {
            if (p.join != JOIN_IN || p.me == kNone || p.down) continue;
            Vec3 tv;
            if (p.target != kNone && mpn < 4 && !script::IsDead(p.target) && script::GetPosition(p.target, &tv))
                mp[mpn++] = MarkerPoint{ p.n, p.colour, { tv.x, tv.y, tv.z }, 0 };
            if (p.ally != kNone && mpn < 4 && script::GetPosition(p.ally, &tv))
                mp[mpn++] = MarkerPoint{ p.n, p.colour, { tv.x, tv.y, tv.z }, 1 };
        }
        RingsSetMarkers(mc, mn, mp, mpn, mode == game::MODE_COMBAT, true);
    }
    ScalingTick(now, g_hero, g_creatureType, g_players);

    // Online host: the public list shows who plays and where the party is (1.4.0).
    static unsigned nextInfo = 0;
    if (OnlinePlay::Hosting() && (int)(now - nextInfo) >= 0) {
        nextInfo = now + 5000;
        int active = 0;
        for (int i = 0; i < 2; ++i) if (g_on[i] && CoopPlayerActive(g_pl[i].n)) ++active;
        wchar_t area[64] = L"";
        uint32_t a = g_hero != kNone ? script::GetArea(g_hero) : kNone;
        if (a != kNone) script::GetName(a, area, 64);
        int maxP = g_players < 2 ? 2 : g_players;
        OnlinePlay::SetHostInfo(1 + active, maxP, maxP - 1 - active, area);
    }
}

void CoopLobbyLoadedSave()
{
    // a save loaded from the lobby: like any loaded game (missing co-op characters are offered back)
    g_fromLobbyThisRun = false;
}

void CoopSetPlayers(int players, bool fromLobby)
{
    if (players < 1) players = 1;
    if (players > 3) players = 3;
    bool was[2] = { g_on[0], g_on[1] };
    g_players = players;
    if (fromLobby) g_fromLobbyThisRun = true;
    UpdateOn();
    for (int i = 0; i < 2; ++i) {
        Player& p = g_pl[i];
        if (was[i] && !g_on[i]) {              // switched off: the AI takes the character
            Release(p, true);
            ForgetCharacter(p);
            p.join = JOIN_UNKNOWN;
        }
        if (fromLobby) p.join = JOIN_UNKNOWN;
    }
    if (fromLobby) g_s.autoJoin = true;       // they joined in the lobby
    Log("Session: %d player%s (Player 2 %s, Player 3 %s)%s", players, players == 1 ? "" : "s",
        g_on[0] ? "on" : "off", g_on[1] ? "on" : "off", fromLobby ? ", started from the co-op lobby" : "");
}

bool CoopPlayerActive(int player)
{
    if (player < 2 || player > 3) return false;
    const Player& p = g_pl[player - 2];
    return g_on[player - 2] && p.join == JOIN_IN && p.wasConnected;
}

bool CoopBarInfo(uint32_t creature, wchar_t* out, int cap)
{
    if (cap > 0) out[0] = 0;
    for (Player& p : g_pl) {
        if (p.join != JOIN_IN || p.me == kNone || p.me != creature || p.barChar != creature) continue;
        swprintf(out, cap, L"%d|%d|%d|%d|%d", p.n, p.barPage, p.barAb[0], p.barAb[1], p.barAb[2]);
        return true;
    }
    return false;
}

void CoopFreeMovementRetest() { g_freeMoveWorks = -1; Log("Free movement: will be tested again on the first 3 s of stick input (probes on)"); }
