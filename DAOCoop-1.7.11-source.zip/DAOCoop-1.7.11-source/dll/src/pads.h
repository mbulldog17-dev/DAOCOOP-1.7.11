#pragma once
#include <windows.h>
#include <xinput.h>

// Which co-op player a controller belongs to. P1 uses the game's own input.
enum CoopPlayer { PLAYER_2 = 0, PLAYER_3 = 1, COOP_PLAYERS = 2 };

struct PadSnapshot {
    bool           connected;
    XINPUT_GAMEPAD gamepad;   // buttons, triggers, sticks
};

// Starts a background thread that polls the XInput pads assigned to P2 and P3
// (indices 0-3, or -1 to leave that player unassigned).
void PadsStart(int p2Index, int p3Index);
void PadsStop();

// Thread-safe copy of the latest state for a co-op player.
PadSnapshot PadsGet(CoopPlayer player);

// Short controller rumble (feedback), and the XInput slot of a co-op player.
void PadsRumble(CoopPlayer player, int ms, int strength = 30000);   // strength 0..65535
// Player 1's own controller (XInput slot, default 0): read only, for the
// screen hand-over button. Set before PadsStart; -1 = don't read it.
void PadsSetP1Index(int index);
PadSnapshot PadsGetP1();
int  PadsIndex(CoopPlayer player);
// Lobby: give a co-op player another controller slot (-1 = none), and read any slot.
void PadsAssign(CoopPlayer player, int index);
int  PadsP1Index();
bool PadsReadSlot(int index, XINPUT_GAMEPAD* out);
// Lobby: watch all slots on the poll thread and remember presses until taken.
void PadsScanSlots(bool on);
WORD PadsTakePressed(int slot);      // buttons pressed since the last call (and clears them)
bool PadsSlotConnected(int slot);
