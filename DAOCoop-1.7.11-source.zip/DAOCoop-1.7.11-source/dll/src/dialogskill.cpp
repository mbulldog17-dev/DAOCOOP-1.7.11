#include "dialogskill.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <cmath>

static bool g_enabled = true;

static const int kAbilities[] = { 4020, 100001, 100002, 100003, 100004 };   // Coercion + ranks
static const int kAttributes[] = { 5, 1 };                                   // Cunning, Strength
static const int kValueTotal = 1, kValueBase = 2;

struct Saved {
    bool     active = false;
    uint32_t hero = 0xFFFFFFFF;
    bool     had[5] = {};
    float    base[2] = {};
    int      player = 1;
};
static Saved g_saved;

void DialogSkillInit(bool enabled)
{
    g_enabled = enabled;
    Log("Dialogue skills: %s", enabled ? "persuade/intimidate checks use the player holding the conversation" : "always the Warden's");
}

void DialogSkillRestore()
{
    if (!g_saved.active) return;
    uint32_t h = g_saved.hero;
    if (script::IsObjectValid(h)) {
        for (int i = 0; i < 5; ++i) {
            bool has = script::HasAbility(h, kAbilities[i]);
            if (g_saved.had[i] && !has) script::AddAbility(h, kAbilities[i]);
            if (!g_saved.had[i] && has) script::RemoveAbility(h, kAbilities[i]);
        }
        for (int i = 0; i < 2; ++i) script::SetCreatureProperty(h, kAttributes[i], g_saved.base[i], kValueBase);
        Log("Dialogue skills: the Warden's own Coercion, Cunning and Strength are back");
    }
    g_saved = Saved();
}

void DialogSkillUse(int player, uint32_t c)
{
    if (!g_enabled) return;
    DialogSkillRestore();
    if (player < 2 || c == 0xFFFFFFFF || !script::IsObjectValid(c)) return;
    uint32_t h = script::GetHero();
    if (!script::IsObjectValid(h) || h == c) return;

    Saved s;
    s.active = true; s.hero = h; s.player = player;
    for (int i = 0; i < 5; ++i) s.had[i] = script::HasAbility(h, kAbilities[i]);
    for (int i = 0; i < 2; ++i) {
        s.base[i] = script::GetCreatureProperty(h, kAttributes[i], kValueBase);
        if (s.base[i] < 0) { Log("Dialogue skills: Warden's attributes unreadable, not swapping"); return; }
    }
    g_saved = s;

    int ranks = 0;
    for (int i = 0; i < 5; ++i) {
        bool want = script::HasAbility(c, kAbilities[i]);
        bool has = s.had[i];
        if (want && !has) script::AddAbility(h, kAbilities[i]);
        if (!want && has) script::RemoveAbility(h, kAbilities[i]);
        if (want && i > 0) ++ranks;
    }
    // Same totals as the player's character (equipment bonuses included).
    float vals[2];
    for (int i = 0; i < 2; ++i) {
        float heroTotal = script::GetCreatureProperty(h, kAttributes[i], kValueTotal);
        float theirs = script::GetCreatureProperty(c, kAttributes[i], kValueTotal);
        vals[i] = theirs;
        if (heroTotal >= 0 && theirs >= 0)
            script::SetCreatureProperty(h, kAttributes[i], s.base[i] + (theirs - heroTotal), kValueBase);
    }
    Log("Dialogue skills: checks now use Player %d's character (Coercion rank %d, Cunning %.0f, Strength %.0f)",
        player, ranks, vals[0], vals[1]);
}
