#pragma once
// Full path of the dinput8.dll our calls are passed on to (a chained mod or Windows' own).
const wchar_t* ProxyTargetPath();
// 1.7.8: while on, the game's DirectInput keyboard reads as nothing pressed (the chat line is open).
void ProxyBlockKeyboard(bool on);
// 1.7.8: another mod's dinput8 that is there but would not load (nullptr: none); error = Windows' error code.
const wchar_t* ProxyChainFailed(unsigned long* error);
