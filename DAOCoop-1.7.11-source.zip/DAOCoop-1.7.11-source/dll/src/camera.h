#pragma once
// Keeps every player on screen.
//
// CameraControllerExplore's follow update (0x771250, thiscall(this, dt)) builds
// the camera every frame from scratch: focus +0x80 = the followed creature's
// position, position +0x70 = focus + offset + direction * zoom distance; the
// view is made from +0x70 and the rotation right after (0x76EFA0). A hook after
// the original moves both points toward the middle of all players and, when
// they spread out, pulls the camera back a little (capped). Both changes are
// smoothed, and nothing builds up because the game recomputes them each frame.
// Tactical camera (mode +0x90 == 1) is left alone.
#include <cstdint>

struct CameraSettings {
    bool  enabled;
    float maxShift;      // metres the view may slide toward the others
    float maxZoom;       // unused (1.2.47: see combatZoom)
    float zoomStart;     // unused
    bool  combatZoom;    // in combat, pull the camera back until everyone fits on screen
    float combatZoomMax; // metres it may pull back
    float exploreZoomMax; // 1.5.5: the same outside combat (someone at a screen edge / off screen), 0 = off
};

void CameraInit(const CameraSettings& s);
// Main tick: positions of the character Player 1 drives and the co-op
// characters (n = how many, first = Player 1's); active = apply now.
void CameraSetPlayers(const float (*pos)[3], int n, bool active, bool combat = false);
// The tactical (zoomed-out, player-panned) camera is on.
bool CameraIsTactical();
// Player 1's character (for the combat zoom's wall check).
void CameraSetLead(uint32_t id);
