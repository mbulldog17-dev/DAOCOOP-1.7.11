#pragma once
// Runs a function on the game's main thread about 60 times a second.
//
// Script commands must run on the thread that owns the game, so we subclass
// the game window and drive our work from a window timer (WM_TIMER is handled
// inside the game's own message loop, between frames).
typedef void (*TickFn)(unsigned nowMs);

// Waits (on the calling thread) for the game window to appear, then hooks it.
// Returns false if no window showed up within timeoutMs.
bool TickStart(TickFn fn, unsigned timeoutMs);
void TickStop();
