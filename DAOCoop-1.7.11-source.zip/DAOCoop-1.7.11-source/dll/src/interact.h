#pragma once
// Players 2 and 3 can use the world (chests, doors, levers, bodies, loot bags,
// traps, ...) but never start conversations: those stay with Player 1.
//
// Use:     the engine's own "use object" path, exactly what a mouse click does
//          (0x7F6550: queues CommandUseObject 0x1F, sends PLACEABLE_ONCLICK),
//          with the default action the object offers (vtable +0x100), and the
//          loot bag for a dead body (creature +0x790).
// Guard 1: conversations - BeginConversation's engine side (0x6976B0) gets
//          Player 1's character as the initiator when a script tries to start
//          a conversation with Player 2/3 (e.g. a chest that talks).
// Guard 2: triggers - ENTER/EXIT events of Player 2/3 on triggers (talk,
//          cutscene, ambush triggers) are dropped in GameObject::HandleEvent
//          (0x698960); trap triggers still go off.
#include <cstdint>

struct InteractSettings {
    bool  enabled;
    float range;                 // metres
    bool  allowTransitions;      // doors that change area
    bool  dialogGuard;
    bool  triggerGuard;
};

void InteractInit(const InteractSettings& s);
// Player `player` (2/3) with character `creature` presses Use. Returns true if
// something was used. dirX/dirY = preferred direction (stick), may be 0.
bool InteractUse(int player, uint32_t creature, float dirX, float dirY);
// What InteractUse would use right now (for the on-screen preview). Writes the
// object, the verb ("open", "loot", ...) and its name.
bool InteractPick(uint32_t creature, float dirX, float dirY, uint32_t* object,
                  const wchar_t** verb, wchar_t* name, int nameCap);
// 1.7.0 testing: writes the nearest placeables / bodies around `me` (name, distance, what using them does) to the log.
void InteractScan(uint32_t me);
// 1.7.0 testing: Player `player` uses one given object (the character walks there, as with a click).
bool InteractUseId(int player, uint32_t me, uint32_t object);
