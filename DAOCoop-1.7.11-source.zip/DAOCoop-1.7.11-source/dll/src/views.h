#pragma once
#include <cstdint>
// 1.7.0: Player 2's and Player 3's own views of the world, drawn by the game's own renderer.
//
// What the game does each frame (DAOrigins.exe 1.05, read in the decompiler):
//   0x52A470  prepares every scene: the small ones (paperdoll, portraits) and then the main one,
//             each through 0x52A090 (thiscall on the graphics object, args: scene, a2, a3, a4).
//   0x52A090  prepares one scene. The scene's camera is scene+0xC0 (a SceneCamera); the camera the
//             renderer uses is SceneCamera+4 (Renderer::PerspectiveCamera, vtable 0xB58604).
//   0x52A600  end frame (IGraphicsInternal vtable +0x54): the frame buffer program draws, then Present.
//   PerspectiveCamera: vtable+4 SetTransform(this, float pos[3], float quat[4]) builds the view
//             matrix (+0x80, R(quat) * T(-pos)) and its inverse (+0xC0).
//
// Each joiner's view = the main scene prepared and drawn again with their own camera, the Present
// swallowed and the picture kept in a texture (single-threaded renderer). Each joiner turns their view
// with their right stick; it keeps out of walls; they get their own HUD (p2hud.h) and their own screens.
// [Views] Experiment = 1 turns it on; [Views] StartMode / LiveMode (ini, read every second):
//   0 off
//   1 the joiners' pictures in the top right corner of Player 1's screen (local test)
//   2 drawn, not shown (cost test)
//   3 online: each online friend gets their own player's picture as their stream (OnlinePlay);
//     Player 1 sees only their own view
//   4 diagnostic (Player 2's camera left on the scene)
//   5 split screen: everyone's whole view in a grid on this screen (online friends still get their own view)
struct IDirect3DSurface9;

void ViewsInit(const wchar_t* iniPath);
// Main thread, every co-op tick: Player 1's character, then each joiner (player 2 / 3; have = false: not in play).
// id: the joiner's character (its collision rays and the bars of their own HUD).
void ViewsSetLead(const float lead[3]);
void ViewsSetPlayer(int player, const float pos[3], bool have, uint32_t id = 0xFFFFFFFF);
// True while a mode is on (Player 1's camera then follows only Player 1).
bool ViewsActive();
// [Views] FollowCompanion = 1: a joiner who isn't in play is stood in for by a companion (solo test).
bool ViewsFollowCompanion();
// A joiner's own view turn (radians, their right stick) while views are drawn: their stick is turned by it too.
bool ViewsJoinerYaw(int player, float* yaw);
// A joiner's own camera heading (unit vector, flat) while views are drawn: their stick moves them along it.
bool ViewsJoinerHeading(int player, float* fx, float* fy);
// Mode 3: the online stream sends each friend their own player's picture.
bool ViewsOnline();
// 1.7.4: how far Player 1's camera draws (metres) while the joiners have their own views, else 0 (the co-op tether)
float ViewsP1DrawDistance();
// Render thread: a joiner's newest picture (not AddRef'd; valid until the next frame), or null.
IDirect3DSurface9* ViewsPicture(int player, int* w = nullptr, int* h = nullptr);
