#include "hooks.h"
#include "log.h"
#include <windows.h>
#include <cstring>

static bool Matches(uintptr_t address, const uint8_t* expect, size_t n)
{
    const uint8_t* p = reinterpret_cast<const uint8_t*>(address);
    return !IsBadReadPtr(p, n) && memcmp(p, expect, n) == 0;
}

void* HookInstall(uintptr_t target, void* hook, size_t stolen, const uint8_t* expect, const char* name)
{
    if (stolen < 5 || stolen > 16 || !Matches(target, expect, stolen)) {
        Log("Hook %s: unexpected bytes at 0x%06X, not installed", name, (unsigned)target);
        return nullptr;
    }
    uint8_t* tramp = static_cast<uint8_t*>(VirtualAlloc(nullptr, 32, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
    if (!tramp) { Log("Hook %s: no memory for trampoline", name); return nullptr; }
    memcpy(tramp, reinterpret_cast<void*>(target), stolen);
    tramp[stolen] = 0xE9;                                       // jmp back into the original
    *reinterpret_cast<int32_t*>(tramp + stolen + 1) =
        static_cast<int32_t>((target + stolen) - (reinterpret_cast<uintptr_t>(tramp) + stolen + 5));

    DWORD old;
    if (!VirtualProtect(reinterpret_cast<void*>(target), stolen, PAGE_EXECUTE_READWRITE, &old)) {
        Log("Hook %s: VirtualProtect failed (%lu)", name, GetLastError());
        VirtualFree(tramp, 0, MEM_RELEASE);
        return nullptr;
    }
    uint8_t* t = reinterpret_cast<uint8_t*>(target);
    t[0] = 0xE9;
    *reinterpret_cast<int32_t*>(t + 1) =
        static_cast<int32_t>(reinterpret_cast<uintptr_t>(hook) - (target + 5));
    for (size_t i = 5; i < stolen; ++i) t[i] = 0x90;
    VirtualProtect(reinterpret_cast<void*>(target), stolen, old, &old);
    FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(target), stolen);
    Log("Hook %s installed at 0x%06X", name, (unsigned)target);
    return tramp;
}

bool PatchBytes(uintptr_t address, const uint8_t* expect, const uint8_t* bytes, size_t count, const char* name)
{
    if (!Matches(address, expect, count)) {
        if (Matches(address, bytes, count)) return true;        // already patched
        Log("Patch %s: unexpected bytes at 0x%06X, skipped", name, (unsigned)address);
        return false;
    }
    DWORD old;
    if (!VirtualProtect(reinterpret_cast<void*>(address), count, PAGE_EXECUTE_READWRITE, &old)) return false;
    memcpy(reinterpret_cast<void*>(address), bytes, count);
    VirtualProtect(reinterpret_cast<void*>(address), count, old, &old);
    FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(address), count);
    return true;
}
