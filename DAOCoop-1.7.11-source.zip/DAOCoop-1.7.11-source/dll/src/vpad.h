#pragma once
// Controllers of online friends (1.2.27): slots 4 and 5 next to XInput's 0-3.
// The online code feeds them; pads.cpp, the lobby and the controller hand-off read them like real pads.
#include <windows.h>
#include <xinput.h>

constexpr int kVPadFirst = 4, kVPadSlots = 6;   // 4 = first online friend, 5 = second
DWORD VPadGetState(DWORD index, XINPUT_STATE* state);       // any slot 0..5 (0-3: XInput)
void  VPadSetRemote(int slot, const XINPUT_GAMEPAD* pad);  // slot 4/5; nullptr = disconnected
bool  VPadRemoteConnected(int slot);
