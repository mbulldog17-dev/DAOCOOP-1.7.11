#pragma once
// Creating Player 2's and Player 3's own characters with the game's real
// character creator. One creator session at a time; the other player waits.
//
// Flow (all on the main thread, driven by CoopCreateTick):
//   1. A game started from the co-op lobby: as soon as the origin story is
//      playing, the creator opens for Player 2, then Player 3 (no START needed).
//      Otherwise (a player who joins later), every joined co-op player without
//      a character tagged "daocoop_p2" / "daocoop_p3" is asked to press START,
//      wherever the party is (not in "Warden alone" areas). The old Ostagar
//      trigger is off unless OfferAtOstagarToo=1.
//   2. PreloadCharGen, CreateObject(default_player.utc) beside the Warden,
//      SetTag "daocoop_pN", SetFollowerState(locked active).
//   3. StartCharGen(new, full creation). While it runs, two engine hooks keep
//      the creator from touching the Warden's story:
//        - module events SELECT_BACKGROUND (55) and MODULE_CHARGEN_DONE (1027)
//          are dropped (they set origin plot flags / teleport to the origin);
//        - the engine's end-of-chargen handler is told the session was a
//          "level up" so it does not start the origin loading screen.
//   4. Back to explore mode; that player's controller now drives the new character.
#include <cstdint>

struct CoopCreateSettings {
    bool    hooks;              // install the two safety hooks (required for 3.)
    bool    autoAtArea;         // offer creation in a trigger area
    wchar_t areas[256];         // comma-separated area tags
    wchar_t templ[64];          // creature template
    int     followerState;      // 7 = locked active, 1 = active
    int     endAs;              // what the engine is told at the end: 1 = level up (safe), 0 = real
    bool    atStart;            // make the characters when the origin story starts (not at Ostagar)
    wchar_t originAreas[128];   // area tag prefixes of the origin stories
    bool    keepInOrigin;       // put co-op characters back if an origin script drops them
    wchar_t soloAreas[128];     // area tag prefixes where the story wants the Warden alone (no putting back)
    bool    anywhere;           // offer the creator to a joined player without a character in any area
};

void     CoopCreateInit(const CoopCreateSettings& s);
// startPressed[p] / canPrompt[p] for p = 2, 3 (index 0, 1 unused).
// canPrompt = that player has joined with a connected controller.
void     CoopCreateTick(unsigned nowMs, uint32_t hero, int creatureType,
                        const bool startPressed[4], const bool canPrompt[4]);
void     CoopCreateBegin(int player, uint32_t hero, int creatureType);   // start now (debug combo)
void     CoopCreateNewGame();                    // the lobby started a new game (creators at the story start)
bool     CoopCreateBusy();                       // a creator session is running: co-op controls off
int      CoopCreatePlayer();                     // 1.7.0: whose creator session is running (2/3), 0 none
bool     CoopCreatePrompting(int player);        // waiting for this player to press START
uint32_t CoopCreateCharacter(int player);        // the "daocoop_pN" creature, if it exists

// Co-op faces (1.2.30): DAOCoop.ini for [Faces], and the face put back after a load / area change.
void CoopFaceSetIni(const wchar_t* ini);
void CoopFaceRefresh(int player, uint32_t creature);
bool CoopCreateSessionOpen();   // the creator is open for Player 2/3 (chargen.gfx skips the difficulty question)
