#include "rings.h"
#include "menubanner.h"
#include "screenwall.h"
#include "d3d9hook.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cmath>
#include <cstring>
#include <cwchar>

// 1.7.4: every marker is projected at draw time, in the picture being drawn (Player 1's on the finished frame,
// each joiner's at the end of their own pass - views.cpp), so it sits right in every player's box.
static RingSettings g_s;
static const int kSeg = 40;
static const int kMaxChars = 3, kMaxPoints = 4;

static CRITICAL_SECTION g_lock;
static bool g_init = false;
static MarkerChar g_chars[kMaxChars];
static MarkerPoint g_points[kMaxPoints];
static int g_nChars = 0, g_nPoints = 0;
static bool g_active = false, g_combat = false;

static const DWORD kGold = 0xC9A55A, kGoldDark = 0x624A28, kGoldBright = 0xF0D68C;

void RingsSetMarkers(const MarkerChar* chars, int nChars, const MarkerPoint* points, int nPoints, bool combat, bool active)
{
    if (!g_init) return;
    EnterCriticalSection(&g_lock);
    g_nChars = 0; g_nPoints = 0;
    for (int i = 0; i < nChars && g_nChars < kMaxChars; ++i) g_chars[g_nChars++] = chars[i];
    for (int i = 0; i < nPoints && g_nPoints < kMaxPoints; ++i) g_points[g_nPoints++] = points[i];
    g_active = active; g_combat = combat;
    LeaveCriticalSection(&g_lock);
}

bool RingsDrawnMarkers() { return g_s.drawn; }

namespace
{
    struct V { float x, y, z, rhw; DWORD c; float u, v; };
    int g_W = 0, g_H = 0;

    DWORD Argb(DWORD rgb, int a) { if (a < 0) a = 0; if (a > 255) a = 255; return ((DWORD)a << 24) | (rgb & 0xFFFFFF); }
    DWORD MixRgb(DWORD a, DWORD b, float t)
    {
        auto ch = [&](int s) { const int x = (a >> s) & 255, y = (b >> s) & 255; return (DWORD)(x + (y - x) * t) << s; };
        return ch(16) | ch(8) | ch(0);
    }
    // a world point -> this picture's pixels (the scene camera as it is now)
    bool Proj(const float p[3], float& x, float& y, bool needVisible)
    {
        float nx, ny; bool on;
        if (!ScreenWallProject(p, &nx, &ny, &on)) return false;
        if (needVisible && !on) return false;
        x = nx * g_W; y = ny * g_H;
        return x > -g_W && x < 2.f * g_W && y > -g_H && y < 2.f * g_H;
    }
    V Pt(float x, float y, DWORD c) { return V{ x - 0.5f, y - 0.5f, 0.f, 1.f, c, 0.f, 0.f }; }

    void Geometry(IDirect3DDevice9* dev)
    {
        dev->SetTexture(0, nullptr);
        dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG2);
        dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG2);
    }
    void Fan(IDirect3DDevice9* dev, const V* v, int n) { dev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, n - 2, v, sizeof(V)); }
    void Diamond(IDirect3DDevice9* dev, float x, float y, float r, DWORD argb)
    {
        const V v[4] = { Pt(x, y - r, argb), Pt(x + r, y, argb), Pt(x, y + r, argb), Pt(x - r, y, argb) };
        Fan(dev, v, 4);
    }
    void Box(IDirect3DDevice9* dev, float x0, float y0, float x1, float y1, DWORD argb)
    {
        const V v[4] = { Pt(x0, y0, argb), Pt(x1, y0, argb), Pt(x1, y1, argb), Pt(x0, y1, argb) };
        Fan(dev, v, 4);
    }

    // ---- the selector ring ----
    void Ring(IDirect3DDevice9* dev, const MarkerChar& c, float spin)
    {
        static float ix[kSeg + 1], iy[kSeg + 1], ox[kSeg + 1], oy[kSeg + 1];
        for (int k = 0; k <= kSeg; ++k) {
            const float a = 6.2831853f * k / kSeg, ca = std::cos(a), sa = std::sin(a);
            const float pi[3] = { c.feet[0] + ca * g_s.radius * 0.78f, c.feet[1] + sa * g_s.radius * 0.78f, c.feet[2] + 0.05f };
            const float po[3] = { c.feet[0] + ca * g_s.radius * 1.06f, c.feet[1] + sa * g_s.radius * 1.06f, c.feet[2] + 0.05f };
            if (!Proj(pi, ix[k], iy[k], false) || !Proj(po, ox[k], oy[k], false)) return;
        }
        auto P = [&](int k, float t, float& x, float& y) { x = ix[k] + (ox[k] - ix[k]) * t; y = iy[k] + (oy[k] - iy[k]) * t; };
        const int a = g_s.alpha;
        V v[(kSeg + 1) * 2];
        // soft glow: clear inside -> the colour -> clear outside
        for (int pass = 0; pass < 2; ++pass) {
            for (int k = 0; k <= kSeg; ++k) {
                float x0, y0, x1, y1;
                P(k, pass ? 0.5f : 0.f, x0, y0); P(k, pass ? 1.f : 0.5f, x1, y1);
                v[k * 2] = Pt(x0, y0, Argb(c.rgb, pass ? a * 55 / 100 : 0));
                v[k * 2 + 1] = Pt(x1, y1, Argb(c.rgb, pass ? 0 : a * 55 / 100));
            }
            dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, kSeg * 2, v, sizeof(V));
        }
        // the fine bright line in the middle
        const DWORD line = MixRgb(c.rgb, 0xFFFFFF, 0.35f);
        for (int k = 0; k <= kSeg; ++k) {
            float x0, y0, x1, y1;
            P(k, 0.44f, x0, y0); P(k, 0.56f, x1, y1);
            v[k * 2] = Pt(x0, y0, Argb(line, a)); v[k * 2 + 1] = Pt(x1, y1, Argb(line, a));
        }
        dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, kSeg * 2, v, sizeof(V));
        // four gold diamonds turning slowly round it
        for (int q = 0; q < 4; ++q) {
            float ang = spin + q * 1.5707963f;
            ang = std::fmod(ang, 6.2831853f); if (ang < 0) ang += 6.2831853f;
            const float fk = ang / 6.2831853f * kSeg;
            const int k0 = (int)fk % kSeg, k1 = k0 + 1;
            const float t = fk - (int)fk;
            float xa, ya, xb, yb, xo0, yo0, xo1, yo1;
            P(k0, 0.5f, xa, ya); P(k1, 0.5f, xb, yb);
            P(k0, 0.f, xo0, yo0); P(k0, 1.f, xo1, yo1);
            const float x = xa + (xb - xa) * t, y = ya + (yb - ya) * t;
            float r = std::sqrt((xo1 - xo0) * (xo1 - xo0) + (yo1 - yo0) * (yo1 - yo0)) * 0.42f;
            if (r < 3.f) r = 3.f;
            if (r > 12.f) r = 12.f;
            Diamond(dev, x, y, r + 1.5f, Argb(kGoldDark, a));
            Diamond(dev, x, y, r, Argb(kGold, a));
            Diamond(dev, x, y, r * 0.45f, Argb(c.rgb, a));
        }
    }

    // ---- the target arrow and the ally diamond ----
    void Arrow(IDirect3DDevice9* dev, float x, float y, float s, DWORD rgb)
    {
        // pointing down at the enemy: a gold-dark outline, the player's colour, a lighter top
        const V o[3] = { Pt(x - 13 * s, y - 17 * s, Argb(kGoldDark, 235)), Pt(x + 13 * s, y - 17 * s, Argb(kGoldDark, 235)), Pt(x, y + 3 * s, Argb(kGoldDark, 235)) };
        dev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, o, sizeof(V));
        const V g[3] = { Pt(x - 11 * s, y - 15.5f * s, Argb(kGold, 245)), Pt(x + 11 * s, y - 15.5f * s, Argb(kGold, 245)), Pt(x, y + 1 * s, Argb(kGold, 245)) };
        dev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, g, sizeof(V));
        const DWORD top = MixRgb(rgb, 0xFFFFFF, 0.45f);
        const V f[3] = { Pt(x - 8.5f * s, y - 14 * s, Argb(top, 250)), Pt(x + 8.5f * s, y - 14 * s, Argb(top, 250)), Pt(x, y - 1.5f * s, Argb(rgb, 250)) };
        dev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, f, sizeof(V));
        Diamond(dev, x, y - 23 * s, 4 * s, Argb(kGold, 240));
    }
    void AllyMark(IDirect3DDevice9* dev, float x, float y, float s, DWORD rgb)
    {
        Diamond(dev, x, y, 13 * s, Argb(kGoldDark, 235));
        Diamond(dev, x, y, 11.5f * s, Argb(kGold, 245));
        Diamond(dev, x, y, 9.5f * s, Argb(rgb, 245));
        const DWORD w = Argb(0xFFF8E8, 250);
        Box(dev, x - 5 * s, y - 1.2f * s, x + 5 * s, y + 1.2f * s, w);
        Box(dev, x - 1.2f * s, y - 5 * s, x + 1.2f * s, y + 5 * s, w);
    }

    // ---- name plates (GDI into a texture, made again only when the name or the size changes) ----
    struct Plate { IDirect3DDevice9* dev = nullptr; IDirect3DTexture9* tex = nullptr; wchar_t name[48] = L""; DWORD rgb = 0; int forH = 0, w = 0, h = 0, tw = 0, th = 0; DWORD usedAt = 0; };
    Plate g_plate[6];

    HFONT PlateFont(int px)
    {
        static const wchar_t* kBody[] = { L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static int pick = -1;
        if (pick < 0) {
            pick = 2;
            HDC dc = CreateCompatibleDC(nullptr);
            for (int i = 0; i < 3; ++i) {
                HFONT f = CreateFontW(-20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, kBody[i]);
                HGDIOBJ o = SelectObject(dc, f);
                wchar_t face[64] = {}; GetTextFaceW(dc, 64, face);
                SelectObject(dc, o); DeleteObject(f);
                if (_wcsicmp(face, kBody[i]) == 0) { pick = i; break; }
            }
            DeleteDC(dc);
        }
        return CreateFontW(-px, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, kBody[pick]);
    }
    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }
    COLORREF Ref(DWORD rgb) { return RGB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
    void FillR(HDC dc, int x0, int y0, int x1, int y1, COLORREF c) { RECT r = { x0, y0, x1, y1 }; HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b); }
    void Grad(HDC dc, int x0, int y0, int x1, int y1, COLORREF a, COLORREF b, bool vertical)
    {
        if (x1 <= x0 || y1 <= y0) return;
        TRIVERTEX v[2] = { { x0, y0, (COLOR16)(GetRValue(a) << 8), (COLOR16)(GetGValue(a) << 8), (COLOR16)(GetBValue(a) << 8), 0 },
                           { x1, y1, (COLOR16)(GetRValue(b) << 8), (COLOR16)(GetGValue(b) << 8), (COLOR16)(GetBValue(b) << 8), 0 } };
        GRADIENT_RECT g = { 0, 1 };
        GdiGradientFill(dc, v, 2, &g, 1, vertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
    }
    void Gem(HDC dc, int cx, int cy, int r, COLORREF c)
    {
        POINT p[4] = { { cx, cy - r }, { cx + r, cy }, { cx, cy + r }, { cx - r, cy } };
        HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
        HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
        Polygon(dc, p, 4);
        SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
    }

    bool MakePlate(IDirect3DDevice9* dev, Plate& pl, const wchar_t* name, DWORD rgb, int H)
    {
        const float s = H / 1080.f < 0.5f ? 0.5f : H / 1080.f;
        auto S = [&](float v) { int x = (int)(v * s + 0.5f); return x < 1 ? 1 : x; };
        HDC dc = CreateCompatibleDC(nullptr);
        HFONT f = PlateFont(S(21));
        HGDIOBJ of = SelectObject(dc, f);
        SIZE ts = {}; GetTextExtentPoint32W(dc, name, (int)wcslen(name), &ts);
        SelectObject(dc, of);
        const int w = ts.cx + S(64), h = S(34);
        const int tw = Pow2(w), th = Pow2(h);
        if (pl.dev != dev) { pl.tex = nullptr; pl.dev = dev; }     // (an old device's texture isn't released: it may be gone)
        if (!pl.tex || pl.tw != tw || pl.th != th) {
            if (pl.tex) { pl.tex->Release(); pl.tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &pl.tex, nullptr)) || !pl.tex) { pl.tex = nullptr; DeleteObject(f); DeleteDC(dc); return false; }
            pl.tw = tw; pl.th = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h;
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        bool ok = false;
        if (bmp && bits) {
            HGDIOBJ ob = SelectObject(dc, bmp);
            SetBkMode(dc, TRANSPARENT);
            const COLORREF key = RGB(255, 0, 255);
            FillR(dc, 0, 0, w, h, key);
            // a banner: dark band, gold lines above and below fading at the ends, gold diamonds at the tips
            const int a0 = S(12), a1 = w - S(12), y0 = S(3), y1 = h - S(3), fade = (a1 - a0) / 5, cy = h / 2;
            Grad(dc, a0, y0, a1, y1, RGB(30, 24, 18), RGB(12, 10, 8), true);
            for (int line = 0; line < 2; ++line) {
                const int y = line ? y1 - 1 : y0;
                Grad(dc, a0, y, a0 + fade, y + 1, RGB(98, 74, 40), RGB(201, 165, 90), false);
                FillR(dc, a0 + fade, y, a1 - fade, y + 1, RGB(201, 165, 90));
                Grad(dc, a1 - fade, y, a1, y + 1, RGB(201, 165, 90), RGB(98, 74, 40), false);
            }
            Gem(dc, S(9), cy, S(7), RGB(201, 165, 90)); Gem(dc, S(9), cy, S(3), RGB(12, 10, 8));
            Gem(dc, w - S(9), cy, S(7), RGB(201, 165, 90)); Gem(dc, w - S(9), cy, S(3), RGB(12, 10, 8));
            // the player's colour as a gem before the name
            Gem(dc, S(27), cy, S(7), RGB(201, 165, 90));
            Gem(dc, S(27), cy, S(5), Ref(rgb));
            HGDIOBJ o2 = SelectObject(dc, f);
            SetTextColor(dc, RGB(240, 230, 204));
            RECT tr = { S(40), 0, w - S(18), h };
            DrawTextW(dc, name, -1, &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
            SelectObject(dc, o2);
            GdiFlush();
            D3DLOCKED_RECT lr;
            if (SUCCEEDED(pl.tex->LockRect(0, &lr, nullptr, 0))) {
                for (int y = 0; y < th; ++y) {
                    uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch);
                    if (y >= h) { memset(dst, 0, tw * 4); continue; }
                    const uint32_t* src = static_cast<const uint32_t*>(bits) + y * w;
                    for (int x = 0; x < w; ++x) { const uint32_t c = src[x] & 0xFFFFFF; dst[x] = c == 0xFF00FF ? 0u : (c | 0xEE000000u); }
                    if (tw > w) memset(dst + w, 0, (tw - w) * 4);
                }
                pl.tex->UnlockRect(0);
                ok = true;
            }
            SelectObject(dc, ob);
            DeleteObject(bmp);
        }
        DeleteObject(f);
        DeleteDC(dc);
        if (ok) { wcsncpy(pl.name, name, 47); pl.name[47] = 0; pl.rgb = rgb; pl.forH = H; pl.w = w; pl.h = h; }
        return ok;
    }
    Plate* PlateFor(IDirect3DDevice9* dev, const wchar_t* name, DWORD rgb)
    {
        const DWORD now = GetTickCount();
        Plate* hit = nullptr; Plate* oldest = &g_plate[0];
        for (Plate& p : g_plate) {
            if (p.tex && p.dev == dev && p.rgb == rgb && p.forH == g_H && wcscmp(p.name, name) == 0) { hit = &p; break; }
            if (p.usedAt < oldest->usedAt) oldest = &p;
        }
        if (!hit) { if (!MakePlate(dev, *oldest, name, rgb, g_H)) return nullptr; hit = oldest; }
        hit->usedAt = now;
        return hit;
    }
    void DrawPlate(IDirect3DDevice9* dev, const Plate& p, float cx, float bottom)
    {
        const float x0 = cx - p.w / 2.f - 0.5f, y0 = bottom - p.h - 0.5f, u1 = (float)p.w / p.tw, v1 = (float)p.h / p.th;
        const DWORD c = 0xFFFFFFFF;
        const V v[4] = { { x0, y0, 0, 1, c, 0, 0 }, { x0 + p.w, y0, 0, 1, c, u1, 0 }, { x0 + p.w, y0 + p.h, 0, 1, c, u1, v1 }, { x0, y0 + p.h, 0, 1, c, 0, v1 } };
        dev->SetTexture(0, p.tex);
        dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
        dev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, v, sizeof(V));
    }
}

void RingsDrawView(IDirect3DDevice9* dev, int viewer)
{
    if (!g_init || !dev) return;
    MarkerChar chars[kMaxChars]; MarkerPoint points[kMaxPoints];
    int nc, np; bool active, combat;
    EnterCriticalSection(&g_lock);
    nc = g_nChars; np = g_nPoints; active = g_active; combat = g_combat;
    for (int i = 0; i < nc; ++i) chars[i] = g_chars[i];
    for (int i = 0; i < np; ++i) points[i] = g_points[i];
    LeaveCriticalSection(&g_lock);
    if (!active || (!nc && !np)) return;
    const bool rings = g_s.mode == 2 || (g_s.mode == 1 && combat);
    if (!rings && !g_s.drawn) return;
    if (!D3D9BackBufferSize(&g_W, &g_H) || g_W <= 0 || g_H <= 0) return;
    const float s = g_H / 1080.f < 0.5f ? 0.5f : g_H / 1080.f;
    const float t = GetTickCount() / 1000.f;

    IDirect3DStateBlock9* sb = D3D9SaveState(dev, 0);   // 1.7.1: made once, captured each frame
    if (!sb) return;
    IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
    dev->GetRenderTarget(0, &oldRt);
    dev->GetDepthStencilSurface(&oldDs);
    if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb) {
        dev->SetRenderTarget(0, bb);
        dev->SetDepthStencilSurface(nullptr);
        const bool began = SUCCEEDED(dev->BeginScene());
        dev->SetVertexShader(nullptr);
        dev->SetPixelShader(nullptr);
        dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
        dev->SetRenderState(D3DRS_ZENABLE, FALSE);
        dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
        dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
        dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
        dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
        dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
        dev->SetRenderState(D3DRS_LIGHTING, FALSE);
        dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
        dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
        dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
        dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
        dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
        dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
        dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
        dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
        dev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
        dev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
        dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
        D3DVIEWPORT9 vp = { 0, 0, (DWORD)g_W, (DWORD)g_H, 0.f, 1.f };
        dev->SetViewport(&vp);

        Geometry(dev);
        // 1. rings under Players 2 and 3 (Player 1's character has the game's own)
        if (rings)
            for (int i = 0; i < nc; ++i) if (chars[i].player >= 2) Ring(dev, chars[i], t * 0.6f + chars[i].player);
        if (g_s.drawn) {
            // 2. target arrows and ally diamonds (two players on the same one: side by side)
            for (int i = 0; i < np; ++i) {
                const MarkerPoint& m = points[i];
                if ((m.kind == 0 && !g_s.enemy) || (m.kind == 1 && !g_s.ally)) continue;
                const float head[3] = { m.feet[0], m.feet[1], m.feet[2] + (m.kind == 0 ? 2.35f : 2.25f) };
                float x, y;
                if (!Proj(head, x, y, true)) continue;
                int same = 0, mine = 0;
                for (int k = 0; k < np; ++k)
                    if (points[k].kind == m.kind && std::fabs(points[k].feet[0] - m.feet[0]) < 0.01f && std::fabs(points[k].feet[1] - m.feet[1]) < 0.01f) { if (k < i) ++mine; ++same; }
                if (same > 1) x += (mine - (same - 1) * 0.5f) * 30.f * s;
                const float bob = std::sin(t * 3.2f + m.player) * 3.f * s;
                if (m.kind == 0) Arrow(dev, x, y + bob, s, m.rgb);
                else AllyMark(dev, x, y + bob - 6 * s, s, m.rgb);
            }
            // 3. name plates over the other players' characters
            if (g_s.tags)
                for (int i = 0; i < nc; ++i) {
                    const MarkerChar& c = chars[i];
                    if (c.player == viewer || !c.name[0]) continue;
                    if (viewer == 1 && c.player == 1) continue;
                    const float head[3] = { c.feet[0], c.feet[1], c.feet[2] + 2.05f };
                    float x, y;
                    if (!Proj(head, x, y, true)) continue;
                    Plate* p = PlateFor(dev, c.name, c.rgb);
                    if (p) DrawPlate(dev, *p, x, y);
                    Geometry(dev);
                }
        }
        dev->SetTexture(0, nullptr);
        if (began) dev->EndScene();
        bb->Release();
    }
    if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
    dev->SetDepthStencilSurface(oldDs);
    if (oldDs) oldDs->Release();
    sb->Apply();   // (kept for the next frame)
}

static void Draw(IDirect3DDevice9* dev) { RingsDrawView(dev, 1); MenuBannerDraw(dev, 1); }   // Player 1's picture (the shared screen: everyone's; 1.7.8: + the menu banner)

void RingsInit(const RingSettings& s)
{
    g_s = s;
    if (g_s.radius < 0.3f) g_s.radius = 0.3f;
    if (g_s.radius > 2.f) g_s.radius = 2.f;
    if (!g_init) { InitializeCriticalSection(&g_lock); g_init = true; }
    if (g_s.mode <= 0 && !g_s.drawn) { Log("Player rings: off"); D3D9SetOverlay(&Draw); return; }   // (1.7.8: kept for the menu banner)
    D3D9SetOverlay(&Draw);
    Log("Player markers: rings %s (%.1f m); %s", g_s.mode == 2 ? "always" : g_s.mode == 1 ? "in combat" : "off", g_s.radius,
        g_s.drawn ? "name plates, target arrows and ally marks drawn in every player's own view" : "the game's floaty icons");
}
