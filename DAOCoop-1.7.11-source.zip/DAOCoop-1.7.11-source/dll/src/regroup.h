#pragma once
// Keeps Players 2/3 from getting lost or stuck.
//
// Area transitions: DoAreaTransition (745) "jumps ALL party members" (script.ldf);
// Players 2/3 are locked-active party members, so doors, world-map travel and
// scripted transitions take them along. This module is the safety net:
//
// Players 2/3 keep their agency: nothing moves them unless they ask.
//   Teleport button: hold LB for 1.5 s -> jump to a safe spot by the Warden
//     (formation spot GetFollowerWouldBeLocation 728 -> GetSafeLocation 659 ->
//     CommandJumpToLocation 581: walkable and unoccupied).
//   Left in another area after a scene (they couldn't play at all): placed by
//     the Warden automatically.
//   Optional (off by default): auto-place when farther than AutoDistance after
//     a scene; auto-teleport after StuckSeconds of pushing without moving.
//   Stuck hint: pushing the stick for 3 s without moving suggests holding LB.
#include <cstdint>

struct RegroupSettings {
    bool  enabled;
    float autoDistance;       // metres; 0 = off. After a scene, farther than this -> placed by the Warden
    float stuckSeconds;       // 0 = never auto-teleport when stuck
};

void RegroupInit(const RegroupSettings& s);
void RegroupTick(unsigned now, int player, uint32_t me, uint32_t hero, int mode /* game::Mode */);
void RegroupNoteStick(int player, bool pushing, unsigned now);    // from the controller code
bool RegroupTeleport(int player, uint32_t me, uint32_t hero, const char* why);
