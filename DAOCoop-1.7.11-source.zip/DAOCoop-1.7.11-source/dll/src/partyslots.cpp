#include "partyslots.h"
#include "hooks.h"
#include "log.h"
#include <cstdint>

// Each entry: address of the instruction, its original bytes; the last byte
// is the slot count (4) or the last slot index (3, for "cmp ...,4 / jge").
struct SlotPatch { uintptr_t address; uint8_t bytes[5]; uint8_t len; const char* what; };

static const SlotPatch kPatches[] = {
    // CCParty constructor: token arrays resized to 4
    { 0x63ADDC, { 0x6A, 0x04 }, 2, "ctor Party.Members size" },
    { 0x63ADF0, { 0x6A, 0x04 }, 2, "ctor Party.MemberSelected size" },
    { 0x63AE04, { 0x6A, 0x04 }, 2, "ctor Party.Summons size" },
    { 0x63AE18, { 0x6A, 0x04 }, 2, "ctor Party.SummonSelected size" },
    // CCParty::UpdatePortraitTokens: local arrays, clear loop, member cap
    { 0x635B8F, { 0x6A, 0x04 }, 2, "update members array" },
    { 0x635BA6, { 0x6A, 0x04 }, 2, "update selected array" },
    { 0x635BB8, { 0x6A, 0x04 }, 2, "update summons array" },
    { 0x635BCB, { 0x6A, 0x04 }, 2, "update summon-selected array" },
    { 0x635C7F, { 0x83, 0xFE, 0x04 }, 3, "update clear loop (cmp esi,4)" },
    { 0x635CB7, { 0x83, 0x7C, 0x24, 0x14, 0x04 }, 5, "update member cap (cmp [esp+14],4)" },
};

static int g_current = 4;          // what the patched instructions hold right now

bool PartySlotsApply(int slots)
{
    if (slots < 4) slots = 4;
    if (slots > 8) slots = 8;
    if (slots == g_current) return true;
    int ok = 0;
    for (const SlotPatch& p : kPatches) {
        uint8_t was[5], nb[5];
        for (int i = 0; i < p.len; ++i) was[i] = nb[i] = p.bytes[i];
        was[p.len - 1] = static_cast<uint8_t>(g_current);
        nb[p.len - 1] = static_cast<uint8_t>(slots);
        if (PatchBytes(p.address, was, nb, p.len, p.what)) ++ok;
    }
    int total = (int)(sizeof(kPatches) / sizeof(kPatches[0]));
    Log("Party slots: %d of %d patches applied for %d HUD slots (was %d)", ok, total, slots, g_current);
    if (ok == total) g_current = slots;
    return ok == total;
}

int PartySlotsCurrent() { return g_current; }
