#include "savesafe.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <windows.h>
#include <shlobj.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cwchar>

using std::wstring;

static SaveSafeSettings g_s;
static wstring g_backupRoot;        // ...\DAOCoop\Backups
static wstring g_charsRoot;         // ...\BioWare\Dragon Age\Characters

// Autosave wait (main thread)
struct Pending {
    bool     active = false;
    wstring  reason, hero, p2, p3;
    FILETIME since = {};            // a save newer than this is the one we asked for
    unsigned start = 0;
    bool     quickSent = false;
};
static Pending g_pend;

// ---------------------------------------------------------------------------
// File helpers
// ---------------------------------------------------------------------------
static bool IsDir(const wstring& p)
{
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY);
}

static bool MakeDirs(const wstring& p)
{
    if (p.empty() || IsDir(p)) return true;
    size_t cut = p.find_last_of(L'\\');
    if (cut != wstring::npos && cut > 2) MakeDirs(p.substr(0, cut));
    return CreateDirectoryW(p.c_str(), nullptr) || GetLastError() == ERROR_ALREADY_EXISTS;
}

struct Entry { wstring name; FILETIME time; bool dir; };

static std::vector<Entry> List(const wstring& dir)
{
    std::vector<Entry> out;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
        out.push_back({ fd.cFileName, fd.ftLastWriteTime, (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 });
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return out;
}

// Newest write time of anything inside (a save folder's own time may not move).
static FILETIME NewestIn(const wstring& dir)
{
    FILETIME best = {};
    for (const Entry& e : List(dir)) {
        FILETIME t = e.dir ? NewestIn(dir + L"\\" + e.name) : e.time;
        if (CompareFileTime(&t, &best) > 0) best = t;
    }
    return best;
}

static bool CopyTree(const wstring& from, const wstring& to, const wstring& renameStem = L"", const wstring& newStem = L"")
{
    if (!MakeDirs(to)) return false;
    bool ok = true;
    for (const Entry& e : List(from)) {
        wstring name = e.name;
        // "AutoSave_1\AutoSave_1.das" style: rename files named after the folder
        if (!renameStem.empty() && !e.dir) {
            size_t dot = name.find_last_of(L'.');
            wstring stem = dot == wstring::npos ? name : name.substr(0, dot);
            if (_wcsicmp(stem.c_str(), renameStem.c_str()) == 0)
                name = newStem + (dot == wstring::npos ? L"" : name.substr(dot));
        }
        wstring a = from + L"\\" + e.name, b = to + L"\\" + name;
        if (e.dir) ok = CopyTree(a, b) && ok;
        else ok = CopyFileW(a.c_str(), b.c_str(), FALSE) && ok;
    }
    return ok;
}

static void DeleteTree(const wstring& dir)
{
    for (const Entry& e : List(dir)) {
        wstring p = dir + L"\\" + e.name;
        if (e.dir) DeleteTree(p);
        else { SetFileAttributesW(p.c_str(), FILE_ATTRIBUTE_NORMAL); DeleteFileW(p.c_str()); }
    }
    RemoveDirectoryW(dir.c_str());
}

static wstring SafeName(const wstring& s)
{
    wstring o;
    for (wchar_t c : s) o += (wcschr(L"\\/:*?\"<>|", c) || c < 32) ? L'_' : c;
    return o.empty() ? L"unknown" : o;
}

// ---------------------------------------------------------------------------
// Finding the Warden's saves
// ---------------------------------------------------------------------------
// The character folder: named after the Warden (an exact or "Name_n" match),
// the most recently saved one when there are several; else the newest folder.
static wstring CharacterFolder(const wstring& hero)
{
    wstring best, bestAny;
    FILETIME tBest = {}, tAny = {};
    for (const Entry& e : List(g_charsRoot)) {
        if (!e.dir) continue;
        wstring saves = g_charsRoot + L"\\" + e.name + L"\\Saves";
        if (!IsDir(saves)) continue;
        FILETIME t = NewestIn(saves);
        bool match = !hero.empty() && (_wcsicmp(e.name.c_str(), hero.c_str()) == 0 ||
                     (_wcsnicmp(e.name.c_str(), hero.c_str(), hero.size()) == 0 && e.name.size() > hero.size() &&
                      (e.name[hero.size()] == L'_' || e.name[hero.size()] == L' ')));
        if (match && CompareFileTime(&t, &tBest) > 0) { tBest = t; best = e.name; }
        if (CompareFileTime(&t, &tAny) > 0) { tAny = t; bestAny = e.name; }
    }
    return best.empty() ? bestAny : best;
}

struct SaveDir { wstring name; FILETIME time; };

static std::vector<SaveDir> SavesNewestFirst(const wstring& charFolder)
{
    std::vector<SaveDir> v;
    wstring saves = g_charsRoot + L"\\" + charFolder + L"\\Saves";
    for (const Entry& e : List(saves))
        if (e.dir) v.push_back({ e.name, NewestIn(saves + L"\\" + e.name) });
    std::sort(v.begin(), v.end(), [](const SaveDir& a, const SaveDir& b) { return CompareFileTime(&a.time, &b.time) > 0; });
    return v;
}

// ---------------------------------------------------------------------------
// Backups (background thread)
// ---------------------------------------------------------------------------
struct Job { wstring charFolder, reason, info; };

static DWORD WINAPI BackupThread(LPVOID arg)
{
    Job* j = static_cast<Job*>(arg);
    std::vector<SaveDir> saves = SavesNewestFirst(j->charFolder);
    if (saves.empty()) { Log("Backup (%ls): no saves yet for \"%ls\"", j->reason.c_str(), j->charFolder.c_str()); delete j; return 0; }

    SYSTEMTIME st;
    GetLocalTime(&st);
    wchar_t stamp[64];
    swprintf(stamp, 64, L"%04d-%02d-%02d_%02d-%02d-%02d_", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    wstring charDir = g_backupRoot + L"\\" + SafeName(j->charFolder);
    wstring set = charDir + L"\\" + stamp + SafeName(j->reason);
    int n = 0, ok = 0;
    for (const SaveDir& s : saves) {
        if (n++ >= g_s.savesPerSet) break;
        if (CopyTree(g_charsRoot + L"\\" + j->charFolder + L"\\Saves\\" + s.name, set + L"\\" + s.name)) ++ok;
    }
    HANDLE f = CreateFileW((set + L"\\info.txt").c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
        std::string utf8(WideCharToMultiByte(CP_UTF8, 0, j->info.c_str(), -1, nullptr, 0, nullptr, nullptr), 0);
        WideCharToMultiByte(CP_UTF8, 0, j->info.c_str(), -1, &utf8[0], (int)utf8.size(), nullptr, nullptr);
        DWORD w; WriteFile(f, utf8.c_str(), (DWORD)strlen(utf8.c_str()), &w, nullptr);
        CloseHandle(f);
    }
    Log("Backup (%ls): %d of %d newest saves of \"%ls\" copied to %ls", j->reason.c_str(), ok, n > g_s.savesPerSet ? g_s.savesPerSet : n,
        j->charFolder.c_str(), set.c_str());

    // keep only the newest sets (names start with the date, so they sort by time)
    std::vector<wstring> sets;
    for (const Entry& e : List(charDir)) if (e.dir) sets.push_back(e.name);
    std::sort(sets.begin(), sets.end());
    while ((int)sets.size() > g_s.keepSets) {
        DeleteTree(charDir + L"\\" + sets.front());
        Log("Backup: removed old set %ls", sets.front().c_str());
        sets.erase(sets.begin());
    }
    delete j;
    return 0;
}

static void StartCopy(const wstring& hero, const wstring& reason, const wstring& p2, const wstring& p3)
{
    wstring folder = CharacterFolder(hero);
    if (folder.empty()) { Log("Backup (%ls): no character folder in %ls", reason.c_str(), g_charsRoot.c_str()); return; }
    Job* j = new Job{ folder, reason, L"Warden=" + hero + L"\r\nP2=" + p2 + L"\r\nP3=" + p3 + L"\r\nReason=" + reason + L"\r\n" };
    HANDLE t = CreateThread(nullptr, 0, BackupThread, j, 0, nullptr);
    if (t) CloseHandle(t); else delete j;
}

void SaveSafeBackup(const wchar_t* reason, bool autosaveFirst, const wchar_t* hero, const wchar_t* p2, const wchar_t* p3)
{
    if (!g_s.enabled || g_pend.active) return;
    autosaveFirst = autosaveFirst && g_s.autosaveBeforeCreator;
    if (!autosaveFirst) { StartCopy(hero, reason, p2, p3); return; }
    g_pend.active = true;
    g_pend.reason = reason; g_pend.hero = hero; g_pend.p2 = p2; g_pend.p3 = p3;
    GetSystemTimeAsFileTime(&g_pend.since);
    g_pend.start = GetTickCount();
    g_pend.quickSent = false;
    Log("Backup (%ls): asking the game for an autosave first", reason);
    script::DoAutoSave();
}

bool SaveSafeBusy() { return g_pend.active; }

void SaveSafeTick(unsigned now)
{
    if (!g_pend.active) return;
    static unsigned next = 0;
    if ((int)(now - next) < 0) return;          // looking at the saves folder twice a second is plenty
    next = now + 500;
    unsigned waited = now - g_pend.start;
    wstring folder = CharacterFolder(g_pend.hero);
    std::vector<SaveDir> saves = folder.empty() ? std::vector<SaveDir>() : SavesNewestFirst(folder);
    bool fresh = !saves.empty() && CompareFileTime(&saves[0].time, &g_pend.since) > 0;
    // wait a moment after the newest file appears, so the save is complete
    if (fresh && waited > 2500) {
        g_pend.active = false;
        Log("Backup (%ls): new save \"%ls\" is on disk", g_pend.reason.c_str(), saves[0].name.c_str());
        StartCopy(g_pend.hero, g_pend.reason, g_pend.p2, g_pend.p3);
        return;
    }
    if (!g_pend.quickSent && waited > 4000) {
        g_pend.quickSent = true;                 // no autosave (combat, disabled...): quick save
        Log("Backup (%ls): no autosave appeared, making a quick save", g_pend.reason.c_str());
        game::SendGameMessage("GameModeController.SaveGameMessage -1 2");
    }
    if (waited > 10000) {
        g_pend.active = false;
        Log("Backup (%ls): no new save after 10 s, backing up the existing saves", g_pend.reason.c_str());
        StartCopy(g_pend.hero, g_pend.reason, g_pend.p2, g_pend.p3);
    }
}

// ---------------------------------------------------------------------------
// Co-op character names per Warden
// ---------------------------------------------------------------------------
static wstring RecordFile() { return g_backupRoot + L"\\coop-characters.ini"; }

void SaveSafeRecord(const wchar_t* hero, int player, const wchar_t* name)
{
    if (!hero || !hero[0] || !name || !name[0]) return;
    wchar_t key[8], old[64];
    swprintf(key, 8, L"P%d", player);
    GetPrivateProfileStringW(SafeName(hero).c_str(), key, L"", old, 64, RecordFile().c_str());
    if (wcscmp(old, name) == 0) return;
    MakeDirs(g_backupRoot);
    WritePrivateProfileStringW(SafeName(hero).c_str(), key, name, RecordFile().c_str());
    Log("Save safety: %ls's Player %d plays \"%ls\"", hero, player, name);
}

bool SaveSafeRecorded(const wchar_t* hero, int player, wchar_t* name, int cap)
{
    wchar_t key[8];
    swprintf(key, 8, L"P%d", player);
    GetPrivateProfileStringW(SafeName(hero).c_str(), key, L"", name, cap, RecordFile().c_str());
    return name[0] != 0;
}

// ---------------------------------------------------------------------------
// Restore: newest backup set whose info.txt names this player's character
// ---------------------------------------------------------------------------
static bool SetHasPlayer(const wstring& set, int player)
{
    HANDLE f = CreateFileW((set + L"\\info.txt").c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    char buf[1024] = {}; DWORD r = 0;
    ReadFile(f, buf, sizeof(buf) - 1, &r, nullptr);
    CloseHandle(f);
    char key[8];
    sprintf(key, "P%d=", player);
    const char* k = strstr(buf, key);
    return k && k[3] && k[3] != '\r' && k[3] != '\n';
}

bool SaveSafeRestore(const wchar_t* hero, int player, wchar_t* msg, int cap)
{
    wstring folder = CharacterFolder(hero);
    if (folder.empty()) { swprintf(msg, cap, L"No saves found for %ls", hero); return false; }
    wstring charDir = g_backupRoot + L"\\" + SafeName(folder);
    std::vector<wstring> sets;
    for (const Entry& e : List(charDir)) if (e.dir) sets.push_back(e.name);
    std::sort(sets.begin(), sets.end());
    for (auto it = sets.rbegin(); it != sets.rend(); ++it) {
        wstring set = charDir + L"\\" + *it;
        if (!SetHasPlayer(set, player)) continue;
        // newest save inside the set
        wstring src; FILETIME best = {};
        for (const Entry& e : List(set)) {
            if (!e.dir) continue;
            FILETIME t = NewestIn(set + L"\\" + e.name);
            if (CompareFileTime(&t, &best) > 0) { best = t; src = e.name; }
        }
        if (src.empty()) continue;
        // a free "Save_<n>" folder next to the Warden's other saves
        wstring saves = g_charsRoot + L"\\" + folder + L"\\Saves";
        int n = 1;
        for (const Entry& e : List(saves))
            if (e.dir && _wcsnicmp(e.name.c_str(), L"Save_", 5) == 0) n = (std::max)(n, _wtoi(e.name.c_str() + 5) + 1);
        wchar_t dst[32];
        swprintf(dst, 32, L"Save_%d", n);
        bool ok = CopyTree(set + L"\\" + src, saves + L"\\" + dst, src, dst);
        Log("Save safety: restore %ls\\%ls -> %ls\\%ls: %s", set.c_str(), src.c_str(), saves.c_str(), dst, ok ? "ok" : "FAILED");
        if (ok) swprintf(msg, cap, L"Restored a backup from %.10ls as a new save - load it from Load Game", it->c_str());
        else swprintf(msg, cap, L"Restoring the backup failed (see DAOCoop.log)");
        return ok;
    }
    swprintf(msg, cap, L"No backup with Player %d's character yet", player);
    return false;
}

// ---------------------------------------------------------------------------

void SaveSafeInit(const SaveSafeSettings& s, const wchar_t* modDir)
{
    g_s = s;
    if (g_s.keepSets < 1) g_s.keepSets = 1;
    if (g_s.savesPerSet < 1) g_s.savesPerSet = 1;

    if (s.charactersDir[0]) g_charsRoot = s.charactersDir;
    else {
        wchar_t docs[MAX_PATH] = {};
        if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_PERSONAL, nullptr, 0, docs)))
            g_charsRoot = wstring(docs) + L"\\BioWare\\Dragon Age\\Characters";
    }
    while (!g_charsRoot.empty() && g_charsRoot.back() == L'\\') g_charsRoot.pop_back();

    g_backupRoot = wstring(modDir) + L"Backups";
    if (!MakeDirs(g_backupRoot)) {
        wchar_t local[MAX_PATH];
        DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", local, MAX_PATH);
        if (n > 0 && n < MAX_PATH - 32) { g_backupRoot = wstring(local) + L"\\DAOCoop\\Backups"; MakeDirs(g_backupRoot); }
    }
    Log("Save safety: %s - saves in %ls, backups in %ls (keep %d sets of %d saves)%s",
        s.enabled ? "on" : "off", g_charsRoot.c_str(), g_backupRoot.c_str(), g_s.keepSets, g_s.savesPerSet,
        IsDir(g_charsRoot) ? "" : " - saves folder not found yet");
}
