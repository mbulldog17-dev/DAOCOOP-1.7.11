#pragma once
// 1.2.46: a ring on the ground under each co-op character in their player colour
// (blue Player 2, green Player 3), so everyone can find their own character in a fight.
// 1.7.4: all the players' markers are drawn here, in every player's own picture with that picture's own camera
// (the game's floaty icons follow only Player 1's camera, so in split screen they were in the wrong place):
//   - the selector ring under Players 2/3's characters (a soft glow, a fine line and turning gold diamonds)
//   - a name plate over the other players' heads (Player 1's in gold)
//   - an arrow over the enemy a player attacks, a "+" diamond over the friend their heals go to
// Styled like the co-op menu (dark plate, gold lines, diamonds).
#include <cstdint>

struct IDirect3DDevice9;

struct RingSettings {
    int   mode;          // rings: 0 off, 1 in combat, 2 always
    float radius;        // metres
    int   alpha;         // 0-255
    bool  drawn;         // 1.7.4: markers drawn here ([Markers] DrawnMarkers), not the game's floaty icons
    bool  tags;          // name plates ([Markers] OwnCharacterTag)
    bool  enemy;         // target arrows ([Markers] EnemyTarget)
    bool  ally;          // ally diamonds ([Markers] AllyTarget)
};
void RingsInit(const RingSettings& s);

struct MarkerChar  { int player; uint32_t rgb; float feet[3]; wchar_t name[48]; };   // player 1-3
struct MarkerPoint { int player; uint32_t rgb; float feet[3]; int kind; };          // kind 0 enemy target, 1 ally
// Main tick: the players' characters, their targets, and whether markers show now.
void RingsSetMarkers(const MarkerChar* chars, int nChars, const MarkerPoint* points, int nPoints, bool combat, bool active);
// Render thread: this picture's markers, with the scene camera as it is now (viewer 1-3: whose picture).
void RingsDrawView(IDirect3DDevice9* dev, int viewer);
bool RingsDrawnMarkers();
