#pragma once
// 1.7.8: when one player has a menu open (inventory, character record, journal, level-up...) the game stops for
// everyone. Everyone else gets a banner in the game's look at the top of their own view, till the menu is shut:
// "THE GAME WAITS - Player 2 (Ali) is in a menu". The player with the menu open doesn't get it. Drawn into each
// player's own picture, so online friends see it in their stream.
struct IDirect3DDevice9;

void MenuBannerDraw(IDirect3DDevice9* dev, int viewer);   // viewer 1-3; on the current back buffer (render thread)
