#pragma once
// Calls the game's own script commands (the same 827 functions the toolset's
// scripts use) from C++. Arguments go onto the script VM stack in reverse
// order, the command's native handler runs, and the result is popped.
//
// Must only be called on the game's main thread, outside script execution
// (we call it from a window timer, see tick.cpp). Every call is guarded: a
// crash inside the game turns into a logged failure, not a game crash.
#include <cstdint>

namespace script {

struct Vec3 { float x, y, z; };

bool Init();            // checks the build; false = everything below is a no-op
bool Ready();

// --- objects -----------------------------------------------------------------
uint32_t GetHero();
uint32_t GetControlled();                       // the party member Player 1 drives
uint32_t GetObjectByTag(const wchar_t* tag, int nth = 0);
bool     IsObjectValid(uint32_t obj);
bool     GetTag(uint32_t obj, wchar_t* out, int cap);
bool     SetTag(uint32_t obj, const wchar_t* tag);
int      GetObjectType(uint32_t obj);           // bit mask, 0 = invalid
uint32_t GetArea(uint32_t obj);
bool     GetPosition(uint32_t obj, Vec3* out);
float    GetFacing(uint32_t obj);
float    GetDistance(uint32_t a, uint32_t b);   // -1 when unknown
bool     GetName(uint32_t obj, wchar_t* out, int cap);
bool     IsDead(uint32_t obj);
int      IsDeadChecked(uint32_t obj);   // 1 dead, 0 alive, -1 could not tell
bool     IsHostile(uint32_t a, uint32_t b);
int      GetCombatState(uint32_t creature);     // 0 = not in combat
int      GetPartySize();
int      GetCommandQueueSize(uint32_t obj);     // queued commands, -1 on failure
void     DoAutoSave();                          // the game's autosave (command 513)
bool     HasAbility(uint32_t creature, int ability);
void     AddAbility(uint32_t creature, int ability);      // no notification
void     RemoveAbility(uint32_t creature, int ability);

// Up to `max` nearest hostile (or friendly) objects of `objectType` around obj,
// nearest first. Returns how many were written, or -1 on failure.
int      GetNearestByHostility(uint32_t obj, bool hostile, int objectType, uint32_t* out, int max,
                               bool livingOnly = true, bool perceivedOnly = true);

// Up to `max` nearest objects of `objectType` (bit mask) around obj, nearest first.
int      GetNearestObjects(uint32_t obj, int objectType, uint32_t* out, int max,
                           bool livingOnly = false, bool perceivedOnly = false);

// --- abilities -----------------------------------------------------------------
int      GetQuickSlot(uint32_t creature, int slot);         // ability id, 0 = empty
bool     IsAbilityAvailable(uint32_t creature, int ability);

// --- commands ----------------------------------------------------------------
// Builds CommandMoveToLocation(Location(area, pos, facing), bRun) and adds it to
// obj's command queue (front of the queue when addToFront).
bool MoveTo(uint32_t obj, const Vec3& pos, float facingDeg, bool run, bool addToFront);
bool Attack(uint32_t obj, uint32_t target, bool addToFront = true);
bool UseAbility(uint32_t obj, int ability, uint32_t target, const Vec3& targetPos, bool addToFront = true);
bool ClearAllCommands(uint32_t obj, bool hard = true);
bool PlayAnimation(uint32_t obj, int animation, int loops, bool addToFront = true);   // ANIM ids (ambient_anim_patterns.gda)
uint32_t CreateItemOn(uint32_t obj, const wchar_t* resource, int stack = 1);   // into obj's inventory, no notification
bool     EquipItem(uint32_t creature, uint32_t item, int slot, int weaponSet = 0); // slot 0 main hand, 1 off hand
uint32_t ItemInEquipSlot(uint32_t creature, int slot, int weaponSet = 0);
int  LineOfSight(uint32_t self, const Vec3& a, const Vec3& b);   // 1 clear, 0 blocked, -1 unknown (collision ray in self's area)
// CommandMoveToObject(oTarget, bRun, fMinRange, 0, fMaxRange) - the game chases the target object
bool MoveToObject(uint32_t obj, uint32_t target, bool run, float minRange, bool addToFront = true);
bool SetPosition(uint32_t obj, const Vec3& pos);
// Puts obj on the walkable spot nearest to pos in 'nearObj''s area (GetSafeLocation + SetLocation)
bool SetPositionSafe(uint32_t obj, uint32_t nearObj, const Vec3& pos);
bool SetLocationSafe(uint32_t obj, uint32_t nearObj, const Vec3& pos, float facingDeg);   // nearest safe spot, facing      // SetPosition(o, v, bJump = FALSE)
void DestroyObject(uint32_t obj);                       // clears the plot flag first
bool SetFollowPartyLeader(uint32_t obj, bool follow);
void SetPrimaryControlled(uint32_t obj);           // the party member Player 1 drives
// Teleports `obj` to a safe, walkable spot: its formation place behind the party
// leader (GetFollowerWouldBeLocation) if that works, else next to `anchor`;
// either way passed through GetSafeLocation. Returns true if a jump was queued.
bool JumpToSafeSpotNear(uint32_t obj, uint32_t anchor);

// --- party / creation (experimental) -------------------------------------------
uint32_t CreateObject(int objectType, const wchar_t* resource, uint32_t nearObj);
bool     AddToParty(uint32_t obj);
bool     SetFollowerState(uint32_t obj, int state);   // 1 active, 2 available, 7 locked active
void     PreloadCharGen();
void     SetGameMode(int gm);                           // GM_* (0 explore)
bool     StartCharGen(uint32_t creature, int mode);   // 0 = full creation, 1 = level up

// --- progression -------------------------------------------------------------
float    GetCreatureProperty(uint32_t creature, int property, int valueType = 1);   // 1 total, 2 base
void     SetCreatureProperty(uint32_t creature, int property, float value, int valueType = 2);
int      GetM2DAInt(int table, const wchar_t* column, int row);
// 1.7.0 (Player 2's HUD)
bool     GetStringById(int strref, wchar_t* out, int cap);
bool     GetM2DAString(int table, const wchar_t* column, int row, wchar_t* out, int cap);
float    GetRemainingCooldown(uint32_t creature, int ability);   // seconds, 0 = ready, -1 unknown
bool     IsModalAbilityActive(uint32_t creature, int ability);
bool     GetCanLevelUp(uint32_t creature);
void     SetAutoLevelUp(uint32_t creature, int mode);   // 0 = the player spends points
// Runs a compiled game script (e.g. L"addxp.ncs") with OBJECT_SELF = obj, after
// setting the module's RUNSCRIPT_VAR (the console "runscript" argument).
bool     RunScriptOn(uint32_t obj, const wchar_t* script, const wchar_t* runscriptVar);

// --- feedback ------------------------------------------------------------------
void DisplayStatusMessage(const wchar_t* text, uint32_t rgb = 0xFFFFFF);
// Text floating over any object (creature, chest, door...) for `seconds`.
void DisplayFloatyMessage(uint32_t obj, const wchar_t* text, uint32_t rgb, float seconds);
// Image floating over a creature until replaced; "" hides it. `image` = texture
// name without .dds (looked up in the game's resources / override).
void ShowFloatyIcon(uint32_t creature, const wchar_t* image);
// 1.7.1: a container's loot window (as placeable_core does when it is used), run as the container
bool OpenInventory(uint32_t container, uint32_t player);

} // namespace script
