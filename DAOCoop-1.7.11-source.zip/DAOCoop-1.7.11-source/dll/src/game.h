#pragma once
// Addresses inside DAOrigins.exe 1.05.13263.0 (GOG build, image base 0x400000),
// found by reverse engineering. See docs/engine-notes.md for how each was found.
//
// Every function address is checked against the bytes the GOG exe has there
// before use (CheckBuild); on any other build the engine bridge stays off.
#include <windows.h>
#include <cstdint>

namespace game {

// --- globals ---------------------------------------------------------------
constexpr uintptr_t kAppPtr        = 0xC327EC; // CClientExoApp*   (size 0x2F0)
constexpr uintptr_t kVmPtr         = 0xC1D080; // script virtual machine*
constexpr uintptr_t kPauseOwnerPtr = 0xC32938; // *(this)+0x5F4 = pause state, byte +0xC = paused

// --- script virtual machine (all __thiscall on the VM object) --------------
constexpr uintptr_t kVmPushInt     = 0xA2D650; // int  (int v)               tag 3
constexpr uintptr_t kVmPushFloat   = 0xA2D690; // int  (float v)             tag 4
constexpr uintptr_t kVmPushVector  = 0xA2D6D0; // int  (const float* xyz)    3 floats
constexpr uintptr_t kVmPushString  = 0xA2D730; // int  (const GameString*)   tag 5   (copied)
constexpr uintptr_t kVmPushResource= 0xA2D890; // int  (const GameString*)   tag 0x60 resource name
constexpr uintptr_t kVmPushStruct  = 0xA2D920; // int  (int type, void* p)   tag 0x10+type (copied)
constexpr uintptr_t kVmPushObject  = 0xA2D980; // int  (uint32 id)           tag 6
constexpr uintptr_t kVmPopInt      = 0xA2F3C0; // int  (int* out)
constexpr uintptr_t kVmPopFloat    = 0xA2F410; // int  (float* out)
constexpr uintptr_t kVmPopVector   = 0xA2F460; // int  (float* xyz)          pops z,y,x
constexpr uintptr_t kVmPopString   = 0xA2F4C0; // int  (GameString* out)     tag 5
constexpr uintptr_t kVmPopStruct   = 0xA2F650; // int  (int type, void** out) returns a COPY we own
constexpr uintptr_t kVmPopObject   = 0xA2F6D0; // int  (uint32* out)
constexpr uintptr_t kVmPopArray    = 0xA2F720; // int  (ArrayValue* out)     {tag, holder*, owner}
constexpr uintptr_t kVmArrayFree   = 0xA2F7C0; // void __thiscall(ArrayValue*)
constexpr uint32_t  kVmStackOffset = 0x1738;   // VM -> value stack (int count at +0)
constexpr uintptr_t kVmStackTruncate = 0xA2F390; // void (int depth), __thiscall on the stack
constexpr uint32_t  kVmImplOffset  = 0x1968;   // VM -> command implementer
// implementer vtable: +0x08 RunCommand(id, argc), +0x18 DestroyStruct(type, p), +0x20 CopyStruct(type, p)
constexpr uint32_t  kImplDestroyStruct = 0x18;
constexpr uint32_t  kImplSelf          = 0x08;   // OBJECT_SELF of the running script
constexpr uintptr_t kImplVtableRunCommand = 0xB00314;   // implementer vtable slot 2 (-> 0x64DD60)
constexpr int       kStructEvent       = 0;

// --- game strings / allocator ----------------------------------------------
constexpr uintptr_t kGameNew       = 0x413660; // void* __cdecl(size_t)
constexpr uintptr_t kGameDelete    = 0x4136C0; // void  __cdecl(void*)
constexpr uintptr_t kStringDtor    = 0x4C0DB0; // void  __thiscall(GameString*)

// --- game mode controller (CClientExoApp+0x114) -----------------------------
constexpr uint32_t  kAppModeCtrl     = 0x114;  // GameModeController*
constexpr uint32_t  kCtrlCurrentMode = 0x74;   // GameMode* (vtable identifies the mode)
constexpr uint32_t  kModeId          = 0x5C;   // int id inside every GameMode

// --- explore camera --------------------------------------------------------
// GameModeController+0x60 = CameraControllerExplore* (vtable 0xB1D954).
// +0x70 camera position, +0x80 focus point (the followed object's position).
constexpr uint32_t  kAppCameraOwner = 0x114;
constexpr uint32_t  kCamOwnerCamera = 0x60;
constexpr uint32_t  kCamPos         = 0x70;
constexpr uint32_t  kCamFocus       = 0x80;

// --- party -----------------------------------------------------------------
// CClientExoApp+0xD0 -> +0x58 = CCParty; +0x234 = std::vector<object id> of members.
constexpr uint32_t  kAppPartyOwner  = 0xD0;
constexpr uint32_t  kPartyOwnerParty= 0x58;
constexpr uint32_t  kPartyMembers   = 0x234;   // {proxy, first, last, end}

// --- engine structure types used on the VM stack ---------------------------
constexpr int kStructLocation = 1;
constexpr int kStructCommand  = 2;

// --- script command IDs (same numbers as the toolset's script.ldf order) ----
enum Cmd : int {
    GETFACING                   = 17,
    GETPOSITION                 = 21,
    GETDISTANCEBETWEENOBJECTS   = 37,
    GETNEARESTOBJECTBYHOSTILITY = 127,
    GETNEARESTOBJECT            = 433,
    GETCONTROLLED               = 168,
    GETPERCEIVEDCREATURELIST    = 169,
    ISOBJECTVALID               = 206,
    GETOBJECTTYPE               = 207,
    GETTAG                      = 209,
    SETTAG                      = 210,
    GETOBJECTBYTAG              = 211,
    ISLOCATIONSAFE              = 456,
    COMMANDJUMPTOLOCATION       = 581,
    GETSAFELOCATION             = 659,
    CHECKLINEOFSIGHTPOSITION    = 47,
    CREATEITEMONOBJECT          = 212,   // (resource, object, int stack, string tag, int suppress, [int droppable]) -> object
    EQUIPITEM                   = 392,   // (object creature, object item, int slot, int weaponSet) -> int
    GETITEMINEQUIPSLOT          = 401,   // (int slot, object creature, [int weaponSet]) -> object    // (vector, vector) -> int; both raised 1.8 m (0x655CA0)
    GETFOLLOWERWOULDBELOCATION  = 728,
    SETLOCALSTRING              = 70,
    EVENT                       = 106,
    HANDLEEVENT                 = 121,
    GETMODULE                   = 224,
    GETAUTOLEVELUP              = 384,
    SETAUTOLEVELUP              = 385,
    GETCANLEVELUP               = 633,
    GETM2DAINT                  = 667,
    GETSTRINGBYSTRINGID         = 179,   // 1.7.0 (Player 2's HUD)
    GETM2DASTRING               = 9,
    GETREMAININGCOOLDOWN        = 195,
    ISMODALABILITYACTIVE        = 726,
    GETCREATUREPROPERTY         = 738,
    SETCREATUREPROPERTY         = 740,
    GETAREA                     = 223,
    ISDEAD                      = 237,
    GETNAME                     = 275,
    CREATEOBJECT                = 306,
    SETPOSITION                 = 22,
    SETLOCATION                 = 458,
    DESTROYOBJECT               = 214,
    SETPLOT                     = 218,
    COMMANDMOVETOOBJECT         = 560,
    GETQUICKSLOT                = 330,
    PRELOADCHARGEN              = 390,
    ADDTOPARTY                  = 396,
    GETPARTYSIZE                = 398,
    LOCATION                    = 454,
    ISHOSTILE                   = 468,
    GETHERO                     = 502,
    GETPARTYLIST                = 504,
    GETCOMBATSTATE              = 526,
    GETCOMMANDQUEUESIZE         = 724,
    DOAUTOSAVE                  = 513,
    HASABILITY                  = 252,
    ADDABILITY                  = 253,
    REMOVEABILITY               = 254,
    SETGAMEMODE                 = 530,
    GETGAMEMODE                 = 529,
    ADDCOMMAND                  = 533,
    CLEARALLCOMMANDS            = 538,
    COMMANDMOVETOLOCATION       = 559,
    COMMANDPLAYANIMATION        = 569,   // (int anim, int loops, int, int blendIn) -> command [0x66FC20]
    COMMANDATTACK               = 566,
    COMMANDUSEABILITY           = 582,
    COMMANDUSEOBJECT            = 586,
    ISABILITYAVAILABLE          = 610,
    SETFOLLOWERSTATE            = 706,
    DISPLAYFLOATYMESSAGE        = 744,
    STARTCHARGEN                = 746,
    SHOWFLOATYICON              = 749,
    OPENINVENTORY               = 410,   // (object container, object player, int bCanAddItems)
    DISPLAYSTATUSMESSAGE        = 747,
    SETFOLLOWPARTYLEADER        = 769,
    SETPRIMARYCONTROLLED        = 815,
};

constexpr uint32_t kInvalidObject = 0xFFFFFFFF;

// Checks that the running exe is the build these addresses were taken from.
// Returns true when the bridge may be used; writes the reason to the log.
void WaitForGameCode();   // 1.4.5: Steam - the code is unscrambled after the DLL loads
bool CheckBuild();

// --- direct reads (all crash-guarded; safe to call any time) ----------------
enum Mode {
    MODE_NONE, MODE_UNKNOWN, MODE_EXPLORE, MODE_COMBAT, MODE_DIALOG, MODE_CUTSCENE,
    MODE_GUI, MODE_DEAD, MODE_PREGAME, MODE_LOADING, MODE_MOVIE, MODE_PARTYPICKER,
    MODE_CHARGEN, MODE_FLYCAM, MODE_FIXED,
};
Mode        CurrentMode(int* rawId = nullptr);
const char* ModeName(Mode m);
bool        IsPaused();
int         PartyMembers(uint32_t* out, int max);   // -1 = unreadable
// Id of the creature's off-screen arrow floaty (floatylayer.gfx), 0 = none.
int         OffscreenFloatyId(uint32_t creature);
// The per-character "party AI" switch of the tactics screen (IsPartyAIEnabled):
// 1 on, 0 off, -1 unreadable. Off: the game's combat round only keeps attacking
// the current target (rules_core sub_00024242) instead of running tactics.
int         GetPartyAI(uint32_t creature);
uint32_t    HeroId();                          // what GetHero returns (read directly)
bool        SetHero(uint32_t creature);        // put the hero back (after the co-op creator)
bool        CameraLook(float* fx, float* fy);  // camera view direction (unnormalised, z up)

// Character creator (GUICharGen) internals.
struct ChargenInfo { void* gui; uint32_t target; void* paperdoll; void* shown; };
bool        ChargenInfoGet(ChargenInfo* out);  // creator GUI, creature being made, preview creature
bool        ChargenUse(uint32_t creature);     // creator + preview work on this creature
bool        ChargenRefresh(int n);             // rebuild the preview after a race/gender/class pick
int         ModelLive(uint32_t creature);      // client +0x7B4 (1 = model live in the world), -1 unknown
bool        RebuildModel(uint32_t creature);   // rebuild the world model from its appearance
bool        AdoptPreviewLook(uint32_t creature); // build its model from the creator preview's look (creator still open)
bool        LookInfo(uint32_t creature, int* appearance, wchar_t* morph, int cap);
// Head morph, NPC style (1.2.23; engine notes "Head morph")
int         ProfileMorphGet(unsigned char* out, int cap);       // the hero's face blob (.mor data); bytes, < 0 failed
bool        ProfileMorphSet(const unsigned char* data, int n);
void*       StashPreviewLook();                                  // copy of the creator preview's appearance data
bool        ApplyLook(uint32_t creature, void* look, bool asHero); // the creature takes 'look' over and rebuilds
// Voice (sound set, client creature +0x96C, e.g. "ss_pc_melf_wise").
bool        SoundSet(uint32_t creature, wchar_t* out, int cap);
bool        SetSoundSetFrom(uint32_t creature, const void* gameString);   // 0x6BD0E0 (= SetSoundSet)
int         ChargenVoiceSync(uint32_t creature);   // creator preview gets the creature's voice: 1 changed, 0 same, -1 n/a
bool        ReadGameString(const void* gameString, wchar_t* out, int cap);
// Cutscene flags of a client creature (diagnostics): +0x23C (low byte: the cutscene's vtbl+0x134
// switch, 0x6A0EA0), +0x23D (high byte: cleared when a cutscene actor takes the creature, 0x7E30B0).
int         CutsceneFlags(uint32_t creature);
bool        SetHeadMorph(uint32_t creature, const wchar_t* resref); // appearance HeadMorph (+0x1C8)
bool        HeadMorph(uint32_t creature, wchar_t* out, int cap);
bool        AppHeadMorph(const void* appearance, wchar_t* out, int cap);   // an appearance object's HeadMorph
// Calls the model builder 'build' (0x6C1400 or its trampoline) with 'face' (.mor data) as the hero's face.
unsigned    BuildWithFace(void* build, void* obj, void* app, int a, int b, int force, const unsigned char* face, int faceLen, const wchar_t* morphName);
bool        DumpChargen(uint32_t realCreature); // log the creator/preview creatures (diagnostics)
void*       ClientCreature(uint32_t creature); // client object (for logs)

// Free movement, the way Player 1's stick/WASD moves the controlled character.
// (dx, dy) = world direction, (cx, cy) = camera forward; run = full speed.
bool        DirectMove(uint32_t creature, float dx, float dy, float cx, float cy, bool run);
bool        DirectStop(uint32_t creature);
int         DirectMoving(uint32_t creature);   // 1 moving freely, 0 not, -1 unknown
bool        SetPartyAI(uint32_t creature, bool on);
// Sends a game message the way the GUI does ("GameModeController.UserTogglePauseMessage").
bool        SendGameMessage(const char* text);

} // namespace game
