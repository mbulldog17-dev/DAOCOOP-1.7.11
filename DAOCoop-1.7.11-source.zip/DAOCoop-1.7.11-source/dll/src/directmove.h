#pragma once
// 1.2.43: let Player 2/3 use the game's own stick movement (the one Player 1 uses).
// The engine's direct-move executor (0x7A8C20, action 0x10) only steers a creature when it
// is the character the game is controlling (creature id == 0x606F10()), and quietly ends the
// move for everyone else. While that executor runs for a co-op character, the two
// "which character is controlled" checks it makes (0x7A8DAD and 0x7A3ADC in 0x7A3810) are
// answered with that character instead. Nothing else in the game sees a different answer.
void DirectMoveFixInstall(bool verbose);
