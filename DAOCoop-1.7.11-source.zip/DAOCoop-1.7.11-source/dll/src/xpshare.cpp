#include "xpshare.h"
#include "equiplock.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <windows.h>
#include <cmath>
#include <cwchar>

static XpShareSettings g_s;
static unsigned g_nextSync = 0;
static uint32_t g_autoLevelOff[4] = { 0, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF };
static volatile uint32_t g_lastCharGen = 0xFFFFFFFF;

static const int kPropLevel = 15;          // PROPERTY_SIMPLE_LEVEL
static const int kPropXp = 19;             // PROPERTY_SIMPLE_EXPERIENCE
static const int kTableXp = 164;           // the XP-per-level table RewardXP uses ("XP" column)

// ---------------------------------------------------------------------------
// Watch StartCharGen (command 746) through the command implementer's
// RunCommand vtable slot: before the handler runs, the VM stack holds its
// arguments with the first one (the creature) on top.
// ---------------------------------------------------------------------------
typedef int (__thiscall* RunCommand_t)(void* impl, int id, int argc);
static RunCommand_t g_origRun = nullptr;

static uint32_t PeekStackObject(int fromTop)
{
    char* vm = *reinterpret_cast<char**>(game::kVmPtr);
    if (!vm) return 0xFFFFFFFF;
    char* stack = vm + game::kVmStackOffset;
    int count = *reinterpret_cast<int*>(stack);
    int idx = count - 1 - fromTop;
    if (idx < 0) return 0xFFFFFFFF;
    int* tags = *reinterpret_cast<int**>(stack + 0xC);
    int* vals = *reinterpret_cast<int**>(stack + 0x10);
    if (!tags || !vals || tags[idx] != 6) return 0xFFFFFFFF;   // tag 6 = object
    return static_cast<uint32_t>(vals[idx]);
}

static int __fastcall HookRunCommand(void* impl, void*, int id, int argc)
{
    if (id == game::STARTCHARGEN) {
        uint32_t c = PeekStackObject(0);
        g_lastCharGen = c;
    }
    return g_origRun(impl, id, argc);
}

static void InstallRunCommandWatch()
{
    void** slot = reinterpret_cast<void**>(game::kImplVtableRunCommand);
    if (IsBadReadPtr(slot, 4) || *slot != reinterpret_cast<void*>(0x64DD60)) {
        Log("XP share: RunCommand vtable slot not as expected, level-up screen hand-off off");
        return;
    }
    DWORD old;
    if (!VirtualProtect(slot, 4, PAGE_READWRITE, &old)) return;
    g_origRun = reinterpret_cast<RunCommand_t>(*slot);
    *slot = reinterpret_cast<void*>(&HookRunCommand);
    VirtualProtect(slot, 4, old, &old);
    Log("XP share: watching StartCharGen (level-up / creator screens)");
}

uint32_t XpShareLastCharGenCreature() { return g_lastCharGen; }

void XpShareInit(const XpShareSettings& s)
{
    g_s = s;
    InstallRunCommandWatch();
    Log("XP share: %s%s", s.enabled ? "co-op characters follow the Warden's XP" : "off",
        s.enabled && s.trimAhead ? " (exactly)" : "");
}

// ---------------------------------------------------------------------------

static void SyncOne(int player, uint32_t c, int heroXp)
{
    if (c == 0xFFFFFFFF || !script::IsObjectValid(c) || script::IsDead(c)) return;

    if (g_autoLevelOff[player] != c) {
        script::SetAutoLevelUp(c, 0);              // the player spends their own points
        g_autoLevelOff[player] = c;
        Log("XP share: auto level-up off for Player %d's character 0x%08X", player, c);
    }

    int xp = (int)lroundf(script::GetCreatureProperty(c, kPropXp, 2));
    if (xp < 0) return;
    int diff = heroXp - xp;
    if (diff > 0) {
        // Behind: give the difference through the game's own RewardXP.
        wchar_t arg[32];
        swprintf(arg, 32, L"%d", diff);
        bool ok = script::RunScriptOn(c, L"addxp.ncs", arg);
        int after = (int)lroundf(script::GetCreatureProperty(c, kPropXp, 2));
        Log("XP share: Player %d +%d XP (%d -> %d, Warden %d) %s", player, diff, xp, after, heroXp,
            ok ? "" : "- addxp failed");
        if (ok && after > xp && diff >= 100) {
            wchar_t text[96];
            swprintf(text, 96, L"Player %d: +%d XP", player, after - xp);
            script::DisplayFloatyMessage(c, text, player == 3 ? 0x66DD66 : 0x4DA6FF, 2.0f);
        }
    } else if (diff < 0 && g_s.trimAhead) {
        // Ahead (killing blows earn 100%, the Warden got 95%): trim back to the
        // Warden, but never below the start of the current level.
        int level = (int)lroundf(script::GetCreatureProperty(c, kPropLevel, 2));
        int floor = level > 0 ? script::GetM2DAInt(kTableXp, L"XP", level) : 0;
        int target = heroXp > floor ? heroXp : floor;
        if (target < xp) {
            script::SetCreatureProperty(c, kPropXp, (float)target, 2);
            static int logged = 0;
            if (++logged <= 20) Log("XP share: Player %d trimmed %d -> %d (Warden %d, level %d starts at %d)",
                                    player, xp, target, heroXp, level, floor);
        }
    }
}

void XpShareTick(unsigned now, uint32_t hero, bool playable)
{
    if (!g_s.enabled || !playable || hero == 0xFFFFFFFF) return;
    if ((int)(now - g_nextSync) < 0) return;
    g_nextSync = now + 2000;

    int heroXp = (int)lroundf(script::GetCreatureProperty(hero, kPropXp, 2));
    if (heroXp <= 0) return;
    for (int p = 2; p <= 3; ++p) {
        uint32_t c = CoopCharacterOf(p);     // registered by coopcontrol / coopcreate
        if (c != 0xFFFFFFFF && c != hero) SyncOne(p, c, heroXp);
    }
}
