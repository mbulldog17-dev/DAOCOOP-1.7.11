#include "d3d9hook.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cstring>

static D3D9PresentCallback g_onPresent = nullptr;
static D3D9PresentCallback g_overlay[4] = {};
void D3D9SetOverlay(D3D9PresentCallback draw) { g_overlay[0] = draw; }
void D3D9AddOverlay(D3D9PresentCallback draw) { for (int i = 1; i < 4; ++i) if (!g_overlay[i]) { g_overlay[i] = draw; return; } }
static D3D9ResetCallback g_onReset = nullptr;
static D3D9ResetCallback g_onReset2 = nullptr;          // 1.7.0 views
static D3D9SwallowCallback g_swallow = nullptr;          // 1.7.0 views
void D3D9SetResetCallback2(D3D9ResetCallback cb) { g_onReset2 = cb; }
void D3D9SetSwallow(D3D9SwallowCallback cb) { g_swallow = cb; }

typedef IDirect3D9* (WINAPI* Create9_t)(UINT);
typedef HRESULT (STDMETHODCALLTYPE* CreateDevice_t)(IDirect3D9*, UINT, D3DDEVTYPE, HWND, DWORD, D3DPRESENT_PARAMETERS*, IDirect3DDevice9**);
typedef HRESULT (STDMETHODCALLTYPE* Present_t)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
typedef HRESULT (STDMETHODCALLTYPE* Reset_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);

static Create9_t g_create9 = nullptr;
static CreateDevice_t g_createDevice = nullptr;
static Present_t g_present = nullptr;
static Reset_t g_reset = nullptr;
static bool g_loggedPresent = false;
static volatile int g_bbW = 0, g_bbH = 0;
static HWND g_wnd = nullptr;
static void NoteSize(const D3DPRESENT_PARAMETERS* pp, HWND w)
{
    if (w) g_wnd = w;
    if (pp && pp->hDeviceWindow) g_wnd = pp->hDeviceWindow;
    g_bbW = pp ? (int)pp->BackBufferWidth : 0; g_bbH = pp ? (int)pp->BackBufferHeight : 0;
}
HWND D3D9GameWindow() { return g_wnd; }

// 1.7.5: frame pacing by the screen. The mod holds the game to 30 frames a second; a timer did that, but it isn't in
// step with the screen's refreshes, so with vsync at 60 Hz most frames stayed up 2 refreshes and some 1 or 3 - an
// uneven picture though every frame was right. In fullscreen, when the refresh rate is a whole multiple of 30, the
// device shows each frame for exactly refresh / 30 refreshes (2 at 60 Hz, 4 at 120 Hz) with one back buffer, and the
// screen paces the game. [Views] ScreenPacing=0 keeps the timer.
static bool g_pacingOn = true;
static int g_pacingFps = 30;
static volatile LONG g_pacedInterval = 0;      // refreshes per frame now (0: not paced by the screen)
void D3D9SetPacing(bool on, int fps) { g_pacingOn = on; g_pacingFps = fps > 0 ? fps : 30; }
int D3D9PacedInterval() { return (int)g_pacedInterval; }
static bool ApplyPacing(IDirect3D9* d3d, UINT adapter, D3DDEVTYPE type, D3DPRESENT_PARAMETERS* pp)
{
    if (!g_pacingOn || !pp || !d3d) return false;
    if (pp->Windowed) { Log("Frame pacing: windowed - the timer paces the game (screen pacing needs fullscreen)"); return false; }
    UINT hz = pp->FullScreen_RefreshRateInHz;
    if (!hz) { D3DDISPLAYMODE m; if (SUCCEEDED(d3d->GetAdapterDisplayMode(adapter, &m))) hz = m.RefreshRate; }
    if (!hz || hz % (UINT)g_pacingFps != 0 || hz / (UINT)g_pacingFps > 4) {
        Log("Frame pacing: %u Hz is not a whole multiple of %d - the timer paces the game (60 or 120 Hz would be even)", hz, g_pacingFps);
        return false;
    }
    const UINT n = hz / (UINT)g_pacingFps;
    const DWORD flag = n == 1 ? D3DPRESENT_INTERVAL_ONE : n == 2 ? D3DPRESENT_INTERVAL_TWO : n == 3 ? D3DPRESENT_INTERVAL_THREE : D3DPRESENT_INTERVAL_FOUR;
    D3DCAPS9 caps;
    if (FAILED(d3d->GetDeviceCaps(adapter, type, &caps)) || !(caps.PresentationIntervals & flag)) {
        Log("Frame pacing: the graphics driver can't show a frame for %u refreshes - the timer paces the game", n);
        return false;
    }
    pp->PresentationInterval = flag;
    if (pp->BackBufferCount > 1) pp->BackBufferCount = 1;   // (no frames waiting in a queue: each shows when it is due)
    Log("Frame pacing: by the screen - %u Hz, each frame shown for %u refreshes (%d a second, even)", hz, n, g_pacingFps);
    return true;
}
bool D3D9BackBufferSize(int* w, int* h)
{
    int a = g_bbW, b = g_bbH;
    if ((a <= 0 || b <= 0) && g_wnd) { RECT r; if (GetClientRect(g_wnd, &r)) { a = r.right - r.left; b = r.bottom - r.top; } }
    if (a <= 0 || b <= 0) return false;
    *w = a; *h = b; return true;
}

static bool PatchSlot(void** slot, void* fn, void** original)
{
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) return false;
    if (original) *original = *slot;
    *slot = fn;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

// Everything drawn on / taken from a finished frame. The game finishes frames in two ways: the device's
// Present (in the world) and its swap chain's Present (1.4.8: the menus, character creation, movies and
// cutscenes - before this, those frames were never streamed to online friends nor shown on their screen).
// 1.5.1: where the drawing thread is, for the watchdog (a frozen game then says in the log where it hangs).
static volatile const char* g_stage = nullptr;
static volatile DWORD g_stageAt = 0, g_stageThread = 0;
static volatile LONG g_watchOn = 0;
const char* D3D9CurrentStage() { return const_cast<const char*>(g_stage); }
void D3D9Stage(const char* what)
{
    g_stageAt = GetTickCount();
    g_stageThread = GetCurrentThreadId();
    g_stage = what;
}
static DWORD WINAPI Watchdog(LPVOID)
{
    const char* reported = nullptr;
    DWORD reportedAt = 0;
    for (;;) {
        Sleep(1000);
        const char* st = const_cast<const char*>(g_stage);
        const DWORD at = g_stageAt;
        if (st && GetTickCount() - at > 3000 && (st != reported || at != reportedAt)) {
            reported = st; reportedAt = at;
            Log("Direct3D 9: WATCHDOG - the drawing thread (%lu) has been stuck for %lu s in: %s",
                (unsigned long)g_stageThread, (unsigned long)((GetTickCount() - at) / 1000), st);
        }
    }
}

static volatile LONG g_inFrame = 0;
static D3D9PresentCallback g_preOverlay = nullptr;     // 1.7.0 views: before every overlay
void D3D9SetPreOverlay(D3D9PresentCallback cb) { g_preOverlay = cb; }

static void OnFrame(IDirect3DDevice9* dev)
{
    if (InterlockedExchange(&g_watchOn, 1) == 0) { HANDLE t = CreateThread(nullptr, 0, Watchdog, nullptr, 0, nullptr); if (t) CloseHandle(t); }
    // two threads finishing frames at once (a loading screen thread?): the second one leaves it alone
    if (InterlockedCompareExchange(&g_inFrame, 1, 0) != 0) {
        static bool noted = false;
        if (!noted) { noted = true; Log("Direct3D 9: frames finished by two threads at once (thread %lu) - this one skipped", (unsigned long)GetCurrentThreadId()); }
        return;
    }
    static DWORD lastThread = 0;
    const DWORD me = GetCurrentThreadId();
    if (me != lastThread) { Log("Direct3D 9: frames now finished by thread %lu%s", (unsigned long)me, D3D9InSwapChainPresent() ? " (swap chain)" : ""); lastThread = me; }
    if (g_preOverlay) { D3D9Stage("views: Player 1's picture back"); g_preOverlay(dev); }
    static const char* kOv[4] = { "overlay: player rings", "overlay 1 (join pop-up)", "overlay 2", "overlay 3" };
    for (int i = 0; i < 4; ++i) {         // drawn first, so online friends see it too
        if (!g_overlay[i]) continue;
        D3D9Stage(kOv[i]);
#ifdef _MSC_VER
        __try { g_overlay[i](dev); } __except (EXCEPTION_EXECUTE_HANDLER) { Log("Direct3D 9: crash in overlay %d - caught, that overlay off", i); g_overlay[i] = nullptr; }
#else
        g_overlay[i](dev);
#endif
    }
    D3D9Stage("online picture");
    if (g_onPresent) {
#ifdef _MSC_VER
        __try { g_onPresent(dev); } __except (EXCEPTION_EXECUTE_HANDLER) { Log("Direct3D 9: crash in the online picture code - caught"); }
#else
        g_onPresent(dev);
#endif
    }
    D3D9Stage(nullptr);
    InterlockedExchange(&g_inFrame, 0);
}

static volatile bool g_inDevicePresent = false;   // (render thread only)
static void (*g_postPresent)() = nullptr;          // 1.7.8: right after the frame went to the screen
void D3D9SetPostPresent(void (*cb)()) { g_postPresent = cb; }
static long long g_presentTicks = 0; static int g_presentCount = 0;   // 1.7.0 performance: time spent in Present
static long long g_presentWait = 0;    // 1.7.5: the same, for the auto quality (screen pacing waits in Present)
long long D3D9TakePresentWait() { const long long t = g_presentWait; g_presentWait = 0; return t; }
void D3D9TakePresentStats(long long* ticks, int* count) { *ticks = g_presentTicks; *count = g_presentCount; g_presentTicks = 0; g_presentCount = 0; }
static HRESULT STDMETHODCALLTYPE HookPresent(IDirect3DDevice9* dev, const RECT* s, const RECT* d, HWND w, const RGNDATA* r)
{
    if (g_swallow && g_swallow(dev)) return D3D_OK;    // 1.7.0: a frame drawn only to be kept (another player's view)
    if (!g_loggedPresent) { g_loggedPresent = true; Log("Direct3D 9: first Present seen (online picture hook working)"); }
    OnFrame(dev);
    g_inDevicePresent = true;              // (if the device's Present goes through the swap chain's: once)
    D3D9Stage("the game's own Present (device)");
    LARGE_INTEGER a, b; QueryPerformanceCounter(&a);
    HRESULT hr = g_present(dev, s, d, w, r);
    QueryPerformanceCounter(&b);
    g_presentTicks += b.QuadPart - a.QuadPart; ++g_presentCount;
    g_presentWait += b.QuadPart - a.QuadPart;
    D3D9Stage(nullptr);
    g_inDevicePresent = false;
    if (g_postPresent) { D3D9Stage("after Present"); g_postPresent(); D3D9Stage(nullptr); }
    return hr;
}

typedef HRESULT (STDMETHODCALLTYPE* ChainPresent_t)(IDirect3DSwapChain9*, const RECT*, const RECT*, HWND, const RGNDATA*, DWORD);
static ChainPresent_t g_chainPresent = nullptr;
static bool g_loggedChain = false;
static volatile bool g_inChain = false;
bool D3D9InSwapChainPresent() { return g_inChain; }
static HRESULT STDMETHODCALLTYPE HookChainPresent(IDirect3DSwapChain9* sc, const RECT* s, const RECT* d, HWND w, const RGNDATA* r, DWORD flags)
{
    if (!g_loggedChain) { g_loggedChain = true; Log("Direct3D 9: first swap chain Present seen (menus / movies streamed too)"); }
    IDirect3DDevice9* dev = nullptr;
    if (!g_inDevicePresent && g_swallow && SUCCEEDED(sc->GetDevice(&dev)) && dev) {
        bool kept = g_swallow(dev);
        dev->Release(); dev = nullptr;
        if (kept) return D3D_OK;
    }
    if (!g_inDevicePresent && SUCCEEDED(sc->GetDevice(&dev)) && dev) { g_inChain = true; OnFrame(dev); g_inChain = false; dev->Release(); }
    if (!g_inDevicePresent) D3D9Stage("the game's own Present (swap chain)");
    LARGE_INTEGER a, b; QueryPerformanceCounter(&a);
    HRESULT hr = g_chainPresent(sc, s, d, w, r, flags);
    QueryPerformanceCounter(&b);
    if (!g_inDevicePresent) { g_presentTicks += b.QuadPart - a.QuadPart; ++g_presentCount; g_presentWait += b.QuadPart - a.QuadPart; }
    if (!g_inDevicePresent) D3D9Stage(nullptr);
    if (!g_inDevicePresent && g_postPresent) { D3D9Stage("after Present"); g_postPresent(); D3D9Stage(nullptr); }
    return hr;
}

static void HookSwapChain(IDirect3DDevice9* dev)
{
    if (g_chainPresent || !dev) return;
    IDirect3DSwapChain9* sc = nullptr;
    if (FAILED(dev->GetSwapChain(0, &sc)) || !sc) { Log("Direct3D 9: no swap chain to hook"); return; }
    void** vt = *reinterpret_cast<void***>(sc);
    bool ok = PatchSlot(&vt[3], reinterpret_cast<void*>(&HookChainPresent), reinterpret_cast<void**>(&g_chainPresent));
    sc->Release();
    Log("Direct3D 9: swap chain Present hook %s", ok ? "on" : "FAILED");
}

static IDirect3DStateBlock9* g_saved[8] = {};
static IDirect3DDevice9* g_savedDev = nullptr;
static void ReleaseSaved()
{
    for (auto& sb : g_saved) if (sb) { sb->Release(); sb = nullptr; }
    g_savedDev = nullptr;
}
IDirect3DStateBlock9* D3D9SaveState(IDirect3DDevice9* dev, int slot)
{
    if (!dev || slot < 0 || slot >= 8) return nullptr;
    if (g_savedDev != dev) { ReleaseSaved(); g_savedDev = dev; }
    IDirect3DStateBlock9*& sb = g_saved[slot];
    if (sb) { if (SUCCEEDED(sb->Capture())) return sb; sb->Release(); sb = nullptr; }
    if (FAILED(dev->CreateStateBlock(D3DSBT_ALL, &sb))) sb = nullptr;   // (a new block holds the state as it is now)
    return sb;
}

static HRESULT STDMETHODCALLTYPE HookReset(IDirect3DDevice9* dev, D3DPRESENT_PARAMETERS* pp)
{
    ReleaseSaved();
    if (g_onReset) g_onReset(dev);
    if (g_onReset2) g_onReset2(dev);
    // 1.7.5: the frame pacing again for the new settings (fullscreen / refresh rate may have changed)
    D3DPRESENT_PARAMETERS keep = pp ? *pp : D3DPRESENT_PARAMETERS{};
    bool paced = false;
    {
        IDirect3D9* d3d = nullptr; D3DDEVICE_CREATION_PARAMETERS cp = {};
        if (pp && SUCCEEDED(dev->GetDirect3D(&d3d)) && d3d) {
            if (SUCCEEDED(dev->GetCreationParameters(&cp))) paced = ApplyPacing(d3d, cp.AdapterOrdinal, cp.DeviceType, pp);
            d3d->Release();
        }
    }
    HRESULT hr = g_reset(dev, pp);
    if (FAILED(hr) && paced) { *pp = keep; paced = false; hr = g_reset(dev, pp); Log("Frame pacing: the reset refused it - the timer paces the game"); }
    InterlockedExchange(&g_pacedInterval, SUCCEEDED(hr) && paced ? (LONG)(pp->PresentationInterval == D3DPRESENT_INTERVAL_TWO ? 2 : pp->PresentationInterval == D3DPRESENT_INTERVAL_THREE ? 3 : pp->PresentationInterval == D3DPRESENT_INTERVAL_FOUR ? 4 : 1) : 0);
    if (SUCCEEDED(hr)) NoteSize(pp, nullptr);
    return hr;
}

// 1.7.0 views: the viewport and scissor rectangles, changed on the way in while a filter is set
// (split screen: Player 1's GUI fitted into Player 1's box).
typedef HRESULT (STDMETHODCALLTYPE* SetViewport_t)(IDirect3DDevice9*, const D3DVIEWPORT9*);
typedef HRESULT (STDMETHODCALLTYPE* SetScissor_t)(IDirect3DDevice9*, const RECT*);
static SetViewport_t g_setViewport = nullptr;
static SetScissor_t g_setScissor = nullptr;
static D3D9RectFilter volatile g_rectFilter = nullptr;
void D3D9SetRectFilter(D3D9RectFilter f) { g_rectFilter = f; }
static HRESULT STDMETHODCALLTYPE HookSetViewport(IDirect3DDevice9* dev, const D3DVIEWPORT9* vp)
{
    D3D9RectFilter f = g_rectFilter;
    if (f && vp) {
        D3DVIEWPORT9 v = *vp;
        long r[4] = { (long)v.X, (long)v.Y, (long)(v.X + v.Width), (long)(v.Y + v.Height) };
        if (f(r)) { v.X = (DWORD)r[0]; v.Y = (DWORD)r[1]; v.Width = (DWORD)(r[2] - r[0]); v.Height = (DWORD)(r[3] - r[1]); return g_setViewport(dev, &v); }
    }
    return g_setViewport(dev, vp);
}
static HRESULT STDMETHODCALLTYPE HookSetScissor(IDirect3DDevice9* dev, const RECT* rc)
{
    D3D9RectFilter f = g_rectFilter;
    if (f && rc) {
        long r[4] = { rc->left, rc->top, rc->right, rc->bottom };
        if (f(r)) { RECT q = { r[0], r[1], r[2], r[3] }; return g_setScissor(dev, &q); }
    }
    return g_setScissor(dev, rc);
}

static HRESULT STDMETHODCALLTYPE HookCreateDevice(IDirect3D9* d3d, UINT a, D3DDEVTYPE t, HWND w, DWORD f, D3DPRESENT_PARAMETERS* pp, IDirect3DDevice9** out)
{
    D3DPRESENT_PARAMETERS keep = pp ? *pp : D3DPRESENT_PARAMETERS{};
    bool paced = ApplyPacing(d3d, a, t, pp);                // 1.7.5
    HRESULT hr = g_createDevice(d3d, a, t, w, f, pp, out);
    if (FAILED(hr) && paced) { *pp = keep; paced = false; hr = g_createDevice(d3d, a, t, w, f, pp, out); Log("Frame pacing: the device refused it - the timer paces the game"); }
    InterlockedExchange(&g_pacedInterval, SUCCEEDED(hr) && paced ? (LONG)(pp->PresentationInterval == D3DPRESENT_INTERVAL_TWO ? 2 : pp->PresentationInterval == D3DPRESENT_INTERVAL_THREE ? 3 : pp->PresentationInterval == D3DPRESENT_INTERVAL_FOUR ? 4 : 1) : 0);
    if (SUCCEEDED(hr)) NoteSize(pp, w);
    if (SUCCEEDED(hr) && out && *out && !g_present) {
        void** vt = *reinterpret_cast<void***>(*out);
        bool ok = PatchSlot(&vt[17], reinterpret_cast<void*>(&HookPresent), reinterpret_cast<void**>(&g_present)) &&
                  PatchSlot(&vt[16], reinterpret_cast<void*>(&HookReset), reinterpret_cast<void**>(&g_reset));
        PatchSlot(&vt[47], reinterpret_cast<void*>(&HookSetViewport), reinterpret_cast<void**>(&g_setViewport));   // 1.7.0 views
        PatchSlot(&vt[75], reinterpret_cast<void*>(&HookSetScissor), reinterpret_cast<void**>(&g_setScissor));
        Log("Direct3D 9: device made (%ux%u, flags 0x%lX%s, thread %lu) - Present/Reset hooks %s", pp ? pp->BackBufferWidth : 0, pp ? pp->BackBufferHeight : 0,
            (unsigned long)f, (f & D3DCREATE_MULTITHREADED) ? " multithreaded" : "", (unsigned long)GetCurrentThreadId(), ok ? "on" : "FAILED");
        HookSwapChain(*out);
    }
    return hr;
}

static IDirect3D9* WINAPI HookCreate9(UINT sdk)
{
    IDirect3D9* d3d = g_create9(sdk);
    if (d3d && !g_createDevice) {
        void** vt = *reinterpret_cast<void***>(d3d);
        PatchSlot(&vt[16], reinterpret_cast<void*>(&HookCreateDevice), reinterpret_cast<void**>(&g_createDevice));
    }
    return d3d;
}

static void** FindImport(HMODULE module, const char* dllName, const char* func)
{
    BYTE* base = reinterpret_cast<BYTE*>(module);
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const IMAGE_DATA_DIRECTORY& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress) return nullptr;
    for (auto* imp = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + dir.VirtualAddress); imp->Name; ++imp) {
        if (_stricmp(reinterpret_cast<char*>(base + imp->Name), dllName) != 0) continue;
        auto* names = reinterpret_cast<IMAGE_THUNK_DATA*>(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
        auto* slots = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imp->FirstThunk);
        for (; names->u1.AddressOfData; ++names, ++slots) {
            if (IMAGE_SNAP_BY_ORDINAL(names->u1.Ordinal)) continue;
            auto* byName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + names->u1.AddressOfData);
            if (strcmp(reinterpret_cast<char*>(byName->Name), func) == 0)
                return reinterpret_cast<void**>(&slots->u1.Function);
        }
    }
    return nullptr;
}

bool D3D9HookInstall(D3D9PresentCallback present, D3D9ResetCallback reset)
{
    g_onPresent = present;
    g_onReset = reset;
    void** slot = FindImport(GetModuleHandleW(nullptr), "d3d9.dll", "Direct3DCreate9");
    if (!slot) { Log("Direct3D 9: Direct3DCreate9 not in the game's imports - online picture off"); return false; }
    bool ok = PatchSlot(slot, reinterpret_cast<void*>(&HookCreate9), reinterpret_cast<void**>(&g_create9));
    Log("Direct3D 9: Direct3DCreate9 hook %s", ok ? "installed" : "FAILED");
    return ok;
}
