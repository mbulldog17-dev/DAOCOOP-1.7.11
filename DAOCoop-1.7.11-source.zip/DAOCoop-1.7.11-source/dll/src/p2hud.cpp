// 1.7.0: Player 2's and Player 3's own HUDs (p2hud.h).
#include "p2hud.h"
#include "log.h"
#include "iconatlas.h"
#include "d3d9hook.h"
#include <windows.h>
#include <d3d9.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cwchar>
#pragma comment(lib, "gdi32.lib")

namespace
{
    CRITICAL_SECTION g_cs;
    bool g_csInit = false;

    struct Panel
    {
        IDirect3DTexture9* tex = nullptr;
        IDirect3DDevice9* dev = nullptr;
        int texW = 0, texH = 0, w = 0, h = 0;
        unsigned rev = 0;
        int forH = 0;                 // the picture height it was rendered for (1.7.0: half size in a split-screen band)
    };
    struct Hud                       // one per joining player (index 0: Player 2, 1: Player 3)
    {
        P2HudData data;
        unsigned rev = 1;
        Panel left, right, over, prompt;
        unsigned leftKey = 0, rightKey = 0, promptKey = 0;
        unsigned revL = 1, revR = 1, revP = 1;   // 1.7.1: each panel redrawn only when what it shows changed
        bool hasIcon[3] = {};        // (render thread) the slot's icon was found in the atlas
    };
    Hud g_hud[2];
    int Index(int player) { return player == 3 ? 1 : 0; }

    const COLORREF kKey = RGB(255, 0, 255);   // see-through
    // 1.7.3: the co-op menu's look (modmenu.cpp) - Dragon Age's own: warm near-black plates, a gold frame with
    // diamond corners, Palatino lettering, cream text
    const COLORREF kPanel = RGB(18, 15, 12), kPanelTop = RGB(30, 24, 18), kPanelBottom = RGB(11, 9, 7);
    const COLORREF kGold = RGB(201, 165, 90), kGoldDark = RGB(98, 74, 40), kGoldBright = RGB(240, 214, 140);
    const COLORREF kWhite = RGB(232, 220, 192), kGrey = RGB(146, 130, 106), kDark = RGB(30, 25, 20);
    COLORREF PlayerColour(int player) { return player == 3 ? RGB(102, 221, 102) : RGB(77, 166, 255); }   // as the rings

    void Lock() { if (!g_csInit) { InitializeCriticalSection(&g_cs); g_csInit = true; } EnterCriticalSection(&g_cs); }
    void Unlock() { LeaveCriticalSection(&g_cs); }

    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }
    // the first of these the PC has (Palatino Linotype comes with Windows)
    HFONT FontFace(int px, bool bold, bool italic, bool heading)
    {
        static const wchar_t* kHead[] = { L"Trajan Pro", L"Cinzel", L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static const wchar_t* kBody[] = { L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static int found[2] = { -1, -1 };
        const wchar_t* const* list = heading ? kHead : kBody;
        const int n = heading ? 5 : 3;
        int& pick = found[heading ? 0 : 1];
        if (pick < 0) {
            pick = n - 1;
            HDC dc = CreateCompatibleDC(nullptr);
            for (int i = 0; i < n; ++i) {
                HFONT f = CreateFontW(-20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                                      CLEARTYPE_QUALITY, DEFAULT_PITCH, list[i]);
                HGDIOBJ old = SelectObject(dc, f);
                wchar_t face[64] = {};
                GetTextFaceW(dc, 64, face);
                SelectObject(dc, old);
                DeleteObject(f);
                if (_wcsicmp(face, list[i]) == 0) { pick = i; break; }
            }
            DeleteDC(dc);
        }
        // (no ClearType: its coloured edges would show against the see-through key colour)
        return CreateFontW(-px, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, italic, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
                           CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, list[pick]);
    }
    HFONT Font(int px, bool bold) { return FontFace(px, bold, false, false); }
    void Fill(HDC dc, RECT r, COLORREF c) { HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b); }
    void Frame(HDC dc, RECT r, COLORREF c, int t)
    {
        HBRUSH b = CreateSolidBrush(c);
        for (int i = 0; i < t; ++i) { RECT q = { r.left + i, r.top + i, r.right - i, r.bottom - i }; FrameRect(dc, &q, b); }
        DeleteObject(b);
    }
    void Text(HDC dc, HFONT f, COLORREF c, const wchar_t* s, RECT r, UINT fmt)
    {
        HGDIOBJ old = SelectObject(dc, f);
        SetTextColor(dc, c);
        DrawTextW(dc, s, -1, &r, fmt | DT_NOPREFIX);
        SelectObject(dc, old);
    }
    void TextSpaced(HDC dc, HFONT f, COLORREF c, const wchar_t* s, RECT r, UINT fmt, int spacing)
    {
        SetTextCharacterExtra(dc, spacing);
        Text(dc, f, c, s, r, fmt);
        SetTextCharacterExtra(dc, 0);
    }
    void Circle(HDC dc, int cx, int cy, int r, COLORREF fill, COLORREF edge)
    {
        HBRUSH b = CreateSolidBrush(fill);
        HPEN p = CreatePen(PS_SOLID, 1, edge);
        HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, p);
        Ellipse(dc, cx - r, cy - r, cx + r, cy + r);
        SelectObject(dc, ob); SelectObject(dc, op);
        DeleteObject(b); DeleteObject(p);
    }
    void Diamond(HDC dc, int cx, int cy, int r, COLORREF c)
    {
        POINT p[4] = { { cx, cy - r }, { cx + r, cy }, { cx, cy + r }, { cx - r, cy } };
        HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
        HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
        Polygon(dc, p, 4);
        SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
    }
    COLORREF Mix(COLORREF a, COLORREF b, float t)
    {
        return RGB((int)(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t), (int)(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t),
                   (int)(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t));
    }
    // one GdiGradientFill call (only when a panel is redrawn - what it shows changed)
    void GradientDir(HDC dc, RECT r, COLORREF a, COLORREF b, bool vertical)
    {
        if (r.right <= r.left || r.bottom <= r.top) return;
        TRIVERTEX v[2] = {
            { r.left, r.top, (COLOR16)(GetRValue(a) << 8), (COLOR16)(GetGValue(a) << 8), (COLOR16)(GetBValue(a) << 8), 0 },
            { r.right, r.bottom, (COLOR16)(GetRValue(b) << 8), (COLOR16)(GetGValue(b) << 8), (COLOR16)(GetBValue(b) << 8), 0 },
        };
        GRADIENT_RECT g = { 0, 1 };
        GdiGradientFill(dc, v, 2, &g, 1, vertical ? GRADIENT_FILL_RECT_V : GRADIENT_FILL_RECT_H);
    }
    void Gradient(HDC dc, RECT r, COLORREF top, COLORREF bottom) { GradientDir(dc, r, top, bottom, true); }
    // a plate in the co-op menu's style: dark gradient, dark - gold - dark frame, gold diamonds in the corners
    void Plate(HDC dc, RECT r, float s, bool corners = true)
    {
        auto S = [&](float v) { int x = (int)(v * s + 0.5f); return x < 1 ? 1 : x; };
        const int c = corners ? S(6) : 0;          // the diamonds stick out of the frame a little: plate inset by that
        RECT p = { r.left + c, r.top + c, r.right - c, r.bottom - c };
        Gradient(dc, p, kPanelTop, kPanelBottom);
        Frame(dc, p, kGoldDark, 1);
        Frame(dc, RECT{ p.left + S(3), p.top + S(3), p.right - S(3), p.bottom - S(3) }, kGold, S(1.5f));
        Frame(dc, RECT{ p.left + S(6), p.top + S(6), p.right - S(6), p.bottom - S(6) }, kGoldDark, 1);
        if (corners) {
            const int d = S(6);
            const int xs[2] = { p.left + S(4), p.right - S(4) }, ys[2] = { p.top + S(4), p.bottom - S(4) };
            for (int i = 0; i < 2; ++i) for (int j = 0; j < 2; ++j) { Diamond(dc, xs[i], ys[j], d, kGold); Diamond(dc, xs[i], ys[j], d / 2, kPanelBottom); }
        }
    }

    // GDI into a DIB, then into the panel's texture (key colour -> transparent).
    template <class F>
    bool Render(IDirect3DDevice9* dev, Panel& p, int w, int h, F draw)
    {
        const int tw = Pow2(w), th = Pow2(h);
        if (p.dev != dev) { p.tex = nullptr; p.dev = dev; }       // (old device's texture not released: may be gone)
        if (!p.tex || p.texW != tw || p.texH != th) {
            if (p.tex) { p.tex->Release(); p.tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &p.tex, nullptr)) || !p.tex) {
                p.tex = nullptr;
                return false;
            }
            p.texW = tw; p.texH = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
        bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h;
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HDC dc = CreateCompatibleDC(nullptr);
        HBITMAP bmp = dc ? CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0) : nullptr;
        if (!dc || !bmp || !bits) { if (bmp) DeleteObject(bmp); if (dc) DeleteDC(dc); return false; }
        HGDIOBJ oldBmp = SelectObject(dc, bmp);
        SetBkMode(dc, TRANSPARENT);
        Fill(dc, RECT{ 0, 0, w, h }, kKey);
        draw(dc);
        GdiFlush();
        bool ok = false;
        D3DLOCKED_RECT lr;
        if (SUCCEEDED(p.tex->LockRect(0, &lr, nullptr, 0))) {
            const uint32_t key = 0x00FF00FFu;
            for (int y = 0; y < th; ++y) {
                uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch);
                if (y >= h) { std::memset(dst, 0, tw * 4); continue; }
                const uint32_t* src = static_cast<const uint32_t*>(bits) + y * w;
                for (int x = 0; x < w; ++x) {
                    uint32_t c = src[x] & 0x00FFFFFFu;
                    dst[x] = c == key ? 0u : (c | 0xF0000000u);
                }
                if (tw > w) std::memset(dst + w, 0, (tw - w) * 4);
            }
            p.tex->UnlockRect(0);
            ok = true;
        }
        SelectObject(dc, oldBmp);
        DeleteObject(bmp);
        DeleteDC(dc);
        if (ok) { p.w = w; p.h = h; }
        return ok;
    }

    // a game-style bar: dark inset, a gradient fill with a light top edge, a thin gold-dark rim
    void Bar(HDC dc, RECT r, float f, COLORREF full, COLORREF empty)
    {
        Fill(dc, RECT{ r.left - 2, r.top - 2, r.right + 2, r.bottom + 2 }, kGoldDark);
        Fill(dc, RECT{ r.left - 1, r.top - 1, r.right + 1, r.bottom + 1 }, RGB(6, 5, 4));
        Gradient(dc, r, Mix(empty, RGB(0, 0, 0), 0.3f), empty);
        if (f > 0.f) {
            RECT q = r; q.right = r.left + (int)((r.right - r.left) * (f > 1.f ? 1.f : f) + 0.5f);
            // light at the top, the full colour a third down, darker at the bottom (like the game's bars)
            const int mid = q.top + (q.bottom - q.top) / 3;
            Gradient(dc, RECT{ q.left, q.top, q.right, mid }, Mix(full, RGB(255, 240, 220), 0.45f), full);
            Gradient(dc, RECT{ q.left, mid, q.right, q.bottom }, full, Mix(full, RGB(0, 0, 0), 0.45f));
            if (q.right - q.left > 2) Fill(dc, RECT{ q.right - 1, q.top, q.right, q.bottom }, Mix(full, RGB(255, 255, 255), 0.5f));   // the bright end
        }
    }

    // bottom left: the player's name, health and stamina / mana
    const int kLeftW = 440, kLeftH = 124;
    void DrawLeft(HDC dc, const P2HudData& d, float s, int player)
    {
        const COLORREF kP2 = PlayerColour(player);
        auto S = [&](float v) { return (int)(v * s + 0.5f); };
        const int w = S(kLeftW), h = S(kLeftH);
        Plate(dc, RECT{ 0, 0, w, h }, s);
        HFONT fName = FontFace(S(25), true, false, false), fTag = FontFace(S(13), true, false, true);
        wchar_t title[96], tag[16];
        swprintf(tag, 16, L"PLAYER %d", player);
        if (d.name[0]) swprintf(title, 96, L"%ls", d.name); else swprintf(title, 96, L"Player %d", player);
        // the player's colour: a gem beside the name, and the tag
        Diamond(dc, S(34), S(38), S(9), kGold);
        Diamond(dc, S(34), S(38), S(7), kP2);
        Diamond(dc, S(32), S(35), S(2), Mix(kP2, RGB(255, 255, 255), 0.6f));
        Text(dc, fName, kGoldBright, title, RECT{ S(52), S(20), w - S(160), S(56) }, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        TextSpaced(dc, fTag, kP2, tag, RECT{ w - S(176), S(20), w - S(34), S(56) }, DT_RIGHT | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP, S(2));
        Fill(dc, RECT{ S(24), S(58), w - S(24), S(59) }, kGoldDark);
        if (d.hp >= 0.f) Bar(dc, RECT{ S(28), S(68), w - S(28), S(84) }, d.hp, RGB(196, 34, 28), RGB(52, 12, 10));
        if (d.mp >= 0.f) Bar(dc, RECT{ S(28), S(93), w - S(28), S(103) }, d.mp,
                             d.mage ? RGB(48, 104, 228) : RGB(60, 168, 52), d.mage ? RGB(10, 20, 54) : RGB(12, 40, 12));
        DeleteObject(fName); DeleteObject(fTag);
    }

    // bottom right: the three ability slots of Player 2's page, placed like the X / Y / B buttons
    const int kRightW = 380, kRightH = 330, kBox = 104;
    RECT SlotRect(int i, float s)
    {
        auto S = [&](float v) { return (int)(v * s + 0.5f); };
        const int w = S(kRightW), box = S(kBox);
        const int cx[3] = { w / 2 - S(112), w / 2, w / 2 + S(112) };
        const int cy[3] = { S(36) + box + S(18), S(36) + box / 2, S(36) + box + S(18) };
        return RECT{ cx[i] - box / 2, cy[i] - box / 2, cx[i] + box / 2, cy[i] + box / 2 };
    }
    // a controller button in its colour, with a gold-dark ring and a little shine (as on the co-op menu's hints)
    void Badge(HDC dc, HFONT f, int cx, int cy, int r, const wchar_t* label, COLORREF col, COLORREF ink)
    {
        Circle(dc, cx, cy, r + 1, kGoldDark, kGoldDark);
        Circle(dc, cx, cy, r, col, Mix(col, RGB(0, 0, 0), 0.5f));
        Circle(dc, cx - r / 3, cy - r / 3, r / 4 > 1 ? r / 4 : 1, Mix(col, RGB(255, 255, 255), 0.45f), Mix(col, RGB(255, 255, 255), 0.45f));
        Text(dc, f, ink, label, RECT{ cx - r, cy - r, cx + r, cy + r }, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
    // layer 0: slots, frames, the page tag (under the icons); layer 1: cooldown seconds and buttons (over the icons)
    void DrawRight(HDC dc, const P2HudData& d, float s, int layer, const bool hasIcon[3])
    {
        auto S = [&](float v) { return (int)(v * s + 0.5f); };
        const int w = S(kRightW), h = S(kRightH);
        HFONT fName = FontFace(S(15), true, false, false), fBtn = FontFace(S(19), true, false, false), fCd = FontFace(S(36), true, false, false),
              fPage = FontFace(S(17), true, false, true), fHint = FontFace(S(16), false, true, false);
        const wchar_t* btn[3] = { L"X", L"Y", L"B" };
        const COLORREF col[3] = { RGB(46, 102, 190), RGB(214, 164, 30), RGB(184, 50, 40) };
        const COLORREF ink[3] = { RGB(250, 250, 250), RGB(36, 26, 8), RGB(250, 250, 250) };
        if (layer == 0) {
            const wchar_t* page = d.page == 1 ? L"RT" : d.page == 2 ? L"LT" : L"";
            if (page[0]) {
                // a small gold plaque with diamonds on its ends
                RECT pr = { w / 2 - S(34), S(2), w / 2 + S(34), S(30) };
                Gradient(dc, pr, kGoldBright, kGold);
                Frame(dc, pr, kGoldDark, 1);
                Diamond(dc, pr.left - S(8), (pr.top + pr.bottom) / 2, S(5), kGold);
                Diamond(dc, pr.right + S(8), (pr.top + pr.bottom) / 2, S(5), kGold);
                TextSpaced(dc, fPage, RGB(36, 26, 10), page, pr, DT_CENTER | DT_VCENTER | DT_SINGLELINE, S(2));
            }
            // on a dark band of its own (text straight on the see-through colour gets pink edges)
            {
                HGDIOBJ o = SelectObject(dc, fHint);
                SIZE ts = {}; GetTextExtentPoint32W(dc, L"Hold RT / LT for more", 21, &ts);
                SelectObject(dc, o);
                const int bx0 = w / 2 - ts.cx / 2 - S(22), bx1 = w / 2 + ts.cx / 2 + S(22), by0 = h - S(30), by1 = h - S(4);
                Gradient(dc, RECT{ bx0 + S(8), by0, bx1 - S(8), by1 }, RGB(26, 21, 16), RGB(12, 10, 8));
                Fill(dc, RECT{ bx0 + S(8), by0, bx1 - S(8), by0 + 1 }, kGoldDark);
                Fill(dc, RECT{ bx0 + S(8), by1 - 1, bx1 - S(8), by1 }, kGoldDark);
                Diamond(dc, bx0 + S(6), (by0 + by1) / 2, S(5), kGoldDark);
                Diamond(dc, bx1 - S(6), (by0 + by1) / 2, S(5), kGoldDark);
                Text(dc, fHint, kGrey, L"Hold RT / LT for more", RECT{ bx0, by0, bx1, by1 }, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            }
        }
        for (int i = 0; i < 3; ++i) {
            RECT r = SlotRect(i, s);
            const bool has = d.ability[i] > 0, icon = has && hasIcon[i];
            if (layer == 0) {
                // a bevelled slot: dark rim, gold, dark - and a sunken dark inside
                Fill(dc, RECT{ r.left - S(3), r.top - S(3), r.right + S(3), r.bottom + S(3) }, RGB(8, 6, 5));
                Gradient(dc, r, has ? RGB(40, 33, 26) : RGB(24, 20, 16), has ? RGB(16, 13, 10) : RGB(12, 10, 8));
                Frame(dc, RECT{ r.left - S(2), r.top - S(2), r.right + S(2), r.bottom + S(2) }, kGoldDark, 1);
                Frame(dc, r, d.active[i] ? RGB(150, 230, 120) : kGold, d.active[i] ? (S(3) < 2 ? 2 : S(3)) : (S(2) < 1 ? 1 : S(2)));
                if (d.active[i]) Frame(dc, RECT{ r.left - S(4), r.top - S(4), r.right + S(4), r.bottom + S(4) }, RGB(70, 140, 60), 1);   // sustained: a green glow
                Frame(dc, RECT{ r.left + S(3), r.top + S(3), r.right - S(3), r.bottom - S(3) }, kGoldDark, 1);
                if (has && !icon) {
                    RECT tr = { r.left + S(8), r.top + S(10), r.right - S(8), r.bottom - S(22) };
                    Text(dc, fName, kWhite, d.abilityName[i][0] ? d.abilityName[i] : L"?", tr, DT_CENTER | DT_WORDBREAK | DT_END_ELLIPSIS);
                } else if (!has) {
                    Diamond(dc, (r.left + r.right) / 2, (r.top + r.bottom) / 2, S(9), RGB(58, 47, 34));
                    Diamond(dc, (r.left + r.right) / 2, (r.top + r.bottom) / 2, S(4), RGB(24, 20, 16));
                }
            }
            if ((layer == 1 && icon) || (layer == 0 && !icon)) {
                if (has && d.cooldown[i] > 0.05f) {
                    if (!icon) {
                        RECT cr = r; cr.left += S(3); cr.right -= S(3); cr.bottom -= S(3);
                        cr.top = r.bottom - S(3) - (int)((r.bottom - r.top - S(6)) * (d.cooldown[i] > 30.f ? 1.f : d.cooldown[i] / 30.f) + 0.5f);
                        if (cr.top < r.top + S(3)) cr.top = r.top + S(3);
                        Fill(dc, cr, RGB(6, 6, 6));
                    }
                    wchar_t t[16]; swprintf(t, 16, L"%d", (int)(d.cooldown[i] + 0.99f));
                    RECT sh = r; OffsetRect(&sh, S(2), S(2));
                    Text(dc, fCd, RGB(1, 1, 1), t, sh, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                    Text(dc, fCd, kGoldBright, t, r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                }
            }
            if (layer == 1) Badge(dc, fBtn, r.right - S(4), r.bottom - S(4), S(15), btn[i], col[i], ink[i]);   // over the icon's corner
        }
        DeleteObject(fName); DeleteObject(fBtn); DeleteObject(fCd); DeleteObject(fPage); DeleteObject(fHint);
    }

    // 1.7.1: bottom middle: [A] Open Chest - what Player 2's A button uses now (their view has no glow or floaty text)
    const int kPromptW = 600, kPromptH = 60;
    void DrawPrompt(HDC dc, const P2HudData& d, float s, int player)
    {
        auto S = [&](float v) { return (int)(v * s + 0.5f); };
        const int w = S(kPromptW), h = S(kPromptH);
        HFONT f = FontFace(S(25), false, false, false), fBtn = FontFace(S(20), true, false, false);
        HGDIOBJ old = SelectObject(dc, f);
        SIZE ts = {}; GetTextExtentPoint32W(dc, d.prompt, (int)wcslen(d.prompt), &ts);
        SelectObject(dc, old);
        int bw = ts.cx + S(110); if (bw > w) bw = w;
        const int x0 = (w - bw) / 2, x1 = x0 + bw;
        // a banner like the game's own: a dark band, gold lines above and below that fade at the ends, diamonds at the tips
        const int y0 = S(8), y1 = h - S(8), cy = h / 2;
        const int a0 = x0 + S(14), a1 = x1 - S(14), fade = (a1 - a0) / 5;
        Gradient(dc, RECT{ a0, y0, a1, y1 }, RGB(28, 23, 17), RGB(13, 10, 8));
        for (int line = 0; line < 2; ++line) {
            const int y = line ? y1 - 1 : y0;
            GradientDir(dc, RECT{ a0, y, a0 + fade, y + 1 }, kGoldDark, kGold, false);
            Fill(dc, RECT{ a0 + fade, y, a1 - fade, y + 1 }, kGold);
            GradientDir(dc, RECT{ a1 - fade, y, a1, y + 1 }, kGold, kGoldDark, false);
        }
        Diamond(dc, x0 + S(10), cy, S(8), kGold);
        Diamond(dc, x0 + S(10), cy, S(3), kPanelBottom);
        Diamond(dc, x1 - S(10), cy, S(8), kGold);
        Diamond(dc, x1 - S(10), cy, S(3), kPanelBottom);
        Fill(dc, RECT{ x0 + S(24), y0 + S(3), x0 + S(27), y1 - S(3) }, PlayerColour(player));   // whose prompt
        Badge(dc, fBtn, x0 + S(50), cy, S(15), L"A", RGB(84, 140, 52), RGB(250, 250, 250));
        Text(dc, f, kWhite, d.prompt, RECT{ x0 + S(76), 0, x1 - S(26), h }, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        DeleteObject(f); DeleteObject(fBtn);
    }

    struct Vtx { float x, y, z, rhw, u, v; };
    void Icon(IDirect3DDevice9* dev, IDirect3DTexture9* tex, const float uv[4], float x0, float y0, float x1, float y1, bool dim)
    {
        x0 -= 0.5f; y0 -= 0.5f; x1 -= 0.5f; y1 -= 0.5f;
        Vtx v[4] = {
            { x0, y0, 0.f, 1.f, uv[0], uv[1] }, { x1, y0, 0.f, 1.f, uv[2], uv[1] },
            { x0, y1, 0.f, 1.f, uv[0], uv[3] }, { x1, y1, 0.f, 1.f, uv[2], uv[3] },
        };
        dev->SetTextureStageState(0, D3DTSS_COLOROP, dim ? D3DTOP_MODULATE : D3DTOP_SELECTARG1);
        dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TFACTOR);
        dev->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_ARGB(255, 70, 70, 70));
        dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
        dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
        dev->SetTexture(0, tex);
        dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vtx));
        dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
        dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
    }
    void Quad(IDirect3DDevice9* dev, const Panel& p, float x0, float y0)
    {
        if (!p.tex) return;
        x0 -= 0.5f; y0 -= 0.5f;
        const float u1 = (float)p.w / p.texW, v1 = (float)p.h / p.texH;
        Vtx v[4] = {
            { x0,       y0,       0.f, 1.f, 0.f, 0.f },
            { x0 + p.w, y0,       0.f, 1.f, u1,  0.f },
            { x0,       y0 + p.h, 0.f, 1.f, 0.f, v1  },
            { x0 + p.w, y0 + p.h, 0.f, 1.f, u1,  v1  },
        };
        dev->SetTexture(0, p.tex);
        dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vtx));
    }
}

void P2HudSet(int player, const P2HudData& d)
{
    Hud& u = g_hud[Index(player)];
    Lock();
    if (std::memcmp(&u.data, &d, sizeof d) != 0) { u.data = d; ++u.rev; }
    Unlock();
}

void P2HudDraw(int player, IDirect3DDevice9* dev, int W, int H) { P2HudDrawAt(player, dev, 0, 0, W, H); }

void P2HudDrawAt(int player, IDirect3DDevice9* dev, int ox, int oy, int W, int H)
{
    Hud& u = g_hud[Index(player)];
    Panel& g_left = u.left; Panel& g_right = u.right; Panel& g_over = u.over; Panel& g_prompt = u.prompt;
    bool* g_hasIcon = u.hasIcon;
    P2HudData d;
    Lock(); d = u.data; Unlock();
    if (!d.valid || W <= 0 || H <= 0) return;
    // 1.7.1: one number per panel for what it shows (before, any change - a cooldown ticking - redrew all three
    // panels with GDI on the drawing thread, several times a second)
    auto Hash = [](const void* p, size_t n, unsigned h) { const unsigned char* b = static_cast<const unsigned char*>(p); for (size_t i = 0; i < n; ++i) h = (h ^ b[i]) * 16777619u; return h; };
    unsigned keyL = Hash(d.name, sizeof d.name, 2166136261u); keyL = Hash(&d.hp, sizeof d.hp, keyL); keyL = Hash(&d.mp, sizeof d.mp, keyL); keyL = Hash(&d.mage, sizeof d.mage, keyL);
    unsigned keyR = Hash(&d.page, sizeof d.page, 2166136261u); keyR = Hash(d.ability, sizeof d.ability, keyR); keyR = Hash(d.abilityName, sizeof d.abilityName, keyR);
    keyR = Hash(d.icon, sizeof d.icon, keyR); keyR = Hash(d.cooldown, sizeof d.cooldown, keyR); keyR = Hash(d.active, sizeof d.active, keyR);
    const unsigned keyP = Hash(d.prompt, sizeof d.prompt, 2166136261u);
    if (keyL != u.leftKey) { u.leftKey = keyL; ++u.revL; }
    if (keyR != u.rightKey) { u.rightKey = keyR; ++u.revR; }
    if (keyP != u.promptKey) { u.promptKey = keyP; ++u.revP; }
    float s = H / 1080.f;
    if (s < 0.5f) s = 0.5f;
    auto S = [&](float v) { return (int)(v * s + 0.5f); };
    if (g_left.forH != H || g_right.forH != H || g_over.forH != H || g_prompt.forH != H) { g_left.rev = g_right.rev = g_over.rev = g_prompt.rev = 0; g_left.forH = g_right.forH = g_over.forH = g_prompt.forH = H; }
    if (d.prompt[0] && (g_prompt.rev != u.revP || g_prompt.dev != dev || !g_prompt.tex)) {
        if (Render(dev, g_prompt, S(kPromptW), S(kPromptH), [&](HDC dc) { DrawPrompt(dc, d, s, player); })) g_prompt.rev = u.revP;
    }
    if (g_left.rev != u.revL || g_left.dev != dev || !g_left.tex) {
        if (Render(dev, g_left, S(kLeftW), S(kLeftH), [&](HDC dc) { DrawLeft(dc, d, s, player); })) g_left.rev = u.revL;
    }
    // which slots have an icon in the game's atlas
    IDirect3DTexture9* itex[3] = {}; float iuv[3][4] = {};
    bool has[3] = {};
    for (int i = 0; i < 3; ++i) has[i] = d.ability[i] > 0 && IconAtlasFind(dev, d.icon[i], &itex[i], iuv[i]);
    if (std::memcmp(has, g_hasIcon, sizeof has) != 0) { std::memcpy(g_hasIcon, has, 3 * sizeof(bool)); g_right.rev = 0; g_over.rev = 0; }
    if (g_right.rev != u.revR || g_right.dev != dev || !g_right.tex) {
        if (Render(dev, g_right, S(kRightW), S(kRightH), [&](HDC dc) { DrawRight(dc, d, s, 0, has); })) g_right.rev = u.revR;
    }
    if (g_over.rev != u.revR || g_over.dev != dev || !g_over.tex) {
        if (Render(dev, g_over, S(kRightW), S(kRightH), [&](HDC dc) { DrawRight(dc, d, s, 1, has); })) g_over.rev = u.revR;
    }
    IDirect3DStateBlock9* sb = D3D9SaveState(dev, player == 3 ? 2 : 1);   // 1.7.1: made once, captured each frame
    dev->SetVertexShader(nullptr);
    dev->SetPixelShader(nullptr);
    dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);
    dev->SetRenderState(D3DRS_ZENABLE, FALSE);
    dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
    dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
    dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    dev->SetRenderState(D3DRS_LIGHTING, FALSE);
    dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
    dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
    dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
    dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
    dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
    dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
    dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
    dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
    dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
    dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
    dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
    dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
    dev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
    dev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
    dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
    Quad(dev, g_left, (float)(ox + S(24)), (float)(oy + H - S(24) - g_left.h));
    const float rx = (float)(ox + W - S(30) - g_right.w), ry = (float)(oy + H - S(24) - g_right.h);
    Quad(dev, g_right, rx, ry);
    for (int i = 0; i < 3; ++i) {
        if (!has[i]) continue;
        RECT r = SlotRect(i, s);
        const float in = (float)S(4);
        Icon(dev, itex[i], iuv[i], rx + r.left + in, ry + r.top + in, rx + r.right - in, ry + r.bottom - in, d.cooldown[i] > 0.05f);
    }
    Quad(dev, g_over, rx, ry);
    if (d.prompt[0]) Quad(dev, g_prompt, (float)(ox + (W - g_prompt.w) / 2), (float)(oy + H - S(200) - g_prompt.h));
    dev->SetTexture(0, nullptr);
    if (sb) sb->Apply();
}
