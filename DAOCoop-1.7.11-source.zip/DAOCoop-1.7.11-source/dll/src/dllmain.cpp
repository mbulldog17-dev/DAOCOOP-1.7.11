// DAOCoop entry point. Loaded by DAOrigins.exe as dinput8.dll (see proxy_dinput8.cpp).
//
// Reads the P2/P3 controllers; each co-op player drives a party
// member through the game's own script commands (script.cpp). Everything it sees goes to <game>\DAOCoop\DAOCoop.log.
#include <windows.h>
#include <psapi.h>
#include <cwchar>
#include <cmath>
#include "log.h"
#include "pads.h"
#include "proxy.h"
#include "script.h"
#include "tick.h"
#include "coopcontrol.h"
#include "probes.h"
#include "game.h"
#include "d3d9hook.h"
#include "online/OnlinePlay.h"
#include "coopcreate.h"
#include "partyslots.h"
#include "equiplock.h"
#include "interact.h"
#include "targetui.h"
#include "xpshare.h"
#include "regroup.h"
#include "lobby.h"
#include "savesafe.h"
#include "camera.h"
#include "views.h"
#include "testpad.h"
#include "scaling.h"
#include "dialogskill.h"
#include "directmove.h"
#include "screenwall.h"
#include "rings.h"
#include "popup.h"
#include "problems.h"
#include "dialogstage.h"

static const char* kVersion = "1.7.11";
static wchar_t g_dir[MAX_PATH];   // <game folder>\DAOCoop\ (settings, logs)

static bool IsGameProcess()
{
    // Other tools in bin_ship (DAOriginsConfig.exe, DAUpdater.exe) also load
    // dinput8.dll. They get the plain forwarder and nothing else.
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    const wchar_t* name = wcsrchr(exe, L'\\');
    name = name ? name + 1 : exe;
    return lstrcmpiW(name, L"DAOrigins.exe") == 0;
}

static void IniPath(wchar_t* ini)
{
    lstrcpyW(ini, g_dir);
    lstrcatW(ini, L"DAOCoop.ini");
}

static int ReadIni(const wchar_t* section, const wchar_t* key, int fallback)
{
    wchar_t ini[MAX_PATH];
    IniPath(ini);
    return (int)GetPrivateProfileIntW(section, key, fallback, ini);
}

static void ReadIniString(const wchar_t* section, const wchar_t* key, const wchar_t* fallback,
                          wchar_t* out, DWORD cap)
{
    wchar_t ini[MAX_PATH];
    IniPath(ini);
    GetPrivateProfileStringW(section, key, fallback, out, cap, ini);
}

// "3,4,5" -> up to n ints; missing entries keep the fallback.
static void ReadIniInts(const wchar_t* section, const wchar_t* key, const int* fallback, int* out, int n)
{
    for (int i = 0; i < n; ++i) out[i] = fallback[i];
    wchar_t buf[64];
    ReadIniString(section, key, L"", buf, 64);
    const wchar_t* p = buf;
    for (int i = 0; i < n && *p; ++i) {
        while (*p == L' ' || *p == L',') ++p;
        if (*p < L'0' || *p > L'9') break;
        int v = 0;
        while (*p >= L'0' && *p <= L'9') v = v * 10 + (*p++ - L'0');
        out[i] = v;
        while (*p && *p != L',') ++p;
    }
}

// "LB,RB,Back" -> XINPUT_GAMEPAD_* mask
static WORD ParseButtons(const wchar_t* list)
{
    static const struct { const wchar_t* name; WORD bit; } kNames[] = {
        { L"A", XINPUT_GAMEPAD_A }, { L"B", XINPUT_GAMEPAD_B }, { L"X", XINPUT_GAMEPAD_X }, { L"Y", XINPUT_GAMEPAD_Y },
        { L"LB", XINPUT_GAMEPAD_LEFT_SHOULDER }, { L"RB", XINPUT_GAMEPAD_RIGHT_SHOULDER },
        { L"LS", XINPUT_GAMEPAD_LEFT_THUMB }, { L"RS", XINPUT_GAMEPAD_RIGHT_THUMB },
        { L"Back", XINPUT_GAMEPAD_BACK }, { L"View", XINPUT_GAMEPAD_BACK }, { L"Start", XINPUT_GAMEPAD_START },
        { L"Up", XINPUT_GAMEPAD_DPAD_UP }, { L"Down", XINPUT_GAMEPAD_DPAD_DOWN },
        { L"Left", XINPUT_GAMEPAD_DPAD_LEFT }, { L"Right", XINPUT_GAMEPAD_DPAD_RIGHT },
    };
    WORD mask = 0;
    wchar_t tok[16];
    const wchar_t* p = list;
    while (*p) {
        while (*p == L',' || *p == L' ') ++p;
        int n = 0;
        while (*p && *p != L',' && *p != L' ' && n < 15) tok[n++] = *p++;
        tok[n] = 0;
        for (const auto& k : kNames) if (n && lstrcmpiW(tok, k.name) == 0) mask |= k.bit;
        while (*p && *p != L',') ++p;
    }
    return mask;
}

// A crash the game doesn't handle: one line in our log (where, and in which module),
// then the normal crash handling (Windows' crash dump) goes on.
static LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;
static LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep)
{
    static volatile LONG once = 0;
    if (InterlockedExchange(&once, 1) == 0 && ep && ep->ExceptionRecord) {
        void* at = ep->ExceptionRecord->ExceptionAddress;
        HMODULE m = nullptr; wchar_t name[MAX_PATH] = L"?";
        if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)at, &m) && m) {
            GetModuleFileNameW(m, name, MAX_PATH);
        }
        const wchar_t* base = wcsrchr(name, L'\\');
        // 1.5.3: no Log() here - the crash may have happened while the log was busy, and waiting for it
        // froze the game; a raw line and a dump instead (problems.cpp)
        char line[600];
        wsprintfA(line, "CRASH: exception 0x%08lX at 0x%08lX (%S+0x%lX), thread %lu", ep->ExceptionRecord->ExceptionCode,
                  (unsigned long)(ULONG_PTR)at, base ? base + 1 : name, (unsigned long)((char*)at - (char*)m), GetCurrentThreadId());
        ProblemsNote(line);
        ProblemsDump(ep, "crash");
    }
    return g_prevFilter ? g_prevFilter(ep) : EXCEPTION_CONTINUE_SEARCH;
}

// The tick runs inside the game's frame, so its cost is frame time: measured,
// and logged every 10 s when it gets noticeable.
static void OnTick(unsigned now)
{
    {   // 1.7.1: the game puts its own crash handler in after ours (no crash was ever written down): ours
        // goes back in front every 2 s, passing on to theirs
        static unsigned nextFilter = 0;
        if ((int)(now - nextFilter) >= 0) {
            nextFilter = now + 2000;
            LPTOP_LEVEL_EXCEPTION_FILTER cur = SetUnhandledExceptionFilter(CrashFilter);
            if (cur && cur != CrashFilter) {
                g_prevFilter = cur;
                static bool said = false;
                if (!said) { said = true; Log("Crash handler: back in front of the game's own (%p)", (void*)cur); }
            }
        }
    }
    static LARGE_INTEGER freq = {};
    if (!freq.QuadPart) QueryPerformanceFrequency(&freq);
    LARGE_INTEGER t[5];
    QueryPerformanceCounter(&t[0]);
    ProblemsHeartbeat();
    {   // 1.5.5: the game's frame rate in the log every 30 s (to see what online streaming costs the host)
        static unsigned fpsFrom = 0, fpsFrames = 0;
        ++fpsFrames;
        if (!fpsFrom) fpsFrom = now;
        if (now - fpsFrom >= 30000) {
            Log("Game speed: %.1f frames per second over the last 30 s (%s)", fpsFrames * 1000.0 / (now - fpsFrom),
                OnlinePlay::Hosting() ? "hosting online" : "not hosting");
            fpsFrom = now; fpsFrames = 0;
        }
    }
    LobbyTick(now);     QueryPerformanceCounter(&t[1]);
    SaveSafeTick(now);  QueryPerformanceCounter(&t[2]);
    CoopTick(now);      QueryPerformanceCounter(&t[3]);
    EquipLockTick(now); QueryPerformanceCounter(&t[4]);
    { game::Mode m = game::CurrentMode(); ProbesTick(now, m == game::MODE_EXPLORE); }
    {   // 1.7.0: the host went back to the main menu: the online friends are told (and go back to theirs)
        static bool wasInGame = false;
        const game::Mode m = game::CurrentMode();
        if (m == game::MODE_PREGAME) { if (wasInGame) OnlinePlay::HostLeftGame(); wasInGame = false; }
        else if (m != game::MODE_NONE && m != game::MODE_LOADING && m != game::MODE_UNKNOWN) wasInGame = true;
    }
    {   // online play: who joined / left, on the host's screen
        std::wstring msg;
        static unsigned nextMsg = 0;
        game::Mode m = game::CurrentMode();
        if ((int)(now - nextMsg) >= 0 && (m == game::MODE_EXPLORE || m == game::MODE_COMBAT) && OnlinePlay::TakeMessage(msg)) {
            nextMsg = now + 2500;
            script::DisplayStatusMessage(msg.c_str(), 0x66CCFF);
        }
    }
    static double sum[4], peak[4]; static int calls = 0; static unsigned next = 0;
    for (int i = 0; i < 4; ++i) {
        double ms = (t[i + 1].QuadPart - t[i].QuadPart) * 1000.0 / (double)freq.QuadPart;
        sum[i] += ms; if (ms > peak[i]) peak[i] = ms;
    }
    ++calls;
    if (!next) next = now + 10000;
    if ((int)(now - next) >= 0) {
        double total = (sum[0] + sum[1] + sum[2] + sum[3]) / calls;
        double worst = peak[0] + peak[1] + peak[2] + peak[3];
        if (total > 0.5 || worst > 8.0)
            Log("Tick cost: %.2f ms average, slowest parts lobby %.1f / saves %.1f / co-op %.1f / screens %.1f ms (%d ticks)",
                total, peak[0], peak[1], peak[2], peak[3], calls);
        for (int i = 0; i < 4; ++i) sum[i] = peak[i] = 0;
        calls = 0; next = now + 10000;
    }
}

// True when the game exe has the "large address aware" flag (the 4GB patch),
// which lets this 32-bit game use 4GB of memory instead of 2GB.
static bool GameIsLargeAddressAware(HMODULE game)
{
    const BYTE* base = (const BYTE*)game;
    const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    const IMAGE_NT_HEADERS* nt = (const IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    return (nt->FileHeader.Characteristics & IMAGE_FILE_LARGE_ADDRESS_AWARE) != 0;
}

static DWORD WINAPI StartupThread(LPVOID)
{
    HMODULE game = GetModuleHandleW(nullptr);
    MODULEINFO info = {};
    GetModuleInformation(GetCurrentProcess(), game, &info, sizeof(info));
    Log("DAOCoop %s loaded into DAOrigins.exe", kVersion);
    Log("Game image base 0x%p, size 0x%X", info.lpBaseOfDll, info.SizeOfImage);
    Log("4GB patch (large address aware): %s", GameIsLargeAddressAware(game) ? "yes" : "no (the Steam version needs Steamless + the 4GB patch for this)");
    Log("DirectInput calls go to %ls", ProxyTargetPath());
    {
        unsigned long err = 0;
        if (const wchar_t* failed = ProxyChainFailed(&err))
            Log("WARNING: the other mod %ls did not load (Windows error %lu%s) - it is not running", failed, err,
                err == 126 ? ": a DLL it needs is missing - for the Native Controller Framework install Microsoft's Visual C++ "
                             "Redistributable x86, https://aka.ms/vs/17/release/vc_redist.x86.exe" : "");
    }

    OnlinePlay::AfterStartup();
    PadsSetP1Index(ReadIni(L"Controllers", L"P1Pad", 0));
    PadsStart(ReadIni(L"Controllers", L"P2Pad", 1), ReadIni(L"Controllers", L"P3Pad", 2));

    // Engine bridge: only on the exact build the addresses were taken from. (The Steam exe's code is
    // only unscrambled by Steam's wrapper after this DLL loads: wait for it first.)
    game::WaitForGameCode();
    if (!script::Init()) return 0;

    // HUD party slots (must happen before a game is loaded).
    PartySlotsApply(ReadIni(L"Party", L"HudSlots", 4));

    // Players 2 and 3: [P2] and [P3]; a key missing from [P3] uses the [P2] value.
    CoopSettings cs = {};
    for (int i = 0; i < 2; ++i) {
        const wchar_t* sec = i == 0 ? L"P2" : L"P3";
        CoopPlayerSettings& c = cs.player[i];
        const CoopPlayerSettings* d = i == 0 ? nullptr : &cs.player[0];
        c.enabled     = ReadIni(sec, L"Enabled", 1) != 0;
        c.leash       = (float)ReadIni(sec, L"LeashMetres", d ? (int)d->leash : 20);
        c.leashCombat = (float)ReadIni(sec, L"LeashCombatMetres", d ? (int)d->leashCombat : 35);
        c.deadzone    = ReadIni(sec, L"DeadzonePercent", d ? (int)lroundf(d->deadzone * 100) : 25) / 100.f;
        c.slots[0][0] = ReadIni(sec, L"QuickSlotX", d ? d->slots[0][0] : 0);
        c.slots[0][1] = ReadIni(sec, L"QuickSlotY", d ? d->slots[0][1] : 1);
        c.slots[0][2] = ReadIni(sec, L"QuickSlotB", d ? d->slots[0][2] : 2);
        static const int kRT[3] = { 3, 4, 5 }, kLT[3] = { 6, 7, 8 };
        ReadIniInts(sec, L"QuickSlotsRT", d ? d->slots[1] : kRT, c.slots[1], 3);
        ReadIniInts(sec, L"QuickSlotsLT", d ? d->slots[2] : kLT, c.slots[2], 3);
        ReadIniString(sec, L"CreatureTags", L"", c.tags, 512);
    }
    cs.autoJoin  = ReadIni(L"Players", L"AutoJoin", 1) != 0;
    cs.debug     = ReadIni(L"Debug", L"Verbose", 0) != 0;
    cs.expCreate = ReadIni(L"Experimental", L"CreateP2Combo", 0) != 0;
    {
        wchar_t idle[32];
        ReadIniString(L"Players", L"IdleInCombat", L"Attack", idle, 32);
        cs.idleMode = lstrcmpiW(idle, L"Stand") == 0 ? COOP_IDLE_STAND
                    : lstrcmpiW(idle, L"Tactics") == 0 ? COOP_IDLE_TACTICS : COOP_IDLE_ATTACK;
    }
    cs.pauseCombo  = ReadIni(L"Players", L"PauseWithViewStart", 1) != 0;
    cs.rumble      = ReadIni(L"Players", L"Rumble", 1) != 0;
    cs.rumbleScale = ReadIni(L"Players", L"RumblePercent", 100) / 100.f;
    cs.helpOnce    = ReadIni(L"Players", L"ShowControlsOnce", 1) != 0;
    IniPath(cs.ini);
    CoopInit(cs);

    // Co-op lobby (start menu "Co-op" button) and the session the last game used.
    LobbySettings ls = {};
    ls.enabled        = ReadIni(L"Lobby", L"Enabled", 1) != 0;
    ls.slotsFromLobby = ReadIni(L"Lobby", L"PartySlotsFromLobby", 1) != 0;
    ls.padP2          = ReadIni(L"Controllers", L"P2Pad", 1);
    ls.padP3          = ReadIni(L"Controllers", L"P3Pad", 2);
    ls.offscreenArrows = ReadIni(L"Markers", L"OffscreenArrows", 1) != 0;
    ls.assignInLobby   = ReadIni(L"Lobby", L"ControllerOrderInLobby", 1) != 0;
    wchar_t iniPath[MAX_PATH];
    IniPath(iniPath);
    LobbyInit(ls, iniPath);

    SaveSafeSettings ss = {};
    ss.enabled               = ReadIni(L"Saves", L"Backups", 1) != 0;
    ss.autosaveBeforeCreator = ReadIni(L"Saves", L"SaveBeforeCreator", 1) != 0;
    ss.keepSets              = ReadIni(L"Saves", L"BackupsPerCharacter", 10);
    ss.savesPerSet           = ReadIni(L"Saves", L"SavesPerBackup", 3);
    ReadIniString(L"Saves", L"Folder", L"", ss.charactersDir, 260);
    SaveSafeInit(ss, g_dir);

    CameraSettings cam = {};
    cam.enabled   = ReadIni(L"Camera", L"KeepEveryoneInView", 1) != 0;
    cam.maxShift  = (float)ReadIni(L"Camera", L"MaxSlideMetres", 12);
    cam.maxZoom   = ReadIni(L"Camera", L"MaxZoomOutPercent", 50) / 100.f + 1.f;
    cam.zoomStart = (float)ReadIni(L"Camera", L"ZoomOutFromMetres", 8);
    cam.combatZoom    = ReadIni(L"Camera", L"CombatZoomOut", 1) != 0;
    cam.combatZoomMax = (float)ReadIni(L"Camera", L"CombatZoomOutMetres", 5);
    cam.exploreZoomMax = (float)ReadIni(L"Camera", L"ZoomOutMetres", 3);
    CameraInit(cam);
    ViewsInit(iniPath);                       // 1.7.0 views test ([Views] Experiment)
    TestPadInit(iniPath);                     // 1.7.0 testing ([TestPad] Enabled)

    ScreenWallSettings sw = {};
    sw.enabled     = ReadIni(L"Camera", L"ScreenWall", 1) != 0;
    sw.edge        = ReadIni(L"Camera", L"ScreenEdgePercent", 3) / 100.f;   // 1.5.5: 8 -> 3 (stopped players too early)
    sw.pullSeconds = (float)ReadIni(L"Camera", L"PullAfterSeconds", 5);
    sw.verbose     = cs.debug;
    ScreenWallInit(sw);

    RingSettings rs = {};
    rs.mode   = ReadIni(L"Markers", L"PlayerRings", 1);
    rs.radius = ReadIni(L"Markers", L"RingSizeCm", 70) / 100.f;
    rs.alpha  = ReadIni(L"Markers", L"RingOpacityPercent", 70) * 255 / 100;
    rs.drawn  = ReadIni(L"Markers", L"DrawnMarkers", 1) != 0;          // 1.7.4
    rs.tags   = ReadIni(L"Markers", L"OwnCharacterTag", 1) != 0;
    rs.enemy  = ReadIni(L"Markers", L"EnemyTarget", 1) != 0;
    rs.ally   = ReadIni(L"Markers", L"AllyTarget", 1) != 0;
    RingsInit(rs);
    PopupInit();                 // 1.4.1: the host's "wants to join" pop-up

    DialogStageSettings ds = {};
    ds.enabled   = ReadIni(L"Party", L"CoopInConversations", 1) != 0;
    ds.cutscenes = ReadIni(L"Party", L"CoopInCutscenes", 1) != 0;
    for (int i = 0; i < 2; ++i) {
        wchar_t name[32];
        ReadIniString(L"Party", i == 0 ? L"CutsceneStanceP2" : L"CutsceneStanceP3", L"listen", name, 32);
        int a = DialogStageStance(name);
        if (a < 0) { Log("Settings: unknown cutscene stance \"%ls\" - using listen", name); a = 800; }
        ds.stance[i] = a;
    }
    DialogStageInit(ds);

    ScalingSettings sc = {};
    sc.enabled    = ReadIni(L"Difficulty", L"ScaleEnemies", 1) != 0;
    sc.perPlayer  = ReadIni(L"Difficulty", L"PercentPerExtraPlayer", 25) / 100.f;
    sc.attributes = ReadIni(L"Difficulty", L"ScaleDamage", 1) != 0;
    ScalingInit(sc);

    DialogSkillInit(ReadIni(L"Players", L"ConversationSkillsOfHolder", 1) != 0);
    LobbyApplySavedSession();

    CoopCreateSettings pc = {};
    pc.hooks         = ReadIni(L"P2Create", L"SafetyHooks", 1) != 0;
    // "OfferAtOstagar" (old installs have it =1) is retired: characters are made
    // at the start of the origin story now; Ostagar only if asked for explicitly.
    pc.autoAtArea    = ReadIni(L"P2Create", L"OfferAtOstagarToo", 0) != 0;
    pc.anywhere      = ReadIni(L"P2Create", L"OfferAnywhere", 1) != 0;
    pc.followerState = ReadIni(L"P2Create", L"FollowerState", 7);
    pc.endAs         = ReadIni(L"P2Create", L"FinishAsLevelUp", 1) != 0 ? 1 : 0;
    ReadIniString(L"P2Create", L"TriggerAreas", L"pre100ar_kings_camp", pc.areas, 256);
    ReadIniString(L"P2Create", L"Template", L"default_player.utc", pc.templ, 64);
    pc.atStart       = ReadIni(L"P2Create", L"AtStoryStart", 1) != 0;
    pc.keepInOrigin  = ReadIni(L"P2Create", L"KeepInPartyDuringOrigin", 1) != 0;
    ReadIniString(L"P2Create", L"OriginAreas", L"bhn,bdn,bdc,bec,bed,bhm", pc.originAreas, 128);
    ReadIniString(L"P2Create", L"SoloAreas", L"bhm600", pc.soloAreas, 128);
    CoopCreateInit(pc);

    EquipLockSettings el = {};
    el.enabled = ReadIni(L"Inventory", L"OwnerLock", 1) != 0;
    el.padP2   = ReadIni(L"Controllers", L"P2Pad", 1);
    el.padP3   = ReadIni(L"Controllers", L"P3Pad", 2);
    wchar_t pass[128];
    ReadIniString(L"Inventory", L"Player1PassThrough", L"LB,RB", pass, 128);
    el.passThrough = ParseButtons(pass);
    wchar_t hand[64];
    ReadIniString(L"Inventory", L"HandOverButton", L"RS", hand, 64);
    el.handOverButton = ParseButtons(hand);
    ReadIniString(L"Inventory", L"HandOverKey", L"F3", hand, 64);
    el.blockPlayer1      = ReadIni(L"Players", L"Player1CantControlCoopCharacters", 1) != 0;
    el.passConversations = ReadIni(L"Players", L"PassConversations", 1) != 0;
    el.handOverKey = (hand[0] == L'F' || hand[0] == L'f') && hand[1] >= L'1' && hand[1] <= L'9'
                   ? VK_F1 + _wtoi(hand + 1) - 1 : 0;           // F1..F12, anything else = none
    EquipLockInit(el);

    InteractSettings is = {};
    is.enabled          = ReadIni(L"Interact", L"Enabled", 1) != 0;
    is.range            = ReadIni(L"Interact", L"RangeDecimetres", 40) / 10.f;
    is.allowTransitions = ReadIni(L"Interact", L"AreaDoors", 1) != 0;
    is.dialogGuard      = ReadIni(L"Interact", L"ConversationsToPlayer1", 1) != 0;
    is.triggerGuard     = ReadIni(L"Interact", L"StoryTriggersPlayer1Only", 1) != 0;
    InteractInit(is);

    TargetUiSettings tu = {};
    tu.enemyMarker = ReadIni(L"Markers", L"EnemyTarget", 1) != 0;
    tu.allyMarker  = ReadIni(L"Markers", L"AllyTarget", 1) != 0;
    tu.usePreview  = ReadIni(L"Markers", L"UsePreview", 1) != 0;
    tu.prompt      = ReadIni(L"Markers", L"UsePrompt", 1) != 0;
    tu.selfTag     = ReadIni(L"Markers", L"OwnCharacterTag", 1) != 0;
    tu.names       = ReadIni(L"Markers", L"CharacterNames", 1) != 0;
    tu.drawn       = ReadIni(L"Markers", L"DrawnMarkers", 1) != 0;   // 1.7.4
    TargetUiInit(tu);

    XpShareSettings xs = {};
    xs.enabled   = ReadIni(L"Experience", L"MatchWarden", 1) != 0;
    xs.trimAhead = ReadIni(L"Experience", L"Exactly", 1) != 0;
    XpShareInit(xs);

    RegroupSettings rg = {};
    rg.enabled      = ReadIni(L"Regroup", L"Enabled", 1) != 0;
    rg.autoDistance = (float)ReadIni(L"Regroup", L"AutoPlaceMetres", 0);
    rg.stuckSeconds = (float)ReadIni(L"Regroup", L"StuckTeleportSeconds", 0);
    RegroupInit(rg);

    CoopFreeMovementTest(ReadIni(L"Debug", L"FreeMovementTest", 0) != 0);
    CoopFollowTarget(ReadIni(L"Debug", L"FollowTarget", 1) != 0);
    {
        bool probes = ReadIni(L"Debug", L"Probes", 0) != 0;
        DirectMoveFixInstall(probes);
        ProbesInit(probes);
        if (probes && ReadIni(L"Debug", L"FreeMovementRetest", 0)) CoopFreeMovementRetest();
    }
    ProblemsInit(g_dir);
    g_prevFilter = SetUnhandledExceptionFilter(CrashFilter);
    // Runs OnTick at the end of every game frame (the game's own thread).
    TickStart(OnTick, 120000);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID reserved)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        if (!IsGameProcess()) return TRUE;

        // Settings and logs live in <game folder>\DAOCoop\, one level above
        // bin_ship where this DLL sits (the installer puts DAOCoop.ini there).
        GetModuleFileNameW(module, g_dir, MAX_PATH);
        wchar_t* slash = wcsrchr(g_dir, L'\\');
        if (slash) *slash = L'\0';                 // ...\bin_ship
        slash = wcsrchr(g_dir, L'\\');
        if (slash) slash[1] = L'\0';               // the game folder, slash kept
        lstrcatW(g_dir, L"DAOCoop\\");
        CreateDirectoryW(g_dir, nullptr);          // fine if it already exists

        wchar_t logPath[MAX_PATH];
        lstrcpyW(logPath, g_dir);
        lstrcatW(logPath, L"DAOCoop.log");
        if (!LogInit(logPath)) {
            // The game folder is under Program Files and may not be writable for
            // the game. Fall back to %LOCALAPPDATA%\DAOCoop\DAOCoop.log.
            DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", logPath, MAX_PATH);
            if (n > 0 && n < MAX_PATH - 32) {
                lstrcatW(logPath, L"\\DAOCoop");
                CreateDirectoryW(logPath, nullptr);
                lstrcatW(logPath, L"\\DAOCoop.log");
                LogInit(logPath);
            }
        }
        Log("Log file: %ls", logPath);

        // 1.5.5: more processor cores. DAOrigins.exe's own header limits the game to processors 0 and 1
        // (load config ProcessAffinityMask = 3, GOG and Steam alike), so the game, its sound and the
        // online stream's encoder all shared two cores. The engine counts the cores it may use when it
        // starts (0x4017D0: GetProcessAffinityMask, one worker thread per extra core), which is after
        // this - so it now starts with more. [Performance] Cores: how many (0 = all, 2 = as shipped).
        {
            int want = ReadIni(L"Performance", L"Cores", 2);   // 1.6.0: default back to the game's own 2 (more is reported to crash)
            DWORD_PTR proc = 0, sys = 0;
            if (want != 2 && GetProcessAffinityMask(GetCurrentProcess(), &proc, &sys) && sys) {
                DWORD_PTR mask = 0;
                int n = 0;
                for (int b = 0; b < (int)(sizeof(DWORD_PTR) * 8); ++b) {
                    const DWORD_PTR bit = (DWORD_PTR)1 << b;
                    if (!(sys & bit)) continue;
                    if (want > 0 && n >= want) break;
                    mask |= bit; ++n;
                }
                if (mask && mask != proc) {
                    if (SetProcessAffinityMask(GetCurrentProcess(), mask))
                        Log("Processor cores: the game may use %d (was limited to mask 0x%lX by the exe; [Performance] Cores=%d)", n, (unsigned long)proc, want);
                    else
                        Log("Processor cores: could not change the game's limit (error %lu)", GetLastError());
                }
            }
            // 1.7.1: the 2 processors the exe asks for (0 and 1) are on most CPUs the two halves of ONE core
            // (Hyper-Threading / SMT): the game's main thread, its renderer work and the mod's threads then shared
            // one core's power. Still 2 processors - the number the game is made for - but on two real cores.
            // [Performance] SpreadCores=0 keeps the exe's own pair.
            if (want == 2 && ReadIni(L"Performance", L"SpreadCores", 1) &&
                GetProcessAffinityMask(GetCurrentProcess(), &proc, &sys) && proc) {
                DWORD len = 0;
                GetLogicalProcessorInformation(nullptr, &len);
                const DWORD count = len / sizeof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION);
                SYSTEM_LOGICAL_PROCESSOR_INFORMATION* info = count ? (SYSTEM_LOGICAL_PROCESSOR_INFORMATION*)HeapAlloc(GetProcessHeap(), 0, len) : nullptr;
                if (info && GetLogicalProcessorInformation(info, &len)) {
                    DWORD_PTR cores[64]; int nc = 0;
                    for (DWORD i = 0; i < count && nc < 64; ++i)
                        if (info[i].Relationship == RelationProcessorCore && (info[i].ProcessorMask & sys)) cores[nc++] = info[i].ProcessorMask & sys;
                    // the exe's pair on one core, and there are at least 2 cores: the first processor of the first two cores
                    bool oneCore = false;
                    for (int c = 0; c < nc; ++c) if ((cores[c] & proc) == proc) oneCore = true;
                    if (oneCore && nc >= 2) {
                        const DWORD_PTR a0 = cores[0] & (~cores[0] + 1), a1 = cores[1] & (~cores[1] + 1);   // lowest bit of each
                        const DWORD_PTR mask = a0 | a1;
                        if (mask != proc && SetProcessAffinityMask(GetCurrentProcess(), mask))
                            Log("Processor cores: the game's 2 processors (mask 0x%lX) were both halves of one core - now one on each of two cores (mask 0x%lX; [Performance] SpreadCores=0 to undo)",
                                (unsigned long)proc, (unsigned long)mask);
                    } else {
                        Log("Processor cores: the game uses mask 0x%lX (%d cores in this PC; already on separate cores)", (unsigned long)proc, nc);
                    }
                }
                if (info) HeapFree(GetProcessHeap(), 0, info);
            }
        }

        // Online play: the game's Direct3D 9 device (before the game makes it).
        {
            wchar_t ini[MAX_PATH];
            IniPath(ini);
            OnlinePlay::Init(ini);
        }
        // 1.7.5: the 30 a second of the frame cap paced by the screen's refreshes (fullscreen, 60 / 120 Hz) instead of a timer
        {
            const bool views = ReadIni(L"Views", L"Experiment", 0) != 0;
            const int cap = ReadIni(L"Views", L"FrameCap", 30);
            D3D9SetPacing(views && cap > 0 && ReadIni(L"Views", L"ScreenPacing", 1) != 0, cap > 0 ? cap : 30);
        }
        D3D9HookInstall(OnlinePlay::OnPresent, OnlinePlay::OnReset);

        // Keep DllMain light: real work happens on our own thread.
        HANDLE t = CreateThread(nullptr, 0, StartupThread, nullptr, 0, nullptr);
        if (t) CloseHandle(t);
    } else if (reason == DLL_PROCESS_DETACH) {
        // On game exit Windows has already stopped our threads; only clean up
        // when the DLL is unloaded while the game keeps running.
        OnlinePlay::NotifyExit();      // 1.7.0: a last goodbye to the online friends (best effort)
        if (reserved == nullptr) { TickStop(); PadsStop(); }
        LogShutdown();
    }
    return TRUE;
}
