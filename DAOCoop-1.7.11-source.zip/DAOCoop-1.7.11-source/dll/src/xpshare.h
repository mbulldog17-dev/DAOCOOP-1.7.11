#pragma once
// Experience for Players 2/3, kept equal to the Warden's: what a single-player
// Warden would have, so the game's level curve and enemy scaling stay as designed.
//
// What the game already does (sys_reward_h, compiled into creature_core.ncs):
//   RewardXPParty(xp) gives EVERY party member (GetPartyList) the full reward
//   - 100% to the killer, 95% to the others, 90% if dead - and never divides
//   by party size. RewardXP() requires GetFollowerState != 0 (our locked-active
//   co-op characters qualify) and does the level-up work (SetCanLevelUp, points).
//
// What we add:
//   - catch-up: a co-op character behind the Warden (new character at Ostagar,
//     or the 95%-vs-100% killer difference) gets the difference through the
//     game's own RewardXP, by running the stock debug script addxp.ncs on it;
//   - no overshoot: a co-op character ahead of the Warden is trimmed back to
//     the Warden's XP (never below the start of its current level);
//   - auto level-up is switched off for co-op characters (they spend their own
//     points, with their own controller - see equiplock / coopcontrol);
//   - StartCharGen calls are watched so the level-up screen of a co-op
//     character goes to that player's controller.
#include <cstdint>

struct XpShareSettings {
    bool enabled;
    bool trimAhead;      // also pull co-op characters down to the Warden's XP
};

void     XpShareInit(const XpShareSettings& s);
void     XpShareTick(unsigned now, uint32_t hero, bool playable);   // main thread
uint32_t XpShareLastCharGenCreature();     // creature of the latest StartCharGen (level-up / creator)
