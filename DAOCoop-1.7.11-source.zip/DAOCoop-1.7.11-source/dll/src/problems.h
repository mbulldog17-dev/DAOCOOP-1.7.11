#pragma once
// 1.5.3: when the game crashes or freezes, leave something to look at.
//  - crash: a line in DAOCoop\DAOCoop-problems.txt and a small dump file (DAOCoop\daocoop-crash-*.dmp),
//    written without the normal log (a crash can happen while the log is busy, and waiting for it froze
//    the game instead of letting Windows close it).
//  - freeze: no game frame for 15 s while the game is the active window -> the same, once per session
//    (daocoop-freeze-*.dmp holds where every thread was).
#include <windows.h>

void ProblemsInit(const wchar_t* dir);          // <game folder>\DAOCoop\ (slash at the end)
void ProblemsHeartbeat();                       // every game frame (the tick)
void ProblemsNote(const char* text);            // one raw line, safe in a crash
bool ProblemsDump(EXCEPTION_POINTERS* ep, const char* why);
