#include "dialogstage.h"
#include "script.h"
#include "game.h"
#include "log.h"
#include <cmath>
#include <cwchar>

static DialogStageSettings g_s;

// The scene that is running (a conversation or a cutscene), 0 = none.
static int      g_scene = 0;
static bool     g_placed = false;
static unsigned g_start = 0;
static uint32_t g_char[2] = { 0xFFFFFFFF, 0xFFFFFFFF };
static bool     g_animated[2];
static script::Vec3 g_before[2], g_last[2];
static bool     g_haveBefore[2], g_haveLast[2];
static script::Vec3 g_placedAt[2];
static bool     g_checked = false;          // the late "cast after all?" check done

// Stances: the looping animations of the game's own ambient patterns (ambient_anim_patterns.gda:
// listener_passive_1 800, arms_crossed 802, hands_behind_back 844, guard_attention 658,
// praying 650, relaxed 625).
struct Stance { const wchar_t* name; int anim; };
static const Stance kStances[] = {
    { L"none", 0 }, { L"listen", 800 }, { L"arms_crossed", 802 }, { L"hands_behind_back", 844 },
    { L"attention", 658 }, { L"pray", 650 }, { L"relaxed", 625 },
};
int DialogStageStance(const wchar_t* name)
{
    for (const Stance& s : kStances) if (_wcsicmp(name, s.name) == 0) return s.anim;
    return -1;
}

void DialogStageInit(const DialogStageSettings& s)
{
    g_s = s;
    Log("Scenes: co-op characters join conversations %s, cutscenes %s (stances P2 %d, P3 %d)",
        s.enabled ? "on" : "off", s.cutscenes ? "on" : "off", s.stance[0], s.stance[1]);
}

static float Dist2(const script::Vec3& a, const script::Vec3& b)
{
    float x = a.x - b.x, y = a.y - b.y;
    return std::sqrt(x * x + y * y);
}

static void EndScene()
{
    for (int i = 0; i < 2; ++i) {
        if (!g_animated[i]) continue;
        g_animated[i] = false;
        if (g_char[i] != 0xFFFFFFFF && script::IsObjectValid(g_char[i])) {
            script::ClearAllCommands(g_char[i], true);            // stops the looping stance
            Log("Scenes: Player %d's stance ended", i + 2);
        }
    }
    g_scene = 0;
}

void DialogStageTick(unsigned now, int mode, uint32_t p2, uint32_t p3)
{
    uint32_t ids[2] = { p2, p3 };
    int scene = mode == game::MODE_DIALOG && g_s.enabled ? 1 : mode == game::MODE_CUTSCENE && g_s.cutscenes ? 2 : 0;

    if (scene != g_scene) {
        if (g_scene) EndScene();
        if (scene) {                                   // a scene just started
            g_scene = scene; g_placed = false; g_checked = false; g_start = now;
            for (int i = 0; i < 2; ++i) { g_char[i] = ids[i]; g_before[i] = g_last[i]; g_haveBefore[i] = g_haveLast[i]; g_animated[i] = false; }
            for (int i = 0; i < 2; ++i)
                if (g_char[i] != 0xFFFFFFFF)
                    Log("Scenes: %s started - Player %d flags 0x%04X", scene == 1 ? "conversation" : "cutscene", i + 2, game::CutsceneFlags(g_char[i]));
        }
    }
    if (!scene) {
        // remember where they stand while playing: the "before" of the next scene
        if (mode == game::MODE_EXPLORE || mode == game::MODE_COMBAT)
            for (int i = 0; i < 2; ++i)
                g_haveLast[i] = ids[i] != 0xFFFFFFFF && script::GetPosition(ids[i], &g_last[i]);
        return;
    }
    // A cutscene can take a while to load its cast: a character placed early that the cutscene
    // then took over (moved again) is left to it, without the stance.
    if (g_placed && !g_checked && scene == 2 && now - g_start > 3000) {
        g_checked = true;
        for (int i = 0; i < 2; ++i) {
            script::Vec3 p;
            if (!g_animated[i] || !script::GetPosition(g_char[i], &p)) continue;
            if (Dist2(p, g_placedAt[i]) > 0.5f) {
                g_animated[i] = false;
                script::ClearAllCommands(g_char[i], true);
                Log("Scenes: Player %d was cast in the cutscene after all (moved %.1f m) - stance dropped", i + 2, Dist2(p, g_placedAt[i]));
            }
        }
    }
    // Let the scene place its cast first (conversations at once, cutscenes after their first frames).
    if (g_placed || now - g_start < (scene == 1 ? 350u : 700u)) return;
    g_placed = true;

    uint32_t hero = game::HeroId();
    script::Vec3 h;
    if (hero == 0xFFFFFFFF || !script::GetPosition(hero, &h)) return;
    float facing = script::GetFacing(hero);
    float f = facing * 0.01745329f;
    float fx = -std::sin(f), fy = std::cos(f);           // the Warden's forward (as game::Heading)
    float rx = fy, ry = -fx;                               // right
    static const float kSide[2] = { -1.1f, 1.1f };        // Player 2 behind-left, Player 3 behind-right
    const char* what = scene == 1 ? "conversation" : "cutscene";
    for (int i = 0; i < 2; ++i) {
        uint32_t c = g_char[i];
        if (c == 0xFFFFFFFF || !script::IsObjectValid(c) || script::IsDeadChecked(c) == 1) continue;
        script::Vec3 p3;
        if (!script::GetPosition(c, &p3)) continue;
        float moved = g_haveBefore[i] ? Dist2(p3, g_before[i]) : 0.f;
        float toHero = Dist2(p3, h);
        int flags = game::CutsceneFlags(c);
        if (moved > 0.5f) { Log("Scenes: Player %d is cast in this %s (moved %.1f m, flags 0x%04X) - left to it", i + 2, what, moved, flags); continue; }
        if (toHero >= 3.0f) {
            script::Vec3 p = { h.x - fx * 1.3f + rx * kSide[i], h.y - fy * 1.3f + ry * kSide[i], h.z };
            if (scene == 2) script::ClearAllCommands(c, true);
            bool ok = script::SetLocationSafe(c, hero, p, facing);
            Log("Scenes: Player %d was %.1f m from the Warden, not in the %s (flags 0x%04X) - placed behind the Warden: %s",
                i + 2, toHero, what, flags, ok ? "ok" : "FAILED");
        } else {
            Log("Scenes: Player %d is already next to the Warden in this %s (%.1f m, flags 0x%04X)", i + 2, what, toHero, flags);
        }
        script::GetPosition(c, &g_placedAt[i]);
        if (scene == 2 && g_s.stance[i] > 0) {
            bool ok = script::PlayAnimation(c, g_s.stance[i], 100, true);
            g_animated[i] = ok;
            Log("Scenes: Player %d takes stance %d: %s", i + 2, g_s.stance[i], ok ? "ok" : "FAILED");
        }
    }
}
