#include "modmenu.h"
#include "targetui.h"
#include "online/OnlineChat.h"
#include "d3d9hook.h"
#include "xinputroute.h"
#include "log.h"
#include "scaling.h"
#include "online/OnlineVoice.h"
#include "online/Paths.h"
#include "online/OnlinePlay.h"
#include <windows.h>
#include <xinput.h>
#include <d3d9.h>
#include <algorithm>
#include <cstdlib>
#include <cwctype>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

// The look follows Dragon Age's own screens: a near-black warm panel, a double gold frame with diamond
// corners, gold small-capital headings, cream text and a dark blood-red band on the chosen row.
namespace
{
    // ---------------- state ----------------
    std::mutex g_m;
    bool g_open = false;
    int g_player = 0, g_pad = -1;
    DWORD g_closedAt = 0;
    int g_closedFor = -1;
    int g_tab = 0, g_sel = 0, g_scroll = 0;
    unsigned g_rev = 1;

    // render thread only
    WORD g_prevButtons = 0;
    bool g_prevKeys[10] = {};
    DWORD g_repeatAt = 0;
    int g_repeatDir = 0;            // 1 up 2 down 3 left 4 right
    bool g_holdMenu = false;
    bool g_menuKeyWas = false;
    bool g_wasOpen = false;
    int g_menuKey = -1;

    IDirect3DDevice9* g_dev = nullptr;
    IDirect3DTexture9* g_tex = nullptr;
    int g_texW = 0, g_texH = 0, g_pw = 0, g_ph = 0;
    unsigned g_texRev = 0;
    std::string g_texStatus;

    const COLORREF kBgTop = RGB(24, 19, 14), kBgBottom = RGB(10, 8, 6);
    const COLORREF kGold = RGB(201, 165, 90), kGoldDark = RGB(98, 74, 40), kGoldBright = RGB(240, 214, 140);
    const COLORREF kCream = RGB(232, 220, 192), kTaupe = RGB(146, 130, 106), kDim = RGB(104, 92, 76);
    const COLORREF kBand = RGB(70, 22, 15), kBandEdge = RGB(120, 52, 30);

    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }

    int IniKey(const char* section, const char* key, const char* fallback, char* name, int cap)
    {
        GetPrivateProfileStringA(section, key, fallback, name, cap, Paths::GetConfigPath().c_str());
        const char* t = name;
        if (!t[0] || _stricmp(t, "none") == 0) return 0;
        if ((t[0] == 'F' || t[0] == 'f') && t[1] >= '1' && t[1] <= '9') { const int n = atoi(t + 1); if (n >= 1 && n <= 12) return VK_F1 + n - 1; }
        if (_stricmp(t, "Pause") == 0) return VK_PAUSE;
        if (_stricmp(t, "ScrollLock") == 0) return VK_SCROLL;
        if (_stricmp(t, "Insert") == 0) return VK_INSERT;
        if (_stricmp(t, "Home") == 0) return VK_HOME;
        if (_stricmp(t, "End") == 0) return VK_END;
        if (t[1] == 0 && t[0] >= 'a' && t[0] <= 'z') return t[0] - 'a' + 'A';
        if (t[1] == 0) return (unsigned char)t[0];
        return 0;
    }
    std::wstring Wide(const char* s) { std::wstring w; for (; *s; ++s) w += (wchar_t)(unsigned char)*s; return w; }

    // down now, or pressed and let go since the last look (a quick tap between two frames)
    bool KeyDown(int vk) { const SHORT st = GetAsyncKeyState(vk); return (st & 0x8001) != 0; }

    bool GameInFront()
    {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        return pid == GetCurrentProcessId();
    }

    // ---------------- the Voice tab ----------------
    constexpr int kRows = 7;               // (1.7.7: the 7th, "Step away", for Players 2 / 3 and online friends only)
    const wchar_t* kRowName[kRows] = { L"Microphone", L"Voice chat", L"Mic sensitivity", L"Friends' voices", L"Echo cancelling", L"\"Mic off\" reminder", L"Step away" };
    int RowsFor(int player) { return player == 1 ? 6 : 7; }
    void (*g_stepAwayCb)(int) = nullptr;
    const wchar_t* kRowHelp[kRows] = {
        L"Turn your microphone on or off. Off lets go of the microphone completely.",
        L"Off: this PC records nothing and plays no voices.",
        L"Higher picks up quieter speech - and more background noise.",
        L"How loud your friends' voices are.",
        L"Takes the game's sound from your speakers out of your mic. Not needed with a headset.",
        L"A small \"Mic off\" note at the top of the screen while your mic is off.",
        L"Press A: the AI plays your character until you come back with View or START.",
    };

    void ChangeRow(int row, int dir)    // dir -1 / +1, 0 = A (switch)
    {
        OnlineVoice::Prefs p = OnlineVoice::GetPrefs();
        switch (row)
        {
        case 0: p.micOn = !p.micOn; break;
        case 1: p.enabled = !p.enabled; break;
        case 2: if (!dir) return; p.sensitivity = std::clamp(p.sensitivity + dir * 5, 0, 100); break;
        case 3: if (!dir) return; p.volume = std::clamp(p.volume + dir * 10, 0, 200); break;
        case 4: p.echoCancel = !p.echoCancel; break;
        case 5: p.showMicOff = !p.showMicOff; break;
        }
        OnlineVoice::SetPrefs(p);
    }

    // ---------------- the Chat tab (1.7.8) ----------------
    constexpr int kPhrases = 8;
    const wchar_t* kPhrase[kPhrases] = { L"Wait for me", L"Follow me", L"Heal me!", L"Attack my target", L"Ready", L"Loot here", L"Good fight", L"Back in a moment" };

    // ---------------- the Game tab (1.7.8) ----------------
    constexpr int kToughSteps = 7;
    const int kTough[kToughSteps] = { 0, 10, 15, 20, 25, 35, 50 };
    bool GameTabLocked(int player) { return player != 1 || OnlinePlay::Watching(); }   // the host's Player 1 sets it
    void ChangeTough(int dir)
    {
        const int now = ScalingPercent();
        int i = 0;
        if (dir > 0) { while (i < kToughSteps - 1 && kTough[i] <= now) ++i; }                 // the next step up
        else { i = kToughSteps - 1; while (i > 0 && kTough[i] >= now) --i; }                    // the next step down
        ScalingSetPercent(kTough[i]);
    }

    // ---------------- the Controls tab ----------------
    struct Line { int kind; std::wstring key, what; };   // kind 0 heading, 1 entry, 2 note
    std::vector<Line> Controls()
    {
        char k1[32], k2[32], k3[32], b1[32];
        IniKey("Inventory", "HandOverKey", "F3", k1, sizeof(k1));
        IniKey("Voice", "MicKey", "Pause", k2, sizeof(k2));
        IniKey("Menu", "Key", "F10", k3, sizeof(k3));
        GetPrivateProfileStringA("Inventory", "HandOverButton", "RS", b1, sizeof(b1), Paths::GetConfigPath().c_str());
        std::vector<Line> v;
        auto H = [&](const wchar_t* t) { v.push_back({ 0, L"", t }); };
        auto E = [&](const std::wstring& k, const std::wstring& t) { v.push_back({ 1, k, t }); };
        H(L"Players 2 and 3 - in the world");
        E(L"Left stick", L"Move (full tilt runs)");
        E(L"Right stick", L"Turn your own view (split screen)");
        E(L"A", L"Attack the target, or open / loot / use what is in front");
        E(L"D-pad up", L"Use what is in front of you");
        E(L"RB", L"Next enemy");
        E(L"D-pad left / right", L"Pick a friend for heals and buffs");
        E(L"X  Y  B", L"Abilities");
        E(L"Hold RT / LT", L"Ability pages 2 and 3");
        E(L"Hold LB  (1.5 s)", L"Teleport to the Warden");
        E(L"START", L"Level up");
        E(L"Hold View  (2 s)", L"This menu (voice chat, controls, step away)");
        E(L"View", L"Your inventory");
        E(L"View + X / Y / B", L"Inventory / character record / journal");
        E(L"View + START", L"Pause or unpause for everyone");
        E(L"This menu: Step away", L"The AI plays you (View or START comes back)");
        E(L"Hold LS  (2 s)", L"Bring back your character from a backup (when offered)");
        H(L"Menus and screens");
        E(Wide(b1), L"Pass a menu or conversation on to the next player");
        E(Wide(k1) + L"  (keyboard)", L"Player 1 passes it on");
        E(L"LB / RB  (Player 1)", L"Flip tabs while another player holds the screen");
        H(L"Co-op lobby");
        E(L"START or A", L"Join");
        E(L"A", L"Ready");
        E(L"B", L"Back / leave the lobby");
        H(L"Player 1");
        E(L"Hold View  (2 s)", L"This menu (controller 1 - START stays the game menu)");
        if (k3[0] && _stricmp(k3, "none") != 0) E(Wide(k3) + L"  (keyboard)", L"This menu");
        if (k2[0] && _stricmp(k2, "none") != 0) E(Wide(k2) + L"  (keyboard)", L"Microphone on / off");
        H(L"Online chat");
        E(L"Hold START 1 s", L"Players 2 / 3: open the chat line, then type on the keyboard");
        E(L"/  (keyboard)", L"Player 1: open the chat line");
        E(L"Enter", L"Send - your controller is back at once");
        E(L"Esc  /  B", L"Close the line without sending");
        E(L"This menu: Chat", L"Quick phrases with the controller");
        H(L"Online");
        E(L"Hold View + START  (2 s)", L"Friend: leave the host's game");
        E(L"Hold Esc  (1.5 s)", L"Friend: leave the host's game");
        E(L"D-pad / stick, then A", L"Host: answer a join request (or arrows and Enter, or click)");
        E(L"Hold View  (2 s)", L"Friend: this menu, on your own PC");
        return v;
    }
    std::vector<Line>& g_lines = *new std::vector<Line>();

    // ---------------- drawing (GDI into a texture) ----------------
    HFONT MakeFont(int px, bool bold, bool italic, bool heading)
    {
        static const wchar_t* kHead[] = { L"Trajan Pro", L"Cinzel", L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        static const wchar_t* kBody[] = { L"Palatino Linotype", L"Book Antiqua", L"Georgia" };
        const wchar_t* const* list = heading ? kHead : kBody;
        const int n = heading ? 5 : 3;
        HDC dc = CreateCompatibleDC(nullptr);
        for (int i = 0; i < n; ++i)
        {
            HFONT f = CreateFontW(-px, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, italic, FALSE, FALSE, DEFAULT_CHARSET, OUT_TT_PRECIS,
                CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, list[i]);
            HGDIOBJ old = SelectObject(dc, f);
            wchar_t face[64] = {};
            GetTextFaceW(dc, 64, face);
            SelectObject(dc, old);
            if (_wcsicmp(face, list[i]) == 0 || i == n - 1) { DeleteDC(dc); return f; }
            DeleteObject(f);
        }
        DeleteDC(dc);
        return nullptr;
    }

    struct Painter
    {
        HDC dc;
        float s;
        int S(float v) const { return (int)(v * s + 0.5f); }
        void Fill(int x0, int y0, int x1, int y1, COLORREF c) { RECT r = { x0, y0, x1, y1 }; HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b); }
        void LineH(int x0, int x1, int y, COLORREF c, int t = 1) { Fill(x0, y, x1, y + t, c); }
        void Frame(int x0, int y0, int x1, int y1, COLORREF c, int t) { Fill(x0, y0, x1, y0 + t, c); Fill(x0, y1 - t, x1, y1, c); Fill(x0, y0, x0 + t, y1, c); Fill(x1 - t, y0, x1, y1, c); }
        void Diamond(int cx, int cy, int r, COLORREF c)
        {
            POINT p[4] = { { cx, cy - r }, { cx + r, cy }, { cx, cy + r }, { cx - r, cy } };
            HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
            HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
            Polygon(dc, p, 4);
            SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
        }
        void Arrow(int cx, int cy, int r, bool left, COLORREF c)
        {
            const int tip = left ? cx - r : cx + r, back = left ? cx + r / 2 : cx - r / 2;
            POINT q[3] = { { tip, cy }, { back, cy - r }, { back, cy + r } };
            HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
            HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
            Polygon(dc, q, 3);
            SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
        }
        void ArrowV(int cx, int cy, int r, bool up, COLORREF c)
        {
            POINT q[3] = { { cx, up ? cy - r : cy + r }, { cx - r, up ? cy + r / 2 : cy - r / 2 }, { cx + r, up ? cy + r / 2 : cy - r / 2 } };
            HBRUSH b = CreateSolidBrush(c); HPEN pen = CreatePen(PS_SOLID, 1, c);
            HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
            Polygon(dc, q, 3);
            SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
        }
        int Width(HFONT f, const std::wstring& t, int spacing = 0)
        {
            HGDIOBJ o = SelectObject(dc, f);
            SetTextCharacterExtra(dc, spacing);
            SIZE sz = {};
            GetTextExtentPoint32W(dc, t.c_str(), (int)t.size(), &sz);
            SetTextCharacterExtra(dc, 0);
            SelectObject(dc, o);
            return sz.cx;
        }
        // align: 0 left, 1 centre, 2 right (x is that edge / the centre); y = the text's middle
        void Text(HFONT f, COLORREF c, const std::wstring& t, int x, int y, int align, int spacing = 0)
        {
            HGDIOBJ o = SelectObject(dc, f);
            SetTextCharacterExtra(dc, spacing);
            SetTextColor(dc, c);
            SIZE sz = {};
            GetTextExtentPoint32W(dc, t.c_str(), (int)t.size(), &sz);
            int x0 = align == 0 ? x : align == 1 ? x - sz.cx / 2 : x - sz.cx;
            TextOutW(dc, x0, y - sz.cy / 2, t.c_str(), (int)t.size());
            SetTextCharacterExtra(dc, 0);
            SelectObject(dc, o);
        }
        // a button picture for the hints: A B X Y in their colours, others in a dark plate
        int Glyph(HFONT f, const std::wstring& label, int x, int y)
        {
            COLORREF fill = RGB(46, 38, 30), ink = kCream;
            bool round = false;
            if (label == L"A") { fill = RGB(84, 140, 52); round = true; }
            else if (label == L"B") { fill = RGB(176, 52, 40); round = true; }
            else if (label == L"X") { fill = RGB(46, 102, 170); round = true; }
            else if (label == L"Y") { fill = RGB(206, 156, 28); round = true; ink = RGB(30, 22, 10); }
            const int h = S(26);
            const int w = round ? h : Width(f, label) + S(16);
            HBRUSH b = CreateSolidBrush(fill); HPEN pen = CreatePen(PS_SOLID, 1, kGoldDark);
            HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, pen);
            if (round) Ellipse(dc, x, y - h / 2, x + w, y + h / 2);
            else RoundRect(dc, x, y - h / 2, x + w, y + h / 2, S(10), S(10));
            SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(pen);
            Text(f, ink, label, x + w / 2, y, 1);
            return w;
        }
        void Divider(int x0, int x1, int y)
        {
            LineH(x0, x1, y, kGoldDark);
            LineH(x0 + S(30), x1 - S(30), y, kGold);
            Diamond((x0 + x1) / 2, y, S(6), kGold);
            Diamond((x0 + x1) / 2, y, S(3), kBgTop);
        }
    };

    struct View { int tab, sel, scroll, player, pad; OnlineVoice::Prefs prefs; std::string status; };

    bool Render(IDirect3DDevice9* dev, const View& v, float s, int pw, int ph)
    {
        const int tw = Pow2(pw), th = Pow2(ph);
        if (!g_tex || g_texW != tw || g_texH != th)
        {
            if (g_tex) { g_tex->Release(); g_tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex)
            {
                g_tex = nullptr;
                Log("Co-op menu: could not make its texture (%dx%d)", tw, th);
                return false;
            }
            g_texW = tw; g_texH = th;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
        bi.bmiHeader.biWidth = pw;
        bi.bmiHeader.biHeight = -ph;
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HDC dc = CreateCompatibleDC(nullptr);
        HBITMAP bmp = dc ? CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0) : nullptr;
        if (!dc || !bmp || !bits) { if (bmp) DeleteObject(bmp); if (dc) DeleteDC(dc); return false; }
        HGDIOBJ oldBmp = SelectObject(dc, bmp);
        SetBkMode(dc, TRANSPARENT);
        Painter P{ dc, s };
        auto S = [&](float x) { return P.S(x); };

        // background: warm near-black, lighter at the top
        for (int y = 0; y < ph; ++y)
        {
            const float t = (float)y / ph;
            P.Fill(0, y, pw, y + 1, RGB((int)(GetRValue(kBgTop) * (1 - t) + GetRValue(kBgBottom) * t),
                (int)(GetGValue(kBgTop) * (1 - t) + GetGValue(kBgBottom) * t), (int)(GetBValue(kBgTop) * (1 - t) + GetBValue(kBgBottom) * t)));
        }
        // the frame: dark - gold - dark, diamonds in the corners
        P.Frame(S(5), S(5), pw - S(5), ph - S(5), kGoldDark, std::max(1, S(1)));
        P.Frame(S(9), S(9), pw - S(9), ph - S(9), kGold, std::max(1, S(2)));
        P.Frame(S(14), S(14), pw - S(14), ph - S(14), kGoldDark, std::max(1, S(1)));
        const int c = S(11);
        P.Diamond(c, c, S(7), kGold); P.Diamond(pw - c, c, S(7), kGold); P.Diamond(c, ph - c, S(7), kGold); P.Diamond(pw - c, ph - c, S(7), kGold);
        P.Diamond(c, c, S(3), kBgTop); P.Diamond(pw - c, c, S(3), kBgTop); P.Diamond(c, ph - c, S(3), kBgBottom); P.Diamond(pw - c, ph - c, S(3), kBgBottom);

        HFONT fTitle = MakeFont(S(36), true, false, true), fSub = MakeFont(S(17), false, true, false), fTab = MakeFont(S(21), true, false, true),
              fRow = MakeFont(S(23), false, false, false), fVal = MakeFont(S(22), true, false, false), fHelp = MakeFont(S(18), false, true, false),
              fHead = MakeFont(S(17), true, false, true), fKey = MakeFont(S(19), true, false, false), fWhat = MakeFont(S(19), false, false, false),
              fHint = MakeFont(S(16), true, false, false);

        // title
        P.Text(fTitle, kGold, L"CO-OP", pw / 2, S(46), 1, S(6));
        std::wstring who = v.player >= 1 && v.player <= 3 ? L"Player " + std::to_wstring(v.player) : L"Online - your own PC";
        if (v.pad < 0) who += L"  (keyboard)";
        P.Text(fSub, kTaupe, who, pw / 2, S(82), 1);
        P.Divider(S(70), pw - S(70), S(106));

        // tabs, LB / RB beside them
        const wchar_t* tabs[4] = { L"VOICE", L"CHAT", L"GAME", L"CONTROLS" };
        const int tabY = S(138), gap = S(50);
        int tws[4], tx[4], total = gap * 3;
        for (int i = 0; i < 4; ++i) { tws[i] = P.Width(fTab, tabs[i], S(4)); total += tws[i]; }
        const int tx0 = pw / 2 - total / 2;
        for (int i = 0, x = tx0; i < 4; ++i) { tx[i] = x; x += tws[i] + gap; }
        const int w1 = tws[3];
        for (int i = 0; i < 4; ++i)
        {
            const bool on = v.tab == i;
            P.Text(fTab, on ? kCream : kDim, tabs[i], tx[i], tabY, 0, S(4));
            if (on)
            {
                P.LineH(tx[i] - S(6), tx[i] + tws[i] + S(6), tabY + S(17), kGold, std::max(1, S(2)));
                P.Diamond(tx[i] + tws[i] / 2, tabY + S(18), S(4), kGoldBright);
            }
        }
        if (v.pad >= 0)
        {
            P.Glyph(fHint, L"LB", tx0 - S(78), tabY);
            P.Glyph(fHint, L"RB", tx[3] + w1 + S(30), tabY);
        }
        P.LineH(S(60), pw - S(60), S(168), kGoldDark);

        const int top = S(184), bottom = ph - S(84);
        if (v.tab == 0)
        {
            const int rows = RowsFor(v.player);
            const int rowH = S(rows > 6 ? 46 : 52), lx = S(96), vx0 = pw - S(400), vx1 = pw - S(96);
            for (int r = 0; r < rows; ++r)
            {
                const int y0 = top + r * rowH, cy = y0 + rowH / 2;
                const bool sel = v.sel == r;
                if (sel)
                {
                    // the chosen row: a dark red band fading out to the right, gold edge on the left
                    for (int x = S(60); x < pw - S(60); ++x)
                    {
                        const float t = (float)(x - S(60)) / (pw - S(120));
                        const float a = t < 0.65f ? 1.0f : 1.0f - (t - 0.65f) / 0.35f * 0.7f;
                        const COLORREF b = RGB((int)(GetRValue(kBand) * a + 14 * (1 - a)), (int)(GetGValue(kBand) * a + 11 * (1 - a)), (int)(GetBValue(kBand) * a + 8 * (1 - a)));
                        P.Fill(x, y0 + S(4), x + 1, y0 + rowH - S(4), b);
                    }
                    P.LineH(S(60), pw - S(60), y0 + S(4), kBandEdge);
                    P.LineH(S(60), pw - S(60), y0 + rowH - S(5), kBandEdge);
                    P.Fill(S(60), y0 + S(4), S(64), y0 + rowH - S(4), kGold);
                    P.Diamond(S(78), cy, S(5), kGoldBright);
                }
                P.Text(fRow, sel ? kCream : RGB(200, 188, 162), kRowName[r], lx, cy, 0);
                const COLORREF valC = sel ? kGoldBright : kGold;
                if (r == 6)
                {
                    P.Text(fVal, valC, sel ? L"Press A" : L"", (vx0 + vx1) / 2 + S(20), cy, 1);
                }
                else if (r == 2 || r == 3)
                {
                    const int val = r == 2 ? v.prefs.sensitivity : v.prefs.volume, max = r == 2 ? 100 : 200;
                    const int bx0 = vx0 + S(20), bx1 = vx1 - S(70);
                    P.Fill(bx0, cy - S(2), bx1, cy + S(2), RGB(58, 48, 38));
                    const int fx = bx0 + (bx1 - bx0) * val / max;
                    P.Fill(bx0, cy - S(2), fx, cy + S(2), RGB(184, 145, 63));
                    if (r == 3) { const int mx = bx0 + (bx1 - bx0) / 2; P.Fill(mx, cy - S(6), mx + 1, cy + S(6), kGoldDark); }   // 100 %
                    P.Diamond(fx, cy, S(8), valC);
                    P.Diamond(fx, cy, S(3), kBgBottom);
                    P.Text(fVal, valC, std::to_wstring(val) + (r == 3 ? L"%" : L""), vx1, cy, 2);
                }
                else
                {
                    bool on = r == 0 ? v.prefs.micOn : r == 1 ? v.prefs.enabled : r == 4 ? v.prefs.echoCancel : v.prefs.showMicOff;
                    std::wstring t = r == 5 ? (on ? L"Shown" : L"Hidden") : (on ? L"On" : L"Off");
                    const int mid = (vx0 + vx1) / 2 + S(20);
                    P.Text(fVal, on ? valC : (sel ? kCream : kTaupe), t, mid, cy, 1);
                    if (sel) { const int half = P.Width(fVal, t) / 2 + S(22); P.Arrow(mid - half, cy, S(7), true, kGold); P.Arrow(mid + half, cy, S(7), false, kGold); }
                }
            }
            const int hy = top + rows * rowH + S(16);
            P.Text(fHelp, kTaupe, kRowHelp[std::clamp(v.sel, 0, rows - 1)], pw / 2, hy, 1);
            std::wstring st;
            if (!v.status.empty()) { st = L"Now: "; for (char ch : v.status) st += (wchar_t)(unsigned char)ch; }
            else st = L"Voice chat starts when you play online. These settings are kept for next time.";
            P.Text(fHelp, kDim, st, pw / 2, hy + S(30), 1);
        }
        else if (v.tab == 1)
        {
            const int rowH = S(44), lx = S(96);
            for (int r = 0; r < kPhrases; ++r)
            {
                const int y0 = top + r * rowH, cy = y0 + rowH / 2;
                const bool sel = v.sel == r;
                if (sel)
                {
                    for (int x = S(60); x < pw - S(60); ++x)
                    {
                        const float t = (float)(x - S(60)) / (pw - S(120));
                        const float a = t < 0.65f ? 1.0f : 1.0f - (t - 0.65f) / 0.35f * 0.7f;
                        const COLORREF b = RGB((int)(GetRValue(kBand) * a + 14 * (1 - a)), (int)(GetGValue(kBand) * a + 11 * (1 - a)), (int)(GetBValue(kBand) * a + 8 * (1 - a)));
                        P.Fill(x, y0 + S(4), x + 1, y0 + rowH - S(4), b);
                    }
                    P.LineH(S(60), pw - S(60), y0 + S(4), kBandEdge);
                    P.LineH(S(60), pw - S(60), y0 + rowH - S(5), kBandEdge);
                    P.Fill(S(60), y0 + S(4), S(64), y0 + rowH - S(4), kGold);
                    P.Diamond(S(78), cy, S(5), kGoldBright);
                }
                P.Text(fRow, sel ? kCream : RGB(200, 188, 162), std::wstring(L"\u201C") + kPhrase[r] + L"\u201D", lx, cy, 0);
                if (sel) P.Text(fVal, kGoldBright, L"Send", pw - S(150), cy, 1);
            }
            const int hy = top + kPhrases * rowH + S(14);
            P.Text(fHelp, kTaupe, OnlineChat::Active() ? L"Sends it to everyone. Or hold START 1 s (or press /) and type (Enter sends)."
                                                         : L"Chat works in online games.", pw / 2, hy, 1);
        }
        else if (v.tab == 2)
        {
            // Game: how much tougher enemies get for each player after the first
            const int rowH = S(52), lx = S(96), vx0 = pw - S(400), vx1 = pw - S(96);
            const int y0 = top, cy = y0 + rowH / 2;
            const bool locked = GameTabLocked(v.player);
            for (int x = S(60); x < pw - S(60); ++x)
            {
                const float t = (float)(x - S(60)) / (pw - S(120));
                const float a = t < 0.65f ? 1.0f : 1.0f - (t - 0.65f) / 0.35f * 0.7f;
                const COLORREF b = RGB((int)(GetRValue(kBand) * a + 14 * (1 - a)), (int)(GetGValue(kBand) * a + 11 * (1 - a)), (int)(GetBValue(kBand) * a + 8 * (1 - a)));
                P.Fill(x, y0 + S(4), x + 1, y0 + rowH - S(4), b);
            }
            P.LineH(S(60), pw - S(60), y0 + S(4), kBandEdge);
            P.LineH(S(60), pw - S(60), y0 + rowH - S(5), kBandEdge);
            P.Fill(S(60), y0 + S(4), S(64), y0 + rowH - S(4), kGold);
            P.Diamond(S(78), cy, S(5), kGoldBright);
            P.Text(fRow, kCream, L"Enemy toughness", lx, cy, 0);
            const int pct = ScalingPercent();
            const std::wstring t = pct ? L"+" + std::to_wstring(pct) + L"% per player" : L"Off";
            const int mid = (vx0 + vx1) / 2 + S(20);
            P.Text(fVal, locked ? kTaupe : kGoldBright, t, mid, cy, 1);
            if (!locked) { const int half = P.Width(fVal, t) / 2 + S(22); P.Arrow(mid - half, cy, S(7), true, kGold); P.Arrow(mid + half, cy, S(7), false, kGold); }
            const int hy = top + rowH + S(16);
            P.Text(fHelp, kTaupe, L"Every player after the first makes enemies this much tougher (health and damage).", pw / 2, hy, 1);
            P.Text(fHelp, kDim, locked ? L"Set by the host (Player 1)." : L"Enemies you already met keep theirs. Kept for next time.", pw / 2, hy + S(30), 1);
        }
        else
        {
            const int keyX = S(330), whatX = S(356), lineH = S(30), headH = S(44);
            int y = top;
            const int n = (int)g_lines.size();
            for (int i = v.scroll; i < n; ++i)
            {
                const Line& l = g_lines[i];
                const int h = l.kind == 0 ? headH : lineH;
                if (y + h > bottom) break;
                if (l.kind == 0)
                {
                    std::wstring up;
                    for (wchar_t ch : l.what) up += (wchar_t)towupper(ch);
                    const int cy = y + headH / 2 + S(4);
                    const int w = P.Width(fHead, up, S(3));
                    P.Text(fHead, kGold, up, pw / 2, cy, 1, S(3));
                    P.LineH(S(90), pw / 2 - w / 2 - S(18), cy, kGoldDark);
                    P.LineH(pw / 2 + w / 2 + S(18), pw - S(90), cy, kGoldDark);
                    P.Diamond(pw / 2 - w / 2 - S(10), cy, S(3), kGold);
                    P.Diamond(pw / 2 + w / 2 + S(10), cy, S(3), kGold);
                }
                else
                {
                    const int cy = y + lineH / 2;
                    P.Text(fKey, RGB(217, 185, 119), l.key, keyX, cy, 2);
                    P.Text(fWhat, kCream, l.what, whatX, cy, 0);
                }
                y += h;
            }
            if (v.scroll > 0) P.ArrowV(pw - S(50), top + S(10), S(8), true, kGold);
            // more below?
            int yy = top; bool more = false;
            for (int i = v.scroll; i < n; ++i) { yy += g_lines[i].kind == 0 ? headH : lineH; if (yy > bottom) { more = true; break; } }
            if (more) P.ArrowV(pw - S(50), bottom - S(10), S(8), false, kGold);
        }

        // footer: what the buttons do
        P.Divider(S(70), pw - S(70), ph - S(66));
        {
            struct Hint { std::vector<std::wstring> keys; std::wstring what; };
            std::vector<Hint> hints;
            if (v.pad >= 0)
            {
                hints.push_back({ { L"LB", L"RB" }, L"Tabs" });
                if (v.tab == 0) { hints.push_back({ { L"D-pad" }, L"Choose / change" }); hints.push_back({ { L"A" }, L"Switch" }); }
                else if (v.tab == 1) { hints.push_back({ { L"D-pad" }, L"Choose" }); hints.push_back({ { L"A" }, L"Send" }); }
                else if (v.tab == 2) { if (!GameTabLocked(v.player)) hints.push_back({ { L"D-pad" }, L"Change" }); }
                else hints.push_back({ { L"D-pad" }, L"Scroll" });
                hints.push_back({ { L"B" }, L"Close" });
            }
            else
            {
                hints.push_back({ { L"Tab" }, L"Tabs" });
                hints.push_back({ { L"Arrows" }, v.tab == 0 ? L"Choose / change" : v.tab == 1 ? L"Choose" : v.tab == 2 ? L"Change" : L"Scroll" });
                if (v.tab == 0) hints.push_back({ { L"Enter" }, L"Switch" });
                else if (v.tab == 1) hints.push_back({ { L"Enter" }, L"Send" });
                hints.push_back({ { L"Backspace" }, L"Close" });
            }
            // measure, then centre
            int total = 0;
            for (const Hint& h : hints)
            {
                for (const auto& k : h.keys) total += (k.size() == 1 ? S(26) : P.Width(fHint, k) + S(16)) + S(6);
                total += P.Width(fHint, h.what) + S(34);
            }
            int x = pw / 2 - total / 2;
            const int y = ph - S(36);
            for (const Hint& h : hints)
            {
                for (const auto& k : h.keys) x += P.Glyph(fHint, k, x, y) + S(6);
                P.Text(fHint, kTaupe, h.what, x + S(4), y, 0);
                x += P.Width(fHint, h.what) + S(34);
            }
        }

        for (HFONT f : { fTitle, fSub, fTab, fRow, fVal, fHelp, fHead, fKey, fWhat, fHint }) if (f) DeleteObject(f);
        GdiFlush();
        bool ok = false;
        D3DLOCKED_RECT lr;
        if (SUCCEEDED(g_tex->LockRect(0, &lr, nullptr, 0)))
        {
            for (int y = 0; y < th; ++y)
            {
                uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch);
                if (y >= ph) { std::memset(dst, 0, size_t(tw) * 4); continue; }
                const uint32_t* src = static_cast<const uint32_t*>(bits) + size_t(y) * pw;
                for (int x = 0; x < pw; ++x) dst[x] = (src[x] & 0x00FFFFFF) | 0xF4000000u;
                if (tw > pw) std::memset(dst + pw, 0, size_t(tw - pw) * 4);
            }
            g_tex->UnlockRect(0);
            ok = true;
        }
        SelectObject(dc, oldBmp);
        DeleteObject(bmp);
        DeleteDC(dc);
        return ok;
    }

    struct Vtx { float x, y, z, rhw; DWORD c; float u, v; };

    void Close(const char* how)
    {
        std::lock_guard<std::mutex> lock(g_m);
        if (!g_open) return;
        g_open = false;
        g_closedAt = GetTickCount();
        g_closedFor = g_player;
        ++g_rev;
        Log("Co-op menu: closed (%s)", how);
    }

    // The owner's buttons / keys, once a frame: what was newly pressed (with repeats for the D-pad / stick / arrows).
    void ReadInput(int pad, bool& up, bool& down, bool& left, bool& right, bool& a, bool& b, bool& lb, bool& rb)
    {
        up = down = left = right = a = b = lb = rb = false;
        const DWORD now = GetTickCount();
        int dir = 0;
        if (pad >= 0)
        {
            XINPUT_STATE st = {};
            if (XInputGetState((DWORD)pad, &st) != ERROR_SUCCESS) { g_prevButtons = 0; return; }
            const WORD bt = st.Gamepad.wButtons, pr = (WORD)(bt & ~g_prevButtons);
            g_prevButtons = bt;
            a = (pr & XINPUT_GAMEPAD_A) != 0;
            b = (pr & (XINPUT_GAMEPAD_B | XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_BACK)) != 0;
            lb = (pr & XINPUT_GAMEPAD_LEFT_SHOULDER) != 0;
            rb = (pr & XINPUT_GAMEPAD_RIGHT_SHOULDER) != 0;
            const int ly = st.Gamepad.sThumbLY, lx = st.Gamepad.sThumbLX;
            if ((bt & XINPUT_GAMEPAD_DPAD_UP) || ly > 16000) dir = 1;
            else if ((bt & XINPUT_GAMEPAD_DPAD_DOWN) || ly < -16000) dir = 2;
            else if ((bt & XINPUT_GAMEPAD_DPAD_LEFT) || lx < -16000) dir = 3;
            else if ((bt & XINPUT_GAMEPAD_DPAD_RIGHT) || lx > 16000) dir = 4;
        }
        else
        {
            const bool front = GameInFront();
            const int keys[10] = { VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT, VK_RETURN, VK_SPACE, VK_BACK, VK_TAB, VK_PRIOR, VK_NEXT };
            bool d[10], pr[10];
            for (int i = 0; i < 10; ++i) { d[i] = front && KeyDown(keys[i]); pr[i] = d[i] && !g_prevKeys[i]; g_prevKeys[i] = d[i]; }
            a = pr[4] || pr[5];
            b = pr[6];
            rb = pr[7] || pr[9];
            lb = pr[8];
            dir = d[0] ? 1 : d[1] ? 2 : d[2] ? 3 : d[3] ? 4 : 0;
        }
        if (dir != g_repeatDir) { g_repeatDir = dir; g_repeatAt = now + 380; if (dir) { up = dir == 1; down = dir == 2; left = dir == 3; right = dir == 4; } }
        else if (dir && (int)(now - g_repeatAt) >= 0) { g_repeatAt = now + 110; up = dir == 1; down = dir == 2; left = dir == 3; right = dir == 4; }
    }

    int MaxScroll()
    {
        // the first line that still lets the last one be seen (about 13 lines fit)
        const int n = (int)g_lines.size();
        int h = 0, i = n;
        while (i > 0) { const int add = g_lines[i - 1].kind == 0 ? 44 : 30; if (h + add > 380) break; h += add; --i; }
        return std::max(0, i);
    }
}

void ModMenuSetStepAway(void (*cb)(int player)) { g_stepAwayCb = cb; }

void ModMenuShow(int player, int padIndex)
{
    {
        std::lock_guard<std::mutex> lock(g_m);
        if (g_open) return;
        g_open = true;
        g_player = player;
        g_pad = padIndex;
        g_sel = 0; g_scroll = 0;
        ++g_rev;
    }
    Log("Co-op menu: opened by %s%d (%s)", player ? "Player " : "the online friend ", player, padIndex >= 0 ? "controller" : "keyboard");
}

bool ModMenuOpen()
{
    std::lock_guard<std::mutex> lock(g_m);
    return g_open || GetTickCount() - g_closedAt < 400;
}

bool ModMenuOpenFor(int player)
{
    std::lock_guard<std::mutex> lock(g_m);
    if (g_open) return g_player == player;
    return g_closedFor == player && GetTickCount() - g_closedAt < 400;
}

void ModMenuDraw(IDirect3DDevice9* dev)
{
    if (!dev) return;
    if (dev != g_dev) { g_tex = nullptr; g_dev = dev; g_texRev = 0; }   // (the old texture belongs to the old device)
    const DWORD now = GetTickCount();

    // opening: Player 1's View held 2 s (their controller, through the game's controller hook), or the menu key
    if (g_menuKey < 0) { char k[32]; g_menuKey = IniKey("Menu", "Key", "F10", k, sizeof(k)); }
    const bool keyDown = g_menuKey && GameInFront() && !OnlineChat::Typing() && KeyDown(g_menuKey);
    const bool keyPressed = keyDown && !g_menuKeyWas;
    g_menuKeyWas = keyDown;
    bool open; int pad, player;
    { std::lock_guard<std::mutex> lock(g_m); open = g_open; pad = g_pad; player = g_player; }
    if (!open)
    {
        // P1's controller 1 hold (host / split screen). A friend watching a host's game opens it from their own
        // controller in the online code; their keyboard key works here as on any PC.
        if (XInputRouteTakeStartHold()) { ModMenuShow(1, 0); open = true; }
        else if (keyPressed) { ModMenuShow(OnlinePlay::Watching() ? 0 : 1, -1); open = true; }
        if (open) { std::lock_guard<std::mutex> lock(g_m); pad = g_pad; player = g_player; }
    }
    else if (keyPressed) { Close("menu key"); open = false; }
    if (open && !g_wasOpen)
    {
        // just opened (here, by Player 2/3's START or by a friend's own controller)
        g_lines = Controls();
        g_prevButtons = 0xFFFF; for (bool& k : g_prevKeys) k = true;   // what is held right now is not a press
        g_repeatDir = -1;
    }
    g_wasOpen = open;

    // Player 1's controller: the game sees it idle while the menu has it (and a moment after)
    const bool wantHold = (open && player == 1 && pad == 0) || (!open && g_holdMenu && now - g_closedAt < 400);
    if (wantHold != g_holdMenu) { g_holdMenu = wantHold; XInputRouteHoldMenu(wantHold); }
    if (!open) return;

    bool up, down, left, right, a, b, lb, rb;
    ReadInput(pad, up, down, left, right, a, b, lb, rb);
    if (b) { Close("B"); g_wasOpen = false; return; }
    {
        std::lock_guard<std::mutex> lock(g_m);
        if (lb || rb) { g_tab = (g_tab + (rb ? 1 : 3)) % 4; g_scroll = 0; g_sel = 0; ++g_rev; }
        if (g_tab <= 1)
        {
            const int rows = g_tab == 0 ? RowsFor(g_player) : kPhrases;
            if (up) { g_sel = (g_sel + rows - 1) % rows; ++g_rev; }
            if (down) { g_sel = (g_sel + 1) % rows; ++g_rev; }
        }
        else if (g_tab == 3)
        {
            if (up && g_scroll > 0) { --g_scroll; ++g_rev; }
            if (down && g_scroll < MaxScroll()) { ++g_scroll; ++g_rev; }
        }
    }
    int tab, sel;
    { std::lock_guard<std::mutex> lock(g_m); tab = g_tab; sel = g_sel; }
    if (tab == 1) {
        if (a && OnlineChat::Active() && sel >= 0 && sel < kPhrases) {   // 1.7.8 quick chat: sent, and the controller is back
            std::wstring name;
            if (player == 2 || player == 3) { wchar_t n[64] = {}; TargetUiName(player, n, 64); name = n; }
            OnlineChat::Say(static_cast<uint8_t>(player == 2 || player == 3 ? player : 0), name, kPhrase[sel]);
            Close("quick chat");
            g_wasOpen = false;
            return;
        }
    }
    else if (tab == 2) {
        if ((left || right) && !GameTabLocked(player)) { ChangeTough(left ? -1 : 1); std::lock_guard<std::mutex> lock(g_m); ++g_rev; }
    }
    else if (tab == 0 && sel == 6) {
        if (a) {                                       // 1.7.7: Step away (was View held 2 s)
            if (player == 0) OnlinePlay::StepAway();                   // a friend's PC: the host gets View held
            else if (g_stepAwayCb && (player == 2 || player == 3)) g_stepAwayCb(player);
            Close("Step away");
            g_wasOpen = false;
            return;
        }
    }
    else if (tab == 0 && (left || right || a)) { ChangeRow(sel, left ? -1 : right ? 1 : 0); std::lock_guard<std::mutex> lock(g_m); ++g_rev; }

    int W = 0, H = 0;
    if (!D3D9BackBufferSize(&W, &H) || W <= 0 || H <= 0) return;
    float s = std::max(0.5f, H / 1080.f);
    int pw = (int)(940 * s + 0.5f), ph = (int)(680 * s + 0.5f);
    if (pw > W - 16) { s *= (float)(W - 16) / pw; pw = (int)(940 * s + 0.5f); ph = (int)(680 * s + 0.5f); }
    if (ph > H - 16) { s *= (float)(H - 16) / ph; pw = (int)(940 * s + 0.5f); ph = (int)(680 * s + 0.5f); }

    View v;
    { std::lock_guard<std::mutex> lock(g_m); v.tab = g_tab; v.sel = g_sel; v.scroll = g_scroll; v.player = g_player; v.pad = g_pad; }
    v.prefs = OnlineVoice::GetPrefs();
    v.status = OnlineVoice::MicStatus();
    unsigned rev;
    { std::lock_guard<std::mutex> lock(g_m); rev = g_rev; }
    if (!g_tex || rev != g_texRev || pw != g_pw || ph != g_ph || v.status != g_texStatus)
    {
        if (!Render(dev, v, s, pw, ph)) return;
        g_texRev = rev; g_pw = pw; g_ph = ph; g_texStatus = v.status;
    }

    IDirect3DStateBlock9* sb = D3D9SaveState(dev, 6);
    if (!sb) return;
    IDirect3DSurface9 *oldRt = nullptr, *oldDs = nullptr, *bb = nullptr;
    dev->GetRenderTarget(0, &oldRt);
    dev->GetDepthStencilSurface(&oldDs);
    if (SUCCEEDED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) && bb)
    {
        dev->SetRenderTarget(0, bb);
        dev->SetDepthStencilSurface(nullptr);
        if (SUCCEEDED(dev->BeginScene()))
        {
            D3DVIEWPORT9 vp = { 0, 0, (DWORD)W, (DWORD)H, 0.f, 1.f };
            dev->SetViewport(&vp);
            dev->SetVertexShader(nullptr);
            dev->SetPixelShader(nullptr);
            dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
            dev->SetRenderState(D3DRS_ZENABLE, FALSE);
            dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
            dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
            dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
            dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
            dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
            dev->SetRenderState(D3DRS_LIGHTING, FALSE);
            dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
            dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
            dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
            dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
            dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
            dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
            dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
            dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
            dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
            dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
            dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
            dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
            dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
            dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
            dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
            dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
            // the game behind it dimmed, like its own menus
            dev->SetTexture(0, nullptr);
            dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG2);
            dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG2);
            const DWORD shade = 0x99000000;
            const Vtx dim[4] = { { -0.5f, -0.5f, 0, 1, shade, 0, 0 }, { W - 0.5f, -0.5f, 0, 1, shade, 0, 0 },
                                 { -0.5f, H - 0.5f, 0, 1, shade, 0, 0 }, { W - 0.5f, H - 0.5f, 0, 1, shade, 0, 0 } };
            dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, dim, sizeof(Vtx));
            // the panel
            dev->SetTexture(0, g_tex);
            dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
            dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
            const float x0 = (float)((W - pw) / 2) - 0.5f, y0 = (float)((H - ph) / 2) - 0.5f;
            const float u1 = (float)pw / g_texW, v1 = (float)ph / g_texH;
            const DWORD white = 0xFFFFFFFF;
            const Vtx q[4] = { { x0, y0, 0, 1, white, 0, 0 }, { x0 + pw, y0, 0, 1, white, u1, 0 },
                               { x0, y0 + ph, 0, 1, white, 0, v1 }, { x0 + pw, y0 + ph, 0, 1, white, u1, v1 } };
            dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, q, sizeof(Vtx));
            dev->SetTexture(0, nullptr);
            dev->EndScene();
        }
        bb->Release();
    }
    if (oldRt) { dev->SetRenderTarget(0, oldRt); oldRt->Release(); }
    dev->SetDepthStencilSurface(oldDs);
    if (oldDs) oldDs->Release();
    sb->Apply();
}
