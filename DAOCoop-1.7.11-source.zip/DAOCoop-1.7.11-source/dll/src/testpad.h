#pragma once
// 1.7.0 testing: a virtual controller (slot 4) driven by [TestPad] in DAOCoop.ini (testpad.cpp).
void TestPadInit(const wchar_t* iniPath);
// Main thread (the co-op tick): runs what the test pad asked for that needs the game's script (SCAN).
void TestPadMainThread();
