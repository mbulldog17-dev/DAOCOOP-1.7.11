#include "popup.h"
#include "d3d9hook.h"
#include "log.h"
#include <windows.h>
#include <d3d9.h>
#include <cstring>
#include <cstdint>

namespace
{
    CRITICAL_SECTION g_cs;
    bool g_init = false;

    // what to show (any thread writes, the render thread reads)
    bool g_show = false;
    DWORD g_noticeUntil = 0;          // a notice (no buttons) hides itself at this time
    std::wstring g_title, g_sub;
    int g_sel = 0;
    unsigned g_rev = 1;

    // where the buttons were drawn (back buffer pixels)
    RECT g_btn[2] = {};
    bool g_btnValid = false;

    // render thread only
    IDirect3DDevice9* g_dev = nullptr;
    IDirect3DTexture9* g_tex = nullptr;
    unsigned g_texRev = 0;
    int g_texW = 0, g_texH = 0, g_pw = 0, g_ph = 0;

    const COLORREF kBg = RGB(20, 16, 12), kGold = RGB(200, 160, 82), kDark = RGB(42, 34, 26),
                   kWhite = RGB(240, 232, 214), kGrey = RGB(160, 150, 134), kInk = RGB(24, 18, 10);

    int Pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }

    HFONT Font(int px, bool bold)
    {
        return CreateFontW(-px, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                           CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, L"Georgia");
    }

    void Text(HDC dc, HFONT f, COLORREF c, const std::wstring& s, RECT r)
    {
        HGDIOBJ old = SelectObject(dc, f);
        SetTextColor(dc, c);
        DrawTextW(dc, s.c_str(), -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_END_ELLIPSIS);
        SelectObject(dc, old);
    }

    void Fill(HDC dc, RECT r, COLORREF c)
    {
        HBRUSH b = CreateSolidBrush(c);
        FillRect(dc, &r, b);
        DeleteObject(b);
    }

    void Frame(HDC dc, RECT r, COLORREF c, int t)
    {
        for (int i = 0; i < t; ++i) { RECT q = { r.left + i, r.top + i, r.right - i, r.bottom - i }; HBRUSH b = CreateSolidBrush(c); FrameRect(dc, &q, b); DeleteObject(b); }
    }

    // Draws the whole box into the texture. Returns the button rects (box pixels).
    bool Render(IDirect3DDevice9* dev, int pw, int ph, float s, const std::wstring& title, const std::wstring& sub, int sel, RECT btn[2])
    {
        const int tw = Pow2(pw), th = Pow2(ph);
        if (!g_tex || g_texW != tw || g_texH != th)
        {
            if (g_tex) { g_tex->Release(); g_tex = nullptr; }
            if (FAILED(dev->CreateTexture(tw, th, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &g_tex, nullptr)) || !g_tex)
            {
                Log("Pop-up: could not make its texture (%dx%d)", tw, th);
                g_tex = nullptr;
                return false;
            }
            g_texW = tw; g_texH = th;
        }

        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
        bi.bmiHeader.biWidth = pw;
        bi.bmiHeader.biHeight = -ph;   // top-down
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HDC dc = CreateCompatibleDC(nullptr);
        HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        if (!dc || !bmp || !bits) { if (bmp) DeleteObject(bmp); if (dc) DeleteDC(dc); return false; }
        HGDIOBJ oldBmp = SelectObject(dc, bmp);
        SetBkMode(dc, TRANSPARENT);

        auto S = [&](float v) { return (int)(v * s + 0.5f); };
        Fill(dc, RECT{ 0, 0, pw, ph }, kBg);
        Frame(dc, RECT{ 0, 0, pw, ph }, kGold, S(2) < 1 ? 1 : S(2));

        HFONT fTitle = Font(S(30), true), fSub = Font(S(20), false), fBtn = Font(S(26), true), fHint = Font(S(16), false);
        Text(dc, fTitle, kWhite, title, RECT{ S(16), S(14), pw - S(16), S(58) });
        Text(dc, fSub, kGrey, sub, RECT{ S(16), S(62), pw - S(16), S(92) });

        const int bw = S(190), bh = S(50), gap = S(40), by = S(108);
        const int bx0 = (pw - (bw * 2 + gap)) / 2;
        const wchar_t* label[2] = { L"Yes", L"No" };
        for (int i = 0; i < 2 && sel >= 0; ++i)               // (sel -1: a notice, no buttons)
        {
            RECT r = { bx0 + i * (bw + gap), by, bx0 + i * (bw + gap) + bw, by + bh };
            btn[i] = r;
            const bool on = sel == i;
            Fill(dc, r, on ? kGold : kDark);
            Frame(dc, r, on ? kWhite : kGold, S(2) < 1 ? 1 : S(2));
            Text(dc, fBtn, on ? kInk : kWhite, label[i], r);
        }
        if (sel >= 0) Text(dc, fHint, kGrey, L"Pick with the D-pad, stick or arrow keys - press A or Enter (or click)", RECT{ S(10), by + bh + S(10), pw - S(10), ph - S(6) });
        else { btn[0] = btn[1] = RECT{ 0, 0, 0, 0 }; }

        DeleteObject(fTitle); DeleteObject(fSub); DeleteObject(fBtn); DeleteObject(fHint);
        GdiFlush();

        D3DLOCKED_RECT lr;
        bool ok = false;
        if (SUCCEEDED(g_tex->LockRect(0, &lr, nullptr, 0)))
        {
            for (int y = 0; y < th; ++y)
            {
                uint32_t* dst = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(lr.pBits) + y * lr.Pitch);
                if (y >= ph) { std::memset(dst, 0, tw * 4); continue; }
                const uint32_t* src = static_cast<const uint32_t*>(bits) + y * pw;
                for (int x = 0; x < pw; ++x) dst[x] = (src[x] & 0x00FFFFFF) | 0xF0000000u;   // a little see-through
                if (tw > pw) std::memset(dst + pw, 0, (tw - pw) * 4);
            }
            g_tex->UnlockRect(0);
            ok = true;
        }
        SelectObject(dc, oldBmp);
        DeleteObject(bmp);
        DeleteDC(dc);
        return ok;
    }

    struct Vtx { float x, y, z, rhw, u, v; };

    void Draw(IDirect3DDevice9* dev)
    {
        if (!g_init) return;
        bool show; std::wstring title, sub; int sel; unsigned rev;
        EnterCriticalSection(&g_cs);
        if (g_show && g_noticeUntil && (int)(GetTickCount() - g_noticeUntil) >= 0) { g_show = false; g_noticeUntil = 0; g_btnValid = false; ++g_rev; }
        show = g_show; title = g_title; sub = g_sub; sel = g_sel; rev = g_rev;
        LeaveCriticalSection(&g_cs);
        if (dev != g_dev)   // a new device: the old texture belongs to the old one
        {
            g_tex = nullptr;   // (not released: its device may be gone)
            g_dev = dev;
            g_texRev = 0;
        }
        if (!show) return;

        int W = 0, H = 0;
        if (!D3D9BackBufferSize(&W, &H)) return;
        float s = H / 1080.f;
        if (s < 0.5f) s = 0.5f;
        int pw = (int)(680 * s + 0.5f), ph = (int)(208 * s + 0.5f);
        if (pw > W - 8) { s *= (float)(W - 8) / pw; pw = (int)(680 * s + 0.5f); ph = (int)(208 * s + 0.5f); }

        RECT btn[2];
        if (rev != g_texRev || pw != g_pw || ph != g_ph || !g_tex)
        {
            if (!Render(dev, pw, ph, s, title, sub, sel, btn)) return;
            g_texRev = rev; g_pw = pw; g_ph = ph;
            const int x0 = (W - pw) / 2, y0 = (int)(H * 0.16f);
            EnterCriticalSection(&g_cs);
            for (int i = 0; i < 2; ++i) g_btn[i] = RECT{ btn[i].left + x0, btn[i].top + y0, btn[i].right + x0, btn[i].bottom + y0 };
            g_btnValid = true;
            LeaveCriticalSection(&g_cs);
        }

        const float x0 = (float)((W - pw) / 2) - 0.5f, y0 = (float)(int)(H * 0.16f) - 0.5f;
        const float u1 = (float)pw / g_texW, v1 = (float)ph / g_texH;
        Vtx v[4] = {
            { x0,      y0,      0.f, 1.f, 0.f, 0.f },
            { x0 + pw, y0,      0.f, 1.f, u1,  0.f },
            { x0,      y0 + ph, 0.f, 1.f, 0.f, v1  },
            { x0 + pw, y0 + ph, 0.f, 1.f, u1,  v1  },
        };
        dev->SetVertexShader(nullptr);
        dev->SetPixelShader(nullptr);
        dev->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);
        dev->SetTexture(0, g_tex);
        dev->SetRenderState(D3DRS_ZENABLE, FALSE);
        dev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
        dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
        dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
        dev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
        dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
        dev->SetRenderState(D3DRS_LIGHTING, FALSE);
        dev->SetRenderState(D3DRS_FOGENABLE, FALSE);
        dev->SetRenderState(D3DRS_STENCILENABLE, FALSE);
        dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);
        dev->SetRenderState(D3DRS_SRGBWRITEENABLE, FALSE);
        dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
        dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
        dev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
        dev->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
        dev->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
        dev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
        dev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
        dev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
        dev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
        dev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
        dev->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
        dev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vtx));
        dev->SetTexture(0, nullptr);
    }
}

void PopupInit()
{
    if (g_init) return;
    InitializeCriticalSection(&g_cs);
    g_init = true;
    D3D9AddOverlay(&Draw);
}

void PopupSet(bool show, const std::wstring& title, const std::wstring& sub, int sel)
{
    if (!g_init) return;
    EnterCriticalSection(&g_cs);
    if (show != g_show || title != g_title || sub != g_sub || sel != g_sel)
    {
        g_show = show; g_title = title; g_sub = sub; g_sel = sel;
        g_noticeUntil = 0;
        ++g_rev;
        if (!show) g_btnValid = false;
    }
    LeaveCriticalSection(&g_cs);
}

int PopupHit(int x, int y)
{
    if (!g_init) return -1;
    int hit = -1;
    EnterCriticalSection(&g_cs);
    if (g_show && g_btnValid)
        for (int i = 0; i < 2; ++i)
            if (x >= g_btn[i].left && x < g_btn[i].right && y >= g_btn[i].top && y < g_btn[i].bottom) hit = i;
    LeaveCriticalSection(&g_cs);
    return hit;
}

void PopupNotice(const std::wstring& title, const std::wstring& sub, unsigned ms)
{
    if (!g_init) return;
    EnterCriticalSection(&g_cs);
    g_show = true; g_title = title; g_sub = sub; g_sel = -1;
    g_noticeUntil = GetTickCount() + ms; if (!g_noticeUntil) g_noticeUntil = 1;
    g_btnValid = false;
    ++g_rev;
    LeaveCriticalSection(&g_cs);
}
