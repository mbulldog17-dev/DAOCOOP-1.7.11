#include "xinputroute.h"
#include "log.h"
#include "vpad.h"
#include <xinput.h>
#include <cstring>

typedef DWORD (WINAPI* XInputGetState_t)(DWORD, XINPUT_STATE*);
typedef DWORD (WINAPI* XInputSetState_t)(DWORD, XINPUT_VIBRATION*);

static XInputGetState_t g_realGet = nullptr;
static XInputSetState_t g_realSet = nullptr;
static volatile LONG g_route = -1;
static volatile LONG g_blank = 0;
static volatile LONG g_hold = 0;           // 1.4.1: the join pop-up is up: the menus see an idle controller
static volatile LONG g_p1None = 0;         // Player 1 plays with keyboard and mouse: pad 0 is a co-op player's          // online friend watching: their own game sees no controller
static volatile LONG g_passThrough = XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_RIGHT_SHOULDER;

static DWORD GetStateRouted(DWORD index, XINPUT_STATE* state)
{
    if (g_blank) return ERROR_DEVICE_NOT_CONNECTED;
    LONG r = g_route;
    if (g_p1None) {
        // keyboard and mouse Player 1: the framework sees a controller only while a co-op player
        // holds a screen (then theirs, as controller 0), never a co-op player's pad otherwise
        if (index != 0 || r < 0 || !g_realGet) return ERROR_DEVICE_NOT_CONNECTED;
        return r >= kVPadFirst ? VPadGetState((DWORD)r, state) : g_realGet((DWORD)r, state);
    }
    if (r < 1 || !g_realGet) return g_realGet ? g_realGet(index, state) : ERROR_DEVICE_NOT_CONNECTED;
    if (index == (DWORD)r) return ERROR_DEVICE_NOT_CONNECTED;       // don't see it twice
    if (index != 0) return g_realGet(index, state);

    DWORD rc = r >= kVPadFirst ? VPadGetState((DWORD)r, state) : g_realGet((DWORD)r, state);   // 4/5: online friend
    if (rc != ERROR_SUCCESS) return rc;
    XINPUT_STATE p1 = {};
    if (g_realGet(0, &p1) == ERROR_SUCCESS) {
        WORD pass = (WORD)(p1.Gamepad.wButtons & (WORD)g_passThrough);
        state->Gamepad.wButtons |= pass;
        state->dwPacketNumber += p1.dwPacketNumber;                 // changes when either pad changes
    }
    return ERROR_SUCCESS;
}

// A short A press for the UI controller (1.2.38: confirms the creator's difficulty question for
// Players 2/3 - replacing chargen.gfx through the override folder breaks the creator's panels).
// From 'start': A held off for 150 ms (whatever the player holds), then on for 150 ms.
static volatile LONG g_injectAt = 0;

// 1.7.2: Player 1's menu button held 2 s opens the co-op menu (the game never sees it); a shorter press reaches the
// game when it is let go (a 120 ms press). Only Player 1's own controller 1, only in the world.
// 1.7.6: that button is View (the map) - START stays the game's own (held: the game menu, to save).
static const WORD kMenuBtn = XINPUT_GAMEPAD_BACK, kOtherBtn = XINPUT_GAMEPAD_START;
static volatile LONG g_startFilter = 0, g_startHeld = 0;
static LONG s_startAt = 0, s_tapAt = 0;
static bool s_startFired = false;
static void StartFilter(DWORD index, DWORD rc, XINPUT_STATE* state)
{
    if (index != 0 || !state || rc != ERROR_SUCCESS) return;
    const bool own = !g_p1None && g_route < 1;          // the state is Player 1's own pad
    WORD& b = state->Gamepad.wButtons;
    const LONG now = (LONG)GetTickCount();
    if (!own || !g_startFilter) {
        if (s_startAt && !s_startFired && !(b & kMenuBtn)) s_tapAt = now ? now : 1;   // let go as it changed
        s_startAt = 0;
    } else {
        const bool down = (b & kMenuBtn) != 0;
        if (down && !s_startAt && !(b & kOtherBtn)) { s_startAt = now ? now : 1; s_startFired = false; }
        if (s_startAt) {
            if (down) {
                b &= ~kMenuBtn;
                if (!s_startFired && now - s_startAt >= 2000) { s_startFired = true; InterlockedExchange(&g_startHeld, 1); }
            } else {
                if (!s_startFired) s_tapAt = now ? now : 1;
                s_startAt = 0;
            }
        }
    }
    if (s_tapAt) {
        const LONG t = now - s_tapAt;
        if (t >= 0 && t < 120) { b |= kMenuBtn; state->dwPacketNumber += 0x20000; }
        else s_tapAt = 0;
    }
}

void XInputRouteStartFilter(bool on) { InterlockedExchange(&g_startFilter, on ? 1 : 0); }
bool XInputRouteTakeStartHold() { return InterlockedExchange(&g_startHeld, 0) != 0; }
bool XInputRouteActive() { return g_realGet != nullptr; }

static DWORD WINAPI HookGetState(DWORD index, XINPUT_STATE* state)
{
    DWORD rc = GetStateRouted(index, state);
    StartFilter(index, rc, state);
    if ((g_hold & 3 || (g_hold & 4 && index == 0)) && rc == ERROR_SUCCESS && state) {
        ZeroMemory(&state->Gamepad, sizeof(state->Gamepad));
        state->dwPacketNumber = 0x7F000000u + index;              // the same "nothing changed" state
        return rc;
    }
    LONG at = g_injectAt;
    if (index == 0 && at) {
        LONG t = (LONG)GetTickCount() - at;
        if (t >= 0 && t < 300) {
            if (rc != ERROR_SUCCESS) { ZeroMemory(state, sizeof(*state)); rc = ERROR_SUCCESS; }
            if (t < 150) state->Gamepad.wButtons &= ~XINPUT_GAMEPAD_A;
            else state->Gamepad.wButtons |= XINPUT_GAMEPAD_A;
            state->dwPacketNumber += 0x10000 + (t < 150 ? 1 : 2);
        } else if (t >= 300) InterlockedCompareExchange(&g_injectAt, 0, at);
    }
    return rc;
}

void XInputRoutePressA(unsigned delayMs)
{
    LONG at = (LONG)(GetTickCount() + delayMs);
    if (!at) at = 1;
    InterlockedExchange(&g_injectAt, at);
}

static DWORD WINAPI HookSetState(DWORD index, XINPUT_VIBRATION* vib)
{
    LONG r = g_route;
    if (!g_realSet) return ERROR_DEVICE_NOT_CONNECTED;
    if (r >= kVPadFirst && index == 0) return ERROR_SUCCESS;        // an online friend: no rumble over the network
    if (g_p1None) return (index == 0 && r >= 0) ? g_realSet((DWORD)r, vib) : ERROR_SUCCESS;
    if (r >= 1 && index == 0) return g_realSet((DWORD)r, vib);      // rumble goes to who holds the UI
    return g_realSet(index, vib);
}

// Patches `func` imported from `dllName` in `module`'s import table.
static void** FindImport(HMODULE module, const char* dllName, const char* func)
{
    BYTE* base = reinterpret_cast<BYTE*>(module);
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    const IMAGE_DATA_DIRECTORY& dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir.VirtualAddress) return nullptr;
    for (auto* imp = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + dir.VirtualAddress); imp->Name; ++imp) {
        if (_stricmp(reinterpret_cast<char*>(base + imp->Name), dllName) != 0) continue;
        auto* names = reinterpret_cast<IMAGE_THUNK_DATA*>(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
        auto* slots = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imp->FirstThunk);
        for (; names->u1.AddressOfData; ++names, ++slots) {
            if (IMAGE_SNAP_BY_ORDINAL(names->u1.Ordinal)) continue;
            auto* byName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + names->u1.AddressOfData);
            if (strcmp(reinterpret_cast<char*>(byName->Name), func) == 0)
                return reinterpret_cast<void**>(&slots->u1.Function);
        }
    }
    return nullptr;
}

static bool Patch(void** slot, void* fn, void** original)
{
    DWORD old;
    if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) return false;
    *original = *slot;
    *slot = fn;
    VirtualProtect(slot, sizeof(void*), old, &old);
    return true;
}

bool XInputRouteInstall()
{
    HMODULE fw = GetModuleHandleW(L"dinput8_chain.dll");
    if (!fw) { Log("Controller hand-off: the controller framework (dinput8_chain.dll) is not loaded"); return false; }
    void** get = FindImport(fw, "XINPUT9_1_0.dll", "XInputGetState");
    void** set = FindImport(fw, "XINPUT9_1_0.dll", "XInputSetState");
    if (!get) { Log("Controller hand-off: the framework does not import XInputGetState as expected"); return false; }
    bool ok = Patch(get, reinterpret_cast<void*>(&HookGetState), reinterpret_cast<void**>(&g_realGet));
    if (set) Patch(set, reinterpret_cast<void*>(&HookSetState), reinterpret_cast<void**>(&g_realSet));
    Log("Controller hand-off: %s", ok ? "ready (framework's XInput patched)" : "patch failed");
    return ok;
}

void XInputRouteSet(int padIndex)
{
    LONG v = (padIndex >= 1 || (padIndex == 0 && g_p1None)) && padIndex < kVPadSlots ? padIndex : -1;
    if (InterlockedExchange(&g_route, v) != v) {
        if (v < 0) Log("Controller UI now follows Player 1 (pad 0)");
        else if (v >= kVPadFirst) Log("Controller UI now follows online friend %d (pad %d)", v - kVPadFirst + 1, v);
        else Log("Controller UI now follows pad %d", v);
    }
}

void XInputRouteP1None(bool on)
{
    if (InterlockedExchange(&g_p1None, on ? 1 : 0) != (on ? 1 : 0))
        Log("Controller UI: Player 1 uses %s", on ? "keyboard and mouse (controller 1 is free for Players 2/3)" : "controller 1");
    if (!on && g_route == 0) InterlockedExchange(&g_route, -1);
}
bool XInputRouteP1NoneGet() { return g_p1None != 0; }

void XInputRouteBlank(bool on)
{
    if (InterlockedExchange(&g_blank, on ? 1 : 0) != (on ? 1 : 0))
        Log("Controller UI: %s", on ? "this game's own menus ignore the controller (watching a friend's game)" : "back to normal");
}

void XInputRouteHold(bool on)
{
    const LONG was = on ? InterlockedOr(&g_hold, 1) : InterlockedAnd(&g_hold, ~1);
    if (((was & 1) != 0) != on) Log("Controller UI: %s", on ? "held for the join pop-up" : "free again");
}

void XInputRouteHoldMenu(bool on)       // 1.7.2: Player 1's controller is in the co-op menu
{
    const LONG was = on ? InterlockedOr(&g_hold, 2) : InterlockedAnd(&g_hold, ~2);
    if (((was & 2) != 0) != on) Log("Controller UI: %s", on ? "held for the co-op menu" : "back from the co-op menu");
}

void XInputRouteHoldChat(bool on)       // 1.7.8: Player 1 is typing in the chat line
{
    const LONG was = on ? InterlockedOr(&g_hold, 4) : InterlockedAnd(&g_hold, ~4);
    if (((was & 4) != 0) != on) Log("Controller UI: %s", on ? "held for the chat line" : "back from the chat line");
}

void XInputRouteSetPassThrough(WORD buttons) { InterlockedExchange(&g_passThrough, buttons); }
int  XInputRouteGet() { return (int)g_route; }
