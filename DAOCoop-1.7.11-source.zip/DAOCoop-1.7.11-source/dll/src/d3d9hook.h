#pragma once
// The game's Direct3D 9 device (1.2.27, online play): Direct3DCreate9 in DAOrigins.exe's import table
// -> IDirect3D9::CreateDevice -> the device's Present and Reset (vtable).
struct IDirect3DDevice9;
typedef void (*D3D9PresentCallback)(IDirect3DDevice9* dev);   // before the real Present (scene ended)
typedef void (*D3D9ResetCallback)(IDirect3DDevice9* dev);     // before the real Reset (free D3DPOOL_DEFAULT things)
bool D3D9HookInstall(D3D9PresentCallback present, D3D9ResetCallback reset);
// The game's back buffer size in pixels (window client size if the device left it 0).
bool D3D9BackBufferSize(int* w, int* h);
// Something drawn on the finished frame, before Present (rings.cpp).
void D3D9SetOverlay(D3D9PresentCallback draw);
// More things drawn on the finished frame (1.4.1: the join pop-up, popup.cpp), after the one above.
void D3D9AddOverlay(D3D9PresentCallback draw);
// 1.7.0 views: called first in Present; true = this frame is kept (copied by the callback) and not shown.
typedef bool (*D3D9SwallowCallback)(IDirect3DDevice9* dev);
void D3D9SetSwallow(D3D9SwallowCallback cb);
// 1.7.0 views: a second Reset callback (free D3DPOOL_DEFAULT things).
void D3D9SetResetCallback2(D3D9ResetCallback cb);
// 1.7.0 views: a filter for viewports / scissor rectangles set by the game (render thread). r = left, top,
// right, bottom in pixels; return true after changing it. nullptr = off.
typedef bool (*D3D9RectFilter)(long r[4]);
void D3D9SetRectFilter(D3D9RectFilter f);
// 1.7.0 performance: QPC ticks spent in the device's Present (vsync / GPU wait) since the last call, and how many.
void D3D9TakePresentStats(long long* ticks, int* count);
// 1.7.5: frame pacing by the screen (fullscreen, refresh a whole multiple of fps): set before the device is made.
void D3D9SetPacing(bool on, int fps);
int D3D9PacedInterval();                 // refreshes per frame now, 0 = not paced by the screen (the timer does it)
long long D3D9TakePresentWait();         // QPC ticks waited in Present since the last call (render thread)
// 1.7.0 views: called on the finished frame before every overlay (views: Player 1's picture put back).
void D3D9SetPreOverlay(D3D9PresentCallback cb);
// The window the game draws into (null before the device exists).
// True while a frame finished through the swap chain's Present is handled (menus, movies, creator).
bool D3D9InSwapChainPresent();
// 1.5.1: what the drawing thread is doing now (a watchdog logs it when it stays there over 3 s); nullptr = done.
void D3D9Stage(const char* what);
const char* D3D9CurrentStage();
// 1.7.1: the device's whole state saved for an overlay to put back after drawing: one state block per `slot`
// (0-7), made once and re-captured each time (making one every frame cost the render thread ~1 ms a time).
// Released before the device is reset. Returns null if it can't be made: draw without saving then.
struct IDirect3DStateBlock9;
IDirect3DStateBlock9* D3D9SaveState(IDirect3DDevice9* dev, int slot);
struct HWND__;
HWND__* D3D9GameWindow();
// 1.7.8: called on the drawing thread right after each shown frame's Present returned (the stream picks up its
// copy of that frame there, instead of a whole frame later)
void D3D9SetPostPresent(void (*cb)());
