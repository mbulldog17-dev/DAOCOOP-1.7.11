#pragma once
// 1.7.0: the game's own GUI icons (abilities, talents, spells, skills ...) for Player 2's HUD.
// They live in the game's atlas <game>\packages\core\data\guiexport.erf: atl_shared_dxt1_00/01.dds, with
// atl_shared_dxt1_dat.xml saying where each icon is ("tlt_ico_shield_bash.dds" -> page, UV rectangle).
// Read from the player's own game files at run time (nothing of the game is copied into the mod).
struct IDirect3DDevice9;
struct IDirect3DTexture9;

// Render thread. name: as in ABI_base's "icon" column ("tlt_ico_shield_bash"), with or without ".dds".
// uv: u0, v0, u1, v1. False when the icon isn't in the atlas (or the atlas couldn't be read).
bool IconAtlasFind(IDirect3DDevice9* dev, const wchar_t* name, IDirect3DTexture9** tex, float uv[4]);
