@echo off
rem Builds the co-op DLL, makes an install package in dist\ and installs it into the game.
rem Add -NoInstall to only build and package.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build-DAOCoop.ps1" %*
echo.
pause
