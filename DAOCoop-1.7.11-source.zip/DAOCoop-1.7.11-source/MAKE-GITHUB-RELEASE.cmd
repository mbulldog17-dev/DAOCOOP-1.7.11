@echo off
rem Makes the GitHub release package (dist\GitHub-<version>\) from the last build - no rebuild.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Make-GitHub-Release.ps1" %*
echo.
pause
