# DAOCoop — 3-player co-op for Dragon Age: Origins Ultimate Edition

Local co-op mod: P1 is the Warden, P2 and P3 each control their own custom
character on an Xbox controller, with three AI companions in a 6-member party.
Full design: the "Dragon Age: Origins 3-Player Co-op — Design Deep Dive" doc.

## Building and installing (one click)

Needs Visual Studio 2022 or 2026 with **Desktop development with C++** (free Community edition is fine).

Double-click **`build.bat`**. It:

1. Builds the DLL (32-bit, like the game).
2. Makes a shareable install package: `dist\DAOCoop-<date.time>.zip` (newest 3 kept).
3. Installs it into the game with that package's own installer. Windows asks for
   permission because the game is under Program Files.

`build.bat -NoInstall` only builds and packages. `uninstall.bat` takes the mod out
and puts back anything it replaced. `MAKE-INSTALL-PACKAGE.cmd` re-packages the
last build without rebuilding.

## Sharing it

Send people the zip from `dist\`. They unzip it and double-click `INSTALL.cmd`;
`UNINSTALL.cmd` takes it out again. The installer:

- finds the game by itself (Steam libraries, Steam and BioWare registry entries, the
  usual game folders on every drive), or lets them pick the folder;
- warns if their `DAOrigins.exe` isn't the version the mod was made for (1.05.13263.0);
- keeps another mod's `dinput8.dll` working (for example the Native Controller Framework) by renaming it
  `dinput8_chain.dll`; DAOCoop passes every DirectInput call on to it, and uninstall gives it its name back;
- removes the `version.dll` that builds before 0.1.2 installed;
- keeps their settings when updating, and keeps backups of the last 5 builds it replaced;
- applies the 4GB patch to `DAOrigins.exe` on the GOG version (the original is saved and uninstall can put it
  back). It skips it on the Steam version: Steam's copy protection refuses to start a changed exe
  ("Application load error 3:0000065432"), and the installer undoes the patch if an older build made it;
- lets the game write its log into the `DAOCoop` folder;
- asks Windows for admin rights only when the game folder needs them.

## What goes where in the game folder

| Path | What it is |
| --- | --- |
| `bin_ship\dinput8.dll` | The mod. The game loads it by itself, and it passes every DirectInput call on to Windows (or to `dinput8_chain.dll`). |
| `bin_ship\dinput8_chain.dll` | Only when another mod had a `dinput8.dll`: that mod, renamed |
| `DAOCoop\DAOCoop.ini` | Settings (controller slots for P2 and P3) |
| `DAOCoop\DAOCoop.log` | Written on every start |
| `DAOCoop\backups\` | DLLs the installer replaced, and the original `DAOrigins.exe` from before the 4GB patch |
| `DAOCoop\install-record.txt` | What the installer did, for uninstalling |

Why `dinput8.dll`: the game imports `DirectInput8Create` from it, so Windows loads ours
from `bin_ship` first; the Native Controller Framework loads the same way on this build.
The first builds used `version.dll`, but crash dumps showed the Steam build always loads
Windows' own `version.dll` from System32, so that copy was never used.

## Project layout

| Path | What it is |
| --- | --- |
| `dll/` | The co-op DLL (C++/CMake) |
| `installer/` | The package installer and its README |
| `scripts/` | Build and packaging scripts |
| `build/`, `dist/` | Build output and install packages (not source) |

## Starting a co-op game (0.8.0)

The start menu has a **Co-op** button under New Game:

1. **Local Co-op** or **Online Multiplayer** (online: Host / Join; menus only for now)
2. **2 Players** or **3 Players**
3. **Lobby**: Players 2/3 press START on their controller to join, then A when ready
   (B steps back). Player 1 chooses Ready. When everyone is ready a 3-second countdown
   starts the normal new game: Player 1 makes the Warden, and as soon as the origin story is
   playing the creator opens for Player 2, then Player 3 - they play the origin together
   with the Warden. A player who joins later is offered the creator wherever the party is.

Plain **New Game** starts a single-player game (co-op controls off). Loading a save uses the
player count of the last started game, and a save that already has the co-op characters in
it always counts as co-op.

## Controls for Players 2 and 3 (0.7.0)

Both co-op controllers have the same controls:

| Button | What it does |
|---|---|
| Left stick | Move (relative to the camera) |
| A | Combat: attack the target. Exploring: open/use the nearest chest, door, body, lever |
| D-pad up | Use the nearest object |
| RB | Next enemy target |
| D-pad left / right | Pick the friend your helpful spells go to (or "none": they go to whoever is hurt worst) |
| X / Y / B | Quickbar slots 1-3 |
| Hold RT + X / Y / B | Quickbar slots 4-6 |
| Hold LT + X / Y / B | Quickbar slots 7-9 |
| Hold LB 1.5 s | Teleport next to the Warden |
| View | Your inventory (Step away is in the co-op menu); View or START rejoins |
| View + Start | Pause / unpause the game for everyone |
| View + X / Y / B | Your own inventory / character / journal |
| Hold View 2 s | The co-op menu: every control (Controls tab), voice chat settings and Step away (Voice tab) |
| / (Player 1) or hold START 1 s (Players 2/3), online | Text chat: type on the keyboard, Enter sends (your controller comes back), Esc / B closes. Quick phrases in the co-op menu's Chat tab |
| RS (in a menu or conversation) | Pass it on to the next player (Player 1: RS or F3) - in conversations your skills count for persuade/intimidate |
| Start | Join; in the game, open your own level-up screen |

In combat a co-op character keeps attacking its target while its player presses nothing
(`IdleInCombat`: Attack, Stand or Tactics). Controllers rumble when your character is hit,
pulse below 25% health, and a message says when a co-op player is knocked out. The edge
arrow for an off-screen party member is blue "P2" / green "P3" for the co-op characters.

Player 1 can't take over the co-op characters. Enemies get +25% health and damage per extra
player, and the camera slides and zooms out a little to keep everyone in view. In the lobby
the first free controller to press START becomes Player 2, the next Player 3.

Markers and arrows show the co-op characters' names in their player's colour
(`CharacterNames=1`).

**Save safety:** copies of the Warden's newest saves go to `DAOCoop\Backups` once per game
launch when co-op is played, and right before a co-op character creator opens (the game
saves first). If a save is loaded without a co-op player's own character, that player can
hold LS for 2 seconds to copy the newest backup that has it into the Load Game list.

A controller that disconnects hands its character to the AI at once. A controller plugged
in later joins with START. Spells pick their own kind of target from the game's ability
table: attacks go to your enemy target, heals and buffs to your picked friend, self-only
modes to you. Slots and leash distances are in `[P2]` / `[P3]` in `DAOCoop.ini`.

## Testing the current build (Milestone 2, step 1)

Plug in the controllers, start the game, load a save and press buttons on P2's and
P3's controllers. Quit and open `<game folder>\DAOCoop\DAOCoop.log`:

```
DAOCoop 0.1.2 loaded into DAOrigins.exe
4GB patch (large address aware): no (normal for the Steam version)
DirectInput calls go to C:\Windows\SysWOW64\dinput8.dll
Controller assignment: P2 = pad 1, P3 = pad 2
P2 controller (pad 1) connected
P2 pressed A
P2 left stick moving
```

No log at all means the DLL didn't load (also check `%LOCALAPPDATA%\DAOCoop\DAOCoop.log`,
where it writes when the game folder isn't writable). If it loaded but controllers don't show
up, change the slots in `DAOCoop.ini`.

## Known issue: Discord overlay

Crash dumps from the character creator all crash inside Discord's overlay
(`DiscordHook.dll`), not in the game or the mod. Turn it off for Dragon Age:
Discord > User Settings > Game Overlay.

## Target build

- **GOG** Ultimate Edition (main test copy from now on): no copy protection, so the installer applies the
  4GB patch. The Steam copy crashed right after character creation, a known out-of-memory problem
  without the patch, which Steam's copy protection blocks.
- Steam Ultimate Edition, `DAOrigins.exe` **1.05.13263.0** (32-bit, Steam DRM wrapper): the mod loads and
  reads controllers, but no 4GB patch is possible.
- The same build the Native Controller Framework mod targets

With both installed, `build.bat` asks once which copy to install into and remembers it in
`game-path.txt`; `build.bat -ChooseGame` asks again.

## Progress

- [x] M0: game located and version confirmed (1.05.13263.0)
- [x] One-click build, install package, installer and uninstaller
- [x] M0: 4GB (LAA) patch in the installer (GOG only; Steam's DRM blocks it)
- [ ] M0: DA Toolset installed
- [ ] M1: six-member party test (Option A vs B)
- [x] M2 step 1a: DLL loads in the game (dinput8.dll) and sees controller 2
- [ ] M2 step 1b: button presses from P2/P3 show in the log (needs a game that gets past character creation)
- [ ] M2 step 2: find the engine's "give a creature a command" function
- [ ] M2 step 3: P2 walks and attacks with one follower
