"""Draws the Player 2/3 HUD markers and writes them as uncompressed 32-bit DDS
(A8R8G8B8), the format Dragon Age's GUI image loader reads from override."""
import struct, sys, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
S = 4                      # supersampling

def dds(img, path):
    img = img.convert("RGBA")
    w, h = img.size
    hdr = struct.pack("<4sI", b"DDS ", 124)
    flags = 0x1 | 0x2 | 0x4 | 0x1000 | 0x8      # caps|height|width|pixelformat|pitch
    hdr += struct.pack("<IIIIII", flags, h, w, w * 4, 0, 0)
    hdr += b"\0" * 44
    hdr += struct.pack("<II4sIIIII", 32, 0x41, b"\0\0\0\0", 32,
                       0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)   # RGB + alpha, BGRA order
    hdr += struct.pack("<IIIII", 0x1000, 0, 0, 0, 0)
    px = bytearray()
    for r, g, b, a in img.getdata():
        px += bytes((b, g, r, a))
    open(path, "wb").write(hdr + px)

def shadowed(base, draw_fn, size):
    """Draw shape with a dark outline/shadow for readability on any background."""
    layer = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(layer), (255, 255, 255, 255))
    alpha = layer.split()[3]
    shadow = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    shadow.putalpha(alpha.filter(ImageFilter.MaxFilter(4 * S + 1)).point(lambda v: min(255, v * 0.85)))
    base.alpha_composite(shadow)

def target_marker(color, label, size=64):
    """Downward chevron with the player tag above it: shown over an enemy."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    font = ImageFont.truetype(FONT, int(22 * S))
    def shape(d, fill):
        c = size * S / 2
        d.text((c, 4 * S), label, font=font, fill=fill, anchor="mt")
        d.polygon([(c - 18 * S, 34 * S), (c + 18 * S, 34 * S), (c, 58 * S)], fill=fill)
    shadowed(img, shape, size)
    col = Image.new("RGBA", img.size, (0, 0, 0, 0))
    shape(ImageDraw.Draw(col), color + (255,))
    img.alpha_composite(col)
    # bright inner edge on the chevron
    d = ImageDraw.Draw(img)
    c = size * S / 2
    d.line([(c - 12 * S, 38 * S), (c, 52 * S), (c + 12 * S, 38 * S)], fill=(255, 255, 255, 170), width=2 * S)
    return img.resize((size, size), Image.LANCZOS)

def self_marker(color, label, size=64):
    """Rounded tag "P2" shown over the player's own character."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    font = ImageFont.truetype(FONT, int(24 * S))
    box = (8 * S, 16 * S, 56 * S, 48 * S)
    def plate(d, fill):
        d.rounded_rectangle(box, radius=9 * S, fill=fill)
    shadowed(img, plate, size)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle(box, radius=9 * S, fill=color + (235,), outline=(255, 255, 255, 220), width=2 * S)
    d.text((size * S / 2, 32 * S), label, font=font, fill=(255, 255, 255, 255), anchor="mm")
    return img.resize((size, size), Image.LANCZOS)

def ally_marker(color, label, size=64):
    """Plus sign in a ring with the player tag: the friend a helpful spell goes to."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    font = ImageFont.truetype(FONT, int(18 * S))
    c = size * S / 2
    def shape(d, fill):
        d.text((c, 2 * S), label, font=font, fill=fill, anchor="mt")
        d.ellipse((c - 17 * S, 24 * S, c + 17 * S, 58 * S), outline=fill, width=5 * S)
        d.rectangle((c - 3 * S, 31 * S, c + 3 * S, 51 * S), fill=fill)
        d.rectangle((c - 10 * S, 38 * S, c + 10 * S, 44 * S), fill=fill)
    shadowed(img, shape, size)
    col = Image.new("RGBA", img.size, (0, 0, 0, 0))
    shape(ImageDraw.Draw(col), color + (255,))
    img.alpha_composite(col)
    return img.resize((size, size), Image.LANCZOS)

def target_marker_n(color, size=64):
    """Chevron only (the player's name is written above it by the floaty layer)."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    c = size * S / 2
    def shape(d, fill):
        d.polygon([(c - 18 * S, 34 * S), (c + 18 * S, 34 * S), (c, 58 * S)], fill=fill)
    shadowed(img, shape, size)
    col = Image.new("RGBA", img.size, (0, 0, 0, 0)); shape(ImageDraw.Draw(col), color + (255,)); img.alpha_composite(col)
    d = ImageDraw.Draw(img)
    d.line([(c - 12 * S, 38 * S), (c, 52 * S), (c + 12 * S, 38 * S)], fill=(255, 255, 255, 170), width=2 * S)
    return img.resize((size, size), Image.LANCZOS)

def ally_marker_n(color, size=64):
    """Plus in a ring, no label."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    c = size * S / 2
    def shape(d, fill):
        d.ellipse((c - 17 * S, 24 * S, c + 17 * S, 58 * S), outline=fill, width=5 * S)
        d.rectangle((c - 3 * S, 31 * S, c + 3 * S, 51 * S), fill=fill)
        d.rectangle((c - 10 * S, 38 * S, c + 10 * S, 44 * S), fill=fill)
    shadowed(img, shape, size)
    col = Image.new("RGBA", img.size, (0, 0, 0, 0)); shape(ImageDraw.Draw(col), color + (255,)); img.alpha_composite(col)
    return img.resize((size, size), Image.LANCZOS)

def self_marker_n(color, size=64):
    """Small diamond under the player's name."""
    img = Image.new("RGBA", (size * S, size * S), (0, 0, 0, 0))
    c = size * S / 2
    def shape(d, fill):
        d.polygon([(c, 40 * S), (c + 9 * S, 49 * S), (c, 58 * S), (c - 9 * S, 49 * S)], fill=fill)
    shadowed(img, shape, size)
    col = Image.new("RGBA", img.size, (0, 0, 0, 0)); shape(ImageDraw.Draw(col), color + (255,)); img.alpha_composite(col)
    return img.resize((size, size), Image.LANCZOS)

if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    players = {"p2": ((77, 166, 255), "P2"), "p3": ((102, 221, 102), "P3")}
    for key, (color, label) in players.items():
        t = target_marker(color, label); dds(t, os.path.join(out, f"daocoop_{key}_target.dds"))
        s = self_marker(color, label);   dds(s, os.path.join(out, f"daocoop_{key}_self.dds"))
        a = ally_marker(color, label);   dds(a, os.path.join(out, f"daocoop_{key}_ally.dds"))
        # "_n" variants: no "P2" text, the character's name is drawn by the floaty layer
        tn = target_marker_n(color); dds(tn, os.path.join(out, f"daocoop_{key}_target_n.dds"))
        an = ally_marker_n(color);   dds(an, os.path.join(out, f"daocoop_{key}_ally_n.dds"))
        sn = self_marker_n(color);   dds(sn, os.path.join(out, f"daocoop_{key}_self_n.dds"))
        if len(sys.argv) > 2:
            t.save(os.path.join(sys.argv[2], f"daocoop_{key}_target.png"))
            s.save(os.path.join(sys.argv[2], f"daocoop_{key}_self.png"))
            a.save(os.path.join(sys.argv[2], f"daocoop_{key}_ally.png"))
            for nm, im in (("target_n", tn), ("ally_n", an), ("self_n", sn)):
                im.save(os.path.join(sys.argv[2], f"daocoop_{key}_{nm}.png"))
    print("markers written to", out)
