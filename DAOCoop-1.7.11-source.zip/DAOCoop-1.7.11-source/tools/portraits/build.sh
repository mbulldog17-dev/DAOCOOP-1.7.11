#!/bin/bash
# Rebuilds dll/assets/portraits.gfx (6 party portraits + Player 2/3 ability bars).
# Imports Portraits.as into the current dll/assets/portraits.gfx (already the 6-slot version).
#   build.sh <ffdec.jar>
set -e
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/build/scripts/__Packages"
cp "$here/Portraits.as" "$here/build/scripts/__Packages/Portraits.as"
java -jar "$1" -importScript "$here/../../dll/assets/portraits.gfx" "$here/build/portraits.gfx" "$here/build/scripts"
cp "$here/build/portraits.gfx" "$here/../../dll/assets/portraits.gfx"
python3 "$here/../gfx-uncompress.py" "$here/../../dll/assets/portraits.gfx"   # 1.7.11: stored uncompressed
echo "dll/assets/portraits.gfx rebuilt"
