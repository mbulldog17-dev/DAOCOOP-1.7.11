class FloatyLayer
{
   var AddBehaviour;
   var VAlign;
   var HAlign;
   var Text_mc_init;
   var SetText;
   static var FloatySymbolNames;
   static var m_aFloatyPool;
   static var BatchUpdateIDs;
   static var BatchUpdatePositionsScalesAlphas;
   static var BatchUpdateOffsets;
   static var BatchCreateIDs;
   static var BatchCreateSymbolIDs;
   static var BatchShowIDs;
   static var BatchHideIDs;
   static var BatchDestroyIDs;
   static var BatchUpdateMessageIDs;
   static var BatchUpdateMessageStrings;
   static var BatchUpdateMessageStyles;
   static var BatchUpdateMessageColours;
   static var BatchUpdateMessageDurations;
   static var BatchUpdateStatsIDs;
   static var BatchUpdateStatsFlags;
   static var BatchUpdateStatsNames;
   static var BatchUpdateStatsCurrentHealths;
   static var BatchUpdateStatsTotalHealths;
   static var BatchUpdateStatsRanks;
   static var BatchUpdateIconIDs;
   static var BatchUpdateIconNames;
   static var BatchUpdateOffscreenIDs;
   static var BatchUpdateOffscreenTypes;
   static var BatchUpdateOffscreenXs;
   static var BatchUpdateOffscreenYs;
   static var m_nFloatyPoolUseCount = 0;
   static var m_mapFloaties = new Object();
   static var MAX_FLOATIES = 50;
   static var FLOATY_SYMBOL_STATS = 0;
   static var FLOATY_SYMBOL_MESSAGE = 1;
   static var FLOATY_SYMBOL_ICON = 2;
   static var FLOATY_SYMBOL_ACTION_BAR = 3;
   static var FLOATY_SYMBOL_OFFSCREEN = 4;
   static var FLOATY_SYMBOL_DEBUG = 5;
   function FloatyLayer()
   {
   }
   static function StartScene()
   {
      FloatyLayer.FloatySymbolNames = new Array(6);
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_STATS] = "FloatyStats";
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_MESSAGE] = "FloatyMessage";
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_ICON] = "FloatyIcon";
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_ACTION_BAR] = "FloatyActionBar";
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_OFFSCREEN] = "FloatyOffscreenIndicator";
      FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_DEBUG] = "DebugWorldSpaceTextFloaty";
      FloatyLayer.m_aFloatyPool = new Array();
      if(GUISystem.RunningInGame == false)
      {
         FloatyLayer.CreateFloaty(1,FloatyLayer.FLOATY_SYMBOL_MESSAGE);
         FuncUtils.CallWithDelay(FloatyLayer.TestFloaty,0.5);
      }
      _root.PauseBorder_mc_init = function()
      {
         MovieUtils.DisableHitTest(this);
         this.AddBehaviour(Behaviour.ScaleToScreen);
         var mcBorder = this;
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.FLOATY_PAUSEBORDER,"Client.Paused",function(a_bPaused)
         {
            var _loc1_ = Number(ExternalCommands.GetValue("Client.UserPaused"));
            if(a_bPaused == true)
            {
               mcBorder.gotoAndPlay("intro");
            }
            else if(_loc1_ == 1)
            {
               mcBorder.gotoAndPlay("outro");
            }
            else
            {
               mcBorder.gotoAndStop(1);
            }
         }
         );
      };
      _root.PauseIndicator_mc_init = function()
      {
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_TOP;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_CENTRE;
         MovieUtils.DisableHitTest(this);
         this.Text_mc_init = function()
         {
            this.SetText(Localization.Strings.LOC_PAUSED);
         };
         var mcPause = this;
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.FLOATY_PAUSETEXT,"Client.Paused",function(a_bPaused)
         {
            var _loc1_ = Number(ExternalCommands.GetValue("Client.UserPaused"));
            if(a_bPaused == true)
            {
               mcPause.gotoAndPlay("intro");
            }
            else if(_loc1_ == 1)
            {
               mcPause.gotoAndPlay("outro");
            }
            else
            {
               mcPause.gotoAndStop(1);
            }
         }
         );
      };
      ExternalCommands.SendMessageArgs("GUI.UpdateFloatyLayerStageSize",Stage.width,Stage.height);
      _root.UpdateLayout = function()
      {
         ExternalCommands.SendMessageArgs("GUI.UpdateFloatyLayerStageSize",Stage.width,Stage.height);
      };
   }
   static function FinishScene()
   {
   }
   static function CreateFloaty(a_nFloatyID, a_nFloatySymbolID)
   {
      var _loc3_ = true;
      var _loc2_ = undefined;
      if(_loc3_ && a_nFloatySymbolID == FloatyLayer.FLOATY_SYMBOL_MESSAGE)
      {
         _loc2_ = FloatyLayer.RequestMessageFloatyFromPool();
      }
      else
      {
         _loc2_ = MovieUtils.CreateMovie(_root,FloatyLayer.FloatySymbolNames[a_nFloatySymbolID]);
      }
      if(_loc2_ != null)
      {
         MovieUtils.DisableHitTest(_loc2_);
         MovieUtils.HideMovie(_loc2_);
         FloatyLayer.m_mapFloaties[a_nFloatyID] = _loc2_;
      }
   }
   static function DestroyFloaty(a_nFloatyID)
   {
      var _loc1_ = FloatyLayer.m_mapFloaties[a_nFloatyID];
      if(_loc1_)
      {
         _loc1_.Destroy();
         if(_loc1_.m_nPoolIndex != undefined && _loc1_.m_nPoolIndex >= 0)
         {
            FloatyLayer.ReturnMessageFloatyToPool(_loc1_);
            MovieUtils.HideMovie(_loc1_);
         }
         else
         {
            MovieUtils.RemoveMovie(_loc1_);
         }
         FloatyLayer.m_mapFloaties[a_nFloatyID] = null;
         delete FloatyLayer.m_mapFloaties[a_nFloatyID];
      }
   }
   static function ShowFloaty(a_nFloatyID)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         MovieUtils.ShowMovie(FloatyLayer.m_mapFloaties[a_nFloatyID]);
      }
   }
   static function HideFloaty(a_nFloatyID)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         MovieUtils.HideMovie(FloatyLayer.m_mapFloaties[a_nFloatyID]);
      }
   }
   static function SetFloatyPosition(a_nFloatyID, a_nX, a_nY, a_nZ, a_fScale, a_fAlpha, a_nOffset)
   {
      var _loc2_ = FloatyLayer.m_mapFloaties[a_nFloatyID];
      if(_loc2_)
      {
         _loc2_._xscale = a_fScale * 100;
         _loc2_._yscale = a_fScale * 100;
         _loc2_._alpha = a_fAlpha * 100;
         var _loc8_ = _loc2_._width * a_fScale;
         var _loc4_ = 8 * a_fScale;
         var _loc6_ = (_root.OriginalStageWidth - Stage.width) / 2 + a_nX;
         var _loc5_ = (_root.OriginalStageHeight - Stage.height) / 2 + a_nY;
         _loc2_._x = _loc6_;
         _loc2_._y = _loc5_ - _loc4_;
         var _loc7_ = _loc2_ instanceof FloatyIcon;
         if(_loc7_ == true)
         {
            _loc2_._y -= _loc4_ * 2.5;
         }
         _loc2_.swapDepths(- a_nZ);
         if(a_nOffset > 0)
         {
            _loc2_._y -= 20 * (a_nOffset - 1);
         }
      }
   }
   static function DisplayFloatyMessage(a_nFloatyID, a_sMessage, a_Style, a_nColour, a_nDuration)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].DisplayMessage(a_sMessage,a_Style,a_nColour,a_nDuration);
      }
   }
   static function DisplayStatusMessage(a_sMessage, a_nColour)
   {
      StatusMessageRoller.DisplayStatusMessage(a_sMessage,a_nColour);
   }
   static function SetFloatyIcon(a_nFloatyID, a_sIconName)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].SetIcon(a_sIconName);
         FloatyLayer.CoopLabelIcon(FloatyLayer.m_mapFloaties[a_nFloatyID],a_sIconName);
      }
   }
   // DAOCoop: markers "daocoop_p2_target_n" / "_ally_n" / "_self_n" have no text;
   // the player's character name (DAOCoop.Name.N) is written above the image.
   static function CoopLabelIcon(a_mc, a_sIcon)
   {
      var _loc6_ = String(a_sIcon);
      var _loc2_ = a_mc.CoopName_txt;
      if(_loc6_.substr(0,9) != "daocoop_p" || _loc6_.substr(_loc6_.length - 2) != "_n")
      {
         if(_loc2_ != undefined)
         {
            _loc2_._visible = false;
         }
         return undefined;
      }
      var _loc7_ = _loc6_.charAt(9);
      var _loc8_ = _loc6_.substr(11,_loc6_.length - 13);
      var _loc5_ = ExternalCommands.GetValue("DAOCoop.Name." + _loc7_);
      if(_loc5_ == null || _loc5_ == undefined || String(_loc5_) == "")
      {
         _loc5_ = "P" + _loc7_;
      }
      if(_loc2_ == undefined)
      {
         _loc2_ = a_mc.createTextField("CoopName_txt",1001,0,0,200,24);
         var _loc3_ = new TextFormat();
         _loc3_.font = "$TitleFont";
         _loc3_.size = 16;
         _loc3_.bold = true;
         _loc3_.align = "center";
         _loc2_.embedFonts = true;
         _loc2_.selectable = false;
         _loc2_.setNewTextFormat(_loc3_);
         var _loc9_ = new flash.filters.GlowFilter(0,0.9,3,3,4,1);
         _loc2_.filters = [_loc9_];
      }
      _loc2_.text = String(_loc5_);
      _loc2_.textColor = _loc7_ != "2" ? 6741350 : 5080831;
      // the marker images are 64x64 with the top part left free for the name
      var _loc4_ = a_mc.Icon_mc;
      var _loc10_ = _loc8_ != "self" ? (_loc8_ != "ally" ? 8 : 2) : 18;
      _loc2_._x = _loc4_._x + 32 - 100;
      _loc2_._y = _loc4_._y + _loc10_;
      _loc2_._visible = true;
   }
   static function UpdateFloatyStats(a_nFloatyID, a_nFlags, a_sName, a_nCurrentHealth, a_nMaxHealth, a_nCreatureRank)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].UpdateData(a_nFlags,a_sName,a_nCurrentHealth,a_nMaxHealth,a_nCreatureRank);
      }
   }
   static function UpdateActionBarFloatyData(a_nFloatyID, a_nActionProgress, a_bInterrupt)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].UpdateData(a_nActionProgress,a_bInterrupt);
      }
   }
   static function UpdateOffscreenIndicatorFloatyData(a_nFloatyID, a_nType, a_X, a_Y)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].UpdateData(a_nType,a_X,a_Y);
         FloatyLayer.CoopMarkOffscreen(FloatyLayer.m_mapFloaties[a_nFloatyID],a_nFloatyID,a_nType);
      }
   }
   // DAOCoop: the off-screen arrow of Player 2/3's character is tinted in the
   // player's colour and labelled "P2"/"P3". The mod says whose arrow it is
   // (ExternalCommands.GetValue "DAOCoop.Floaty.<id>"); asked again now and then.
   static function CoopMarkOffscreen(a_mc, a_nID, a_nType)
   {
      if(a_mc.m_nCoopAsk == undefined || a_mc.m_nCoopAsk <= 0)
      {
         var _loc5_ = ExternalCommands.GetValue("DAOCoop.Floaty." + a_nID);
         a_mc.m_nCoopOwner = (_loc5_ == null || _loc5_ == undefined) ? 0 : Number(_loc5_);
         a_mc.m_nCoopAsk = 240;
         a_mc.m_sCoopName = "";
         if(a_mc.m_nCoopOwner == 2 || a_mc.m_nCoopOwner == 3)
         {
            var _loc10_ = ExternalCommands.GetValue("DAOCoop.Name." + a_mc.m_nCoopOwner);
            a_mc.m_sCoopName = (_loc10_ == null || _loc10_ == undefined) ? "" : String(_loc10_);
         }
      }
      a_mc.m_nCoopAsk = a_mc.m_nCoopAsk - 1;
      var _loc4_ = a_mc.PlayerOffscreen_mc;
      var _loc6_ = a_mc.m_nCoopOwner;
      if(a_nType != 0 || (_loc6_ != 2 && _loc6_ != 3))
      {
         if(a_mc.m_nCoopTint != undefined && a_mc.m_nCoopTint != 0)
         {
            new Color(_loc4_).setTransform({ra:100,ga:100,ba:100,aa:100,rb:0,gb:0,bb:0,ab:0});
            a_mc.m_nCoopTint = 0;
         }
         if(a_mc.CoopLabel_txt != undefined)
         {
            a_mc.CoopLabel_txt._visible = false;
         }
         return undefined;
      }
      if(a_mc.m_nCoopTint != _loc6_)
      {
         if(_loc6_ == 2)
         {
            new Color(_loc4_).setTransform({ra:35,ga:65,ba:100,aa:100,rb:20,gb:70,bb:150,ab:0});
         }
         else
         {
            new Color(_loc4_).setTransform({ra:40,ga:100,ba:40,aa:100,rb:30,gb:140,bb:30,ab:0});
         }
         a_mc.m_nCoopTint = _loc6_;
      }
      var _loc2_ = a_mc.CoopLabel_txt;
      if(_loc2_ == undefined)
      {
         _loc2_ = a_mc.createTextField("CoopLabel_txt",1000,0,0,160,26);
         var _loc3_ = new TextFormat();
         _loc3_.font = "$TitleFont";
         _loc3_.size = 18;
         _loc3_.bold = true;
         _loc3_.align = "center";
         _loc2_.embedFonts = true;
         _loc2_.selectable = false;
         _loc2_.setNewTextFormat(_loc3_);
      }
      _loc2_.text = a_mc.m_sCoopName != "" ? a_mc.m_sCoopName : "P" + _loc6_;
      _loc2_.textColor = _loc6_ != 2 ? 6741350 : 5080831;
      // just inside the arrow (it points out of the screen)
      var _loc7_ = _loc4_._rotation;
      var _loc8_ = 0;
      var _loc9_ = 0;
      if(_loc7_ > -45 && _loc7_ < 45)
      {
         _loc8_ = -100;
      }
      else if(_loc7_ >= 45 && _loc7_ < 135)
      {
         _loc9_ = -40;
      }
      else if(_loc7_ >= 135 || _loc7_ <= -135)
      {
         _loc8_ = 100;
      }
      else
      {
         _loc9_ = 40;
      }
      _loc2_._x = _loc4_._x + _loc8_ - 80;
      _loc2_._y = _loc4_._y + _loc9_ - 13;
      _loc2_._visible = _loc4_._visible && !_loc4_.MovieHidden;
   }
   static function UpdateDebugWorldSpaceTextFloatyData(a_nFloatyID, a_sText)
   {
      if(FloatyLayer.m_mapFloaties[a_nFloatyID])
      {
         FloatyLayer.m_mapFloaties[a_nFloatyID].UpdateData(a_sText);
      }
   }
   static function TestFloaty()
   {
      FloatyLayer.m_mapFloaties[1].SetType(1);
      FloatyLayer.SetFloatyPosition(1,400,400,4.9);
      FloatyLayer.DisplayFloatyMessage(1,"This is some ambient dialog that should wrap onto two lines...",3,16777215,0);
      FloatyLayer.DisplayFloatyMessage(1,"123",1,65535,0);
      for(var _loc1_ in FloatyLayer.m_mapFloaties)
      {
         FloatyLayer.SetFloatyIcon(_loc1_,"respawn");
         break;
      }
   }
   static function Lerp(t, a, b)
   {
      return a + t * (b - a);
   }
   static function InverseLerp(v, a, b)
   {
      return (v - a) / (b - a);
   }
   static function Clamp(v, a_fMin, a_fMax)
   {
      return Math.max(a_fMin,Math.min(v,a_fMax));
   }
   static function ShowAllFloatyNames()
   {
      for(var _loc1_ in FloatyLayer.m_mapFloaties)
      {
         MovieUtils.ShowMovie(FloatyLayer.m_mapFloaties[_loc1_].Name_mc);
      }
   }
   static function HideAllFloatyNames()
   {
      for(var _loc1_ in FloatyLayer.m_mapFloaties)
      {
         MovieUtils.HideMovie(FloatyLayer.m_mapFloaties[_loc1_].Name_mc);
      }
   }
   static function UpdateAllFloatyPositions()
   {
      if(FloatyLayer.BatchUpdateIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchUpdateIDs.length)
         {
            FloatyLayer.SetFloatyPosition(FloatyLayer.BatchUpdateIDs[_loc1_],FloatyLayer.BatchUpdatePositionsScalesAlphas[_loc1_ * 5],FloatyLayer.BatchUpdatePositionsScalesAlphas[_loc1_ * 5 + 1],FloatyLayer.BatchUpdatePositionsScalesAlphas[_loc1_ * 5 + 2],FloatyLayer.BatchUpdatePositionsScalesAlphas[_loc1_ * 5 + 3],FloatyLayer.BatchUpdatePositionsScalesAlphas[_loc1_ * 5 + 4],FloatyLayer.BatchUpdateOffsets[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchUpdateIDs.clear();
         FloatyLayer.BatchUpdatePositionsScalesAlphas.clear();
         FloatyLayer.BatchUpdateOffsets.clear();
      }
   }
   static function ProcessBatchUpdates()
   {
      if(FloatyLayer.BatchCreateIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchCreateIDs.length)
         {
            FloatyLayer.CreateFloaty(FloatyLayer.BatchCreateIDs[_loc1_],FloatyLayer.BatchCreateSymbolIDs[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchCreateIDs.clear();
         FloatyLayer.BatchCreateSymbolIDs.clear();
      }
      if(FloatyLayer.BatchShowIDs.length > 0)
      {
         _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchShowIDs.length)
         {
            FloatyLayer.ShowFloaty(FloatyLayer.BatchShowIDs[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchShowIDs.clear();
      }
      FloatyLayer.UpdateAllFloatyPositions();
      FloatyLayer.ProcessBatchMessageFloaties();
      FloatyLayer.ProcessBatchStatsFloaties();
      FloatyLayer.ProcessBatchIconFloaties();
      FloatyLayer.ProcessBatchOffscreenFloaties();
      if(FloatyLayer.BatchHideIDs.length > 0)
      {
         _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchHideIDs.length)
         {
            FloatyLayer.HideFloaty(FloatyLayer.BatchHideIDs[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchHideIDs.clear();
      }
      if(FloatyLayer.BatchDestroyIDs.length > 0)
      {
         _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchDestroyIDs.length)
         {
            FloatyLayer.DestroyFloaty(FloatyLayer.BatchDestroyIDs[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchDestroyIDs.clear();
      }
   }
   static function ProcessBatchMessageFloaties()
   {
      if(FloatyLayer.BatchUpdateMessageIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchUpdateMessageIDs.length)
         {
            FloatyLayer.DisplayFloatyMessage(FloatyLayer.BatchUpdateMessageIDs[_loc1_],FloatyLayer.BatchUpdateMessageStrings[_loc1_],FloatyLayer.BatchUpdateMessageStyles[_loc1_],FloatyLayer.BatchUpdateMessageColours[_loc1_],FloatyLayer.BatchUpdateMessageDurations[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchUpdateMessageIDs.clear();
         FloatyLayer.BatchUpdateMessageStrings.clear();
         FloatyLayer.BatchUpdateMessageStyles.clear();
         FloatyLayer.BatchUpdateMessageColours.clear();
         FloatyLayer.BatchUpdateMessageDurations.clear();
      }
   }
   static function ProcessBatchStatsFloaties()
   {
      if(FloatyLayer.BatchUpdateStatsIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchUpdateStatsIDs.length)
         {
            FloatyLayer.UpdateFloatyStats(FloatyLayer.BatchUpdateStatsIDs[_loc1_],FloatyLayer.BatchUpdateStatsFlags[_loc1_],FloatyLayer.BatchUpdateStatsNames[_loc1_],FloatyLayer.BatchUpdateStatsCurrentHealths[_loc1_],FloatyLayer.BatchUpdateStatsTotalHealths[_loc1_],FloatyLayer.BatchUpdateStatsRanks[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchUpdateStatsIDs.clear();
         FloatyLayer.BatchUpdateStatsFlags.clear();
         FloatyLayer.BatchUpdateStatsNames.clear();
         FloatyLayer.BatchUpdateStatsCurrentHealths.clear();
         FloatyLayer.BatchUpdateStatsTotalHealths.clear();
         FloatyLayer.BatchUpdateStatsRanks.clear();
      }
   }
   static function ProcessBatchIconFloaties()
   {
      if(FloatyLayer.BatchUpdateIconIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchUpdateIconIDs.length)
         {
            FloatyLayer.SetFloatyIcon(FloatyLayer.BatchUpdateIconIDs[_loc1_],FloatyLayer.BatchUpdateIconNames[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchUpdateIconIDs.clear();
         FloatyLayer.BatchUpdateIconNames.clear();
      }
   }
   static function ProcessBatchOffscreenFloaties()
   {
      if(FloatyLayer.BatchUpdateOffscreenIDs.length > 0)
      {
         var _loc1_ = 0;
         while(_loc1_ < FloatyLayer.BatchUpdateOffscreenIDs.length)
         {
            FloatyLayer.UpdateOffscreenIndicatorFloatyData(FloatyLayer.BatchUpdateOffscreenIDs[_loc1_],FloatyLayer.BatchUpdateOffscreenTypes[_loc1_],FloatyLayer.BatchUpdateOffscreenXs[_loc1_],FloatyLayer.BatchUpdateOffscreenYs[_loc1_]);
            _loc1_ = _loc1_ + 1;
         }
         FloatyLayer.BatchUpdateOffscreenIDs.clear();
         FloatyLayer.BatchUpdateOffscreenTypes.clear();
         FloatyLayer.BatchUpdateOffscreenXs.clear();
         FloatyLayer.BatchUpdateOffscreenYs.clear();
      }
   }
   static function RequestMessageFloatyFromPool()
   {
      var _loc2_ = undefined;
      if(FloatyLayer.m_nFloatyPoolUseCount < FloatyLayer.m_aFloatyPool.length)
      {
         _loc2_ = FloatyLayer.m_aFloatyPool[FloatyLayer.m_nFloatyPoolUseCount];
      }
      else if(FloatyLayer.m_aFloatyPool.length < FloatyLayer.MAX_FLOATIES)
      {
         _loc2_ = MovieUtils.CreateMovie(_root,FloatyLayer.FloatySymbolNames[FloatyLayer.FLOATY_SYMBOL_MESSAGE]);
         FloatyLayer.m_aFloatyPool.push(_loc2_);
      }
      if(_loc2_ != null)
      {
         _loc2_.m_nPoolIndex = FloatyLayer.m_nFloatyPoolUseCount;
         FloatyLayer.m_nFloatyPoolUseCount += 1;
      }
      return _loc2_;
   }
   static function ReturnMessageFloatyToPool(a_mcFloaty)
   {
      var _loc1_ = a_mcFloaty.m_nPoolIndex;
      if(_loc1_ != FloatyLayer.m_nFloatyPoolUseCount - 1)
      {
         FloatyLayer.m_aFloatyPool[_loc1_] = FloatyLayer.m_aFloatyPool[FloatyLayer.m_nFloatyPoolUseCount - 1];
         FloatyLayer.m_aFloatyPool[_loc1_].m_nPoolIndex = _loc1_;
         FloatyLayer.m_aFloatyPool[FloatyLayer.m_nFloatyPoolUseCount - 1] = a_mcFloaty;
      }
      FloatyLayer.m_nFloatyPoolUseCount -= 1;
   }
   static function PrintFloatyLists()
   {
      var _loc3_ = new Array();
      for(var _loc4_ in FloatyLayer.m_mapFloaties)
      {
         _loc3_.push(_loc4_);
      }
      var _loc2_ = new Array();
      var _loc1_ = 0;
      while(_loc1_ < FloatyLayer.m_aFloatyPool.length)
      {
         _loc2_.push(FloatyLayer.m_aFloatyPool[_loc1_]);
         _loc1_ = _loc1_ + 1;
      }
      trace("FLOATIES: " + _loc3_ + " / " + FloatyLayer.m_nFloatyPoolUseCount + " / " + _loc2_);
   }
}
