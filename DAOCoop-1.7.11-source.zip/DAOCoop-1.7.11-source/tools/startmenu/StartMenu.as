class StartMenu extends Scene
{
   var SetText;
   var AddBehaviour;
   var VAlign;
   var HAlign;
   var SetButtonAction;
   var Disable;
   var Text;
   var PreserveAspectRatio;
   var DisableAlignment;
   var MaxScale;
   var gotoAndStop;
   var stop;
   var ConnectScrollbar;
   static var SelectedModule;
   static var ms_StartMenuButtons;
   static var ms_LoginWidget;
   static var ms_Loading;
   static var m_fCloudUpdateTime;
   static var CLOUD1_ANIM_END = -7498;
   static var CLOUD1_ANIM_LOOP = 900;
   static var CLOUD1_ANIM_SPEED = StartMenu.CLOUD1_ANIM_END / StartMenu.CLOUD1_ANIM_LOOP;
   static var CLOUD2_ANIM_END = -3150;
   static var CLOUD2_ANIM_LOOP = 200;
   static var CLOUD2_ANIM_SPEED = StartMenu.CLOUD2_ANIM_END / StartMenu.CLOUD2_ANIM_LOOP;
   static var ms_ShowContents = false;
   function StartMenu()
   {
      super();
   }
   static function StartScene()
   {
      if(GUISystem.RunningInGame == false)
      {
         ExternalCommands.GetNumMembers = function(x)
         {
            return 2;
         };
         ExternalCommands.GetValue = function(x)
         {
            return x;
         };
      }
      ContextSystem.CreateContext("StartMenuContext");
      ContextSystem.PushContext("StartMenuContext");
      ExternalCommands.PlayGUISound(SoundEvents.ST_SHOW_START_MENU);
      if(ExternalCommands.GetValue("ClientOptions.GameOptions.SkipWelcomeMessage") == 0)
      {
         Popups.ShowDialogBox(Localization.Strings.LOC_WELCOME_MESSAGE,Localization.Strings.LOC_OK,function()
         {
         }
         );
         ExternalCommands.SendMessageArgs("ClientOptions.SetClientOptionMessage","GameOptions.SkipWelcomeMessage","1");
         ExternalCommands.SendMessage("ClientOptions.CommitOptions");
      }
      StartMenu.SetupMainMenuButtonInitFunctions();
   }
   static function FinishScene()
   {
      ExternalCommands.PlayGUISound(SoundEvents.ST_HIDE_START_MENU);
      ContextSystem.PopContext("StartMenuContext");
   }
   static function StartScene_Default()
   {
      SceneManager.PlayScene("MainMenuIntro");
   }
   static function FinishScene_Default()
   {
   }
   static function StartScene_MainMenuIntro()
   {
      var _loc2_ = new GUI.FocusContainer.ListContainer();
      FocusManager.AddContainer(_root,_loc2_);
   }
   static function FinishScene_MainMenuIntro()
   {
   }
   static function StartScene_MainMenu()
   {
      var _loc2_ = new GUI.FocusContainer.ListContainer();
      FocusManager.AddContainer(_root,_loc2_);
   }
   static function FinishScene_MainMenu()
   {
   }
   static function StartScene_ModuleList()
   {
      var _loc2_ = new GUI.FocusContainer.ListContainer();
      FocusManager.AddContainer(_root,_loc2_);
      StartMenu.SetupModuleListInitFunctions();
   }
   static function FinishScene_ModuleList()
   {
   }
   static function StartScene_Outro()
   {
   }
   static function FinishScene_Outro()
   {
   }
   static function Resume()
   {
      ExternalCommands.SendMessage("SaveLoad.ResumeGame");
   }
   static function NewGame()
   {
      ExternalCommands.GetValue("DAOCoop.Cmd.SinglePlayer");
      fscommand("LoadModule","single player");
   }
   static function LoadGame()
   {
      StartMenu.HideContents();
      ExternalCommands.SendMessageArgs("SaveLoad.SetSaveLoadMode","2");
      ExternalCommands.SendMessageArgs("GameModeController.PushGUIScreen","SaveLoad");
   }
   static function DownloadableContent()
   {
      ExternalCommands.SendMessageArgs("GameModeController.PushGUIScreen","PRCContentManager");
   }
   static function Screenshots()
   {
      StartMenu.HideContents();
      ExternalCommands.SendMessageArgs("GameModeController.PushGUIScreen","GUICommunityFeatures");
   }
   static function LoadModule()
   {
      SceneManager.PlayScene("ModuleList");
   }
   static function Options()
   {
      StartMenu.HideContents();
      ExternalCommands.SendMessageArgs("GameModeController.PushGUIScreen","Options");
   }
   static function Credits()
   {
      StartMenu.HideContents();
      ExternalCommands.SendMessageArgs("GameModeController.PushGUIScreen","Credits");
   }
   static function Quit()
   {
      fscommand("QuitGame");
   }
   static function Play()
   {
      if(StartMenu.SelectedModule)
      {
         StartMenu.LoadSelectedModule();
      }
   }
   static function Back()
   {
      if(StartMenu.ms_Coop != null)
      {
         StartMenu.CoopBack();
         return undefined;
      }
      SceneManager.PlayScene("MainMenu");
   }
   static function LoadSelectedModule()
   {
      fscommand("LoadModule",StartMenu.SelectedModule);
   }
   static function SetupMainMenuButtonInitFunctions()
   {
      StartMenu.ms_ShowContents = ExternalCommands.GetValue("GameMode.ShowStartMenuContents") != 0;
      if(StartMenu.ms_ShowContents == false)
      {
         var nObserverID = TokenManager.AddTokenObserverWithID(_OBSERVER_ID.STARTMENU_CONTENTS,"GameMode.ShowStartMenuContents",function(a_Value)
         {
            if(a_Value != 0)
            {
               StartMenu.ms_ShowContents = true;
               MovieUtils.ShowMovie(StartMenu.ms_StartMenuButtons);
               MovieUtils.ShowMovie(StartMenu.ms_LoginWidget);
               MovieUtils.HideMovie(StartMenu.ms_Loading);
               StartMenu.ms_StartMenuButtons.play();
               StartMenu.ms_LoginWidget.play();
               TokenManager.RemoveTokenObserverByID(nObserverID);
            }
         }
         );
      }
      StartMenu.CoopInstall();
      _root.CoopButton_init = function()
      {
         this.SetButtonAction(StartMenu.CoopOpen);
         this.SetText("Co-op");
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         this.OnAction = function(a_sAction)
         {
            this.SimulateButtonPush();
            return true;
         };
         FocusManager.AddItem(this);
         StartMenu.CoopFocusAfter(this,this._parent.NewGameButton);
      };
      _root.StartMenuTitle_mc_init = function()
      {
         this.SetText(Localization.Strings.LOC_START_MENU_TITLE);
      };
      _root.CopyrightText_mc_init = function()
      {
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_BOTTOM;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_CENTRE;
         this.SetText(Localization.Strings.LOC_START_MENU_COPYRIGHT);
      };
      _root.ResumeButton_init = function()
      {
         this.SetButtonAction(StartMenu.Resume);
         this.SetText(Localization.Strings.LOC_RESUME);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         StartMenu.UpdateLoadButtons();
         FocusManager.AddItem(this);
      };
      _root.NewGameButton_init = function()
      {
         this.SetButtonAction(StartMenu.NewGame);
         this.SetText(Localization.Strings.LOC_NEW_GAME);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
         if(GUISystem.Platform != "PC")
         {
            FocusManager.SetCurrentFocus(this);
         }
      };
      _root.LoadGameButton_init = function()
      {
         this.SetButtonAction(StartMenu.LoadGame);
         this.SetText(Localization.Strings.LOC_LOAD_GAME);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         StartMenu.UpdateLoadButtons();
         TokenManager.AddTokenObserverWithID(_OBSERVER_ID.STARTMENU_UPDATELOADBUTTON,"SaveLoad.HeroList",function()
         {
            StartMenu.UpdateLoadButtons();
         }
         );
         FocusManager.AddItem(this);
      };
      _root.DownloadableContentButton_init = function()
      {
         this.SetButtonAction(StartMenu.DownloadableContent);
         this.SetText(Localization.Strings.LOC_DOWNLOADABLE_CONTENT);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
      };
      _root.ModuleButton_init = function()
      {
         this.SetButtonAction(StartMenu.LoadModule);
         this.SetText(Localization.Strings.LOC_OTHER_CAMPAIGN);
         FocusManager.AddItem(this);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         if(ExternalCommands.GetNumMembers("Client.ModuleInfoList") == 0)
         {
            this.Disable();
         }
      };
      _root.OptionsButton_init = function()
      {
         this.SetButtonAction(StartMenu.Options);
         this.SetText(Localization.Strings.LOC_OPTIONS);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
      };
      _root.CreditsButton_init = function()
      {
         this.SetButtonAction(StartMenu.Credits);
         this.SetText(Localization.Strings.LOC_CREDITS);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
      };
      _root.QuitButton_init = function()
      {
         this.SetButtonAction(StartMenu.Quit);
         this.SetText(Localization.Strings.LOC_QUIT);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
      };
      _root.ScreenshotsButton_init = function()
      {
         this.SetButtonAction(StartMenu.Screenshots);
         this.SetText(Localization.Strings.LOC_ONLINE_FEATURES);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         FocusManager.AddItem(this);
      };
      _root.Version_init = function()
      {
         this.Text.text = ExternalCommands.GetValue("Client.VersionString");
      };
      _root.Logo_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
         this.PreserveAspectRatio = true;
         this.DisableAlignment = true;
         this.MaxScale = 1.3;
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_TOP;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_RIGHT;
      };
      _root.LogoContainer_mc.Logo_mc.LogoG_mc.Origins_mc_init = function()
      {
         var _loc2_ = ExternalCommands.GetString("ClientOptions.GameOptions.Locale");
         _loc2_ = _loc2_.toUpperCase();
         _loc2_ = _loc2_.substr(0,2);
         this.gotoAndStop(_loc2_);
      };
      _root.StartMenuButtons_mc_init = function()
      {
         StartMenu.ms_StartMenuButtons = this;
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_BOTTOM;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_RIGHT;
         if(StartMenu.ms_ShowContents == false)
         {
            MovieUtils.HideMovie(this);
            this.stop();
         }
      };
      _root.LoginWidgetContainer_mc_init = function()
      {
         StartMenu.ms_LoginWidget = this;
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.VAlign = Behaviour.AlignedLayout.ALIGN_BOTTOM;
         this.HAlign = Behaviour.AlignedLayout.ALIGN_LEFT;
         if(StartMenu.ms_ShowContents == false)
         {
            MovieUtils.HideMovie(this);
            this.stop();
         }
      };
      _root.Loading_mc_init = function()
      {
         this.AddBehaviour(Behaviour.AlignedLayout);
         this.HAlign = Behaviour.AlignedLayout.ALIGN_RIGHT;
         this.VAlign = Behaviour.AlignedLayout.ALIGN_BOTTOM;
         StartMenu.ms_Loading = this;
         if(StartMenu.ms_ShowContents)
         {
            MovieUtils.HideMovie(this);
         }
      };
      _root.Black_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
      };
      _root.Overlay_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
      };
      _root.EdgeShadow_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
      };
      _root.TempBackground_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
      };
      _root.TempBackground2_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
      };
      _root.BackgroundImageContainer_mc_init = function()
      {
         this.AddBehaviour(Behaviour.ScaleToScreen);
         this.PreserveAspectRatio = true;
      };
      FuncUtils.RepeatWithDelay(function()
      {
         StartMenu.AnimateClouds();
      }
      ,0.016666666666666666);
   }
   static function SetupModuleListInitFunctions()
   {
      _root.Version_init = function()
      {
         this.Text.text = ExternalCommands.GetValue("Client.VersionString");
      };
      _root.PlayButton_init = function()
      {
         this.SetText(Localization.Strings.LOC_PLAY_MODULE);
         this.SetButtonAction(StartMenu.Play);
         FocusManager.AddItem(this);
      };
      _root.BackButton_init = function()
      {
         this.SetText(Localization.Strings.LOC_CANCEL);
         this.SetButtonAction(StartMenu.Back);
         FocusManager.AddItem(this);
      };
      _root.ModuleScrollbar_init = function()
      {
         this.ConnectScrollbar(_root.ModuleList);
      };
      _root.DescriptionText_mc_init = function()
      {
         this.SetText("");
      };
      _root.header_txt_mc_init = function()
      {
         this.SetText(Localization.Strings.LOC_CAMPAIGNS_HEAD);
      };
   }
   static function UpdateLoadButtons()
   {
      if(ExternalCommands.GetNumMembers("SaveLoad.HeroList") == 0)
      {
         _root.StartButtons_mc.StartMenuButtons_mc.LoadGameButton.Disable();
         MovieUtils.HideMovie(_root.StartButtons_mc.StartMenuButtons_mc.ResumeButton);
      }
      else
      {
         _root.StartButtons_mc.StartMenuButtons_mc.LoadGameButton.Enable();
         MovieUtils.ShowMovie(_root.StartButtons_mc.StartMenuButtons_mc.ResumeButton);
      }
   }
   static function ShowContents()
   {
      MovieUtils.ShowMovie(_root.StartButtons_mc);
      _root.StartButtons_mc.StartMenuButtons_mc.gotoAndPlay(1);
      MovieUtils.ShowMovie(_root.LogoContainer_mc);
      MovieUtils.ShowMovie(_root.LoginWidgetContainer_mc);
   }
   static function HideContents()
   {
      MovieUtils.HideMovie(_root.StartButtons_mc);
      MovieUtils.HideMovie(_root.LogoContainer_mc);
      MovieUtils.HideMovie(_root.LoginWidgetContainer_mc);
   }
   static function AnimateClouds()
   {
      var _loc3_ = _root.BackgroundImageContainer_mc.BackgroundImage_mc.Cloud1_mc;
      var _loc2_ = _root.BackgroundImageContainer_mc.BackgroundImage_mc.Cloud2_mc;
      var _loc4_ = getTimer();
      var _loc5_ = (_loc4_ - StartMenu.m_fCloudUpdateTime) / 1000;
      StartMenu.m_fCloudUpdateTime = _loc4_;
      _loc3_._x += StartMenu.CLOUD1_ANIM_SPEED * _loc5_;
      while(_loc3_._x < StartMenu.CLOUD1_ANIM_END)
      {
         _loc3_._x -= StartMenu.CLOUD1_ANIM_END;
      }
      _loc2_._x += StartMenu.CLOUD2_ANIM_SPEED * _loc5_;
      while(_loc2_._x < StartMenu.CLOUD2_ANIM_END)
      {
         _loc2_._x -= StartMenu.CLOUD2_ANIM_END;
      }
   }
   // ======================================================================
   // DAOCoop: Co-op button and the co-op menus (local / online, 2 or 3
   // players, lobby). The mod answers through ExternalCommands.GetValue
   // ("DAOCoop.*"); without the mod the button never appears.
   // ======================================================================
   static var COOP_SPACING = 34;
   static var ms_CoopLockButton = null;
   static var ms_CoopStatus = null;
   static var ms_CoopCodeField = null;
   static var ms_CoopGamesShown = "";
   static var ms_CoopJoinFrom = "browse";
   static var ms_CoopReturned = false;
   static var ms_CoopWantList = false;
   static var ms_CoopRefreshAt = 0;
   static var ms_CoopLocked = false;
   static var COOP_GOLD = 13547636;
   static var COOP_GREEN = 8376959;
   static var COOP_GREY = 10132122;
   static var COOP_WHITE = 15787720;
   static var ms_Coop = null;
   static var ms_CoopScreen = "";
   static var ms_CoopOnline = false;
   static var ms_CoopLoad = false;
   static var ms_CoopReady = false;
   static var ms_CoopCountdown = -1;
   static var ms_CoopLines = null;
   static var ms_CoopReadyButton = null;
   static var ms_CoopAvailable = 0;
   static var ms_CoopLaidOut = false;
   static var ms_CoopOrigY = null;
   static var ms_CoopFocusTarget = null;
   static function CoopCmd(a_sName)
   {
      return ExternalCommands.GetValue("DAOCoop." + a_sName);
   }
   static function CoopUsingController()
   {
      return GUISystem.Platform != "PC" || Number(ExternalCommands.GetValue("DebugOptions.EnableController")) == 1;
   }
   static function CoopInstall()
   {
      var _loc2_ = _root.createEmptyMovieClip("DAOCoopWatch_mc",16001);
      _loc2_.m_nWait = 0;
      _loc2_.m_nRetry = 0;
      _loc2_.onEnterFrame = function()
      {
         var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc;
         if(_loc2_ == undefined || _loc2_.NewGameButton == undefined)
         {
            return undefined;
         }
         if(_loc2_._currentframe < _loc2_._totalframes)
         {
            StartMenu.ms_CoopLaidOut = false;
            return undefined;
         }
         if(!StartMenu.ms_CoopLaidOut)
         {
            StartMenu.ms_CoopLaidOut = true;
            this.m_nRetry = 0;
            StartMenu.CoopLayout(_loc2_);
         }
         else if(StartMenu.ms_CoopAvailable != 1 && this.m_nRetry < 30)
         {
            // the mod may not be listening yet: ask again every 2 seconds for a minute
            this.m_nWait = this.m_nWait + 1;
            if(this.m_nWait >= 120)
            {
               this.m_nWait = 0;
               this.m_nRetry = this.m_nRetry + 1;
               StartMenu.CoopLayout(_loc2_);
            }
         }
      };
   }
   static function CoopLayout(a_mcButtons)
   {
      if(StartMenu.ms_CoopAvailable != 1)
      {
         var _loc3_ = StartMenu.CoopCmd("Version");
         StartMenu.ms_CoopAvailable = (_loc3_ == null || _loc3_ == undefined || String(_loc3_) == "") ? -1 : 1;
      }
      if(StartMenu.ms_CoopAvailable != 1)
      {
         return undefined;
      }
      var _loc2_ = a_mcButtons.NewGameButton;
      if(StartMenu.ms_CoopOrigY == null)
      {
         StartMenu.ms_CoopOrigY = {newGame:_loc2_._y,resume:a_mcButtons.ResumeButton._y};
      }
      // Room for "Co-op" right under "New Game": the two buttons above move up one row.
      _loc2_._y = StartMenu.ms_CoopOrigY.newGame - StartMenu.COOP_SPACING;
      a_mcButtons.ResumeButton._y = StartMenu.ms_CoopOrigY.resume - StartMenu.COOP_SPACING;
      if(a_mcButtons.CoopButton == undefined)
      {
         a_mcButtons.attachMovie("bu_m","CoopButton",500,{_x:_loc2_._x,_y:StartMenu.ms_CoopOrigY.newGame,_xscale:_loc2_._xscale,_yscale:_loc2_._yscale});
      }
      else
      {
         a_mcButtons.CoopButton._y = StartMenu.ms_CoopOrigY.newGame;
      }
   }
   static function CoopFocusAfter(a_Item, a_After)
   {
      // The start menu's list runs bottom-to-top (buttons are added in
      // placement order), so put Co-op where its height on screen says.
      var _loc3_ = FocusManager.FindParentContainer(a_Item._parent);
      if(_loc3_ == null || _loc3_.m_Contents == null)
      {
         return undefined;
      }
      var _loc2_ = _loc3_.m_Contents;
      var _loc4_ = _loc2_.find(a_Item);
      if(_loc4_ >= 0)
      {
         _loc2_.splice(_loc4_,1);
      }
      var _loc5_ = _loc2_.find(a_After);
      if(_loc5_ < 0)
      {
         _loc2_.push(a_Item);
         return undefined;
      }
      // Direction of the list: compare a neighbour of "New Game" with it.
      var _loc6_ = _loc2_[_loc5_ + 1];
      var _loc7_ = _loc2_[_loc5_ - 1];
      var _loc8_ = true;
      if(_loc6_ != undefined && _loc6_._y != undefined)
      {
         _loc8_ = _loc6_._y > a_After._y;
      }
      else if(_loc7_ != undefined && _loc7_._y != undefined)
      {
         _loc8_ = _loc7_._y < a_After._y;
      }
      // Co-op sits just below New Game on screen.
      if(_loc8_)
      {
         _loc2_.splice(_loc5_ + 1,0,a_Item);
      }
      else
      {
         _loc2_.splice(_loc5_,0,a_Item);
      }
   }
   // --- opening / closing ------------------------------------------------------
   static function CoopOpen()
   {
      var _loc3_ = _root.StartButtons_mc;
      var _loc2_ = _loc3_.StartMenuButtons_mc;
      StartMenu.CoopCmd("Cmd.Open");
      var _loc4_ = _loc3_._parent.createEmptyMovieClip("DAOCoopMenu_mc",16000);
      _loc4_._x = _loc3_._x;
      _loc4_._y = _loc3_._y;
      _loc4_._xscale = _loc3_._xscale;
      _loc4_._yscale = _loc3_._yscale;
      var _loc5_ = _loc4_.createEmptyMovieClip("Inner_mc",1);
      _loc5_._x = _loc2_._x;
      _loc5_._y = _loc2_._y;
      _loc5_._xscale = _loc2_._xscale;
      _loc5_._yscale = _loc2_._yscale;
      StartMenu.ms_Coop = _loc5_;
      StartMenu.ms_CoopOnline = false;
      StartMenu.ms_CoopLoad = false;
      MovieUtils.HideMovie(_loc3_);
      StartMenu.CoopShow("mode");
   }
   static function CoopClose()
   {
      StartMenu.CoopCmd("Cmd.Close");
      StartMenu.CoopRemoveUi();
      var _loc2_ = _root.StartButtons_mc;
      MovieUtils.ShowMovie(_loc2_);
      if(StartMenu.CoopUsingController())
      {
         FocusManager.SetCurrentFocus(_loc2_.StartMenuButtons_mc.CoopButton);
      }
   }
   static function CoopRemoveUi()
   {
      if(StartMenu.ms_Coop != null)
      {
         StartMenu.CoopClearScreen();
         StartMenu.ms_Coop._parent.removeMovieClip();
      }
      StartMenu.ms_Coop = null;
      StartMenu.ms_CoopScreen = "";
   }
   static function CoopBack()
   {
      var _loc2_ = StartMenu.ms_CoopScreen;
      if(_loc2_ == "lobby")
      {
         StartMenu.CoopShow("players");
      }
      else if(_loc2_ == "join")
      {
         StartMenu.CoopCmd("Cmd.JoinBack");
         StartMenu.CoopShow("joinmenu");
      }
      else if(_loc2_ == "browse" || _loc2_ == "code")
      {
         StartMenu.CoopShow("joinmenu");
      }
      else if(_loc2_ == "joinmenu")
      {
         StartMenu.CoopCmd("Cmd.Leave");
         StartMenu.CoopShow("online");
      }
      else if(_loc2_ == "players")
      {
         StartMenu.CoopShow("start");
      }
      else if(_loc2_ == "start")
      {
         StartMenu.CoopShow(!StartMenu.ms_CoopOnline ? "mode" : "online");
      }
      else if(_loc2_ == "online")
      {
         StartMenu.CoopShow("mode");
      }
      else
      {
         StartMenu.CoopClose();
      }
   }
   // --- screens -------------------------------------------------------------
   static function CoopClearScreen()
   {
      var _loc4_ = StartMenu.ms_Coop.Screen_mc;
      if(_loc4_ == undefined)
      {
         return undefined;
      }
      var _loc3_ = FocusManager.FindParentContainer(StartMenu.ms_Coop);
      if(_loc3_ != null && _loc3_.m_Contents != null)
      {
         var _loc2_ = _loc3_.m_Contents.length - 1;
         while(_loc2_ >= 0)
         {
            if(_loc3_.m_Contents[_loc2_]._parent == _loc4_)
            {
               _loc3_.m_Contents.splice(_loc2_,1);
            }
            _loc2_ = _loc2_ - 1;
         }
      }
      delete _loc4_.onEnterFrame;
      _loc4_.removeMovieClip();
      StartMenu.ms_CoopLines = null;
      StartMenu.ms_CoopReadyButton = null;
      StartMenu.ms_CoopLockButton = null;
      StartMenu.ms_CoopStatus = null;
      StartMenu.ms_CoopCodeField = null;
   }
   static function CoopShow(a_sScreen)
   {
      StartMenu.CoopClearScreen();
      StartMenu.ms_CoopScreen = a_sScreen;
      StartMenu.ms_CoopCountdown = -1;
      var _loc3_ = StartMenu.ms_Coop.createEmptyMovieClip("Screen_mc",1);
      _loc3_.m_nButtons = 0;
      var _loc4_ = StartMenu.CoopBottom();
      var _loc5_ = StartMenu.COOP_SPACING;
      var _loc6_ = null;
      if(a_sScreen == "mode")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Co-op",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Play the campaign together",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Ver_txt","DAOCoop " + StartMenu.CoopCmd("Version"),_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Local_bu","Local Co-op",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.ms_CoopOnline = false;
            StartMenu.CoopCmd("Cmd.Mode.local");
            StartMenu.CoopShow("start");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Online_bu","Online Multiplayer",_loc4_ - _loc5_,function()
         {
            StartMenu.ms_CoopOnline = true;
            StartMenu.CoopShow("online");
         }
         ,true);
      }
      else if(a_sScreen == "online")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Online Multiplayer",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Host a game, or join one from the list or with an invite code",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt","Friends need the game and this mod",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Host_bu","Host Game",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Mode.host");
            StartMenu.CoopShow("start");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Join_bu","Join Game",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Mode.join");
            StartMenu.CoopShow("joinmenu");
         }
         ,true);
      }
      else if(a_sScreen == "start")
      {
         // New game or a saved one (asked before the lobby)
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt",!StartMenu.ms_CoopOnline ? "Local Co-op" : "Host Game",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Start a new game or load a save?",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt","With a save, everyone's characters come back with it",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"New_bu","New Game",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.ms_CoopLoad = false;
            StartMenu.CoopCmd("Cmd.Start.new");
            StartMenu.CoopShow("players");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"LoadSave_bu","Load Game",_loc4_ - _loc5_,function()
         {
            StartMenu.ms_CoopLoad = true;
            StartMenu.CoopCmd("Cmd.Start.load");
            StartMenu.CoopShow("players");
         }
         ,ExternalCommands.GetNumMembers("SaveLoad.HeroList") > 0);
      }
      else if(a_sScreen == "players")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt",!StartMenu.ms_CoopOnline ? "Local Co-op" : "Host Game",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","How many players?",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt",!StartMenu.ms_CoopLoad ? "Player 1 makes the Warden, then everyone else makes theirs as the story starts" : "After the lobby Player 1 picks the save to load",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Two_bu","2 Players",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Players.2");
            StartMenu.CoopShow("lobby");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Three_bu","3 Players",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Players.3");
            StartMenu.CoopShow("lobby");
         }
         ,true);
      }
      else if(a_sScreen == "joinmenu")
      {
         // 1.4.3: Join Game - the list of games, or a friend's invite code
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Join Game",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Browse everyone's open games, or join a friend with their invite code",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt","Hosts with Lock Lobby off show in the list - they say yes or no to each player",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Browse_bu","Browse Games",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Refresh");
            StartMenu.ms_CoopWantList = true;
            StartMenu.CoopShow("browse");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Code_bu","Join a Friend",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopShow("code");
         }
         ,true);
         StartMenu.CoopWatchJoin(_loc3_,false);
      }
      else if(a_sScreen == "browse")
      {
         var _loc16_ = String(StartMenu.CoopCmd("Games")).split("|");
         StartMenu.ms_CoopGamesShown = _loc16_.slice(1).join("|");
         StartMenu.CoopPanel(_loc3_,_loc4_ - 9 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Open Games",_loc4_ - 9 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.ms_CoopStatus = StartMenu.CoopText(_loc3_,"Status_txt",_loc16_[0],_loc4_ - 8 * _loc5_ - 4,StartMenu.COOP_GREY,16);
         var _loc17_ = 1;
         while(_loc17_ < _loc16_.length && _loc17_ <= 6)
         {
            var _loc18_ = String(_loc16_[_loc17_]);
            var _loc19_ = _loc18_.indexOf("~");
            var _loc20_ = StartMenu.CoopGameButton(_loc3_,_loc17_,_loc18_.substr(0,_loc19_),_loc18_.substr(_loc19_ + 1),_loc4_ - (8 - _loc17_) * _loc5_);
            if(_loc6_ == null)
            {
               _loc6_ = _loc20_;
            }
            _loc17_ = _loc17_ + 1;
         }
         var _loc21_ = StartMenu.CoopMakeButton(_loc3_,"Refresh_bu","Refresh",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Refresh");
            StartMenu.ms_CoopWantList = true;
            StartMenu.ms_CoopRefreshAt = getTimer();
            if(StartMenu.ms_CoopStatus != null)
            {
               StartMenu.ms_CoopStatus.text = "Refreshing...";
            }
         }
         ,true);
         if(_loc6_ == null)
         {
            _loc6_ = _loc21_;
         }
         StartMenu.CoopWatchJoin(_loc3_,true);
      }
      else if(a_sScreen == "code")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 6 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Join a Friend",_loc4_ - 6 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Type your friend's invite code, or copy it (Ctrl+C) and press Paste",_loc4_ - 5 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         var _loc22_ = _loc3_.createTextField("Code_txt",_loc3_.getNextHighestDepth(),StartMenu.CoopRight() - 560,_loc4_ - 4 * _loc5_ + 2,380,32);
         var _loc23_ = new TextFormat();
         _loc23_.font = "$TitleFont";
         _loc23_.size = 22;
         _loc23_.color = StartMenu.COOP_WHITE;
         _loc23_.align = "center";
         _loc22_.embedFonts = true;
         _loc22_.type = "input";
         _loc22_.selectable = true;
         _loc22_.multiline = false;
         _loc22_.maxChars = 48;
         _loc22_.border = true;
         _loc22_.borderColor = StartMenu.COOP_GOLD;
         _loc22_.background = true;
         _loc22_.backgroundColor = 1118481;
         _loc22_.setNewTextFormat(_loc23_);
         _loc22_.text = String(StartMenu.CoopCmd("Clipboard"));
         _loc22_.setTextFormat(_loc23_);
         StartMenu.ms_CoopCodeField = _loc22_;
         StartMenu.ms_CoopStatus = StartMenu.CoopText(_loc3_,"Status_txt",!StartMenu.ms_CoopReturned ? "" : String(String(StartMenu.CoopCmd("Games")).split("|")[0]),_loc4_ - 3 * _loc5_ - 2,StartMenu.COOP_GREY,16);
         StartMenu.ms_CoopReturned = false;
         StartMenu.CoopMakeButton(_loc3_,"Paste_bu","Paste",_loc4_ - 2 * _loc5_,function()
         {
            var _loc2_ = String(StartMenu.CoopCmd("Clipboard"));
            if(_loc2_ == "")
            {
               StartMenu.ms_CoopStatus.text = "No invite code on the clipboard - copy it first (Ctrl+C)";
            }
            else
            {
               StartMenu.ms_CoopCodeField.text = _loc2_;
               StartMenu.ms_CoopStatus.text = "";
            }
         }
         ,true);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"JoinCode_bu","Join",_loc4_ - _loc5_,function()
         {
            if(String(StartMenu.CoopCmd("Cmd.Code." + StartMenu.ms_CoopCodeField.text)) == "ok")
            {
               StartMenu.ms_CoopJoinFrom = "code";
               StartMenu.CoopShow("join");
            }
            else
            {
               var _loc2_ = String(StartMenu.CoopCmd("Games")).split("|");
               StartMenu.ms_CoopStatus.text = _loc2_[0];
            }
         }
         ,true);
         if(!StartMenu.CoopUsingController())
         {
            Selection.setFocus(_loc22_);
         }
         StartMenu.CoopWatchJoin(_loc3_,false);
      }
      else if(a_sScreen == "lobby" || a_sScreen == "join")
      {
         // 1.4.1: the host of an online game gets a "Lock Lobby" on/off button above Ready
         var _loc13_ = "";
         if(a_sScreen == "lobby" && StartMenu.ms_CoopOnline)
         {
            _loc13_ = String(StartMenu.CoopCmd("Locked"));
         }
         var _loc14_ = _loc13_ == "0" || _loc13_ == "1";
         var _loc15_ = !_loc14_ ? 8 : 9;
         StartMenu.CoopPanel(_loc3_,_loc4_ - _loc15_ * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.ms_CoopLines = new Array();
         var _loc7_ = 0;
         while(_loc7_ < 7)
         {
            StartMenu.ms_CoopLines.push(StartMenu.CoopText(_loc3_,"Line" + _loc7_ + "_txt","",_loc4_ - (_loc15_ - _loc7_) * _loc5_ + 6 - (_loc7_ != 0 ? 0 : 14),_loc7_ != 0 ? StartMenu.COOP_GOLD : StartMenu.COOP_WHITE,_loc7_ != 0 ? 18 : 26));
            _loc7_ = _loc7_ + 1;
         }
         if(_loc14_)
         {
            StartMenu.ms_CoopLocked = _loc13_ == "1";
            StartMenu.ms_CoopLockButton = StartMenu.CoopMakeButton(_loc3_,"Lock_bu",!StartMenu.ms_CoopLocked ? "Lock Lobby: Off" : "Lock Lobby: On",_loc4_ - 2 * _loc5_,function()
            {
               StartMenu.ms_CoopLocked = !StartMenu.ms_CoopLocked;
               StartMenu.CoopCmd(!StartMenu.ms_CoopLocked ? "Cmd.Lock.0" : "Cmd.Lock.1");
               StartMenu.ms_CoopLockButton.SetText(!StartMenu.ms_CoopLocked ? "Lock Lobby: Off" : "Lock Lobby: On");
               StartMenu.CoopPoll();
            }
            ,true);
         }
         if(a_sScreen == "lobby")
         {
            StartMenu.ms_CoopReady = false;
            _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Ready_bu","Ready",_loc4_ - _loc5_,function()
            {
               StartMenu.CoopSetReady(!StartMenu.ms_CoopReady);
            }
            ,true);
            StartMenu.ms_CoopReadyButton = _loc6_;
         }
         _loc3_.m_nFrame = 0;
         _loc3_.onEnterFrame = function()
         {
            this.m_nFrame = this.m_nFrame + 1;
            if(this.m_nFrame % 6 == 1)
            {
               StartMenu.CoopPoll();
            }
         };
      }
      var _loc8_ = StartMenu.CoopMakeButton(_loc3_,"Back_bu","Back",_loc4_,StartMenu.CoopBack,true);
      if(_loc6_ == null)
      {
         _loc6_ = _loc8_;
      }
      StartMenu.CoopCentre(_loc3_);
      StartMenu.ms_CoopFocusTarget = _loc6_;
      _loc3_.m_nSortTries = 0;
      StartMenu.CoopAfterShow(_loc3_);
   }
   static function CoopGameButton(a_mcScreen, a_nIndex, a_sId, a_sLabel, a_nY)
   {
      return StartMenu.CoopMakeButton(a_mcScreen,"Game" + a_nIndex + "_bu",a_sLabel,a_nY,function()
      {
         if(String(StartMenu.CoopCmd("Cmd.Ask." + a_sId)) == "ok")
         {
            StartMenu.ms_CoopJoinFrom = "browse";
            StartMenu.CoopShow("join");
         }
         else if(StartMenu.ms_CoopStatus != null)
         {
            StartMenu.ms_CoopStatus.text = String(String(StartMenu.CoopCmd("Games")).split("|")[0]);
         }
      }
      ,true);
   }
   // Join menus: an invite code copied meanwhile connects by itself -> the status screen;
   // the game list is kept up to date (a_bList).
   static function CoopWatchJoin(a_mcScreen, a_bList)
   {
      a_mcScreen.m_nFrame = 0;
      a_mcScreen.onEnterFrame = function()
      {
         this.m_nFrame = this.m_nFrame + 1;
         if(this.m_nFrame % 15 != 1)
         {
            return undefined;
         }
         if(String(StartMenu.CoopCmd("JoinStage")) != "0")
         {
            StartMenu.ms_CoopJoinFrom = StartMenu.ms_CoopScreen != "code" ? "browse" : "code";
            StartMenu.CoopShow("join");
            return undefined;
         }
         if(a_bList)
         {
            var _loc2_ = String(StartMenu.CoopCmd("Games")).split("|");
            // the list changes only when Refresh was pressed (or on the way in): shown once it has arrived
            var _loc3_ = String(_loc2_[0]);
            var _loc4_ = _loc3_.indexOf("Getting the list") < 0 && getTimer() - StartMenu.ms_CoopRefreshAt > 700;
            if(StartMenu.ms_CoopWantList && _loc4_)
            {
               StartMenu.ms_CoopWantList = false;
               if(_loc2_.slice(1).join("|") != StartMenu.ms_CoopGamesShown)
               {
                  StartMenu.CoopShow("browse");
                  return undefined;
               }
            }
            if(StartMenu.ms_CoopStatus != null && !StartMenu.ms_CoopWantList)
            {
               StartMenu.ms_CoopStatus.text = _loc3_ != "" ? _loc3_ : (_loc2_.length > 1 ? "Press Refresh to look again" : "No open games right now - press Refresh to look again");
            }
         }
      };
   }
   static function CoopAfterShow(a_mcScreen)
   {
      if(StartMenu.ms_Coop == null || StartMenu.ms_Coop.Screen_mc != a_mcScreen)
      {
         return undefined;
      }
      var _loc2_ = StartMenu.CoopSortFocus(a_mcScreen);
      a_mcScreen.m_nSortTries = a_mcScreen.m_nSortTries + 1;
      if(_loc2_ < a_mcScreen.m_nButtons && a_mcScreen.m_nSortTries < 40)
      {
         // the buttons register themselves a frame or two after they are made
         FuncUtils.CallWithDelay(function()
         {
            StartMenu.CoopAfterShow(a_mcScreen);
         }
         ,0.03);
         return undefined;
      }
      if(StartMenu.CoopUsingController() && StartMenu.ms_CoopFocusTarget != null)
      {
         FocusManager.SetCurrentFocus(StartMenu.ms_CoopFocusTarget);
      }
      StartMenu.ms_CoopFocusTarget = null;
   }
   static function CoopSortFocus(a_mcScreen)
   {
      // The focus list runs bottom-to-top ("down" = previous entry), so this
      // screen's buttons go in lowest-on-screen first, or the cursor skips.
      var _loc5_ = FocusManager.FindParentContainer(a_mcScreen);
      if(_loc5_ == null || _loc5_.m_Contents == null)
      {
         return 0;
      }
      var _loc2_ = _loc5_.m_Contents;
      var _loc3_ = new Array();
      var _loc6_ = -1;
      var _loc4_ = _loc2_.length - 1;
      while(_loc4_ >= 0)
      {
         if(_loc2_[_loc4_]._parent == a_mcScreen)
         {
            _loc3_.push(_loc2_[_loc4_]);
            _loc2_.splice(_loc4_,1);
            _loc6_ = _loc4_;
         }
         _loc4_ = _loc4_ - 1;
      }
      if(_loc6_ < 0)
      {
         _loc6_ = _loc2_.length;
      }
      _loc3_.sort(function(a, b)
      {
         return b._y - a._y;
      }
      );
      _loc4_ = 0;
      while(_loc4_ < _loc3_.length)
      {
         _loc2_.splice(_loc6_ + _loc4_,0,_loc3_[_loc4_]);
         _loc4_ = _loc4_ + 1;
      }
      return _loc3_.length;
   }
   static function CoopCentre(a_mcScreen)
   {
      // Move the screen so its panel sits in the middle of the screen.
      var _loc2_ = a_mcScreen.Panel_mc.getBounds(_root);
      if(_loc2_ == undefined || _loc2_.xMax <= _loc2_.xMin)
      {
         return undefined;
      }
      var _loc4_ = _root.OriginalStageWidth;
      var _loc5_ = _root.OriginalStageHeight;
      var _loc3_ = {x:0,y:0};
      if(_loc4_ > 0 && _loc5_ > 0)
      {
         _loc3_.x = _loc4_ / 2;
         _loc3_.y = _loc5_ / 2;
         _root.localToGlobal(_loc3_);
      }
      else
      {
         _loc3_.x = Stage.width / 2;
         _loc3_.y = Stage.height / 2;
      }
      var _loc6_ = {x:(_loc2_.xMin + _loc2_.xMax) / 2,y:(_loc2_.yMin + _loc2_.yMax) / 2};
      _root.localToGlobal(_loc6_);
      a_mcScreen._parent.globalToLocal(_loc3_);
      a_mcScreen._parent.globalToLocal(_loc6_);
      a_mcScreen._x = a_mcScreen._x + (_loc3_.x - _loc6_.x);
      a_mcScreen._y = a_mcScreen._y + (_loc3_.y - _loc6_.y);
   }
   static function CoopSetReady(a_bReady)
   {
      StartMenu.ms_CoopReady = a_bReady;
      StartMenu.CoopCmd(!a_bReady ? "Cmd.Ready.0" : "Cmd.Ready.1");
      if(StartMenu.ms_CoopReadyButton != null)
      {
         StartMenu.ms_CoopReadyButton.SetText(!a_bReady ? "Ready" : "Not Ready");
      }
      StartMenu.CoopPoll();
   }
   static function CoopPoll()
   {
      if(StartMenu.ms_CoopLines == null)
      {
         return undefined;
      }
      // 1.4.3: joining stopped (the host said no, no answer...): back to where it was asked from
      if(StartMenu.ms_CoopScreen == "join" && String(StartMenu.CoopCmd("JoinStage")) == "0")
      {
         StartMenu.ms_CoopReturned = true;
         StartMenu.CoopShow(StartMenu.ms_CoopJoinFrom);
         return undefined;
      }
      var _loc7_ = String(StartMenu.CoopCmd("Lobby"));
      var _loc4_ = _loc7_.split("|");
      var _loc8_ = _loc4_[0] == "1";
      var _loc9_ = _loc4_[1] == "1";
      // 1.2.32: Player 1 can ready up from the keyboard (E): keep the button in step
      var _loc12_ = _loc4_[2] == "1";
      if(_loc12_ != StartMenu.ms_CoopReady && StartMenu.ms_CoopReadyButton != null)
      {
         StartMenu.ms_CoopReady = _loc12_;
         StartMenu.ms_CoopReadyButton.SetText(!_loc12_ ? "Ready" : "Not Ready");
      }
      var _loc3_ = 0;
      while(_loc3_ < StartMenu.ms_CoopLines.length)
      {
         var _loc5_ = StartMenu.ms_CoopLines[_loc3_];
         var _loc2_ = _loc4_[_loc3_ + 3];
         if(_loc2_ == undefined)
         {
            _loc5_.text = "";
         }
         else
         {
            var _loc6_ = _loc2_.charAt(0);
            _loc5_.text = _loc2_.substr(1);
            _loc5_.textColor = _loc6_ != "R" ? (_loc6_ != "X" ? (_loc6_ != "H" ? StartMenu.COOP_GOLD : StartMenu.COOP_WHITE) : StartMenu.COOP_GREY) : StartMenu.COOP_GREEN;
         }
         _loc3_ = _loc3_ + 1;
      }
      // Everyone ready: count down 3 seconds, then start the game.
      if(_loc8_ && _loc9_)
      {
         if(StartMenu.ms_CoopCountdown < 0)
         {
            StartMenu.ms_CoopCountdown = getTimer();
         }
         var _loc10_ = 3 - Math.floor((getTimer() - StartMenu.ms_CoopCountdown) / 1000);
         var _loc11_ = Math.min(_loc4_.length - 3,StartMenu.ms_CoopLines.length) - 1;
         if(_loc11_ >= 0)
         {
            StartMenu.ms_CoopLines[_loc11_].text = "Everyone is ready! Starting in " + Math.max(_loc10_,0) + "...";
         }
         if(_loc10_ <= 0)
         {
            StartMenu.CoopLaunch();
         }
      }
      else
      {
         StartMenu.ms_CoopCountdown = -1;
      }
   }
   static function CoopLaunch()
   {
      var _loc2_ = String(StartMenu.CoopCmd("Cmd.Launch"));
      if(_loc2_ != "ok")
      {
         StartMenu.ms_CoopCountdown = -1;
         return undefined;
      }
      StartMenu.ms_CoopLines = null;
      StartMenu.CoopRemoveUi();
      MovieUtils.ShowMovie(_root.StartButtons_mc);
      if(StartMenu.ms_CoopLoad)
      {
         // A saved game: the game's own Load screen; Players 2/3 come back with the save.
         StartMenu.LoadGame();
         return undefined;
      }
      // The normal new game: Player 1 makes the Warden; the others make theirs as the story starts.
      fscommand("LoadModule","single player");
   }
   // --- building blocks ---------------------------------------------------------
   static function CoopBottom()
   {
      var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc.QuitButton;
      return _loc2_ == undefined ? 292 : _loc2_._y;
   }
   static function CoopRight()
   {
      var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc.NewGameButton;
      return _loc2_._x + _loc2_._width;
   }
   static function CoopPanel(a_mcScreen, a_nTop, a_nBottom)
   {
      var _loc3_ = StartMenu.CoopRight() + 12;
      var _loc4_ = _loc3_ - 760;
      var _loc2_ = a_mcScreen.createEmptyMovieClip("Panel_mc",0);
      _loc2_.beginFill(0,60);
      _loc2_.moveTo(_loc4_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nBottom);
      _loc2_.lineTo(_loc4_,a_nBottom);
      _loc2_.lineTo(_loc4_,a_nTop);
      _loc2_.endFill();
      _loc2_.lineStyle(1,StartMenu.COOP_GOLD,40);
      _loc2_.moveTo(_loc4_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nTop);
   }
   static function CoopText(a_mcScreen, a_sName, a_sText, a_nY, a_nColour, a_nSize)
   {
      var _loc4_ = 740;
      var _loc5_ = StartMenu.CoopRight() - 738;
      var _loc2_ = a_mcScreen.createTextField(a_sName,a_mcScreen.getNextHighestDepth(),_loc5_,a_nY,_loc4_,a_nSize + 14);
      var _loc3_ = new TextFormat();
      _loc3_.font = "$TitleFont";
      _loc3_.size = a_nSize;
      _loc3_.color = a_nColour;
      _loc3_.align = "center";
      _loc2_.embedFonts = true;
      _loc2_.selectable = false;
      _loc2_.multiline = false;
      _loc2_.wordWrap = false;
      _loc2_.setNewTextFormat(_loc3_);
      _loc2_.text = a_sText;
      _loc2_.setTextFormat(_loc3_);
      return _loc2_;
   }
   static function CoopMakeButton(a_mcScreen, a_sName, a_sLabel, a_nY, a_fnAction, a_bEnabled)
   {
      var _loc3_ = _root.StartButtons_mc.StartMenuButtons_mc.NewGameButton;
      a_mcScreen[a_sName + "_init"] = function()
      {
         this.SetText(a_sLabel);
         this.SetButtonAction(a_fnAction);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         this.OnAction = function(a_sAction)
         {
            this.SimulateButtonPush();
            return true;
         };
         FocusManager.AddItem(this);
         if(a_bEnabled == false)
         {
            this.Disable();
         }
      };
      a_mcScreen.m_nButtons = a_mcScreen.m_nButtons + 1;
      // centred under the panel's middle
      var _loc4_ = StartMenu.CoopRight() - 368 - _loc3_._width / 2;
      return a_mcScreen.attachMovie("bu_m",a_sName,a_mcScreen.getNextHighestDepth(),{_x:_loc4_,_y:a_nY,_xscale:_loc3_._xscale,_yscale:_loc3_._yscale});
   }
}
