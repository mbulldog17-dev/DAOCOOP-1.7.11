   // ======================================================================
   // DAOCoop: Co-op button and the co-op menus (local / online, 2 or 3
   // players, lobby). The mod answers through ExternalCommands.GetValue
   // ("DAOCoop.*"); without the mod the button never appears.
   // ======================================================================
   static var COOP_SPACING = 34;
   static var COOP_GOLD = 13547636;
   static var COOP_GREEN = 8376959;
   static var COOP_GREY = 10132122;
   static var COOP_WHITE = 15787720;
   static var ms_Coop = null;
   static var ms_CoopScreen = "";
   static var ms_CoopOnline = false;
   static var ms_CoopLoad = false;
   static var ms_CoopReady = false;
   static var ms_CoopCountdown = -1;
   static var ms_CoopLines = null;
   static var ms_CoopReadyButton = null;
   static var ms_CoopAvailable = 0;
   static var ms_CoopLaidOut = false;
   static var ms_CoopOrigY = null;
   static var ms_CoopFocusTarget = null;
   static function CoopCmd(a_sName)
   {
      return ExternalCommands.GetValue("DAOCoop." + a_sName);
   }
   static function CoopUsingController()
   {
      return GUISystem.Platform != "PC" || Number(ExternalCommands.GetValue("DebugOptions.EnableController")) == 1;
   }
   static function CoopInstall()
   {
      var _loc2_ = _root.createEmptyMovieClip("DAOCoopWatch_mc",16001);
      _loc2_.m_nWait = 0;
      _loc2_.m_nRetry = 0;
      _loc2_.onEnterFrame = function()
      {
         var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc;
         if(_loc2_ == undefined || _loc2_.NewGameButton == undefined)
         {
            return undefined;
         }
         if(_loc2_._currentframe < _loc2_._totalframes)
         {
            StartMenu.ms_CoopLaidOut = false;
            return undefined;
         }
         if(!StartMenu.ms_CoopLaidOut)
         {
            StartMenu.ms_CoopLaidOut = true;
            this.m_nRetry = 0;
            StartMenu.CoopLayout(_loc2_);
         }
         else if(StartMenu.ms_CoopAvailable != 1 && this.m_nRetry < 30)
         {
            // the mod may not be listening yet: ask again every 2 seconds for a minute
            this.m_nWait = this.m_nWait + 1;
            if(this.m_nWait >= 120)
            {
               this.m_nWait = 0;
               this.m_nRetry = this.m_nRetry + 1;
               StartMenu.CoopLayout(_loc2_);
            }
         }
      };
   }
   static function CoopLayout(a_mcButtons)
   {
      if(StartMenu.ms_CoopAvailable != 1)
      {
         var _loc3_ = StartMenu.CoopCmd("Version");
         StartMenu.ms_CoopAvailable = (_loc3_ == null || _loc3_ == undefined || String(_loc3_) == "") ? -1 : 1;
      }
      if(StartMenu.ms_CoopAvailable != 1)
      {
         return undefined;
      }
      var _loc2_ = a_mcButtons.NewGameButton;
      if(StartMenu.ms_CoopOrigY == null)
      {
         StartMenu.ms_CoopOrigY = {newGame:_loc2_._y,resume:a_mcButtons.ResumeButton._y};
      }
      // Room for "Co-op" right under "New Game": the two buttons above move up one row.
      _loc2_._y = StartMenu.ms_CoopOrigY.newGame - StartMenu.COOP_SPACING;
      a_mcButtons.ResumeButton._y = StartMenu.ms_CoopOrigY.resume - StartMenu.COOP_SPACING;
      if(a_mcButtons.CoopButton == undefined)
      {
         a_mcButtons.attachMovie("bu_m","CoopButton",500,{_x:_loc2_._x,_y:StartMenu.ms_CoopOrigY.newGame,_xscale:_loc2_._xscale,_yscale:_loc2_._yscale});
      }
      else
      {
         a_mcButtons.CoopButton._y = StartMenu.ms_CoopOrigY.newGame;
      }
   }
   static function CoopFocusAfter(a_Item, a_After)
   {
      // The start menu's list runs bottom-to-top (buttons are added in
      // placement order), so put Co-op where its height on screen says.
      var _loc3_ = FocusManager.FindParentContainer(a_Item._parent);
      if(_loc3_ == null || _loc3_.m_Contents == null)
      {
         return undefined;
      }
      var _loc2_ = _loc3_.m_Contents;
      var _loc4_ = _loc2_.find(a_Item);
      if(_loc4_ >= 0)
      {
         _loc2_.splice(_loc4_,1);
      }
      var _loc5_ = _loc2_.find(a_After);
      if(_loc5_ < 0)
      {
         _loc2_.push(a_Item);
         return undefined;
      }
      // Direction of the list: compare a neighbour of "New Game" with it.
      var _loc6_ = _loc2_[_loc5_ + 1];
      var _loc7_ = _loc2_[_loc5_ - 1];
      var _loc8_ = true;
      if(_loc6_ != undefined && _loc6_._y != undefined)
      {
         _loc8_ = _loc6_._y > a_After._y;
      }
      else if(_loc7_ != undefined && _loc7_._y != undefined)
      {
         _loc8_ = _loc7_._y < a_After._y;
      }
      // Co-op sits just below New Game on screen.
      if(_loc8_)
      {
         _loc2_.splice(_loc5_ + 1,0,a_Item);
      }
      else
      {
         _loc2_.splice(_loc5_,0,a_Item);
      }
   }
   // --- opening / closing ------------------------------------------------------
   static function CoopOpen()
   {
      var _loc3_ = _root.StartButtons_mc;
      var _loc2_ = _loc3_.StartMenuButtons_mc;
      StartMenu.CoopCmd("Cmd.Open");
      var _loc4_ = _loc3_._parent.createEmptyMovieClip("DAOCoopMenu_mc",16000);
      _loc4_._x = _loc3_._x;
      _loc4_._y = _loc3_._y;
      _loc4_._xscale = _loc3_._xscale;
      _loc4_._yscale = _loc3_._yscale;
      var _loc5_ = _loc4_.createEmptyMovieClip("Inner_mc",1);
      _loc5_._x = _loc2_._x;
      _loc5_._y = _loc2_._y;
      _loc5_._xscale = _loc2_._xscale;
      _loc5_._yscale = _loc2_._yscale;
      StartMenu.ms_Coop = _loc5_;
      StartMenu.ms_CoopOnline = false;
      StartMenu.ms_CoopLoad = false;
      MovieUtils.HideMovie(_loc3_);
      StartMenu.CoopShow("mode");
   }
   static function CoopClose()
   {
      StartMenu.CoopCmd("Cmd.Close");
      StartMenu.CoopRemoveUi();
      var _loc2_ = _root.StartButtons_mc;
      MovieUtils.ShowMovie(_loc2_);
      if(StartMenu.CoopUsingController())
      {
         FocusManager.SetCurrentFocus(_loc2_.StartMenuButtons_mc.CoopButton);
      }
   }
   static function CoopRemoveUi()
   {
      if(StartMenu.ms_Coop != null)
      {
         StartMenu.CoopClearScreen();
         StartMenu.ms_Coop._parent.removeMovieClip();
      }
      StartMenu.ms_Coop = null;
      StartMenu.ms_CoopScreen = "";
   }
   static function CoopBack()
   {
      var _loc2_ = StartMenu.ms_CoopScreen;
      if(_loc2_ == "lobby")
      {
         StartMenu.CoopShow("players");
      }
      else if(_loc2_ == "join")
      {
         StartMenu.CoopCmd("Cmd.Leave");
         StartMenu.CoopShow("online");
      }
      else if(_loc2_ == "players")
      {
         StartMenu.CoopShow("start");
      }
      else if(_loc2_ == "start")
      {
         StartMenu.CoopShow(!StartMenu.ms_CoopOnline ? "mode" : "online");
      }
      else if(_loc2_ == "online")
      {
         StartMenu.CoopShow("mode");
      }
      else
      {
         StartMenu.CoopClose();
      }
   }
   // --- screens -------------------------------------------------------------
   static function CoopClearScreen()
   {
      var _loc4_ = StartMenu.ms_Coop.Screen_mc;
      if(_loc4_ == undefined)
      {
         return undefined;
      }
      var _loc3_ = FocusManager.FindParentContainer(StartMenu.ms_Coop);
      if(_loc3_ != null && _loc3_.m_Contents != null)
      {
         var _loc2_ = _loc3_.m_Contents.length - 1;
         while(_loc2_ >= 0)
         {
            if(_loc3_.m_Contents[_loc2_]._parent == _loc4_)
            {
               _loc3_.m_Contents.splice(_loc2_,1);
            }
            _loc2_ = _loc2_ - 1;
         }
      }
      delete _loc4_.onEnterFrame;
      _loc4_.removeMovieClip();
      StartMenu.ms_CoopLines = null;
      StartMenu.ms_CoopReadyButton = null;
   }
   static function CoopShow(a_sScreen)
   {
      StartMenu.CoopClearScreen();
      StartMenu.ms_CoopScreen = a_sScreen;
      StartMenu.ms_CoopCountdown = -1;
      var _loc3_ = StartMenu.ms_Coop.createEmptyMovieClip("Screen_mc",1);
      _loc3_.m_nButtons = 0;
      var _loc4_ = StartMenu.CoopBottom();
      var _loc5_ = StartMenu.COOP_SPACING;
      var _loc6_ = null;
      if(a_sScreen == "mode")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Co-op",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Play the campaign together",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Ver_txt","DAOCoop " + StartMenu.CoopCmd("Version"),_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Local_bu","Local Co-op",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.ms_CoopOnline = false;
            StartMenu.CoopCmd("Cmd.Mode.local");
            StartMenu.CoopShow("start");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Online_bu","Online Multiplayer",_loc4_ - _loc5_,function()
         {
            StartMenu.ms_CoopOnline = true;
            StartMenu.CoopShow("online");
         }
         ,true);
      }
      else if(a_sScreen == "online")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt","Online Multiplayer",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Host shares an invite code - friends join with it",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt","Friends need the game and this mod",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Host_bu","Host Game",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Mode.host");
            StartMenu.CoopShow("start");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Join_bu","Join Game",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Mode.join");
            StartMenu.CoopShow("join");
         }
         ,true);
      }
      else if(a_sScreen == "start")
      {
         // New game or a saved one (asked before the lobby)
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt",!StartMenu.ms_CoopOnline ? "Local Co-op" : "Host Game",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","Start a new game or load a save?",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt","With a save, everyone's characters come back with it",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"New_bu","New Game",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.ms_CoopLoad = false;
            StartMenu.CoopCmd("Cmd.Start.new");
            StartMenu.CoopShow("players");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"LoadSave_bu","Load Game",_loc4_ - _loc5_,function()
         {
            StartMenu.ms_CoopLoad = true;
            StartMenu.CoopCmd("Cmd.Start.load");
            StartMenu.CoopShow("players");
         }
         ,ExternalCommands.GetNumMembers("SaveLoad.HeroList") > 0);
      }
      else if(a_sScreen == "players")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 5 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.CoopText(_loc3_,"Title_txt",!StartMenu.ms_CoopOnline ? "Local Co-op" : "Host Game",_loc4_ - 5 * _loc5_ - 20,StartMenu.COOP_WHITE,28);
         StartMenu.CoopText(_loc3_,"Sub_txt","How many players?",_loc4_ - 4 * _loc5_ - 6,StartMenu.COOP_GOLD,18);
         StartMenu.CoopText(_loc3_,"Sub2_txt",!StartMenu.ms_CoopLoad ? "Player 1 makes the Warden, then everyone else makes theirs as the story starts" : "After the lobby Player 1 picks the save to load",_loc4_ - 3 * _loc5_ - 4,StartMenu.COOP_GREY,14);
         _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Two_bu","2 Players",_loc4_ - 2 * _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Players.2");
            StartMenu.CoopShow("lobby");
         }
         ,true);
         StartMenu.CoopMakeButton(_loc3_,"Three_bu","3 Players",_loc4_ - _loc5_,function()
         {
            StartMenu.CoopCmd("Cmd.Players.3");
            StartMenu.CoopShow("lobby");
         }
         ,true);
      }
      else if(a_sScreen == "lobby" || a_sScreen == "join")
      {
         StartMenu.CoopPanel(_loc3_,_loc4_ - 8 * _loc5_ - 30,_loc4_ + _loc5_);
         StartMenu.ms_CoopLines = new Array();
         var _loc7_ = 0;
         while(_loc7_ < 7)
         {
            StartMenu.ms_CoopLines.push(StartMenu.CoopText(_loc3_,"Line" + _loc7_ + "_txt","",_loc4_ - (8 - _loc7_) * _loc5_ + 6 - (_loc7_ != 0 ? 0 : 14),_loc7_ != 0 ? StartMenu.COOP_GOLD : StartMenu.COOP_WHITE,_loc7_ != 0 ? 18 : 26));
            _loc7_ = _loc7_ + 1;
         }
         if(a_sScreen == "lobby")
         {
            StartMenu.ms_CoopReady = false;
            _loc6_ = StartMenu.CoopMakeButton(_loc3_,"Ready_bu","Ready",_loc4_ - _loc5_,function()
            {
               StartMenu.CoopSetReady(!StartMenu.ms_CoopReady);
            }
            ,true);
            StartMenu.ms_CoopReadyButton = _loc6_;
         }
         _loc3_.m_nFrame = 0;
         _loc3_.onEnterFrame = function()
         {
            this.m_nFrame = this.m_nFrame + 1;
            if(this.m_nFrame % 6 == 1)
            {
               StartMenu.CoopPoll();
            }
         };
      }
      var _loc8_ = StartMenu.CoopMakeButton(_loc3_,"Back_bu","Back",_loc4_,StartMenu.CoopBack,true);
      if(_loc6_ == null)
      {
         _loc6_ = _loc8_;
      }
      StartMenu.CoopCentre(_loc3_);
      StartMenu.ms_CoopFocusTarget = _loc6_;
      _loc3_.m_nSortTries = 0;
      StartMenu.CoopAfterShow(_loc3_);
   }
   static function CoopAfterShow(a_mcScreen)
   {
      if(StartMenu.ms_Coop == null || StartMenu.ms_Coop.Screen_mc != a_mcScreen)
      {
         return undefined;
      }
      var _loc2_ = StartMenu.CoopSortFocus(a_mcScreen);
      a_mcScreen.m_nSortTries = a_mcScreen.m_nSortTries + 1;
      if(_loc2_ < a_mcScreen.m_nButtons && a_mcScreen.m_nSortTries < 40)
      {
         // the buttons register themselves a frame or two after they are made
         FuncUtils.CallWithDelay(function()
         {
            StartMenu.CoopAfterShow(a_mcScreen);
         }
         ,0.03);
         return undefined;
      }
      if(StartMenu.CoopUsingController() && StartMenu.ms_CoopFocusTarget != null)
      {
         FocusManager.SetCurrentFocus(StartMenu.ms_CoopFocusTarget);
      }
      StartMenu.ms_CoopFocusTarget = null;
   }
   static function CoopSortFocus(a_mcScreen)
   {
      // The focus list runs bottom-to-top ("down" = previous entry), so this
      // screen's buttons go in lowest-on-screen first, or the cursor skips.
      var _loc5_ = FocusManager.FindParentContainer(a_mcScreen);
      if(_loc5_ == null || _loc5_.m_Contents == null)
      {
         return 0;
      }
      var _loc2_ = _loc5_.m_Contents;
      var _loc3_ = new Array();
      var _loc6_ = -1;
      var _loc4_ = _loc2_.length - 1;
      while(_loc4_ >= 0)
      {
         if(_loc2_[_loc4_]._parent == a_mcScreen)
         {
            _loc3_.push(_loc2_[_loc4_]);
            _loc2_.splice(_loc4_,1);
            _loc6_ = _loc4_;
         }
         _loc4_ = _loc4_ - 1;
      }
      if(_loc6_ < 0)
      {
         _loc6_ = _loc2_.length;
      }
      _loc3_.sort(function(a, b)
      {
         return b._y - a._y;
      }
      );
      _loc4_ = 0;
      while(_loc4_ < _loc3_.length)
      {
         _loc2_.splice(_loc6_ + _loc4_,0,_loc3_[_loc4_]);
         _loc4_ = _loc4_ + 1;
      }
      return _loc3_.length;
   }
   static function CoopCentre(a_mcScreen)
   {
      // Move the screen so its panel sits in the middle of the screen.
      var _loc2_ = a_mcScreen.Panel_mc.getBounds(_root);
      if(_loc2_ == undefined || _loc2_.xMax <= _loc2_.xMin)
      {
         return undefined;
      }
      var _loc4_ = _root.OriginalStageWidth;
      var _loc5_ = _root.OriginalStageHeight;
      var _loc3_ = {x:0,y:0};
      if(_loc4_ > 0 && _loc5_ > 0)
      {
         _loc3_.x = _loc4_ / 2;
         _loc3_.y = _loc5_ / 2;
         _root.localToGlobal(_loc3_);
      }
      else
      {
         _loc3_.x = Stage.width / 2;
         _loc3_.y = Stage.height / 2;
      }
      var _loc6_ = {x:(_loc2_.xMin + _loc2_.xMax) / 2,y:(_loc2_.yMin + _loc2_.yMax) / 2};
      _root.localToGlobal(_loc6_);
      a_mcScreen._parent.globalToLocal(_loc3_);
      a_mcScreen._parent.globalToLocal(_loc6_);
      a_mcScreen._x = a_mcScreen._x + (_loc3_.x - _loc6_.x);
      a_mcScreen._y = a_mcScreen._y + (_loc3_.y - _loc6_.y);
   }
   static function CoopSetReady(a_bReady)
   {
      StartMenu.ms_CoopReady = a_bReady;
      StartMenu.CoopCmd(!a_bReady ? "Cmd.Ready.0" : "Cmd.Ready.1");
      if(StartMenu.ms_CoopReadyButton != null)
      {
         StartMenu.ms_CoopReadyButton.SetText(!a_bReady ? "Ready" : "Not Ready");
      }
      StartMenu.CoopPoll();
   }
   static function CoopPoll()
   {
      if(StartMenu.ms_CoopLines == null)
      {
         return undefined;
      }
      var _loc7_ = String(StartMenu.CoopCmd("Lobby"));
      var _loc4_ = _loc7_.split("|");
      var _loc8_ = _loc4_[0] == "1";
      var _loc9_ = _loc4_[1] == "1";
      // 1.2.32: Player 1 can ready up from the keyboard (E): keep the button in step
      var _loc12_ = _loc4_[2] == "1";
      if(_loc12_ != StartMenu.ms_CoopReady && StartMenu.ms_CoopReadyButton != null)
      {
         StartMenu.ms_CoopReady = _loc12_;
         StartMenu.ms_CoopReadyButton.SetText(!_loc12_ ? "Ready" : "Not Ready");
      }
      var _loc3_ = 0;
      while(_loc3_ < StartMenu.ms_CoopLines.length)
      {
         var _loc5_ = StartMenu.ms_CoopLines[_loc3_];
         var _loc2_ = _loc4_[_loc3_ + 3];
         if(_loc2_ == undefined)
         {
            _loc5_.text = "";
         }
         else
         {
            var _loc6_ = _loc2_.charAt(0);
            _loc5_.text = _loc2_.substr(1);
            _loc5_.textColor = _loc6_ != "R" ? (_loc6_ != "X" ? (_loc6_ != "H" ? StartMenu.COOP_GOLD : StartMenu.COOP_WHITE) : StartMenu.COOP_GREY) : StartMenu.COOP_GREEN;
         }
         _loc3_ = _loc3_ + 1;
      }
      // Everyone ready: count down 3 seconds, then start the game.
      if(_loc8_ && _loc9_)
      {
         if(StartMenu.ms_CoopCountdown < 0)
         {
            StartMenu.ms_CoopCountdown = getTimer();
         }
         var _loc10_ = 3 - Math.floor((getTimer() - StartMenu.ms_CoopCountdown) / 1000);
         var _loc11_ = Math.min(_loc4_.length - 3,StartMenu.ms_CoopLines.length) - 1;
         if(_loc11_ >= 0)
         {
            StartMenu.ms_CoopLines[_loc11_].text = "Everyone is ready! Starting in " + Math.max(_loc10_,0) + "...";
         }
         if(_loc10_ <= 0)
         {
            StartMenu.CoopLaunch();
         }
      }
      else
      {
         StartMenu.ms_CoopCountdown = -1;
      }
   }
   static function CoopLaunch()
   {
      var _loc2_ = String(StartMenu.CoopCmd("Cmd.Launch"));
      if(_loc2_ != "ok")
      {
         StartMenu.ms_CoopCountdown = -1;
         return undefined;
      }
      StartMenu.ms_CoopLines = null;
      StartMenu.CoopRemoveUi();
      MovieUtils.ShowMovie(_root.StartButtons_mc);
      if(StartMenu.ms_CoopLoad)
      {
         // A saved game: the game's own Load screen; Players 2/3 come back with the save.
         StartMenu.LoadGame();
         return undefined;
      }
      // The normal new game: Player 1 makes the Warden; the others make theirs as the story starts.
      fscommand("LoadModule","single player");
   }
   // --- building blocks ---------------------------------------------------------
   static function CoopBottom()
   {
      var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc.QuitButton;
      return _loc2_ == undefined ? 292 : _loc2_._y;
   }
   static function CoopRight()
   {
      var _loc2_ = _root.StartButtons_mc.StartMenuButtons_mc.NewGameButton;
      return _loc2_._x + _loc2_._width;
   }
   static function CoopPanel(a_mcScreen, a_nTop, a_nBottom)
   {
      var _loc3_ = StartMenu.CoopRight() + 12;
      var _loc4_ = _loc3_ - 760;
      var _loc2_ = a_mcScreen.createEmptyMovieClip("Panel_mc",0);
      _loc2_.beginFill(0,60);
      _loc2_.moveTo(_loc4_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nBottom);
      _loc2_.lineTo(_loc4_,a_nBottom);
      _loc2_.lineTo(_loc4_,a_nTop);
      _loc2_.endFill();
      _loc2_.lineStyle(1,StartMenu.COOP_GOLD,40);
      _loc2_.moveTo(_loc4_,a_nTop);
      _loc2_.lineTo(_loc3_,a_nTop);
   }
   static function CoopText(a_mcScreen, a_sName, a_sText, a_nY, a_nColour, a_nSize)
   {
      var _loc4_ = 740;
      var _loc5_ = StartMenu.CoopRight() - 738;
      var _loc2_ = a_mcScreen.createTextField(a_sName,a_mcScreen.getNextHighestDepth(),_loc5_,a_nY,_loc4_,a_nSize + 14);
      var _loc3_ = new TextFormat();
      _loc3_.font = "$TitleFont";
      _loc3_.size = a_nSize;
      _loc3_.color = a_nColour;
      _loc3_.align = "center";
      _loc2_.embedFonts = true;
      _loc2_.selectable = false;
      _loc2_.multiline = false;
      _loc2_.wordWrap = false;
      _loc2_.setNewTextFormat(_loc3_);
      _loc2_.text = a_sText;
      _loc2_.setTextFormat(_loc3_);
      return _loc2_;
   }
   static function CoopMakeButton(a_mcScreen, a_sName, a_sLabel, a_nY, a_fnAction, a_bEnabled)
   {
      var _loc3_ = _root.StartButtons_mc.StartMenuButtons_mc.NewGameButton;
      a_mcScreen[a_sName + "_init"] = function()
      {
         this.SetText(a_sLabel);
         this.SetButtonAction(a_fnAction);
         FuncUtils.ChainFunction(this,"onRollOverHitArea",function()
         {
            ExternalCommands.PlayGUISound(SoundEvents.ST_START_MENU_ROLLOVER);
         }
         );
         this.OnAction = function(a_sAction)
         {
            this.SimulateButtonPush();
            return true;
         };
         FocusManager.AddItem(this);
         if(a_bEnabled == false)
         {
            this.Disable();
         }
      };
      a_mcScreen.m_nButtons = a_mcScreen.m_nButtons + 1;
      // centred under the panel's middle
      var _loc4_ = StartMenu.CoopRight() - 368 - _loc3_._width / 2;
      return a_mcScreen.attachMovie("bu_m",a_sName,a_mcScreen.getNextHighestDepth(),{_x:_loc4_,_y:a_nY,_xscale:_loc3_._xscale,_yscale:_loc3_._yscale});
   }
