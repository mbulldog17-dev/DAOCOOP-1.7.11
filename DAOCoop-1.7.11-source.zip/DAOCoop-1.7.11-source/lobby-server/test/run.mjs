// Minimal stand-ins for the Workers runtime, enough to walk through the lobby's flows.
class FakeWS {
  constructor(name) { this.name = name; this.sent = []; this.att = null; this.tags = []; this.closed = false; this.peer = null; }
  send(t) { if (this.closed) throw new Error("closed"); this.sent.push(t); }
  close() { this.closed = true; }
  serializeAttachment(a) { this.att = JSON.parse(JSON.stringify(a)); }
  deserializeAttachment() { return this.att; }
}
globalThis.WebSocketPair = class { constructor() { const c = new FakeWS("client"), s = new FakeWS("server"); c.peer = s; s.peer = c; this[0] = c; this[1] = s; } };
globalThis.WebSocketRequestResponsePair = class { constructor(a, b) { this.a = a; this.b = b; } };
const RealResponse = globalThis.Response;
globalThis.Response = class { constructor(body, init = {}) { this.body = body; this.status = init.status ?? 200; this.webSocket = init.webSocket; } async text() { return String(this.body); } };
const { Lobby } = await import("../worker.js");
const sockets = [];
const ctx = {
  setWebSocketAutoResponse() {},
  acceptWebSocket(ws, tags) { ws.tags = tags; sockets.push(ws); },
  getWebSockets(tag) { return sockets.filter((w) => !w.closed && w.tags.includes(tag)); },
  getTags(ws) { return ws.tags; },
  storage: { alarm: 0, async setAlarm(t) { this.alarm = t; } },
};
const lobby = new Lobby(ctx, {});
const req = (path, ip = "9.9.9.9", ws = true) => ({
  url: "https://x" + path, cf: { country: "US" },
  headers: { get: (h) => (h === "cf-connecting-ip" ? ip : h === "Upgrade" && ws ? "websocket" : null) },
});
const last = (ws) => Object.fromEntries(new URLSearchParams(ws.sent.at(-1)));
const assert = (c, m) => { if (!c) { console.error("FAIL:", m); process.exit(1); } console.log("ok -", m); };

// host lists a game
let r = await lobby.fetch(req("/v1/host?v=1.3.5&name=Valun&max=3&open=2", "1.1.1.1"));
const hostWs = sockets.at(-1);
assert(r.status === 101 && last(hostWs).t === "hello", "host gets hello");
const hid = last(hostWs).id;
await lobby.webSocketMessage(hostWs, "t=update&area=Lothering&players=1&open=2&locked=0");
r = await lobby.fetch(req("/v1/list?v=1.3.5", "2.2.2.2", false));
let list = JSON.parse(r.body);
assert(list.length === 1 && list[0].id === hid && list[0].area === "Lothering", "listed with area");
r = await lobby.fetch(req("/v1/list?v=1.3.4", "2.2.2.2", false));
assert(JSON.parse(r.body).length === 0, "other version not listed");

// a player asks to join
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=Wraith&cid=77&addr=5.5.5.5:4000&lan=192.168.1.9:4000`, "5.5.5.5"));
const joinWs = sockets.at(-1);
assert(r.status === 101 && last(joinWs).t === "waiting", "player waits");
let rq = last(hostWs);
assert(rq.t === "request" && rq.name === "Wraith" && rq.addr === "5.5.5.5:4000", "host sees the request with the player's address");
await lobby.webSocketMessage(hostWs, `t=answer&req=${rq.req}&ok=1&token=12345&addr=1.1.1.1:27615&lan=192.168.0.2:27615`);
let ac = last(joinWs);
assert(ac.t === "accepted" && ac.token === "12345" && ac.addr === "1.1.1.1:27615" && joinWs.closed, "accepted: player gets the host's address, request closed");

// decline
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=Troll`, "6.6.6.6"));
const j2 = sockets.at(-1); rq = last(hostWs);
await lobby.webSocketMessage(hostWs, `t=answer&req=${rq.req}&ok=0&why=No%20thanks`);
assert(last(j2).t === "declined" && last(j2).why === "No thanks", "declined with reason");

// lock hides and blocks
await lobby.webSocketMessage(hostWs, "t=update&locked=1");
r = await lobby.fetch(req("/v1/list?v=1.3.5", "2.2.2.2", false));
assert(JSON.parse(r.body).length === 0, "locked game not listed");
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=X`, "7.7.7.7"));
assert(r.status === 409 && r.body === "That game is locked.", "locked game refuses joins");
await lobby.webSocketMessage(hostWs, "t=update&locked=0");

// timeout
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=Slow`, "8.8.8.8"));
const j3 = sockets.at(-1); j3.att.until = Date.now() - 1;
await lobby.alarm();
assert(last(j3).t === "declined" && last(hostWs).t === "cancel", "unanswered request times out, host prompt cancelled");

// rate limit
for (let i = 0; i < 6; i++) await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=S${i}`, "4.4.4.4"));
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=S7`, "4.4.4.4"));
assert(r.status === 429, "rate limit per address");

// host leaves: waiting players are told
r = await lobby.fetch(req(`/v1/join?v=1.3.5&host=${hid}&name=Late`, "3.3.3.3"));
const j4 = sockets.at(-1);
hostWs.closed = true; await lobby.webSocketClose(hostWs, 1000, "bye");
assert(last(j4).t === "declined" && last(j4).why === "The host stopped.", "host leaving declines waiting players");
r = await lobby.fetch(req("/v1/list?v=1.3.5", "2.2.2.2", false));
assert(JSON.parse(r.body).length === 0, "gone from the list");
console.log("all lobby tests passed");
