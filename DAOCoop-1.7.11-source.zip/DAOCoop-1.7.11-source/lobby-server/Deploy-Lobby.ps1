# DAOCoop: put the lobby server online (Cloudflare Workers, free plan) and put its address into the mod.
# Run it with "PUT THE LOBBY SERVER ONLINE.cmd". Safe to run again (it updates the same server).
$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath $PSScriptRoot

function Done($code) {
    Write-Host ''
    Read-Host 'Press Enter to close' | Out-Null
    exit $code
}

Write-Host '=== DAOCoop lobby server ===' -ForegroundColor Cyan
Write-Host ''

# Node.js (for Cloudflare's "wrangler" tool)
$npx = Get-Command npx.cmd -ErrorAction SilentlyContinue
if (-not $npx) {
    Write-Host 'Node.js is not installed. It is needed once, to send the server to Cloudflare.' -ForegroundColor Yellow
    Write-Host 'The download page opens now: install the "LTS" version, then run this again.'
    Start-Process 'https://nodejs.org/en/download'
    Done 1
}

# 1. sign in
Write-Host 'Step 1 of 3: Cloudflare account' -ForegroundColor Cyan
$who = & npx.cmd --yes wrangler@4 whoami 2>&1 | Out-String
if ($who -match 'not authenticated' -or $who -notmatch '@') {
    Write-Host 'A browser window opens: sign in (or make a free account), then click Allow.'
    & npx.cmd --yes wrangler@4 login
    if ($LASTEXITCODE -ne 0) { Write-Host 'Signing in did not finish. Run this again.' -ForegroundColor Red; Done 1 }
} else {
    Write-Host 'Already signed in.'
}

# 2. send the server (the first time Cloudflare may ask you to pick a workers.dev name - type one and press Enter)
Write-Host ''
Write-Host 'Step 2 of 3: sending the server to Cloudflare' -ForegroundColor Cyan
Write-Host '(If it asks for a workers.dev subdomain name, type any name you like, for example your Nexus name.)'
& npx.cmd --yes wrangler@4 deploy
if ($LASTEXITCODE -ne 0) { Write-Host 'Sending the server failed - see the messages above.' -ForegroundColor Red; Done 1 }

# its address (a second, quiet send prints it again)
$out = & npx.cmd --yes wrangler@4 deploy 2>&1 | Out-String
$m = [regex]::Match($out, 'https://[A-Za-z0-9.-]+\.workers\.dev')
if (-not $m.Success) {
    Write-Host 'The server is online, but its address was not found in the output:' -ForegroundColor Yellow
    Write-Host $out
    Write-Host 'Copy the https://....workers.dev address into dll\src\online\LobbyServer.h by hand.'
    Done 1
}
$url = $m.Value
Write-Host "Server address: $url" -ForegroundColor Green

# 3. into the mod
Write-Host ''
Write-Host 'Step 3 of 3: putting the address into the mod' -ForegroundColor Cyan
$header = Join-Path $PSScriptRoot '..\dll\src\online\LobbyServer.h'
if (-not (Test-Path -LiteralPath $header)) { Write-Host "Not found: $header" -ForegroundColor Red; Done 1 }
$text = [IO.File]::ReadAllText($header)
$new = [regex]::Replace($text, '#define DAOCOOP_LOBBY_SERVER ".*"', ('#define DAOCOOP_LOBBY_SERVER "' + $url + '"'))
[IO.File]::WriteAllText($header, $new)
Write-Host 'LobbyServer.h updated.'

# check it answers (a brand-new workers.dev name can take a few minutes to work everywhere)
$ok = $false
for ($i = 0; $i -lt 6 -and -not $ok; $i++) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 10 -Uri $url
        if ($r.Content -match 'DAOCoop lobby server') { $ok = $true }
    } catch { Start-Sleep -Seconds 5 }
}
Write-Host ''
if ($ok) { Write-Host 'The server answers. All set!' -ForegroundColor Green }
else { Write-Host 'The server does not answer yet - a new address can take a few minutes. The mod will reach it once it does.' -ForegroundColor Yellow }
Write-Host 'Now build the mod ("1 - BUILD AND INSTALL THE MOD"). Every build from now on uses this server.'
Done 0
