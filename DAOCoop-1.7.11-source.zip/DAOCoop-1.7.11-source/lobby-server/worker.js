// DAOCoop lobby server: the public game list and the "may I join?" requests.
//
// It never carries game traffic. Hosts list their game here (one WebSocket per host, kept open
// while hosting); players browse the list and ask to join; the host's game shows the request
// and answers; only then do the two games learn each other's address and connect directly
// (UDP hole punching, see the mod's OnlinePlay.cpp).
//
// Messages are URL-encoded text ("t=request&req=12&name=Wraith"), easy to read on both sides.
//
//   GET  /v1/list?v=<mod version>           -> JSON: the open, unlocked games of that version
//   WS   /v1/host?v=&name=&max=&open=        host connection
//        server -> host: t=hello&id=<listing id>
//                        t=request&req=&name=&cid=&addr=&lan=&seen=&country=
//        host -> server: t=update&name=&area=&players=&max=&open=&diff=&locked=0|1
//                        t=answer&req=&ok=1&token=&addr=&lan=      (or ok=0&why=)
//                        t=ping                                    (auto-answered t=pong)
//   WS   /v1/join?v=&host=&name=&cid=&addr=&lan=   one join request
//        server -> player: t=waiting | t=accepted&token=&addr=&lan= | t=declined&why=
//        (gone / full / locked / other version / too many requests: HTTP 409 or 429 with the reason)
//
// Privacy: a host's address goes only to a player the host accepted; a player's address only
// to the host they asked.

const MAX_NAME = 32, MAX_AREA = 48, MAX_WHY = 80;
const ANSWER_TIMEOUT_MS = 40_000;
const JOIN_PER_MINUTE = 6;          // per IP
const HOSTS_PER_IP = 3;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/v1/")) {
      return new Response("DAOCoop lobby server", { headers: { "content-type": "text/plain" } });
    }
    const id = env.LOBBY.idFromName("global");
    return env.LOBBY.get(id).fetch(request);
  },
};

function clean(s, max) {
  return String(s ?? "").replace(/[\u0000-\u001f\u007f|&=]/g, "").trim().slice(0, max);
}
function num(s, lo, hi, def) {
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : def;
}
function addr(s) {            // "1.2.3.4:5678" or ""
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3}):(\d{1,5})$/.exec(String(s ?? ""));
  if (!m) return "";
  const ok = m.slice(1, 5).every((x) => +x <= 255) && +m[5] > 0 && +m[5] < 65536;
  return ok ? m[0] : "";
}
function enc(obj) {
  return Object.entries(obj).map(([k, v]) => `${k}=${encodeURIComponent(String(v ?? ""))}`).join("&");
}
function dec(text) {
  const o = {};
  for (const part of String(text).split("&")) {
    const i = part.indexOf("=");
    if (i <= 0) continue;
    try { o[part.slice(0, i)] = decodeURIComponent(part.slice(i + 1)); } catch { /* bad escape: skip */ }
  }
  return o;
}
function randomId(len) {
  const abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const b = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(b, (x) => abc[x % abc.length]).join("");
}
function send(ws, obj) { try { ws.send(enc(obj)); } catch { /* closed */ } }

export class Lobby {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.joinTimes = new Map();      // ip -> [ms, ...] (last minute)
    // Ping/pong without waking the object up.
    this.ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair("t=ping", "t=pong"));
  }

  // Everything lives in the sockets' attachments, so it survives the object sleeping.
  hosts() {
    const out = new Map();
    for (const ws of this.ctx.getWebSockets("host")) {
      const a = ws.deserializeAttachment();
      if (a && a.id) out.set(a.id, { ws, a });
    }
    return out;
  }
  joins() {
    const out = new Map();
    for (const ws of this.ctx.getWebSockets("join")) {
      const a = ws.deserializeAttachment();
      if (a && a.req) out.set(a.req, { ws, a });
    }
    return out;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const q = Object.fromEntries(url.searchParams);
    const ip = request.headers.get("cf-connecting-ip") || "";
    const country = (request.cf && request.cf.country) || "";
    const ver = clean(q.v, 16);

    if (url.pathname === "/v1/list") {
      const now = Date.now();
      const list = [];
      for (const { a } of this.hosts().values()) {
        if (a.locked || a.ver !== ver || a.open <= 0) continue;
        list.push({ id: a.id, name: a.name, area: a.area, players: a.players, max: a.max, open: a.open,
                    diff: a.diff, country: a.country, minutes: Math.floor((now - a.since) / 60000) });
      }
      list.sort((x, y) => (x.country === country ? 0 : 1) - (y.country === country ? 0 : 1) || x.minutes - y.minutes);
      return new Response(JSON.stringify(list.slice(0, 50)), {
        headers: { "content-type": "application/json", "cache-control": "no-store" },
      });
    }

    if (request.headers.get("Upgrade") !== "websocket") return new Response("expected a WebSocket", { status: 426 });
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    if (url.pathname === "/v1/host") {
      let fromIp = 0;
      for (const { a } of this.hosts().values()) if (a.ip === ip) fromIp++;
      if (fromIp >= HOSTS_PER_IP) return new Response("too many games from this address", { status: 429 });
      const id = randomId(6);
      const a = { id, ip, country, ver, since: Date.now(),
                  name: clean(q.name, MAX_NAME) || "Host", area: "", diff: "",
                  players: 1, max: num(q.max, 2, 3, 3), open: num(q.open, 0, 2, 2), locked: false };
      this.ctx.acceptWebSocket(server, ["host"]);
      server.serializeAttachment(a);
      send(server, { t: "hello", id });
      return new Response(null, { status: 101, webSocket: client });
    }

    if (url.pathname === "/v1/join") {
      const now = Date.now();
      const times = (this.joinTimes.get(ip) || []).filter((t) => now - t < 60_000);
      if (times.length >= JOIN_PER_MINUTE) return new Response("too many requests, wait a minute", { status: 429 });
      times.push(now);
      this.joinTimes.set(ip, times);

      // Turned away before connecting: plain HTTP with the reason as text.
      const host = this.hosts().get(clean(q.host, 8));
      const no = (why) => new Response(why, { status: 409, headers: { "content-type": "text/plain" } });
      if (!host) return no("That game is gone.");
      if (host.a.ver !== ver) return no("That game runs a different DAOCoop version.");
      if (host.a.locked) return no("That game is locked.");
      if (host.a.open <= 0) return no("That game is full.");
      this.ctx.acceptWebSocket(server, ["join"]);

      const req = randomId(8);
      const name = clean(q.name, MAX_NAME) || "Someone";
      server.serializeAttachment({ req, host: host.a.id, ip, until: now + ANSWER_TIMEOUT_MS });
      send(host.ws, { t: "request", req, name, cid: clean(q.cid, 12), addr: addr(q.addr), lan: addr(q.lan), seen: ip, country });
      send(server, { t: "waiting" });
      await this.ctx.storage.setAlarm(now + ANSWER_TIMEOUT_MS + 500);
      return new Response(null, { status: 101, webSocket: client });
    }

    return new Response("not found", { status: 404 });
  }

  async webSocketMessage(ws, message) {
    const tags = this.ctx.getTags(ws);
    const m = dec(typeof message === "string" ? message : new TextDecoder().decode(message));
    if (!tags.includes("host")) return;                 // players only wait
    const a = ws.deserializeAttachment();
    if (!a) return;
    if (m.t === "update") {
      if (m.name !== undefined) a.name = clean(m.name, MAX_NAME) || a.name;
      if (m.area !== undefined) a.area = clean(m.area, MAX_AREA);
      if (m.diff !== undefined) a.diff = clean(m.diff, 16);
      if (m.players !== undefined) a.players = num(m.players, 1, 3, a.players);
      if (m.max !== undefined) a.max = num(m.max, 2, 3, a.max);
      if (m.open !== undefined) a.open = num(m.open, 0, 2, a.open);
      if (m.locked !== undefined) a.locked = m.locked === "1";
      ws.serializeAttachment(a);
      if (a.locked || a.open <= 0)                       // turn away anyone still waiting
        for (const j of this.joins().values())
          if (j.a.host === a.id) { send(j.ws, { t: "declined", why: a.locked ? "That game is locked." : "That game is full." }); j.ws.close(1000, "done"); }
      return;
    }
    if (m.t === "answer") {
      const j = this.joins().get(clean(m.req, 12));
      if (!j || j.a.host !== a.id) return;
      if (m.ok === "1") send(j.ws, { t: "accepted", token: clean(m.token, 12), addr: addr(m.addr), lan: addr(m.lan) });
      else send(j.ws, { t: "declined", why: clean(m.why, MAX_WHY) || "The host said no." });
      j.ws.close(1000, "done");
    }
  }

  async webSocketClose(ws, code, reason) {
    const tags = this.ctx.getTags(ws);
    if (tags.includes("host")) {
      const a = ws.deserializeAttachment();
      for (const j of this.joins().values())
        if (a && j.a.host === a.id) { send(j.ws, { t: "declined", why: "The host stopped." }); j.ws.close(1000, "done"); }
    } else if (tags.includes("join")) {
      // the player gave up: the host's prompt goes away
      const a = ws.deserializeAttachment();
      const h = a && this.hosts().get(a.host);
      if (h) send(h.ws, { t: "cancel", req: a.req });
    }
    try { ws.close(code, reason); } catch { /* already closed */ }
  }

  async webSocketError(ws) { await this.webSocketClose(ws, 1011, "error"); }

  // Requests nobody answered in time.
  async alarm() {
    const now = Date.now();
    let next = 0;
    for (const j of this.joins().values()) {
      if (j.a.until <= now) {
        send(j.ws, { t: "declined", why: "The host did not answer." });
        const h = this.hosts().get(j.a.host);
        if (h) send(h.ws, { t: "cancel", req: j.a.req });
        j.ws.close(1000, "done");
      } else if (!next || j.a.until < next) next = j.a.until;
    }
    if (next) await this.ctx.storage.setAlarm(next + 500);
  }
}
