# Packs the mod into one small zip anyone can install: the built DLL, clean settings, the installer /
# uninstaller and a README. Nothing personal: no saves, logs or source code.
# build.bat runs it after every successful build; MAKE-INSTALL-PACKAGE.cmd runs it by hand.
#   -Dll "<path to dinput8.dll>"   default: build\Release\dinput8.dll in the project
#   -OutDir "<folder>"             default: dist\ in the project
#   -Version "<text>"              default: the mod version in dll\src\dllmain.cpp (kVersion), else the build date
#   -GameVersion "<x.y.z.w>"       the DAOrigins.exe version the mod is made for
#   -Keep 3                        how many packages to keep (0 = keep all)
#   -Quiet                         fewer messages (used by the build script)
# Writes the unzipped package folder's path to the output, so the build script can install from it.
param(
    [string]$Dll = "",
    [string]$Helper = "",
    [string]$SetupStub = "",
    [string]$OutDir = "",
    [string]$Version = "",
    [string]$GameVersion = "1.05.13263.0",
    [int]$Keep = 3,
    [switch]$Quiet
)
$ErrorActionPreference = "Stop"
$project = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Say([string]$text, [string]$color = "Gray") { if (-not $Quiet) { Write-Host $text -ForegroundColor $color } }
function Md5([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm MD5).Hash.ToLower() }
# a .cmd file needs Windows line ends
function Write-Cmd([string]$path, [string[]]$lines) { [IO.File]::WriteAllText($path, (($lines -join "`r`n") + "`r`n"), [Text.Encoding]::ASCII) }

if (-not $Dll) { $Dll = Join-Path $project "build\Release\dinput8.dll" }
if (-not (Test-Path -LiteralPath $Dll)) { throw "There is no built DLL at $Dll. Run build.bat first." }
if (-not $OutDir) { $OutDir = Join-Path $project "dist" }
$installer = Join-Path $project "installer\Install-DAOCoop.ps1"
$readme = Join-Path $project "installer\Package-README.txt"
$ini = Join-Path $project "dll\DAOCoop.ini"
foreach ($need in @($installer, $readme, $ini)) { if (-not (Test-Path -LiteralPath $need)) { throw "$need is missing." } }

$di = Get-Item -LiteralPath $Dll
if (-not $Version) {
    $main = Join-Path $project "dll\src\dllmain.cpp"
    if (Test-Path -LiteralPath $main) {
        $m = Select-String -LiteralPath $main -Pattern 'kVersion\s*=\s*"([^"]+)"' | Select-Object -First 1
        if ($m) { $Version = $m.Matches[0].Groups[1].Value }
    }
}
if (-not $Version) { $Version = $di.LastWriteTime.ToString("yyyy.MM.dd.HHmm") }
$name = "DAOCoop-" + $Version
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$root = Join-Path $OutDir $name
if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $root "files\bin_ship") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $root "files\DAOCoop") | Out-Null

Copy-Item -LiteralPath $Dll -Destination (Join-Path $root "files\bin_ship\dinput8.dll") -Force
Copy-Item -LiteralPath $ini -Destination (Join-Path $root "files\DAOCoop\DAOCoop.ini") -Force
# 1.6.0: the 64-bit stream encoder (built by build.bat into build-helper\); without it online play encodes in the game
if (-not $Helper) { $Helper = Join-Path $project "build-helper\Release\DAOCoopStream.exe" }
if (Test-Path -LiteralPath $Helper) {
    Copy-Item -LiteralPath $Helper -Destination (Join-Path $root "files\DAOCoop\DAOCoopStream.exe") -Force
    Say "Included DAOCoopStream.exe (64-bit stream encoder)."
} else {
    # 1.7.8: never a package without it - each friend's own view (and the encoding off the game's thread) needs it
    throw "DAOCoopStream.exe (the 64-bit stream encoder) did not build - no package made. See the helper build errors above."
}
$assets = Join-Path $project "dll\assets"
if (Test-Path -LiteralPath $assets) {
    New-Item -ItemType Directory -Force -Path (Join-Path $root "files\override") | Out-Null
    Get-ChildItem -LiteralPath $assets -File | Where-Object { $_.Extension -in ".gfx", ".dds" } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $root ("files\override\" + $_.Name)) -Force }
}
Copy-Item -LiteralPath $installer -Destination (Join-Path $root "Install-DAOCoop.ps1") -Force
Copy-Item -LiteralPath $readme -Destination (Join-Path $root "README.txt") -Force
$licenses = Join-Path $project "installer\LICENSES.txt"
if (Test-Path -LiteralPath $licenses) { Copy-Item -LiteralPath $licenses -Destination (Join-Path $root "LICENSES.txt") -Force }
Write-Cmd (Join-Path $root "INSTALL.cmd") @(
    "@echo off", "cd /d `"%~dp0`"",
    "echo Installing the DAOCoop co-op mod for Dragon Age: Origins...",
    "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0Install-DAOCoop.ps1`" %*",
    "echo.", "pause")
Write-Cmd (Join-Path $root "UNINSTALL.cmd") @(
    "@echo off", "cd /d `"%~dp0`"",
    "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0Install-DAOCoop.ps1`" -Uninstall %*",
    "echo.", "pause")

$lines = @("Package=DAOCoop co-op mod for Dragon Age: Origins - install package",
           ("Version=" + $Version),
           ("Created=" + (Get-Date -Format "yyyy-MM-dd HH:mm")),
           ("DllBuilt=" + $di.LastWriteTime.ToString("yyyy-MM-dd HH:mm")),
           ("DllMd5=" + (Md5 $Dll)),
           ("GameVersion=" + $GameVersion))
Set-Content -LiteralPath (Join-Path $root "manifest.txt") -Value $lines -Encoding ASCII

# 1.7.8: what players download - no scripts in it (virus scanners took our own self-extracting setup, which ran
# PowerShell with "-ExecutionPolicy Bypass", for a dropper):
#   DAOCoop-<version>-Setup.exe   Inno Setup installer (a well-known installer), made with Inno Setup 6's ISCC.exe
#   DAOCoop-<version>.zip         the same files laid out like the game folder, for a manual install
# The unzipped package folder (with Install-DAOCoop.ps1) stays: build.bat installs into this PC's game from it.
$manual = Join-Path $OutDir ($name + "-manual")
if (Test-Path -LiteralPath $manual) { Remove-Item -LiteralPath $manual -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $manual "bin_ship"), (Join-Path $manual "DAOCoop"), (Join-Path $manual "packages\core\override\DAOCoop") | Out-Null
Copy-Item -LiteralPath (Join-Path $root "files\bin_ship\dinput8.dll") -Destination (Join-Path $manual "bin_ship") -Force
Copy-Item -Path (Join-Path $root "files\DAOCoop\*") -Destination (Join-Path $manual "DAOCoop") -Force
if (Test-Path -LiteralPath (Join-Path $root "files\override")) {
    Copy-Item -Path (Join-Path $root "files\override\*") -Destination (Join-Path $manual "packages\core\override\DAOCoop") -Force
}
Copy-Item -LiteralPath (Join-Path $root "README.txt") -Destination $manual -Force
if (Test-Path -LiteralPath (Join-Path $root "LICENSES.txt")) { Copy-Item -LiteralPath (Join-Path $root "LICENSES.txt") -Destination $manual -Force }
$zip = Join-Path $OutDir ($name + ".zip")
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
# entries written one by one with "/" in their names (every unzip tool reads those; .NET Framework's
# CreateFromDirectory writes "\", which some tools show as one long file name)
Add-Type -AssemblyName System.IO.Compression
$zs = [System.IO.Compression.ZipFile]::Open($zip, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $base = (Get-Item -LiteralPath $manual).FullName.TrimEnd('\') + '\'
    foreach ($f in @(Get-ChildItem -LiteralPath $manual -Recurse -File)) {
        $entry = $f.FullName.Substring($base.Length).Replace('\', '/')
        [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zs, $f.FullName, $entry, [System.IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $zs.Dispose() }
foreach ($need in @("bin_ship/dinput8.dll", "DAOCoop/DAOCoop.ini", "DAOCoop/DAOCoopStream.exe")) {
    $zr = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try { if (-not ($zr.Entries | Where-Object { $_.FullName -eq $need })) { throw "The manual install zip is missing $need." } } finally { $zr.Dispose() }
}
Remove-Item -LiteralPath $manual -Recurse -Force
$kb = [Math]::Round((Get-Item -LiteralPath $zip).Length / 1KB)
Write-Host "Manual install zip: $zip ($kb KB)" -ForegroundColor Green

# the installer: Inno Setup 6 (free - https://jrsoftware.org/isdl.php, or: winget install JRSoftware.InnoSetup)
$iscc = @((Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"), (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"),
          (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe")) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $iscc) {
    throw "Inno Setup 6 is not installed, so the installer (Setup.exe) can't be made. Install it once (free): https://jrsoftware.org/isdl.php - or in a command prompt: winget install JRSoftware.InnoSetup - then build again."
}
$iss = Join-Path $project "installer\DAOCoop.iss"
$innoLog = Join-Path $OutDir "inno-build.log"
& $iscc /Q "/DMyVersion=$Version" "/DPkg=$root" "/DOutDir=$OutDir" $iss 2>&1 | Tee-Object -FilePath $innoLog | Out-Host
if ($LASTEXITCODE -ne 0) { throw "Inno Setup could not make the installer (see above, or dist\inno-build.log)." }
$setup = Join-Path $OutDir ($name + "-Setup.exe")
if ($Keep -gt 0) {
    foreach ($pat in @("DAOCoop-*.zip", "DAOCoop-*-Setup.exe")) {
        Get-ChildItem -LiteralPath $OutDir -Filter $pat -File | Sort-Object LastWriteTime -Descending | Select-Object -Skip $Keep | Remove-Item -Force -ErrorAction SilentlyContinue
    }
    Get-ChildItem -LiteralPath $OutDir -Directory -Filter "DAOCoop-*" | Where-Object { $_.Name -notlike "Nexus-*" } |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip $Keep | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host ("Installer: $setup (" + [Math]::Round((Get-Item -LiteralPath $setup).Length / 1KB) + " KB)") -ForegroundColor Green
Say "Share the Setup.exe (and the zip for a manual install). README.txt explains the rest."
# 1.7.11: the GitHub release package (dist\GitHub-<version>\: the files to attach, checksums, release notes)
try { & (Join-Path $PSScriptRoot "Make-GitHub-Release.ps1") -Version $Version -OutDir $OutDir | Out-Host }
catch { Write-Host ("The GitHub release package could not be made: " + $_.Exception.Message) -ForegroundColor Yellow }
Write-Output $root
