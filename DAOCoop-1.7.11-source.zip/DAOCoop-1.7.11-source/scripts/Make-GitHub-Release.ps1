# 1.7.11: makes the GitHub release package - dist\GitHub-<version>\ with the files to attach to a release on
# github.com (the manual install zip and the installer), their SHA-256 checksums, the release notes to paste
# (from the changelog in docs\NEXUS-PAGE.txt) and the steps to publish it.
# Make-Install-Package.ps1 runs it after making the zip and the installer; it can also be run by hand:
#   powershell -ExecutionPolicy Bypass -File scripts\Make-GitHub-Release.ps1 [-Version 1.7.11] [-Repo user/DAOCoop]
param(
    [string]$Version = "",
    [string]$OutDir = "",
    [string]$Repo = ""          # owner/name on GitHub (optional - only used for links in the notes)
)
$ErrorActionPreference = "Stop"
$project = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (-not $OutDir) { $OutDir = Join-Path $project "dist" }
if (-not $Version) {
    $m = Select-String -LiteralPath (Join-Path $project "dll\src\dllmain.cpp") -Pattern 'kVersion\s*=\s*"([^"]+)"' | Select-Object -First 1
    if (-not $m) { throw "No version given and none found in dll\src\dllmain.cpp." }
    $Version = $m.Matches[0].Groups[1].Value
}
$name = "DAOCoop-" + $Version
$zip = Join-Path $OutDir ($name + ".zip")
$setup = Join-Path $OutDir ($name + "-Setup.exe")
foreach ($f in @($zip, $setup)) { if (-not (Test-Path -LiteralPath $f)) { throw "$f is missing - build first (build.bat)." } }

$rel = Join-Path $OutDir ("GitHub-" + $Version)
if (Test-Path -LiteralPath $rel) { Remove-Item -LiteralPath $rel -Recurse -Force }
New-Item -ItemType Directory -Force -Path $rel | Out-Null
Copy-Item -LiteralPath $zip -Destination $rel -Force
Copy-Item -LiteralPath $setup -Destination $rel -Force

# checksums (players can check a download: certutil -hashfile <file> SHA256)
$sums = @()
foreach ($f in @($zip, $setup)) {
    $h = (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower()
    $sums += ("{0}  {1}" -f $h, (Split-Path -Leaf $f))
}
$utf8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText((Join-Path $rel "SHA256SUMS.txt"), (($sums -join "`n") + "`n"), $utf8)

# what's new: the "- " lines of the CHANGELOG section of docs\NEXUS-PAGE.txt
$changes = @()
$page = Join-Path $project "docs\NEXUS-PAGE.txt"
if (Test-Path -LiteralPath $page) {
    $in = $false
    foreach ($line in [IO.File]::ReadAllLines($page, $utf8)) {
        if ($line -like "--- CHANGELOG*") { $in = $true; continue }
        if ($in) {
            if ($line -like "---*") { break }
            if ($line -match '^\s*-\s+(.+)$') { $changes += ("- " + $Matches[1]) }
        }
    }
}
if ($changes.Count -eq 0) { $changes = @("- See the changelog on the mod page.") }

$src = if ($Repo) { "https://github.com/$Repo" } else { "this repository" }
$zipLeaf = Split-Path -Leaf $zip
$setupLeaf = Split-Path -Leaf $setup
$notes = @(
    "# DAOCoop $Version",
    "",
    "Local split-screen and online co-op for up to 3 players in **Dragon Age: Origins** (patch 1.05, GOG / Steam / EA).",
    "",
    "## What's new",
    ""
) + $changes + @(
    "",
    "## Download",
    "",
    "| File | What it is |",
    "|---|---|",
    "| ``$zipLeaf`` | **Recommended.** The mod's files laid out like the game folder - no installer, no scripts. |",
    "| ``$setupLeaf`` | The same files with an installer: finds the game, keeps the Native Controller Framework working, and adds an uninstaller (Windows Settings > Apps). |",
    "",
    "## Install (zip)",
    "",
    "1. Close the game.",
    "2. Copy the three folders in the zip (``bin_ship``, ``DAOCoop``, ``packages``) into your Dragon Age: Origins folder (the one that has ``bin_ship`` in it), merging them.",
    "3. Using the [Native Controller Framework](https://www.nexusmods.com/dragonage/mods/7051)? First rename its ``bin_ship\dinput8.dll`` to ``dinput8_chain.dll`` so both mods load.",
    "4. Start the game - a **Co-op** button appears under New Game.",
    "",
    "Updating: copy the new files over the old ones (keep your old ``DAOCoop\DAOCoop.ini`` if you changed settings).",
    "",
    "Windows SmartScreen may warn about the installer because it isn't signed - choose *More info > Run anyway*.",
    "",
    "## Checksums (SHA-256)",
    "",
    "``````"
) + $sums + @(
    "``````",
    "",
    "Check a download in a command prompt: ``certutil -hashfile <file> SHA256``",
    "",
    "## Source",
    "",
    "Built from the source in $src - see BUILDING.md (Visual Studio 2022 + Inno Setup 6, then ``build.bat -NoInstall``). No game files are included."
)
[IO.File]::WriteAllText((Join-Path $rel "RELEASE-NOTES.md"), (($notes -join "`n") + "`n"), $utf8)

$steps = @(
    "Publishing DAOCoop $Version on GitHub",
    "",
    "1. Upload the source first (the repository's files should match this version): on the repository page,",
    "   Add file > Upload files, drop in the contents of the source folder, Commit changes.",
    "2. On the repository page, click Releases (right side) > Draft a new release.",
    "3. Choose a tag: type  v$Version  and pick 'Create new tag: v$Version on publish'.",
    "4. Release title:  DAOCoop $Version",
    "5. Description: paste everything from RELEASE-NOTES.md (in this folder).",
    "6. Attach binaries (the box under the description): drag in",
    "       $zipLeaf",
    "       $setupLeaf",
    "7. Leave 'Set as the latest release' ticked and click Publish release.",
    "",
    "The release page then has its own link to share, e.g. https://github.com/<you>/DAOCoop/releases/tag/v$Version",
    "and https://github.com/<you>/DAOCoop/releases/latest always points to the newest one."
)
[IO.File]::WriteAllText((Join-Path $rel "HOW-TO-PUBLISH.txt"), (($steps -join "`r`n") + "`r`n"), $utf8)
Write-Host "GitHub release package: $rel" -ForegroundColor Green
